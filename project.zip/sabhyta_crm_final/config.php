<?php
/**
 * SABHYTA CRM application settings.
 * Database settings are read from SABHYTA_DB_* environment variables in api/db.php.
 */

// Application Settings
define('APP_NAME', 'SABHYTA CRM Professional');
define('APP_VERSION', '2.0');
define('APP_DEBUG', false);
define('APP_TIMEZONE', 'Asia/Kolkata');

// Session Settings
define('SESSION_TIMEOUT', 3600); // 1 hour
define('SESSION_REMEMBER', 2592000); // 30 days

// Security
define('ENABLE_2FA', false);
define('PASSWORD_MIN_LENGTH', 6);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCK_TIME', 900); // 15 minutes

// Features
define('ENABLE_AUTO_FETCH', true); // Quotation Auto-Fetch
define('ENABLE_SALARY_PROCESSING', true);
define('ENABLE_REPORTS', true);
define('ENABLE_ANALYTICS', true);

// File Upload
define('MAX_UPLOAD_SIZE', 5242880); // 5MB
define('ALLOWED_UPLOAD_TYPES', ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'png', 'gif']);
define('UPLOAD_PATH', __DIR__ . '/uploads/');

// Email Settings (Optional)
define('MAIL_DRIVER', 'smtp');
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_FROM', 'noreply@sabhyta.com');
define('MAIL_USERNAME', '');
define('MAIL_PASSWORD', '');

// API Settings
define('API_TIMEOUT', 30);
define('API_RATE_LIMIT', 100); // requests per minute

// Timezone
date_default_timezone_set(APP_TIMEZONE);

// Enable error reporting in development
if (APP_DEBUG) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(0);
}

