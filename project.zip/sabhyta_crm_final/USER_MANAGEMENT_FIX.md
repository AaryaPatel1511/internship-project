# User Management Fix Notes

## Problems fixed
1. **Infinite "Loading roles..."** – User Management APIs (`user_roles.php`, `users.php`, `user_masters.php`, `user_permissions.php`) used mysqli `$conn`, but `api/db.php` only provided PDO `$pdo`. Connection was undefined → API crashed → UI stayed on "Loading...".
2. **Column name mismatch** – User Management SQL used `dept_name` / `desig_name` while HRMS schema uses `department_name` / `designation_name`. Queries failed when tables came from HRMS.
3. **SQL schema conflicts** – `schema_user_management.sql` tried to recreate departments/designations with different columns. Fixed to only create roles/permissions tables and use HRMS masters.
4. **No error feedback** – Frontend never cleared "Loading..." on API failure. Now shows clear error messages.

## What was changed
- `api/db.php` – provides both `$pdo` (PDO) and `$conn` (mysqli)
- `api/users.php`, `user_roles.php`, `user_masters.php`, `user_permissions.php`, `user_management_dashboard.php` – rewritten to PDO + dual column support
- `database/schema_user_management.sql` – compatible schema (no conflicting dept/desig tables)
- `database/seed_user_management.sql` – seeds into HRMS-style columns
- `modules/user_management.js` – proper loading / error UI for Roles, Permissions, Departments, Designations, Users
- Auto-seed: if roles/modules tables are empty, APIs create default Super Admin / Admin / Manager / Supervisor / Executive roles and basic permissions

## Setup order (phpMyAdmin or mysql CLI)
1. `database/schema.sql`
2. `database/schema_hrms_sales.sql`
3. `database/schema_user_management.sql`
4. `database/seed_user_management.sql` (optional – APIs also auto-seed roles)
5. Run `database/seed_demo_data.php` via browser or CLI for sample employees/departments

## Login
Ensure you are logged in (session required). Without a valid session all User Management APIs return 401 and the UI will show an error instead of spinning forever.

## Employees in HRMS
Employees come from the HRMS `employees` table (seeded by `seed_demo_data.php`). User Management "Users" page lists those employees and lets you assign roles from the Roles tab.
