-- =========================================================
-- SABHYTACRM Database Schema
-- Import this file in phpMyAdmin (or via mysql CLI) BEFORE
-- running the app. It creates the database and the
-- `customers` table used by the Customer Management module.
-- =========================================================

CREATE DATABASE IF NOT EXISTS sabhytacrm
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE sabhytacrm;

-- ---------------------------------------------------------
-- customers table
-- Mirrors every field in the "Customer Information",
-- "Company Details" and "Registered Address" cards in the
-- Customer form on the frontend.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS customers (
  id                    INT AUTO_INCREMENT PRIMARY KEY,

  -- Customer Information
  customer_code         VARCHAR(50)  NOT NULL,
  customer_type         VARCHAR(30)  NOT NULL,
  customer_category     VARCHAR(30),
  customer_name         VARCHAR(150) NOT NULL,
  company_name          VARCHAR(150),
  display_name          VARCHAR(150),
  gst_number             VARCHAR(30),
  pan_number             VARCHAR(20),
  tan_number             VARCHAR(20),
  cin_number             VARCHAR(30),
  msme_number            VARCHAR(30),
  industry               VARCHAR(50),
  business_nature        VARCHAR(50),
  turnover                DECIMAL(15,2),
  employees               INT,
  website                 VARCHAR(150),
  email                    VARCHAR(150) NOT NULL,
  mobile                   VARCHAR(20)  NOT NULL,
  alt_mobile               VARCHAR(20),
  landline                 VARCHAR(20),
  fax                      VARCHAR(20),
  status                   VARCHAR(20)  DEFAULT 'Active',
  lead_source              VARCHAR(30),
  customer_since           DATE,
  rating                   TINYINT,
  sales_executive          VARCHAR(100),
  branch                   VARCHAR(100),
  remarks                  TEXT,

  -- Company Details
  legal_company_name       VARCHAR(150),
  trade_name                VARCHAR(150),
  registration_number       VARCHAR(50),
  gst_registration_date     DATE,
  pan_card_file              VARCHAR(255),
  gst_certificate_file       VARCHAR(255),
  incorporation_certificate_file VARCHAR(255),
  business_license_file      VARCHAR(255),
  iso_certificate_file       VARCHAR(255),
  udyam_certificate_file     VARCHAR(255),
  company_logo_file          VARCHAR(255),
  company_profile_file       VARCHAR(255),

  -- Registered Address
  address_line1              VARCHAR(200),
  address_line2               VARCHAR(200),
  area                         VARCHAR(100),
  city                          VARCHAR(100),
  district                      VARCHAR(100),
  state                         VARCHAR(100),
  country                       VARCHAR(100) DEFAULT 'India',
  pincode                       VARCHAR(10),

  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_customer_code (customer_code)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- users table (login / logout)
-- Passwords are bcrypt hashes created by PHP's password_hash().
-- Do NOT insert plain-text passwords here. The very first time
-- anyone opens login.html with an empty users table, the app
-- shows a one-time "Create Admin Account" screen instead of a
-- sign-in form (see api/auth.php action=register_first_admin) —
-- no separate seed script needs to be run.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          VARCHAR(50)  DEFAULT 'Admin',
  avatar_path   VARCHAR(255) NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- generic_records table
-- Powers every OTHER sidebar item (Leads, Quotation, Sales,
-- Project Management, HRMS, Accounts, Inventory, Helpdesk,
-- etc.) with one shared, real, database-backed table instead
-- of a bespoke table per menu item. `module_key` identifies
-- which sidebar leaf a row belongs to (e.g. "crm__add-lead").
-- Deepen any one of these into its own dedicated table later
-- using the same pattern as `customers`.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS generic_records (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  module_key    VARCHAR(150) NOT NULL,
  module_label  VARCHAR(150) NOT NULL,
  title         VARCHAR(200) NOT NULL,
  party_name    VARCHAR(150),
  assigned_to   VARCHAR(150),
  record_date   DATE,
  amount        DECIMAL(15,2),
  status        VARCHAR(30) DEFAULT 'Active',
  notes         TEXT,
  -- Holds the full JSON payload for modules that need more structure
  -- than the flat columns above (e.g. Create Quote: line items,
  -- financial summary, commercial terms, linked customer id, etc.)
  extra_data    LONGTEXT,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  INDEX idx_module_key (module_key)
) ENGINE=InnoDB;
