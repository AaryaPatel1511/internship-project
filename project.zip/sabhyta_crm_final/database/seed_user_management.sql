-- ============================================================
-- USER MANAGEMENT SEED DATA (Compatible with HRMS schema)
-- Departments / Designations use HRMS column names when present
-- ============================================================

USE sabhytacrm;

-- Seed departments into HRMS-style columns if table uses department_name
-- Safe: INSERT IGNORE / only when empty patterns

-- Try HRMS columns first (department_code, department_name)
INSERT IGNORE INTO departments (id, department_code, department_name, description, status)
SELECT * FROM (
  SELECT 1 AS id, 'SALES' AS department_code, 'Sales & Business Development' AS department_name, 'Sales and business development department' AS description, 'Active' AS status
  UNION ALL SELECT 2, 'DEV', 'Software Development', 'Software development and technical team', 'Active'
  UNION ALL SELECT 3, 'HR', 'Human Resources', 'Human resources and recruitment', 'Active'
  UNION ALL SELECT 4, 'ACC', 'Accounts & Finance', 'Accounting and financial management', 'Active'
  UNION ALL SELECT 5, 'MKT', 'Marketing', 'Marketing and campaigns', 'Active'
  UNION ALL SELECT 6, 'PM', 'Project Management', 'Project management office', 'Active'
  UNION ALL SELECT 7, 'SUP', 'Support & Helpdesk', 'Customer support and helpdesk', 'Active'
  UNION ALL SELECT 8, 'ADM', 'Administration', 'Administrative operations', 'Active'
) AS tmp
WHERE EXISTS (
  SELECT 1 FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'departments' AND COLUMN_NAME = 'department_name'
);

-- Designations (HRMS style: designation_name)
INSERT IGNORE INTO designations (id, designation_name, department_id, job_description, status)
SELECT * FROM (
  SELECT 1 AS id, 'Sales Manager' AS designation_name, 1 AS department_id, 'Manages sales team and revenue' AS job_description, 'Active' AS status
  UNION ALL SELECT 2, 'Sales Supervisor', 1, 'Supervises sales team', 'Active'
  UNION ALL SELECT 3, 'Sales Executive', 1, 'Handles leads and conversions', 'Active'
  UNION ALL SELECT 4, 'Development Manager', 2, 'Manages development team', 'Active'
  UNION ALL SELECT 5, 'Tech Lead', 2, 'Technical lead for projects', 'Active'
  UNION ALL SELECT 6, 'Software Developer', 2, 'Develops software solutions', 'Active'
  UNION ALL SELECT 7, 'HR Manager', 3, 'Manages human resources', 'Active'
  UNION ALL SELECT 8, 'HR Supervisor', 3, 'Supervises HR operations', 'Active'
  UNION ALL SELECT 9, 'HR Executive', 3, 'Handles recruitment and payroll', 'Active'
  UNION ALL SELECT 10, 'Finance Manager', 4, 'Manages financial operations', 'Active'
  UNION ALL SELECT 11, 'Accounts Supervisor', 4, 'Supervises accounting', 'Active'
  UNION ALL SELECT 12, 'Accounts Executive', 4, 'Handles accounting records', 'Active'
  UNION ALL SELECT 13, 'Marketing Manager', 5, 'Manages marketing campaigns', 'Active'
  UNION ALL SELECT 14, 'Marketing Supervisor', 5, 'Supervises marketing team', 'Active'
  UNION ALL SELECT 15, 'Marketing Executive', 5, 'Executes marketing activities', 'Active'
  UNION ALL SELECT 16, 'Project Manager', 6, 'Manages projects', 'Active'
  UNION ALL SELECT 17, 'Project Coordinator', 6, 'Coordinates project activities', 'Active'
  UNION ALL SELECT 18, 'Support Manager', 7, 'Manages support team', 'Active'
  UNION ALL SELECT 19, 'Support Executive', 7, 'Provides customer support', 'Active'
  UNION ALL SELECT 20, 'Administrative Officer', 8, 'Handles administrative tasks', 'Active'
) AS tmp
WHERE EXISTS (
  SELECT 1 FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'designations' AND COLUMN_NAME = 'designation_name'
);

-- Roles
INSERT IGNORE INTO roles (id, role_name, role_level, description, status) VALUES
(1, 'Super Admin', 1, 'Complete system authority - Full access to all modules and settings', 'Active'),
(2, 'Admin', 2, 'Company administration - Manage users, departments, and operational data', 'Active'),
(3, 'Manager', 3, 'Department control - Full access to department data and team management', 'Active'),
(4, 'Supervisor', 4, 'Team control - Manage team members and their work', 'Active'),
(5, 'Executive', 5, 'User level - Access only assigned data and own records', 'Active');

-- Modules
INSERT IGNORE INTO modules (id, module_name, module_icon, description, status) VALUES
(1, 'CRM', 'fa-users', 'Customer Relationship Management', 'Active'),
(2, 'HRMS', 'fa-user-tie', 'Human Resource Management', 'Active'),
(3, 'Accounts', 'fa-wallet', 'Financial and Accounting Management', 'Active'),
(4, 'Projects', 'fa-project-diagram', 'Project Management', 'Active'),
(5, 'Inventory', 'fa-box-open', 'Stock and Inventory Management', 'Active'),
(6, 'Helpdesk', 'fa-headset', 'Support and Ticket Management', 'Active'),
(7, 'Reports', 'fa-chart-pie', 'Reporting and Analytics', 'Active'),
(8, 'Administration', 'fa-user-shield', 'System Administration', 'Active');

-- Permissions
INSERT IGNORE INTO permissions (id, module_id, permission_name, action_type, description, status) VALUES
(1, 1, 'View Leads', 'view', 'View lead records', 'Active'),
(2, 1, 'Add Lead', 'add', 'Create new leads', 'Active'),
(3, 1, 'Edit Lead', 'edit', 'Modify lead information', 'Active'),
(4, 1, 'Delete Lead', 'delete', 'Delete lead records', 'Active'),
(5, 1, 'Assign Lead', 'assign', 'Assign leads to users', 'Active'),
(6, 1, 'Export Leads', 'export', 'Export lead data', 'Active'),
(7, 1, 'View Customers', 'view', 'View customer records', 'Active'),
(8, 1, 'Add Customer', 'add', 'Create new customers', 'Active'),
(9, 1, 'Edit Customer', 'edit', 'Modify customer data', 'Active'),
(10, 1, 'Approve Quotation', 'approve', 'Approve quotations', 'Active'),
(11, 2, 'View Employees', 'view', 'View employee records', 'Active'),
(12, 2, 'Add Employee', 'add', 'Create new employee records', 'Active'),
(13, 2, 'Edit Employee', 'edit', 'Modify employee information', 'Active'),
(14, 2, 'Delete Employee', 'delete', 'Delete employee records', 'Active'),
(15, 2, 'View Attendance', 'view', 'View attendance records', 'Active'),
(16, 2, 'Manage Leave', 'edit', 'Approve/manage leave requests', 'Active'),
(17, 2, 'View Payroll', 'view', 'View payroll information', 'Active'),
(18, 2, 'Process Payroll', 'edit', 'Process salary and payroll', 'Active'),
(19, 3, 'View Accounts', 'view', 'View account records', 'Active'),
(20, 3, 'Add Invoice', 'add', 'Create invoices', 'Active'),
(21, 3, 'Approve Payment', 'approve', 'Approve payments', 'Active'),
(22, 3, 'View Reports', 'view', 'View financial reports', 'Active'),
(23, 4, 'View Projects', 'view', 'View projects', 'Active'),
(24, 4, 'Create Project', 'add', 'Create new projects', 'Active'),
(25, 4, 'Manage Tasks', 'edit', 'Assign and manage tasks', 'Active'),
(26, 4, 'Approve Project', 'approve', 'Approve project deliverables', 'Active'),
(27, 8, 'Manage Users', 'edit', 'Create and manage users', 'Active'),
(28, 8, 'Manage Roles', 'edit', 'Create and modify roles', 'Active'),
(29, 8, 'Manage Permissions', 'edit', 'Assign permissions to roles', 'Active'),
(30, 8, 'View Audit Logs', 'view', 'View system audit logs', 'Active');

-- Role permissions - Super Admin all
INSERT IGNORE INTO role_permissions (role_id, permission_id, data_scope, status)
SELECT 1, id, 'all', 'Active' FROM permissions
WHERE NOT EXISTS (SELECT 1 FROM role_permissions WHERE role_id = 1 AND permission_id = permissions.id);

-- Assign Super Admin role to first active employee (if any)
INSERT IGNORE INTO user_roles (employee_id, role_id, assigned_by, status)
SELECT e.id, 1, e.id, 'Active'
FROM employees e
WHERE e.employment_status = 'Active'
ORDER BY e.id
LIMIT 1;
