-- =========================================================
-- SABHYTA CRM - ERP MODULES SCHEMA
-- Marketing / Project Management / Asset Management /
-- Document Management / Administration
--
-- Safe to run more than once (CREATE TABLE IF NOT EXISTS).
-- The application also creates these tables automatically the
-- first time any of these modules is opened, so importing this
-- file by hand is optional.
--
-- NAMING: the specification uses short generic table names such
-- as modules, permissions, roles, users, audit_logs, maintenance
-- and files. Several of those already exist in this project for
-- other features (User Management uses modules / permissions /
-- roles, login uses users). To avoid clashing, every new table
-- carries a short module prefix:
--     mk_   Marketing            pm_   Project Management
--     am_   Asset Management     dms_  Document Management
--     adm_  Administration
--
-- Cross-module references (customers, employees, users,
-- departments, roles) use real foreign keys with ON DELETE
-- SET NULL so that deleting an employee or customer never
-- destroys project / asset / document history.
-- =========================================================

CREATE DATABASE IF NOT EXISTS sabhytacrm CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sabhytacrm;

-- ---------------------------------------------------------
-- MARKETING
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS mk_audience_lists (
  list_id        INT AUTO_INCREMENT PRIMARY KEY,
  list_name      VARCHAR(150) NOT NULL,
  channel        ENUM('Email','SMS','WhatsApp','Social') NOT NULL DEFAULT 'Email',
  source         ENUM('Customers','Leads','CSV Upload','Manual') NOT NULL DEFAULT 'Manual',
  description    TEXT NULL,
  status         ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  created_by     INT NULL,
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_mk_list_channel (channel)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mk_audience_contacts (
  contact_id        INT AUTO_INCREMENT PRIMARY KEY,
  list_id           INT NOT NULL,
  full_name         VARCHAR(150) NULL,
  email             VARCHAR(190) NULL,
  phone             VARCHAR(30) NULL,
  city              VARCHAR(100) NULL,
  state             VARCHAR(100) NULL,
  country           VARCHAR(100) NULL,
  opt_in            TINYINT(1) NOT NULL DEFAULT 1,
  opt_in_at         DATETIME NULL,
  whatsapp_verified TINYINT(1) NOT NULL DEFAULT 0,
  status            ENUM('Active','Unsubscribed','Bounced') NOT NULL DEFAULT 'Active',
  source_ref        VARCHAR(50) NULL,
  created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_mk_contact_list (list_id),
  INDEX idx_mk_contact_email (email),
  INDEX idx_mk_contact_phone (phone),
  CONSTRAINT fk_mk_contact_list FOREIGN KEY (list_id) REFERENCES mk_audience_lists(list_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mk_suppression (
  suppression_id INT AUTO_INCREMENT PRIMARY KEY,
  channel        ENUM('Email','SMS','WhatsApp') NOT NULL,
  contact_value  VARCHAR(190) NOT NULL,
  reason         ENUM('Unsubscribed','Hard Bounce','Opt-out','Complaint','Manual') NOT NULL DEFAULT 'Unsubscribed',
  notes          VARCHAR(255) NULL,
  added_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_mk_suppress (channel, contact_value)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mk_email_campaigns (
  campaign_id        INT AUTO_INCREMENT PRIMARY KEY,
  campaign_name      VARCHAR(190) NOT NULL,
  objective          ENUM('Product Launch','Seasonal Sale','Newsletter','Retention','Event','Other') NOT NULL DEFAULT 'Newsletter',
  list_id            INT NULL,
  sender_name        VARCHAR(120) NULL,
  sender_email       VARCHAR(190) NULL,
  sender_domain_auth TINYINT(1) NOT NULL DEFAULT 0,
  subject_line       VARCHAR(255) NULL,
  preheader_text     VARCHAR(255) NULL,
  html_template      MEDIUMTEXT NULL,
  plain_text_body    TEXT NULL,
  banner_image       VARCHAR(255) NULL,
  localized_copy     TEXT NULL,
  language           VARCHAR(40) NULL,
  landing_url        VARCHAR(500) NULL,
  utm_source         VARCHAR(80) NULL,
  utm_medium         VARCHAR(80) NULL,
  utm_campaign       VARCHAR(120) NULL,
  utm_content        VARCHAR(120) NULL,
  tracking_url       VARCHAR(500) NULL,
  spam_score         DECIMAL(3,1) NULL,
  scheduled_at       DATETIME NULL,
  status             ENUM('Draft','Scheduled','Running','Completed','Paused','Cancelled') NOT NULL DEFAULT 'Draft',
  total_recipients   INT NOT NULL DEFAULT 0,
  suppressed_count   INT NOT NULL DEFAULT 0,
  launched_at        DATETIME NULL,
  created_by         INT NULL,
  created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_mk_email_status (status),
  CONSTRAINT fk_mk_email_list FOREIGN KEY (list_id) REFERENCES mk_audience_lists(list_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mk_sms_campaigns (
  campaign_id      INT AUTO_INCREMENT PRIMARY KEY,
  campaign_name    VARCHAR(190) NOT NULL,
  objective        ENUM('Product Launch','Seasonal Sale','Reminder','Retention','Event','Other') NOT NULL DEFAULT 'Reminder',
  list_id          INT NULL,
  sender_id        VARCHAR(20) NULL,
  message_text     TEXT NULL,
  segments         INT NOT NULL DEFAULT 1,
  dlt_entity_id    VARCHAR(60) NULL,
  dlt_template_id  VARCHAR(60) NULL,
  opt_out_text     VARCHAR(120) NULL,
  short_url        VARCHAR(255) NULL,
  scheduled_at     DATETIME NULL,
  status           ENUM('Draft','Scheduled','Running','Completed','Paused','Cancelled') NOT NULL DEFAULT 'Draft',
  total_recipients INT NOT NULL DEFAULT 0,
  suppressed_count INT NOT NULL DEFAULT 0,
  launched_at      DATETIME NULL,
  created_by       INT NULL,
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_mk_sms_status (status),
  CONSTRAINT fk_mk_sms_list FOREIGN KEY (list_id) REFERENCES mk_audience_lists(list_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mk_whatsapp_campaigns (
  campaign_id       INT AUTO_INCREMENT PRIMARY KEY,
  campaign_name     VARCHAR(190) NOT NULL,
  objective         ENUM('Product Launch','Seasonal Sale','Reminder','Retention','Event','Other') NOT NULL DEFAULT 'Product Launch',
  list_id           INT NULL,
  template_name     VARCHAR(150) NULL,
  template_category ENUM('Marketing','Utility','Authentication') NOT NULL DEFAULT 'Marketing',
  template_status   ENUM('Draft','Submitted','Approved','Rejected') NOT NULL DEFAULT 'Draft',
  template_body     TEXT NULL,
  media_type        ENUM('None','Image','Video','PDF') NOT NULL DEFAULT 'None',
  media_file        VARCHAR(255) NULL,
  button_type       ENUM('None','Quick Reply','Call To Action') NOT NULL DEFAULT 'None',
  button_config     TEXT NULL,
  scheduled_at      DATETIME NULL,
  status            ENUM('Draft','Scheduled','Running','Completed','Paused','Cancelled') NOT NULL DEFAULT 'Draft',
  total_recipients  INT NOT NULL DEFAULT 0,
  suppressed_count  INT NOT NULL DEFAULT 0,
  launched_at       DATETIME NULL,
  created_by        INT NULL,
  created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_mk_wa_status (status),
  CONSTRAINT fk_mk_wa_list FOREIGN KEY (list_id) REFERENCES mk_audience_lists(list_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mk_wa_flows (
  flow_id          INT AUTO_INCREMENT PRIMARY KEY,
  flow_name        VARCHAR(150) NOT NULL,
  trigger_keyword  VARCHAR(100) NULL,
  reply_message    TEXT NULL,
  fallback_message TEXT NULL,
  is_fallback      TINYINT(1) NOT NULL DEFAULT 0,
  status           ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mk_social_audiences (
  audience_id        INT AUTO_INCREMENT PRIMARY KEY,
  persona_name       VARCHAR(150) NOT NULL,
  platform           ENUM('Facebook','Instagram','LinkedIn','X (Twitter)','YouTube','Google Ads','Other') NOT NULL DEFAULT 'Facebook',
  age_range          VARCHAR(30) NULL,
  gender             ENUM('All','Male','Female','Other') NOT NULL DEFAULT 'All',
  locations          VARCHAR(255) NULL,
  interests          TEXT NULL,
  lookalike_source   VARCHAR(190) NULL,
  retargeting_pixel  VARCHAR(100) NULL,
  estimated_size     INT NULL,
  status             ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mk_social_campaigns (
  campaign_id      INT AUTO_INCREMENT PRIMARY KEY,
  campaign_name    VARCHAR(190) NOT NULL,
  platform         ENUM('Facebook','Instagram','LinkedIn','X (Twitter)','YouTube','Google Ads','Other') NOT NULL DEFAULT 'Facebook',
  post_type        ENUM('Image','Carousel','Video / Reel','Story','Text','Ad') NOT NULL DEFAULT 'Image',
  audience_id      INT NULL,
  creative_file    VARCHAR(255) NULL,
  ad_copy_a        TEXT NULL,
  ad_copy_b        TEXT NULL,
  publish_at       DATETIME NULL,
  budget           DECIMAL(12,2) NULL,
  bidding_strategy ENUM('Lowest Cost','Cost Cap','Bid Cap','Target ROAS','Manual CPC','Organic (No Bid)') NOT NULL DEFAULT 'Lowest Cost',
  api_credential   TEXT NULL,
  landing_url      VARCHAR(500) NULL,
  utm_campaign     VARCHAR(120) NULL,
  tracking_url     VARCHAR(500) NULL,
  status           ENUM('Draft','Scheduled','Running','Completed','Paused','Cancelled') NOT NULL DEFAULT 'Draft',
  launched_at      DATETIME NULL,
  created_by       INT NULL,
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_mk_social_status (status),
  CONSTRAINT fk_mk_social_aud FOREIGN KEY (audience_id) REFERENCES mk_social_audiences(audience_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mk_utm_links (
  utm_id          INT AUTO_INCREMENT PRIMARY KEY,
  link_name       VARCHAR(190) NOT NULL,
  channel         ENUM('Email','SMS','WhatsApp','Social','Other') NOT NULL DEFAULT 'Email',
  base_url        VARCHAR(500) NOT NULL,
  utm_source      VARCHAR(80) NOT NULL,
  utm_medium      VARCHAR(80) NOT NULL,
  utm_campaign    VARCHAR(120) NOT NULL,
  utm_term        VARCHAR(120) NULL,
  utm_content     VARCHAR(120) NULL,
  generated_url   VARCHAR(1000) NULL,
  short_url       VARCHAR(255) NULL,
  conversion_goal VARCHAR(150) NULL,
  pixel_id        VARCHAR(100) NULL,
  status          ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mk_performance (
  perf_id        INT AUTO_INCREMENT PRIMARY KEY,
  channel        ENUM('Email','SMS','WhatsApp','Social') NOT NULL,
  campaign_name  VARCHAR(190) NOT NULL,
  period_start   DATE NULL,
  period_end     DATE NULL,
  sent           INT NOT NULL DEFAULT 0,
  delivered      INT NOT NULL DEFAULT 0,
  opens          INT NOT NULL DEFAULT 0,
  clicks         INT NOT NULL DEFAULT 0,
  conversions    INT NOT NULL DEFAULT 0,
  unsubscribes   INT NOT NULL DEFAULT 0,
  bounces        INT NOT NULL DEFAULT 0,
  impressions    INT NOT NULL DEFAULT 0,
  spend          DECIMAL(12,2) NOT NULL DEFAULT 0,
  revenue        DECIMAL(12,2) NOT NULL DEFAULT 0,
  data_source    ENUM('Manual','CSV Import') NOT NULL DEFAULT 'Manual',
  notes          VARCHAR(255) NULL,
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_mk_perf_channel (channel)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mk_ab_tests (
  test_id        INT AUTO_INCREMENT PRIMARY KEY,
  test_name      VARCHAR(190) NOT NULL,
  channel        ENUM('Email','SMS','WhatsApp','Social') NOT NULL DEFAULT 'Email',
  campaign_name  VARCHAR(190) NULL,
  variable_tested ENUM('Subject Line','Content','Send Time','CTA','Creative','Audience') NOT NULL DEFAULT 'Subject Line',
  variant_a      VARCHAR(255) NULL,
  variant_b      VARCHAR(255) NULL,
  metric         ENUM('Open Rate','Click-Through Rate','Conversion Rate') NOT NULL DEFAULT 'Open Rate',
  a_sent         INT NOT NULL DEFAULT 0,
  a_success      INT NOT NULL DEFAULT 0,
  b_sent         INT NOT NULL DEFAULT 0,
  b_success      INT NOT NULL DEFAULT 0,
  status         ENUM('Running','Completed') NOT NULL DEFAULT 'Running',
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------
-- PROJECT MANAGEMENT
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS pm_projects (
  project_id         INT AUTO_INCREMENT PRIMARY KEY,
  project_code       VARCHAR(30) NOT NULL,
  project_name       VARCHAR(255) NOT NULL,
  description        TEXT NULL,
  client_id          INT NULL,
  project_manager_id INT NULL,
  priority           ENUM('Low','Medium','High') NOT NULL DEFAULT 'Medium',
  budget             DECIMAL(14,2) NULL,
  estimated_hours    DECIMAL(9,2) NULL,
  start_date         DATE NULL,
  end_date           DATE NULL,
  status             ENUM('Planning','Active','Testing','Completed') NOT NULL DEFAULT 'Planning',
  created_by         INT NULL,
  created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_pm_project_code (project_code),
  INDEX idx_pm_project_status (status),
  CONSTRAINT fk_pm_project_client  FOREIGN KEY (client_id)          REFERENCES customers(id) ON DELETE SET NULL,
  CONSTRAINT fk_pm_project_manager FOREIGN KEY (project_manager_id) REFERENCES employees(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pm_milestones (
  milestone_id       INT AUTO_INCREMENT PRIMARY KEY,
  project_id         INT NOT NULL,
  milestone_title    VARCHAR(255) NOT NULL,
  due_date           DATE NULL,
  deliverable_amount DECIMAL(10,2) NULL,
  status             ENUM('Pending','Reached') NOT NULL DEFAULT 'Pending',
  reached_on         DATE NULL,
  created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_pm_ms_project (project_id),
  CONSTRAINT fk_pm_ms_project FOREIGN KEY (project_id) REFERENCES pm_projects(project_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pm_modules (
  module_id    INT AUTO_INCREMENT PRIMARY KEY,
  project_id   INT NOT NULL,
  module_name  VARCHAR(255) NOT NULL,
  description  TEXT NULL,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_pm_mod_project (project_id),
  CONSTRAINT fk_pm_mod_project FOREIGN KEY (project_id) REFERENCES pm_projects(project_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pm_tasks (
  task_id           INT AUTO_INCREMENT PRIMARY KEY,
  module_id         INT NOT NULL,
  task_name         VARCHAR(255) NOT NULL,
  description       TEXT NULL,
  priority          ENUM('Low','Medium','High') NOT NULL DEFAULT 'Medium',
  status            ENUM('To Do','In Progress','Done') NOT NULL DEFAULT 'To Do',
  start_date        DATE NULL,
  due_date          DATE NULL,
  estimated_hours   DECIMAL(7,2) NULL,
  depends_on_task_id INT NULL,
  created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_pm_task_module (module_id),
  INDEX idx_pm_task_status (status),
  CONSTRAINT fk_pm_task_module FOREIGN KEY (module_id) REFERENCES pm_modules(module_id) ON DELETE CASCADE,
  CONSTRAINT fk_pm_task_dep    FOREIGN KEY (depends_on_task_id) REFERENCES pm_tasks(task_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pm_sub_tasks (
  sub_task_id    INT AUTO_INCREMENT PRIMARY KEY,
  task_id        INT NOT NULL,
  sub_task_title VARCHAR(255) NOT NULL,
  is_completed   TINYINT(1) NOT NULL DEFAULT 0,
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_pm_sub_task (task_id),
  CONSTRAINT fk_pm_sub_task FOREIGN KEY (task_id) REFERENCES pm_tasks(task_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pm_team_assignments (
  assignment_id  INT AUTO_INCREMENT PRIMARY KEY,
  task_id        INT NOT NULL,
  user_id        INT NOT NULL,
  assigned_date  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  role_note      VARCHAR(100) NULL,
  UNIQUE KEY uq_pm_assign (task_id, user_id),
  INDEX idx_pm_assign_user (user_id),
  CONSTRAINT fk_pm_assign_task FOREIGN KEY (task_id) REFERENCES pm_tasks(task_id) ON DELETE CASCADE,
  CONSTRAINT fk_pm_assign_emp  FOREIGN KEY (user_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pm_time_tracking (
  time_log_id  INT AUTO_INCREMENT PRIMARY KEY,
  task_id      INT NOT NULL,
  user_id      INT NOT NULL,
  start_time   DATETIME NOT NULL,
  end_time     DATETIME NULL,
  total_hours  DECIMAL(5,2) NULL,
  notes        VARCHAR(255) NULL,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_pm_time_task (task_id),
  INDEX idx_pm_time_user (user_id),
  CONSTRAINT fk_pm_time_task FOREIGN KEY (task_id) REFERENCES pm_tasks(task_id) ON DELETE CASCADE,
  CONSTRAINT fk_pm_time_emp  FOREIGN KEY (user_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pm_files (
  file_id        INT AUTO_INCREMENT PRIMARY KEY,
  project_id     INT NOT NULL,
  file_name      VARCHAR(255) NOT NULL,
  file_url_path  VARCHAR(500) NOT NULL,
  file_category  ENUM('Brief','Contract','Requirement','Design','Deliverable','Other') NOT NULL DEFAULT 'Other',
  file_size      INT NULL,
  uploaded_by    INT NULL,
  uploaded_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_pm_file_project (project_id),
  CONSTRAINT fk_pm_file_project FOREIGN KEY (project_id) REFERENCES pm_projects(project_id) ON DELETE CASCADE,
  CONSTRAINT fk_pm_file_user    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pm_testing_bugs (
  bug_id             INT AUTO_INCREMENT PRIMARY KEY,
  project_id         INT NOT NULL,
  task_id            INT NULL,
  bug_title          VARCHAR(255) NOT NULL,
  issue_description  TEXT NULL,
  severity           ENUM('Minor','Major','Critical') NOT NULL DEFAULT 'Minor',
  status             ENUM('Open','Fixing','Resolved') NOT NULL DEFAULT 'Open',
  reported_by        INT NULL,
  assigned_to        INT NULL,
  resolved_at        DATETIME NULL,
  created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_pm_bug_project (project_id),
  INDEX idx_pm_bug_status (status),
  CONSTRAINT fk_pm_bug_project  FOREIGN KEY (project_id)  REFERENCES pm_projects(project_id) ON DELETE CASCADE,
  CONSTRAINT fk_pm_bug_task     FOREIGN KEY (task_id)     REFERENCES pm_tasks(task_id) ON DELETE SET NULL,
  CONSTRAINT fk_pm_bug_reporter FOREIGN KEY (reported_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_pm_bug_assignee FOREIGN KEY (assigned_to) REFERENCES employees(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pm_client_approvals (
  approval_id    INT AUTO_INCREMENT PRIMARY KEY,
  project_id     INT NOT NULL,
  client_id      INT NULL,
  milestone_id   INT NULL,
  approval_type  VARCHAR(100) NOT NULL,
  status         ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  feedback_notes TEXT NULL,
  signed_by      VARCHAR(150) NULL,
  requested_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  decided_at     DATETIME NULL,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_pm_appr_project (project_id),
  CONSTRAINT fk_pm_appr_project FOREIGN KEY (project_id)   REFERENCES pm_projects(project_id) ON DELETE CASCADE,
  CONSTRAINT fk_pm_appr_client  FOREIGN KEY (client_id)    REFERENCES customers(id) ON DELETE SET NULL,
  CONSTRAINT fk_pm_appr_ms      FOREIGN KEY (milestone_id) REFERENCES pm_milestones(milestone_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pm_deployments (
  deployment_id   INT AUTO_INCREMENT PRIMARY KEY,
  project_id      INT NOT NULL,
  version_tag     VARCHAR(50) NOT NULL,
  environment     ENUM('Staging','Production') NOT NULL DEFAULT 'Staging',
  deployment_date DATETIME NOT NULL,
  deployed_by     INT NULL,
  release_notes   TEXT NULL,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_pm_dep_project (project_id),
  CONSTRAINT fk_pm_dep_project FOREIGN KEY (project_id)  REFERENCES pm_projects(project_id) ON DELETE CASCADE,
  CONSTRAINT fk_pm_dep_user    FOREIGN KEY (deployed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pm_maintenance (
  maintenance_id    INT AUTO_INCREMENT PRIMARY KEY,
  project_id        INT NOT NULL,
  request_date      DATETIME NOT NULL,
  issue_details     TEXT NOT NULL,
  priority          ENUM('Low','Medium','High') NOT NULL DEFAULT 'Medium',
  assigned_to       INT NULL,
  resolution_status ENUM('Logged','In Progress','Closed') NOT NULL DEFAULT 'Logged',
  resolution_notes  TEXT NULL,
  closed_at         DATETIME NULL,
  created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_pm_maint_project (project_id),
  CONSTRAINT fk_pm_maint_project FOREIGN KEY (project_id)  REFERENCES pm_projects(project_id) ON DELETE CASCADE,
  CONSTRAINT fk_pm_maint_emp     FOREIGN KEY (assigned_to) REFERENCES employees(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------
-- ASSET MANAGEMENT
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS am_assets (
  asset_id        INT AUTO_INCREMENT PRIMARY KEY,
  asset_tag       VARCHAR(100) NOT NULL,
  asset_type      ENUM('Laptop','Desktop','Printer','Server','Software') NOT NULL,
  brand_model     VARCHAR(255) NOT NULL,
  serial_number   VARCHAR(255) NULL,
  purchase_date   DATE NULL,
  purchase_cost   DECIMAL(12,2) NOT NULL DEFAULT 0,
  status          ENUM('In Stock','In Use','In Repair','Retired') NOT NULL DEFAULT 'In Stock',
  vendor_name     VARCHAR(255) NULL,
  invoice_number  VARCHAR(100) NULL,
  warranty_expiry DATE NULL,
  branch          VARCHAR(150) NULL,
  location        VARCHAR(150) NULL,
  specifications  TEXT NULL,
  retired_on      DATE NULL,
  salvage_received DECIMAL(12,2) NULL,
  created_by      INT NULL,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_am_asset_tag (asset_tag),
  INDEX idx_am_asset_type (asset_type),
  INDEX idx_am_asset_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS am_software_licenses (
  license_id       INT AUTO_INCREMENT PRIMARY KEY,
  asset_id         INT NOT NULL,
  software_name    VARCHAR(255) NOT NULL,
  license_type     ENUM('Perpetual','Subscription','Volume','Open Source') NOT NULL DEFAULT 'Subscription',
  license_key      VARCHAR(500) NULL,
  seats_total      INT NOT NULL DEFAULT 1,
  seats_available  INT NOT NULL DEFAULT 1,
  expiry_date      DATE NULL,
  renewal_cost     DECIMAL(10,2) NULL,
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_am_lic_asset (asset_id),
  CONSTRAINT fk_am_lic_asset FOREIGN KEY (asset_id) REFERENCES am_assets(asset_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS am_asset_allocations (
  allocation_id      INT AUTO_INCREMENT PRIMARY KEY,
  asset_id           INT NOT NULL,
  employee_id        INT NULL,
  department_id      INT NULL,
  allocated_date     DATE NOT NULL,
  return_due_date    DATE NULL,
  actual_return_date DATE NULL,
  allocation_status  ENUM('Active','Returned','Overdue') NOT NULL DEFAULT 'Active',
  condition_on_issue VARCHAR(150) NULL,
  condition_on_return VARCHAR(150) NULL,
  remarks            TEXT NULL,
  created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_am_alloc_asset (asset_id),
  INDEX idx_am_alloc_emp (employee_id),
  CONSTRAINT fk_am_alloc_asset FOREIGN KEY (asset_id)      REFERENCES am_assets(asset_id) ON DELETE CASCADE,
  CONSTRAINT fk_am_alloc_emp   FOREIGN KEY (employee_id)   REFERENCES employees(id) ON DELETE SET NULL,
  CONSTRAINT fk_am_alloc_dept  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS am_maintenance_logs (
  maintenance_id    INT AUTO_INCREMENT PRIMARY KEY,
  asset_id          INT NOT NULL,
  maintenance_type  ENUM('Routine','Break/Fix','Upgrade') NOT NULL DEFAULT 'Routine',
  service_date      DATE NOT NULL,
  issue_description TEXT NULL,
  vendor_name       VARCHAR(255) NULL,
  repair_cost       DECIMAL(10,2) NOT NULL DEFAULT 0,
  next_service_date DATE NULL,
  status            ENUM('Scheduled','In Progress','Completed') NOT NULL DEFAULT 'Scheduled',
  completed_on      DATE NULL,
  created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_am_maint_asset (asset_id),
  CONSTRAINT fk_am_maint_asset FOREIGN KEY (asset_id) REFERENCES am_assets(asset_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS am_asset_history (
  history_id    INT AUTO_INCREMENT PRIMARY KEY,
  asset_id      INT NOT NULL,
  action_type   ENUM('Purchased','Assigned','Returned','Repaired','Retired','Maintenance','Updated','Depreciated') NOT NULL,
  performed_by  INT NULL,
  action_date   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  remarks       TEXT NULL,
  INDEX idx_am_hist_asset (asset_id),
  CONSTRAINT fk_am_hist_asset FOREIGN KEY (asset_id)     REFERENCES am_assets(asset_id) ON DELETE CASCADE,
  CONSTRAINT fk_am_hist_user  FOREIGN KEY (performed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS am_asset_depreciation (
  depreciation_id         INT AUTO_INCREMENT PRIMARY KEY,
  asset_id                INT NOT NULL,
  ledger_account_id       INT NULL,
  depreciation_method     ENUM('Straight Line','Declining Balance') NOT NULL DEFAULT 'Straight Line',
  useful_life_months      INT NOT NULL DEFAULT 36,
  salvage_value           DECIMAL(12,2) NOT NULL DEFAULT 0,
  current_book_value      DECIMAL(12,2) NOT NULL DEFAULT 0,
  accumulated_depreciation DECIMAL(12,2) NOT NULL DEFAULT 0,
  last_calculated         DATE NULL,
  UNIQUE KEY uq_am_dep_asset (asset_id),
  CONSTRAINT fk_am_dep_asset FOREIGN KEY (asset_id) REFERENCES am_assets(asset_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS am_gl_postings (
  posting_id        INT AUTO_INCREMENT PRIMARY KEY,
  asset_id          INT NOT NULL,
  event_type        ENUM('Purchase','Depreciation','Maintenance','Disposal') NOT NULL,
  period_key        VARCHAR(20) NOT NULL DEFAULT '',
  amount            DECIMAL(12,2) NOT NULL,
  entry_date        DATE NULL,
  narration         VARCHAR(255) NULL,
  journal_record_id INT NULL,
  posted_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_am_gl (asset_id, event_type, period_key),
  CONSTRAINT fk_am_gl_asset FOREIGN KEY (asset_id) REFERENCES am_assets(asset_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------
-- DOCUMENT MANAGEMENT
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS dms_documents (
  doc_id             INT AUTO_INCREMENT PRIMARY KEY,
  title              VARCHAR(255) NOT NULL,
  category           ENUM('Contract','NDA','Agreement','Proposal','Company','Employee','Client') NOT NULL,
  owner_id           INT NULL,
  client_id          INT NULL,
  employee_id        INT NULL,
  current_version_id INT NULL,
  status             ENUM('Draft','Pending Review','Active','Archived') NOT NULL DEFAULT 'Draft',
  description        TEXT NULL,
  effective_date     DATE NULL,
  expiry_date        DATE NULL,
  renewal_alert_days INT NOT NULL DEFAULT 30,
  created_by         INT NULL,
  created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_dms_doc_cat (category),
  INDEX idx_dms_doc_status (status),
  CONSTRAINT fk_dms_doc_owner  FOREIGN KEY (owner_id)    REFERENCES employees(id) ON DELETE SET NULL,
  CONSTRAINT fk_dms_doc_client FOREIGN KEY (client_id)   REFERENCES customers(id) ON DELETE SET NULL,
  CONSTRAINT fk_dms_doc_emp    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS dms_document_versions (
  version_id     INT AUTO_INCREMENT PRIMARY KEY,
  doc_id         INT NOT NULL,
  version_number VARCHAR(10) NOT NULL,
  file_name      VARCHAR(255) NOT NULL,
  file_url_path  VARCHAR(500) NOT NULL,
  file_size      INT NULL,
  file_type      VARCHAR(20) NULL,
  uploaded_by    INT NULL,
  upload_date    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  change_log     TEXT NULL,
  UNIQUE KEY uq_dms_ver (doc_id, version_number),
  CONSTRAINT fk_dms_ver_doc  FOREIGN KEY (doc_id)      REFERENCES dms_documents(doc_id) ON DELETE CASCADE,
  CONSTRAINT fk_dms_ver_user FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS dms_document_permissions (
  permission_id INT AUTO_INCREMENT PRIMARY KEY,
  doc_id        INT NOT NULL,
  user_id       INT NULL,
  role_id       INT NULL,
  access_level  ENUM('View','Comment','Edit','Admin') NOT NULL DEFAULT 'View',
  granted_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_dms_perm_doc (doc_id),
  CONSTRAINT fk_dms_perm_doc  FOREIGN KEY (doc_id)  REFERENCES dms_documents(doc_id) ON DELETE CASCADE,
  CONSTRAINT fk_dms_perm_user FOREIGN KEY (user_id) REFERENCES employees(id) ON DELETE CASCADE,
  CONSTRAINT fk_dms_perm_role FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS dms_document_signatures (
  signature_id   INT AUTO_INCREMENT PRIMARY KEY,
  doc_id         INT NOT NULL,
  version_id     INT NOT NULL,
  signer_user_id INT NULL,
  signer_name    VARCHAR(150) NOT NULL,
  signed_at      DATETIME NOT NULL,
  ip_address     VARCHAR(45) NULL,
  remarks        VARCHAR(255) NULL,
  INDEX idx_dms_sig_doc (doc_id),
  CONSTRAINT fk_dms_sig_doc  FOREIGN KEY (doc_id)         REFERENCES dms_documents(doc_id) ON DELETE CASCADE,
  CONSTRAINT fk_dms_sig_ver  FOREIGN KEY (version_id)     REFERENCES dms_document_versions(version_id) ON DELETE CASCADE,
  CONSTRAINT fk_dms_sig_user FOREIGN KEY (signer_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS dms_audit_logs (
  log_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
  doc_id     INT NULL,
  doc_title  VARCHAR(255) NULL,
  version_id INT NULL,
  user_id    INT NULL,
  user_name  VARCHAR(150) NULL,
  action     ENUM('Created','Viewed','Downloaded','Updated','Deleted','Version Added','Signed','Permission Changed','Restored') NOT NULL,
  details    VARCHAR(255) NULL,
  ip_address VARCHAR(45) NULL,
  timestamp  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_dms_audit_doc (doc_id),
  INDEX idx_dms_audit_time (timestamp),
  CONSTRAINT fk_dms_audit_doc  FOREIGN KEY (doc_id)  REFERENCES dms_documents(doc_id) ON DELETE SET NULL,
  CONSTRAINT fk_dms_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------
-- ADMINISTRATION
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS adm_system_settings (
  setting_id    INT AUTO_INCREMENT PRIMARY KEY,
  setting_group ENUM('Company','Email','SMS','WhatsApp','Payment','Finance','Backup') NOT NULL,
  setting_key   VARCHAR(100) NOT NULL,
  setting_value TEXT NULL,
  is_encrypted  TINYINT(1) NOT NULL DEFAULT 0,
  updated_by    INT NULL,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_adm_setting_key (setting_key),
  INDEX idx_adm_setting_group (setting_group)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS adm_audit_logs (
  log_id           BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id          INT NULL,
  user_name        VARCHAR(150) NULL,
  action_performed TEXT NOT NULL,
  table_affected   VARCHAR(100) NULL,
  request_method   VARCHAR(10) NULL,
  ip_address       VARCHAR(45) NULL,
  outcome          ENUM('Success','Failed') NOT NULL DEFAULT 'Success',
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_adm_audit_time (created_at),
  INDEX idx_adm_audit_user (user_id),
  INDEX idx_adm_audit_table (table_affected)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS adm_security_rules (
  rule_id     INT AUTO_INCREMENT PRIMARY KEY,
  rule_type   ENUM('IP_Whitelist','IP_Blacklist','Password_Policy') NOT NULL,
  rule_value  VARCHAR(255) NOT NULL,
  description VARCHAR(255) NULL,
  is_active   TINYINT(1) NOT NULL DEFAULT 1,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_adm_rule_type (rule_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS adm_backup_history (
  backup_id    INT AUTO_INCREMENT PRIMARY KEY,
  file_name    VARCHAR(255) NOT NULL,
  file_size_mb DECIMAL(8,2) NOT NULL DEFAULT 0,
  status       ENUM('Success','Failed','In Progress') NOT NULL DEFAULT 'In Progress',
  backup_type  ENUM('Manual','Scheduled') NOT NULL DEFAULT 'Manual',
  tables_count INT NULL,
  executed_by  VARCHAR(150) NULL,
  message      VARCHAR(500) NULL,
  executed_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------
-- LOGIN ACCOUNTS (existing `users` table) - additive columns
-- Lets Administration suspend an account and link it to an
-- employee. Existing rows keep working (default Active).
-- (MariaDB / XAMPP syntax. The application adds these itself
-- when it detects they are missing.)
-- ---------------------------------------------------------
ALTER TABLE users ADD COLUMN IF NOT EXISTS status ENUM('Active','Suspended') NOT NULL DEFAULT 'Active';
ALTER TABLE users ADD COLUMN IF NOT EXISTS employee_id INT NULL;
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login_at DATETIME NULL;
