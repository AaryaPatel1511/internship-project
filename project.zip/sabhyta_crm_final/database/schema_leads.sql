-- =========================================================
-- SABHYTA CRM — Lead Management Module
-- Dedicated schema (replaces the generic_records fallback for
-- every leaf under the "Lead Management" sidebar section).
-- Run this once after schema.sql. Safe to re-run (IF NOT EXISTS).
-- =========================================================

-- ---------------------------------------------------------
-- leads  (a.k.a. lead_master in the functional spec)
-- One row per lead, from first capture through to booking or
-- loss. Every field listed in the "Add Lead" specification is
-- represented here as a real column (not a JSON blob) so the
-- record is reportable and searchable.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS leads (
  id                     INT AUTO_INCREMENT PRIMARY KEY,
  lead_code              VARCHAR(30)  NOT NULL,          -- auto-generated, e.g. LD-000123

  -- Basic Information
  lead_date              DATETIME     NOT NULL,
  customer_name          VARCHAR(150) NOT NULL,
  mobile                 VARCHAR(20)  NOT NULL,
  alternate_mobile       VARCHAR(20),
  email                  VARCHAR(150),
  gender                 VARCHAR(20),
  dob                    DATE,

  -- Address
  address_line           VARCHAR(255),
  landmark               VARCHAR(150),
  city                   VARCHAR(100),
  district               VARCHAR(100),
  state                  VARCHAR(100),
  country                VARCHAR(100) DEFAULT 'India',
  pincode                VARCHAR(12),

  -- Vehicle Requirement
  vehicle_brand          VARCHAR(100),
  vehicle_model          VARCHAR(100),
  variant                VARCHAR(100),
  fuel_type              VARCHAR(30),
  transmission           VARCHAR(30),
  color_preference       VARCHAR(60),
  budget                 DECIMAL(15,2),
  expected_purchase_date DATE,

  -- Purchase Details
  finance_required       ENUM('Yes','No') DEFAULT 'No',
  exchange_required      ENUM('Yes','No') DEFAULT 'No',
  test_drive_required    ENUM('Yes','No') DEFAULT 'No',
  corporate_customer     ENUM('Yes','No') DEFAULT 'No',
  existing_customer      ENUM('Yes','No') DEFAULT 'No',

  -- Lead Source
  lead_source            VARCHAR(40)  NOT NULL DEFAULT 'Walk-in',
  -- populated only for API-captured sources, used for de-duplication
  -- against the platform's own lead id (Facebook Lead ID / Google Lead ID / etc.)
  source_ref_id           VARCHAR(150),
  source_campaign         VARCHAR(150),
  source_adset            VARCHAR(150),
  source_ad_name          VARCHAR(150),
  source_keyword          VARCHAR(150),
  source_landing_page     VARCHAR(255),
  source_campaign_cost    DECIMAL(12,2),
  page_url                VARCHAR(255),
  ip_address              VARCHAR(64),
  browser                 VARCHAR(150),

  -- Sales Assignment
  branch                 VARCHAR(100),
  sales_executive        VARCHAR(150),
  team_leader            VARCHAR(150),
  priority               ENUM('Hot','Warm','Cold') DEFAULT 'Warm',

  -- Remarks
  requirement_notes      TEXT,
  notes                  TEXT,
  attachment             VARCHAR(255),

  -- Lifecycle / status flow:
  -- New Lead -> Assigned -> Contacted -> Follow-up -> Interested ->
  -- Test Drive -> Quotation Sent -> Finance -> Booking -> Delivered -> Closed
  -- (Not Interested / Lost breaks off the flow at any point.)
  status                 VARCHAR(30) DEFAULT 'New Lead',
  next_followup_date     DATE,

  -- Lost Lead details (populated only when status = 'Lost')
  lost_date              DATE,
  lost_reason            VARCHAR(60),
  competitor_name        VARCHAR(120),
  price_difference       DECIMAL(12,2),

  -- Converted / Booking details (populated only when status = 'Converted')
  booking_number          VARCHAR(50),
  invoice_number          VARCHAR(50),
  booking_date            DATE,
  delivery_date           DATE,
  finance_company         VARCHAR(120),
  loan_amount             DECIMAL(15,2),
  final_amount            DECIMAL(15,2),
  payment_mode            VARCHAR(40),
  booking_amount          DECIMAL(15,2),
  discount_given          DECIMAL(12,2),
  exchange_value          DECIMAL(12,2),
  accessories_sold        DECIMAL(12,2),
  insurance_amount        DECIMAL(12,2),
  extended_warranty       DECIMAL(12,2),
  rto_charges             DECIMAL(12,2),
  accessories_package     VARCHAR(150),
  delivery_executive      VARCHAR(150),

  created_by             VARCHAR(100),
  created_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_lead_code (lead_code),
  INDEX idx_mobile (mobile),
  INDEX idx_status (status),
  INDEX idx_source (lead_source),
  INDEX idx_executive (sales_executive),
  INDEX idx_priority (priority),
  INDEX idx_followup_date (next_followup_date)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- lead_followups — full follow-up history per lead
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS lead_followups (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  lead_id             INT NOT NULL,
  followup_date       DATE NOT NULL,
  followup_time       TIME,
  next_followup_date  DATE,
  executive           VARCHAR(150),
  discussion          TEXT,
  customer_feedback   TEXT,
  status              VARCHAR(30) NOT NULL DEFAULT 'Call Later',
  -- comma-separated list of reminder channels chosen: SMS,WhatsApp,Email,CRM Notification
  reminder_channels    VARCHAR(150),
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE,
  INDEX idx_lead (lead_id),
  INDEX idx_next_followup (next_followup_date)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- lead_status_history — every stage transition, for audit /
-- the "Status Fields: Updated By, Updated Date" requirement.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS lead_status_history (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  lead_id     INT NOT NULL,
  old_status  VARCHAR(30),
  new_status  VARCHAR(30) NOT NULL,
  remarks     VARCHAR(255),
  updated_by  VARCHAR(100),
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE,
  INDEX idx_lead (lead_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- lead_source_settings — one row per integration (Website,
-- Facebook, Google Ads, WhatsApp). Holds the credentials /
-- tokens the dealership pastes in from their own developer
-- account, plus the auto-generated inbound webhook secret.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS lead_source_settings (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  source_key     VARCHAR(30) NOT NULL,      -- website | facebook | google_ads | whatsapp
  webhook_token  VARCHAR(64) NOT NULL,      -- shared secret appended to the webhook URL as ?token=
  config_json    LONGTEXT,                  -- { appId, appSecret, pageId, accessToken, ... } per source
  is_active      TINYINT(1) DEFAULT 1,
  last_test_at   TIMESTAMP NULL,
  last_test_result VARCHAR(255),
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_source (source_key)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- lead_webhook_logs — raw inbound payload log for every hit
-- to api/lead_webhooks.php, so failed/rejected pushes from
-- Facebook / Google / WhatsApp / the website form can be
-- diagnosed without server log access.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS lead_webhook_logs (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  source_key   VARCHAR(30) NOT NULL,
  status       VARCHAR(20) NOT NULL,   -- received | created | duplicate | rejected
  message      VARCHAR(255),
  payload      LONGTEXT,
  lead_id      INT NULL,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  INDEX idx_source (source_key)
) ENGINE=InnoDB;

-- Seed the four integrations with a random webhook token so the
-- Integration Settings screen has something to display immediately.
INSERT IGNORE INTO lead_source_settings (source_key, webhook_token, config_json, is_active) VALUES
  ('website',   SUBSTRING(MD5(RAND()), 1, 32), '{}', 1),
  ('facebook',  SUBSTRING(MD5(RAND()), 1, 32), '{}', 1),
  ('google_ads',SUBSTRING(MD5(RAND()), 1, 32), '{}', 1),
  ('whatsapp',  SUBSTRING(MD5(RAND()), 1, 32), '{}', 1);
