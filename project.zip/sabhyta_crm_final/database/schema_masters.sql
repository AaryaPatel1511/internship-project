-- =========================================================
-- SABHYTACRM — MASTER MODULE extension schema
-- ---------------------------------------------------------
-- Run this ONCE against your existing sabhytacrm database,
-- AFTER database/schema.sql and database/schema_hrms_sales.sql
-- (phpMyAdmin -> Import, or
-- `mysql -u root -p sabhytacrm < database/schema_masters.sql`).
--
-- New sidebar "Master" section:
--   - Department / Designation   -> reuse existing `departments` /
--                                    `designations` tables (just moved
--                                    out of the HRMS menu into Master)
--   - Account Group / Sub Group  -> NEW dedicated table below,
--                                    seeded from the Account Group /
--                                    Sub Group spec sheet. This feeds
--                                    the "Account Group" + "Sub Group"
--                                    cascading dropdown in every
--                                    Accounts form (Chart of Accounts,
--                                    Income, Expenses, Purchase, Journal…)
--   - Holiday / Leave Type / Currency / Branch / Cost Center /
--     Payment Terms -> use the existing `generic_records` table
--     (module_key "master__…") — same JSON pattern as every other
--     rich HRMS/Sales/Accounts leaf. No new tables needed for these;
--     any form anywhere that needs one of them looks it up live via
--     api/records.php?module=master__<slug>.
-- =========================================================

USE sabhytacrm;

-- ---------------------------------------------------------
-- account_groups  (Master > Account Group, feeds Sub Group cascade)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS account_groups (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  account_type   VARCHAR(20)  NOT NULL,   -- Asset / Liability / Income / Expense / Equity
  category       VARCHAR(100) NOT NULL,   -- Current Assets / Fixed Assets / Investments / Current Liabilities / Long-Term Liabilities / Equity / Capital / Income / Expenses
  group_name     VARCHAR(150) NOT NULL,   -- e.g. "Bank", "Accounts Payable"
  sub_group_name VARCHAR(150) NOT NULL,   -- e.g. "Savings Account", "Sundry Creditors"
  is_system      TINYINT(1) DEFAULT 0,    -- 1 = came from the standard spec sheet (protected from delete)
  status         VARCHAR(20) DEFAULT 'Active',
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_group (group_name),
  INDEX idx_account_type (account_type),
  UNIQUE KEY uq_group_subgroup (group_name, sub_group_name)
) ENGINE=InnoDB;

-- Seed (INSERT IGNORE, so re-running this file is always safe once the
-- UNIQUE KEY above exists). 135 standard Account Group / Sub Group rows —
-- Assets, Liabilities, Equity from the spec sheet, plus the standard
-- Income & Expense groups from the Chart of Accounts spec.
INSERT IGNORE INTO account_groups (account_type, category, group_name, sub_group_name, is_system, status) VALUES
('Asset', 'Current Assets', 'Cash', 'Cash in Hand', 1, 'Active'),
('Asset', 'Current Assets', 'Cash', 'Petty Cash', 1, 'Active'),
('Asset', 'Current Assets', 'Bank', 'Current Account', 1, 'Active'),
('Asset', 'Current Assets', 'Bank', 'Savings Account', 1, 'Active'),
('Asset', 'Current Assets', 'Bank', 'Fixed Deposit', 1, 'Active'),
('Asset', 'Current Assets', 'Bank', 'Cash Credit Account', 1, 'Active'),
('Asset', 'Current Assets', 'Accounts Receivable', 'Sundry Debtors', 1, 'Active'),
('Asset', 'Current Assets', 'Accounts Receivable', 'Customer Outstanding', 1, 'Active'),
('Asset', 'Current Assets', 'Accounts Receivable', 'Bills Receivable', 1, 'Active'),
('Asset', 'Current Assets', 'Inventory', 'Raw Material', 1, 'Active'),
('Asset', 'Current Assets', 'Inventory', 'Work in Progress (WIP)', 1, 'Active'),
('Asset', 'Current Assets', 'Inventory', 'Finished Goods', 1, 'Active'),
('Asset', 'Current Assets', 'Inventory', 'Packing Material', 1, 'Active'),
('Asset', 'Current Assets', 'Inventory', 'Consumables', 1, 'Active'),
('Asset', 'Current Assets', 'Advances', 'Advance to Suppliers', 1, 'Active'),
('Asset', 'Current Assets', 'Advances', 'Employee Advance', 1, 'Active'),
('Asset', 'Current Assets', 'Advances', 'Project Advance', 1, 'Active'),
('Asset', 'Current Assets', 'Deposits', 'Security Deposit', 1, 'Active'),
('Asset', 'Current Assets', 'Deposits', 'Rental Deposit', 1, 'Active'),
('Asset', 'Current Assets', 'GST Assets', 'Input CGST', 1, 'Active'),
('Asset', 'Current Assets', 'GST Assets', 'Input SGST', 1, 'Active'),
('Asset', 'Current Assets', 'GST Assets', 'Input IGST', 1, 'Active'),
('Asset', 'Current Assets', 'GST Assets', 'GST Refund Receivable', 1, 'Active'),
('Asset', 'Current Assets', 'TDS Receivable', 'TDS on Contractor', 1, 'Active'),
('Asset', 'Current Assets', 'TDS Receivable', 'TDS on Professional', 1, 'Active'),
('Asset', 'Current Assets', 'Loans & Advances', 'Short-Term Loan', 1, 'Active'),
('Asset', 'Current Assets', 'Loans & Advances', 'Interest Receivable', 1, 'Active'),
('Asset', 'Current Assets', 'Other Current Assets', 'Prepaid Expenses', 1, 'Active'),
('Asset', 'Current Assets', 'Other Current Assets', 'Accrued Income', 1, 'Active'),
('Asset', 'Current Assets', 'Other Current Assets', 'Other Receivables', 1, 'Active'),
('Asset', 'Fixed Assets', 'Land', 'Freehold Land', 1, 'Active'),
('Asset', 'Fixed Assets', 'Building', 'Office Building', 1, 'Active'),
('Asset', 'Fixed Assets', 'Building', 'Factory Building', 1, 'Active'),
('Asset', 'Fixed Assets', 'Plant & Machinery', 'Manufacturing Machines', 1, 'Active'),
('Asset', 'Fixed Assets', 'Plant & Machinery', 'HVAC Equipment', 1, 'Active'),
('Asset', 'Fixed Assets', 'Furniture & Fixtures', 'Office Furniture', 1, 'Active'),
('Asset', 'Fixed Assets', 'Furniture & Fixtures', 'Modular Furniture', 1, 'Active'),
('Asset', 'Fixed Assets', 'Office Equipment', 'Printers', 1, 'Active'),
('Asset', 'Fixed Assets', 'Office Equipment', 'Projectors', 1, 'Active'),
('Asset', 'Fixed Assets', 'Office Equipment', 'Scanners', 1, 'Active'),
('Asset', 'Fixed Assets', 'Computers', 'Desktop', 1, 'Active'),
('Asset', 'Fixed Assets', 'Computers', 'Laptop', 1, 'Active'),
('Asset', 'Fixed Assets', 'Computers', 'Server', 1, 'Active'),
('Asset', 'Fixed Assets', 'Vehicles', 'Car', 1, 'Active'),
('Asset', 'Fixed Assets', 'Vehicles', 'Bike', 1, 'Active'),
('Asset', 'Fixed Assets', 'Vehicles', 'Commercial Vehicle', 1, 'Active'),
('Asset', 'Fixed Assets', 'Electrical Equipment', 'UPS', 1, 'Active'),
('Asset', 'Fixed Assets', 'Electrical Equipment', 'DG Set', 1, 'Active'),
('Asset', 'Fixed Assets', 'Electrical Equipment', 'Air Conditioner', 1, 'Active'),
('Asset', 'Fixed Assets', 'Intangible Assets', 'Software License', 1, 'Active'),
('Asset', 'Fixed Assets', 'Intangible Assets', 'ERP Software', 1, 'Active'),
('Asset', 'Fixed Assets', 'Intangible Assets', 'Website Development', 1, 'Active'),
('Asset', 'Fixed Assets', 'Intangible Assets', 'Trademark', 1, 'Active'),
('Asset', 'Fixed Assets', 'Intangible Assets', 'Patent', 1, 'Active'),
('Asset', 'Fixed Assets', 'Capital Work in Progress', 'Building Under Construction', 1, 'Active'),
('Asset', 'Fixed Assets', 'Capital Work in Progress', 'Machinery Under Installation', 1, 'Active'),
('Asset', 'Investments', 'Long Term Investments', 'Mutual Fund', 1, 'Active'),
('Asset', 'Investments', 'Long Term Investments', 'Shares', 1, 'Active'),
('Asset', 'Investments', 'Long Term Investments', 'Bonds', 1, 'Active'),
('Asset', 'Investments', 'Long Term Investments', 'Government Securities', 1, 'Active'),
('Asset', 'Investments', 'Short Term Investments', 'Mutual Fund', 1, 'Active'),
('Asset', 'Investments', 'Short Term Investments', 'Equity Trading', 1, 'Active'),
('Liability', 'Current Liabilities', 'Accounts Payable', 'Sundry Creditors', 1, 'Active'),
('Liability', 'Current Liabilities', 'Accounts Payable', 'Vendor Outstanding', 1, 'Active'),
('Liability', 'Current Liabilities', 'Accounts Payable', 'Bills Payable', 1, 'Active'),
('Liability', 'Current Liabilities', 'GST Liability', 'Output CGST', 1, 'Active'),
('Liability', 'Current Liabilities', 'GST Liability', 'Output SGST', 1, 'Active'),
('Liability', 'Current Liabilities', 'GST Liability', 'Output IGST', 1, 'Active'),
('Liability', 'Current Liabilities', 'GST Liability', 'GST Payable', 1, 'Active'),
('Liability', 'Current Liabilities', 'TDS Payable', 'Contractor TDS', 1, 'Active'),
('Liability', 'Current Liabilities', 'TDS Payable', 'Professional TDS', 1, 'Active'),
('Liability', 'Current Liabilities', 'TDS Payable', 'Salary TDS', 1, 'Active'),
('Liability', 'Current Liabilities', 'Employee Liabilities', 'Salary Payable', 1, 'Active'),
('Liability', 'Current Liabilities', 'Employee Liabilities', 'Bonus Payable', 1, 'Active'),
('Liability', 'Current Liabilities', 'Employee Liabilities', 'Leave Encashment', 1, 'Active'),
('Liability', 'Current Liabilities', 'Employee Liabilities', 'PF Payable', 1, 'Active'),
('Liability', 'Current Liabilities', 'Employee Liabilities', 'ESI Payable', 1, 'Active'),
('Liability', 'Current Liabilities', 'Statutory Dues', 'Professional Tax', 1, 'Active'),
('Liability', 'Current Liabilities', 'Statutory Dues', 'Labour Welfare Fund', 1, 'Active'),
('Liability', 'Current Liabilities', 'Statutory Dues', 'EPF', 1, 'Active'),
('Liability', 'Current Liabilities', 'Statutory Dues', 'ESI', 1, 'Active'),
('Liability', 'Current Liabilities', 'Advances', 'Customer Advance', 1, 'Active'),
('Liability', 'Current Liabilities', 'Advances', 'Security Deposit Received', 1, 'Active'),
('Liability', 'Current Liabilities', 'Outstanding Expenses', 'Electricity Expense Payable', 1, 'Active'),
('Liability', 'Current Liabilities', 'Outstanding Expenses', 'Rent Payable', 1, 'Active'),
('Liability', 'Current Liabilities', 'Outstanding Expenses', 'Audit Fee Payable', 1, 'Active'),
('Liability', 'Current Liabilities', 'Outstanding Expenses', 'Interest Payable', 1, 'Active'),
('Liability', 'Current Liabilities', 'Short-Term Borrowings', 'Cash Credit', 1, 'Active'),
('Liability', 'Current Liabilities', 'Short-Term Borrowings', 'Overdraft', 1, 'Active'),
('Liability', 'Current Liabilities', 'Short-Term Borrowings', 'Working Capital Loan', 1, 'Active'),
('Liability', 'Long-Term Liabilities', 'Bank Loan', 'Home Loan', 1, 'Active'),
('Liability', 'Long-Term Liabilities', 'Bank Loan', 'Term Loan', 1, 'Active'),
('Liability', 'Long-Term Liabilities', 'Bank Loan', 'Machinery Loan', 1, 'Active'),
('Liability', 'Long-Term Liabilities', 'Financial Institution Loan', 'NBFC Loan', 1, 'Active'),
('Liability', 'Long-Term Liabilities', 'Financial Institution Loan', 'Vehicle Loan', 1, 'Active'),
('Liability', 'Long-Term Liabilities', 'Unsecured Loan', 'Director Loan', 1, 'Active'),
('Liability', 'Long-Term Liabilities', 'Unsecured Loan', 'Partner Loan', 1, 'Active'),
('Liability', 'Long-Term Liabilities', 'Unsecured Loan', 'Loan from Friends & Relatives', 1, 'Active'),
('Liability', 'Long-Term Liabilities', 'Lease Liability', 'Office Lease', 1, 'Active'),
('Liability', 'Long-Term Liabilities', 'Lease Liability', 'Equipment Lease', 1, 'Active'),
('Liability', 'Long-Term Liabilities', 'Deferred Tax Liability', 'Deferred Tax', 1, 'Active'),
('Liability', 'Long-Term Liabilities', 'Provision', 'Gratuity Provision', 1, 'Active'),
('Liability', 'Long-Term Liabilities', 'Provision', 'Leave Encashment Provision', 1, 'Active'),
('Equity', 'Equity / Capital', 'Capital Account', 'Owner Capital', 1, 'Active'),
('Equity', 'Equity / Capital', 'Capital Account', 'Partner Capital', 1, 'Active'),
('Equity', 'Equity / Capital', 'Capital Account', 'Director Capital', 1, 'Active'),
('Equity', 'Equity / Capital', 'Share Capital', 'Equity Share Capital', 1, 'Active'),
('Equity', 'Equity / Capital', 'Share Capital', 'Preference Share Capital', 1, 'Active'),
('Equity', 'Equity / Capital', 'Reserve & Surplus', 'General Reserve', 1, 'Active'),
('Equity', 'Equity / Capital', 'Reserve & Surplus', 'Capital Reserve', 1, 'Active'),
('Equity', 'Equity / Capital', 'Reserve & Surplus', 'Retained Earnings', 1, 'Active'),
('Equity', 'Equity / Capital', 'Reserve & Surplus', 'Profit & Loss Balance', 1, 'Active'),
('Equity', 'Equity / Capital', 'Current Year Profit', 'Current Financial Year Profit', 1, 'Active'),
('Equity', 'Equity / Capital', 'Current Year Loss', 'Current Financial Year Loss', 1, 'Active'),
('Income', 'Income', 'Product Sales', 'Product Sales', 1, 'Active'),
('Income', 'Income', 'Service Income', 'Service Income', 1, 'Active'),
('Income', 'Income', 'Project Revenue', 'Project Revenue', 1, 'Active'),
('Income', 'Income', 'Consultancy Income', 'Consultancy Income', 1, 'Active'),
('Income', 'Income', 'Rental Income', 'Rental Income', 1, 'Active'),
('Income', 'Income', 'Interest Income', 'Interest Income', 1, 'Active'),
('Income', 'Income', 'Other Income', 'Other Income', 1, 'Active'),
('Expense', 'Expenses', 'Purchase', 'Purchase', 1, 'Active'),
('Expense', 'Expenses', 'Salary', 'Salary', 1, 'Active'),
('Expense', 'Expenses', 'Rent', 'Rent', 1, 'Active'),
('Expense', 'Expenses', 'Electricity', 'Electricity', 1, 'Active'),
('Expense', 'Expenses', 'Internet', 'Internet', 1, 'Active'),
('Expense', 'Expenses', 'Telephone', 'Telephone', 1, 'Active'),
('Expense', 'Expenses', 'Fuel', 'Fuel', 1, 'Active'),
('Expense', 'Expenses', 'Travel', 'Travel', 1, 'Active'),
('Expense', 'Expenses', 'Repair & Maintenance', 'Repair & Maintenance', 1, 'Active'),
('Expense', 'Expenses', 'Marketing', 'Marketing', 1, 'Active'),
('Expense', 'Expenses', 'Office Expenses', 'Office Expenses', 1, 'Active'),
('Expense', 'Expenses', 'Legal Fees', 'Legal Fees', 1, 'Active'),
('Expense', 'Expenses', 'Professional Charges', 'Professional Charges', 1, 'Active'),
('Expense', 'Expenses', 'Miscellaneous Expenses', 'Miscellaneous Expenses', 1, 'Active');
