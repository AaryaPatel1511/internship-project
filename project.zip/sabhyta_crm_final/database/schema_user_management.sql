-- ============================================================
-- USER MANAGEMENT SYSTEM SCHEMA (Compatible with HRMS)
-- Run AFTER schema.sql and schema_hrms_sales.sql
-- Does NOT recreate departments/designations (uses HRMS ones)
-- ============================================================

USE sabhytacrm;

-- 1. ROLES TABLE
CREATE TABLE IF NOT EXISTS roles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  role_name VARCHAR(100) UNIQUE NOT NULL,
  role_level INT NOT NULL,
  description TEXT,
  status VARCHAR(20) DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_level (role_level),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. MODULES TABLE
CREATE TABLE IF NOT EXISTS modules (
  id INT AUTO_INCREMENT PRIMARY KEY,
  module_name VARCHAR(100) UNIQUE NOT NULL,
  module_icon VARCHAR(50),
  description TEXT,
  status VARCHAR(20) DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. PERMISSIONS TABLE
CREATE TABLE IF NOT EXISTS permissions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  module_id INT NOT NULL,
  permission_name VARCHAR(150) NOT NULL,
  action_type VARCHAR(50) NOT NULL,
  description TEXT,
  status VARCHAR(20) DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_module (module_id),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. ROLE PERMISSIONS
CREATE TABLE IF NOT EXISTS role_permissions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  role_id INT NOT NULL,
  permission_id INT NOT NULL,
  data_scope VARCHAR(50) DEFAULT 'own',
  status VARCHAR(20) DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_role (role_id),
  INDEX idx_permission (permission_id),
  UNIQUE KEY unique_role_perm (role_id, permission_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. USER ROLES (Employee -> Roles)
CREATE TABLE IF NOT EXISTS user_roles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employee_id INT NOT NULL,
  role_id INT NOT NULL,
  assigned_by INT NULL,
  assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status VARCHAR(20) DEFAULT 'Active',
  INDEX idx_employee (employee_id),
  INDEX idx_role (role_id),
  UNIQUE KEY unique_emp_role (employee_id, role_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. USER PERMISSIONS (overrides)
CREATE TABLE IF NOT EXISTS user_permissions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employee_id INT NOT NULL,
  permission_id INT NOT NULL,
  data_scope VARCHAR(50) DEFAULT 'own',
  is_allowed TINYINT(1) DEFAULT 1,
  valid_from DATE,
  valid_to DATE,
  reason VARCHAR(255),
  approved_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_employee (employee_id),
  INDEX idx_permission (permission_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. REPORTING HIERARCHY
CREATE TABLE IF NOT EXISTS reporting_hierarchy (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employee_id INT NOT NULL,
  manager_id INT,
  supervisor_id INT,
  hierarchy_level INT,
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_employee (employee_id),
  INDEX idx_manager (manager_id),
  UNIQUE KEY unique_emp_hier (employee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. USER LOGIN AUDIT
CREATE TABLE IF NOT EXISTS user_login_audit (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employee_id INT NOT NULL,
  login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  logout_time TIMESTAMP NULL,
  ip_address VARCHAR(50),
  device_info VARCHAR(255),
  login_status VARCHAR(20),
  reason_if_failed VARCHAR(255),
  INDEX idx_employee (employee_id),
  INDEX idx_login_time (login_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. TEAMS
CREATE TABLE IF NOT EXISTS teams (
  id INT AUTO_INCREMENT PRIMARY KEY,
  team_name VARCHAR(150) NOT NULL,
  team_code VARCHAR(50) UNIQUE NOT NULL,
  department_id INT,
  team_lead_id INT,
  description TEXT,
  status VARCHAR(20) DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_dept (department_id),
  INDEX idx_lead (team_lead_id),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. TEAM MEMBERS
CREATE TABLE IF NOT EXISTS team_members (
  id INT AUTO_INCREMENT PRIMARY KEY,
  team_id INT NOT NULL,
  employee_id INT NOT NULL,
  role_in_team VARCHAR(100),
  joined_date DATE,
  status VARCHAR(20) DEFAULT 'Active',
  INDEX idx_team (team_id),
  INDEX idx_employee (employee_id),
  UNIQUE KEY unique_team_emp (team_id, employee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- DEFAULT SEED DATA
-- ============================================================

INSERT IGNORE INTO roles (id, role_name, role_level, description, status) VALUES
(1, 'Super Admin', 1, 'Complete system authority - Full access to all modules and settings', 'Active'),
(2, 'Admin', 2, 'Company administration - Manage users, departments, and operational data', 'Active'),
(3, 'Manager', 3, 'Department control - Full access to department data and team management', 'Active'),
(4, 'Supervisor', 4, 'Team control - Manage team members and their work', 'Active'),
(5, 'Executive', 5, 'User level - Access only assigned data and own records', 'Active');

INSERT IGNORE INTO modules (id, module_name, module_icon, description, status) VALUES
(1, 'CRM', 'fa-users', 'Customer Relationship Management', 'Active'),
(2, 'HRMS', 'fa-user-tie', 'Human Resource Management', 'Active'),
(3, 'Accounts', 'fa-wallet', 'Financial and Accounting Management', 'Active'),
(4, 'Projects', 'fa-project-diagram', 'Project Management', 'Active'),
(5, 'Inventory', 'fa-box-open', 'Stock and Inventory Management', 'Active'),
(6, 'Helpdesk', 'fa-headset', 'Support and Ticket Management', 'Active'),
(7, 'Reports', 'fa-chart-pie', 'Reporting and Analytics', 'Active'),
(8, 'Administration', 'fa-user-shield', 'System Administration', 'Active');

INSERT IGNORE INTO permissions (id, module_id, permission_name, action_type, description, status) VALUES
(1, 1, 'View Leads', 'view', 'View lead records', 'Active'),
(2, 1, 'Add Lead', 'add', 'Create new leads', 'Active'),
(3, 1, 'Edit Lead', 'edit', 'Modify lead information', 'Active'),
(4, 1, 'Delete Lead', 'delete', 'Delete lead records', 'Active'),
(5, 1, 'Assign Lead', 'assign', 'Assign leads to users', 'Active'),
(6, 1, 'Export Leads', 'export', 'Export lead data', 'Active'),
(7, 1, 'View Customers', 'view', 'View customer records', 'Active'),
(8, 1, 'Add Customer', 'add', 'Create new customers', 'Active'),
(9, 1, 'Edit Customer', 'edit', 'Modify customer data', 'Active'),
(10, 1, 'Approve Quotation', 'approve', 'Approve quotations', 'Active'),
(11, 2, 'View Employees', 'view', 'View employee records', 'Active'),
(12, 2, 'Add Employee', 'add', 'Create new employee records', 'Active'),
(13, 2, 'Edit Employee', 'edit', 'Modify employee information', 'Active'),
(14, 2, 'Delete Employee', 'delete', 'Delete employee records', 'Active'),
(15, 2, 'View Attendance', 'view', 'View attendance records', 'Active'),
(16, 2, 'Manage Leave', 'edit', 'Approve/manage leave requests', 'Active'),
(17, 2, 'View Payroll', 'view', 'View payroll information', 'Active'),
(18, 2, 'Process Payroll', 'edit', 'Process salary and payroll', 'Active'),
(19, 3, 'View Accounts', 'view', 'View account records', 'Active'),
(20, 3, 'Add Invoice', 'add', 'Create invoices', 'Active'),
(21, 3, 'Approve Payment', 'approve', 'Approve payments', 'Active'),
(22, 3, 'View Reports', 'view', 'View financial reports', 'Active'),
(23, 4, 'View Projects', 'view', 'View projects', 'Active'),
(24, 4, 'Create Project', 'add', 'Create new projects', 'Active'),
(25, 4, 'Manage Tasks', 'edit', 'Assign and manage tasks', 'Active'),
(26, 4, 'Approve Project', 'approve', 'Approve project deliverables', 'Active'),
(27, 8, 'Manage Users', 'edit', 'Create and manage users', 'Active'),
(28, 8, 'Manage Roles', 'edit', 'Create and modify roles', 'Active'),
(29, 8, 'Manage Permissions', 'edit', 'Assign permissions to roles', 'Active'),
(30, 8, 'View Audit Logs', 'view', 'View system audit logs', 'Active');

-- Super Admin gets all permissions
INSERT IGNORE INTO role_permissions (role_id, permission_id, data_scope, status)
SELECT 1, id, 'all', 'Active' FROM permissions;

-- Admin company-level subset
INSERT IGNORE INTO role_permissions (role_id, permission_id, data_scope, status) VALUES
(2, 1, 'company', 'Active'), (2, 2, 'company', 'Active'), (2, 3, 'company', 'Active'),
(2, 7, 'company', 'Active'), (2, 8, 'company', 'Active'), (2, 9, 'company', 'Active'),
(2, 11, 'company', 'Active'), (2, 12, 'company', 'Active'), (2, 13, 'company', 'Active'),
(2, 15, 'company', 'Active'), (2, 16, 'company', 'Active'), (2, 17, 'company', 'Active'),
(2, 18, 'company', 'Active'), (2, 27, 'company', 'Active');

-- Manager department-level
INSERT IGNORE INTO role_permissions (role_id, permission_id, data_scope, status) VALUES
(3, 1, 'department', 'Active'), (3, 2, 'department', 'Active'), (3, 3, 'department', 'Active'),
(3, 5, 'department', 'Active'), (3, 7, 'department', 'Active'), (3, 9, 'department', 'Active'),
(3, 11, 'department', 'Active'), (3, 13, 'department', 'Active'), (3, 15, 'department', 'Active'),
(3, 23, 'department', 'Active'), (3, 25, 'department', 'Active');

-- Supervisor team-level
INSERT IGNORE INTO role_permissions (role_id, permission_id, data_scope, status) VALUES
(4, 1, 'team', 'Active'), (4, 2, 'team', 'Active'), (4, 3, 'team', 'Active'),
(4, 7, 'team', 'Active'), (4, 11, 'team', 'Active'), (4, 15, 'team', 'Active'),
(4, 23, 'team', 'Active'), (4, 25, 'team', 'Active');

-- Executive own-level
INSERT IGNORE INTO role_permissions (role_id, permission_id, data_scope, status) VALUES
(5, 1, 'own', 'Active'), (5, 2, 'own', 'Active'), (5, 3, 'own', 'Active'),
(5, 7, 'own', 'Active'), (5, 11, 'own', 'Active'), (5, 15, 'own', 'Active'),
(5, 23, 'own', 'Active');

-- View uses the real HRMS columns (department_name / designation_name).
-- NOTE: the old version referenced dept_name / desig_name which do not exist
-- in the HRMS tables, so this view (and anything reading it) failed to build.
CREATE OR REPLACE VIEW v_user_with_roles AS
SELECT
  e.id,
  CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as full_name,
  e.employee_code,
  e.official_email,
  e.mobile_number,
  d.department_name as dept_name,
  dg.designation_name as desig_name,
  r.role_name,
  r.role_level,
  e.employment_status,
  e.date_of_joining
FROM employees e
LEFT JOIN departments d ON e.department_id = d.id
LEFT JOIN designations dg ON e.designation_id = dg.id
LEFT JOIN user_roles ur ON e.id = ur.employee_id AND ur.status = 'Active'
LEFT JOIN roles r ON ur.role_id = r.id
WHERE e.employment_status = 'Active';
