-- =========================================================
-- Run this once if you already had SABHYTACRM installed
-- before the Lead Management + professional login update.
-- (Brand-new installs: schema.sql + schema_leads.sql already
-- include everything below — this file is only for upgrades.)
-- =========================================================

-- Adds a profile photo column to users, used by the redesigned
-- top-navbar avatar and the login/profile screens.
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS avatar_path VARCHAR(255) NULL AFTER role;

-- Everything else (leads, lead_followups, lead_status_history,
-- lead_source_settings, lead_webhook_logs) lives in
-- schema_leads.sql — import that file too if you haven't already:
--
--   mysql -u root sabhytacrm < database/schema_leads.sql
