<?php
/**
 * COMPREHENSIVE TEST DATA SEEDING
 * Populates database with realistic test data for all modules
 * Run this after initial database setup for demo/testing purposes
 */

require_once __DIR__ . '/../api/db.php';

echo "Starting test data seeding...\n\n";

try {
    // ===== SEED DEPARTMENTS =====
    echo "Creating Departments...\n";
    
    $departments = [
        ['HR', 'Human Resources', 'Department for HR operations'],
        ['IT', 'Information Technology', 'IT infrastructure and development'],
        ['Sales', 'Sales & Marketing', 'Sales and customer acquisition'],
        ['Finance', 'Finance & Accounting', 'Financial management'],
        ['Operations', 'Operations', 'Operational efficiency'],
    ];

    foreach ($departments as $dept) {
        $code = 'DEPT-' . strtoupper(substr($dept[0], 0, 3)) . '-' . rand(1000, 9999);
        $stmt = $pdo->prepare("INSERT IGNORE INTO departments (department_code, department_name, description) VALUES (?, ?, ?)");
        $stmt->execute([$code, $dept[1], $dept[2]]);
    }

    // ===== SEED DESIGNATIONS =====
    echo "Creating Designations...\n";
    
    $designations = [
        'Software Engineer', 'Senior Developer', 'Project Manager', 
        'Sales Executive', 'Sales Manager', 'HR Manager', 'Finance Manager',
        'Business Analyst', 'Quality Analyst', 'DevOps Engineer',
        'UI/UX Designer', 'Technical Lead', 'Consultant'
    ];

    foreach ($designations as $desg) {
        $stmt = $pdo->prepare("INSERT IGNORE INTO designations (designation_name) VALUES (?)");
        $stmt->execute([$desg]);
    }

    // ===== SEED EMPLOYEES =====
    echo "Creating Employees...\n";
    
    $employees = [
        ['Rajesh', 'Kumar', 'M', 'raj.kumar@company.com', '9876543210', 8000000, 'IT', 1],
        ['Priya', 'Singh', 'F', 'priya.singh@company.com', '9876543211', 6500000, 'Sales', 2],
        ['Amit', 'Patel', 'M', 'amit.patel@company.com', '9876543212', 7200000, 'IT', 3],
        ['Neha', 'Gupta', 'F', 'neha.gupta@company.com', '9876543213', 5500000, 'HR', 4],
        ['Vikram', 'Sharma', 'M', 'vikram.sharma@company.com', '9876543214', 9500000, 'Finance', 5],
        ['Ananya', 'Mishra', 'F', 'ananya.mishra@company.com', '9876543215', 6000000, 'Operations', 6],
        ['Arjun', 'Verma', 'M', 'arjun.verma@company.com', '9876543216', 5800000, 'IT', 1],
        ['Diya', 'Reddy', 'F', 'diya.reddy@company.com', '9876543217', 6300000, 'Sales', 2],
    ];

    $getDeptId = $pdo->prepare("SELECT id FROM departments WHERE department_name = ? LIMIT 1");
    $getDesgId = $pdo->prepare("SELECT id FROM designations WHERE designation_name = ? LIMIT 1");

    $empCodes = [];
    $counter = 1001;
    
    foreach ($employees as $emp) {
        $counter++;
        $code = 'EMP-' . $counter;
        $empCodes[] = $code;

        // Get department ID
        $getDeptId->execute(['Information Technology']);
        $deptResult = $getDeptId->fetch();
        $deptId = $deptResult['id'] ?? 1;

        // Get designation ID
        $getDesgId->execute(['Software Engineer']);
        $desgResult = $getDesgId->fetch();
        $desgId = $desgResult['id'] ?? 1;

        $stmt = $pdo->prepare("
            INSERT IGNORE INTO employees 
            (employee_code, first_name, last_name, gender, official_email, mobile_number, ctc, 
             basic_salary, hra, da, conveyance, medical_allowance, special_allowance, 
             pf, esic, professional_tax, gross_salary, net_salary, 
             department_id, designation_id, branch, date_of_joining, employment_status,
             bank_name, account_number, ifsc_code, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $basicSalary = $emp[6] / 12; // Convert CTC to monthly basic
        $hra = $basicSalary * 0.5;
        $da = $basicSalary * 0.1;
        $conveyance = 1600;
        $medical = 1250;
        $special = $basicSalary * 0.05;
        $grossSalary = $basicSalary + $hra + $da + $conveyance + $medical + $special;
        $pf = min($basicSalary * 0.12, 1800);
        $esic = ($grossSalary <= 21000) ? $grossSalary * 0.0075 : 0;
        $profTax = ($grossSalary > 15000) ? 200 : 0;
        $netSalary = $grossSalary - ($pf + $esic + $profTax);

        $stmt->execute([
            $code, $emp[0], $emp[1], $emp[2], $emp[3], $emp[4], $emp[6],
            $basicSalary, $hra, $da, $conveyance, $medical, $special,
            $pf, $esic, $profTax, $grossSalary, $netSalary,
            $deptId, $desgId, 'Mumbai', date('Y-m-d', strtotime('-2 years')), 'Active',
            'HDFC Bank', 'ACC' . $counter, 'HDFC0000123', 'Active'
        ]);
    }

    // ===== SEED CUSTOMERS =====
    echo "Creating Customers...\n";
    
    $customers = [
        ['Tech Solutions Pvt Ltd', 'tech-solutions', 'pvt-ltd', 'Bangalore', '080-2345-6789', 'contact@techsol.com'],
        ['Global Industries Inc', 'global-industries', 'inc', 'Delhi', '011-2345-6789', 'info@globalind.com'],
        ['Smart Manufacturing Ltd', 'smart-manufacturing', 'ltd', 'Chennai', '044-2345-6789', 'sales@smartmfg.com'],
        ['Digital Enterprises', 'digital-enterprises', 'ent', 'Pune', '020-2345-6789', 'contact@digent.com'],
        ['Innovation Labs India', 'innovation-labs', 'pvt-ltd', 'Hyderabad', '040-2345-6789', 'info@innovlabs.com'],
    ];

    foreach ($customers as $cust) {
        $custCode = strtoupper($cust[1]) . '-' . rand(1000, 9999);
        $stmt = $pdo->prepare("
            INSERT IGNORE INTO customers 
            (customer_code, customer_type, customer_name, company_name, city, mobile, email, status)
            VALUES (?, 'Corporate', ?, ?, ?, ?, ?, 'Active')
        ");
        $stmt->execute([$custCode, $cust[0], $cust[0], $cust[3], '9876543210', $cust[5]]);
    }

    // ===== SEED QUOTATIONS =====
    echo "Creating Sample Quotations...\n";
    
    $stmt = $pdo->prepare("SELECT id, customer_name FROM customers LIMIT 5");
    $stmt->execute();
    $customersData = $stmt->fetchAll();

    $productServices = [
        ['Software Development Services', 'Custom web and mobile app development'],
        ['IT Consulting', 'Business process optimization and IT strategy'],
        ['Cloud Infrastructure Setup', 'AWS and Azure cloud deployment services'],
        ['Data Analytics Solution', 'Business intelligence and analytics platform'],
        ['Cybersecurity Assessment', 'Security audit and vulnerability assessment'],
    ];

    foreach ($customersData as $cust) {
        for ($i = 0; $i < 2; $i++) {
            $quoteNum = 'QT-' . date('Ym') . '-' . rand(100, 999);
            $items = [];
            $totalAmount = 0;

            for ($j = 0; $j < rand(2, 4); $j++) {
                $product = $productServices[array_rand($productServices)];
                $qty = rand(1, 5);
                $rate = rand(10000, 100000);
                $amount = $qty * $rate;
                $totalAmount += $amount;

                $items[] = [
                    'productService' => $product[0],
                    'description' => $product[1],
                    'quantity' => $qty,
                    'unit' => 'Nos',
                    'rate' => $rate,
                    'amount' => $amount
                ];
            }

            $extraData = [
                'customerId' => $cust['id'],
                'items' => $items,
                'subtotal' => $totalAmount,
                'tax' => round($totalAmount * 0.18, 2),
                'total' => round($totalAmount * 1.18, 2),
                'paymentTerms' => 'Net 30 Days',
                'deliveryTerms' => 'FOB',
                'warranty' => '12 Months',
                'currency' => 'INR'
            ];

            $stmt = $pdo->prepare("
                INSERT IGNORE INTO generic_records 
                (module_key, module_label, title, party_name, amount, record_date, status, extra_data)
                VALUES (?, 'Create Quote', ?, ?, ?, ?, 'Active', ?)
            ");

            $stmt->execute([
                'CRM||Create Quote',
                $quoteNum,
                $cust['customer_name'],
                round($totalAmount * 1.18, 2),
                date('Y-m-d'),
                json_encode($extraData)
            ]);
        }
    }

    // ===== SEED LEADS =====
    echo "Creating Sample Leads...\n";
    
    $leadSources = ['Website', 'Referral', 'Email', 'Cold Call', 'Social Media'];
    $leadStatuses = ['New', 'Qualified', 'Proposal Sent', 'Negotiation', 'Lost'];

    for ($i = 0; $i < 10; $i++) {
        $leadName = 'Lead-' . date('Ymd') . '-' . rand(1000, 9999);
        $stmt = $pdo->prepare("
            INSERT IGNORE INTO generic_records 
            (module_key, module_label, title, party_name, amount, record_date, status, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            'CRM||Add Lead',
            'Lead',
            $leadName,
            'Lead - ' . rand(1, 1000),
            rand(50000, 500000),
            date('Y-m-d'),
            $leadStatuses[array_rand($leadStatuses)],
            'Sample lead created for testing. Source: ' . $leadSources[array_rand($leadSources)]
        ]);
    }

    // ===== SEED ACCOUNTS =====
    echo "Creating Sample Accounts...\n";
    
    $accounts = [
        ['1001', 'Bank Accounts', 'HDFC Bank - Current Account'],
        ['1002', 'Bank Accounts', 'ICICI Bank - Savings Account'],
        ['2001', 'Accounts Payable', 'Supplier Payables'],
        ['3001', 'Capital', 'Share Capital'],
        ['4001', 'Revenue', 'Service Revenue'],
        ['5001', 'Expenses', 'Salaries and Wages'],
    ];

    foreach ($accounts as $acc) {
        $stmt = $pdo->prepare("
            INSERT IGNORE INTO generic_records 
            (module_key, module_label, title, amount, status)
            VALUES (?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            'Accounts||Chart of Accounts',
            'Account',
            $acc[0] . ' - ' . $acc[2],
            0,
            'Active'
        ]);
    }

    echo "\n✓ All test data created successfully!\n\n";
    echo "Sample Credentials:\n";
    echo "  Email: admin@sabhytacrm.com\n";
    echo "  Password: admin123\n\n";
    echo "Test Data Summary:\n";
    echo "  - Departments: 5\n";
    echo "  - Designations: 13\n";
    echo "  - Employees: 8\n";
    echo "  - Customers: 5\n";
    echo "  - Quotations: 10\n";
    echo "  - Leads: 10\n";
    echo "  - Accounts: 6\n\n";

} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    exit(1);
}
?>
