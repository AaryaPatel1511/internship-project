-- =========================================================
-- SABHYTACRM — HRMS + Sales extension schema
-- ---------------------------------------------------------
-- Run this ONCE against your existing sabhytacrm database,
-- AFTER database/schema.sql (phpMyAdmin -> Import, or
-- `mysql -u root -p sabhytacrm < database/schema_hrms_sales.sql`).
--
-- Adds real, dedicated tables for the highest-value HRMS/Sales
-- modules (mirrors how `customers` already works):
--   - departments   (HRMS > Department)
--   - designations  (HRMS > Designation)
--   - employees     (HRMS > Employee)  <-- master data
--   - sales_orders  (Sales > Sales Order, with line items as JSON)
--
-- Every OTHER HRMS/Sales leaf item (Recruitment, Internship,
-- Attendance, Leave, Holidays, Payroll, Salary, Bonus, Incentive,
-- Performance, Appraisal, Exit Process, Experience Letter, ID Card,
-- Documents, Proforma Invoice, Invoice, Receipt, Payment) continues
-- to use the existing `generic_records` table (module_key prefixed
-- "hrms__" / "sales__") with its full field set stored as JSON in
-- `extra_data` — exactly the same pattern already used by "Create
-- Quote". This keeps every employee/department/customer/sales-order
-- reference in those forms a REAL, live foreign-key style lookup
-- against the tables below, without needing ~20 bespoke tables.
-- =========================================================

USE sabhytacrm;

-- ---------------------------------------------------------
-- departments
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS departments (
  id                 INT AUTO_INCREMENT PRIMARY KEY,
  department_code    VARCHAR(50) NOT NULL,
  department_name    VARCHAR(150) NOT NULL,
  department_head_id INT NULL,          -- soft-reference -> employees.id
  parent_department_id INT NULL,        -- soft-reference -> departments.id
  description        TEXT,
  status             VARCHAR(20) DEFAULT 'Active',
  created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_department_code (department_code)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- designations
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS designations (
  id                    INT AUTO_INCREMENT PRIMARY KEY,
  designation_name      VARCHAR(150) NOT NULL,
  department_id         INT NULL,       -- soft-reference -> departments.id
  reporting_manager_id  INT NULL,       -- soft-reference -> employees.id
  salary_grade          VARCHAR(50),
  job_description       TEXT,
  responsibilities      TEXT,
  status                VARCHAR(20) DEFAULT 'Active',
  created_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- employees  (HRMS > Employee) — master data. Every other
-- HRMS/Sales form's "Employee" dropdown pulls live from here.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS employees (
  id                        INT AUTO_INCREMENT PRIMARY KEY,

  -- Personal Information
  employee_code             VARCHAR(50) NOT NULL,
  employee_type             VARCHAR(30),   -- Permanent / Contract / Internship / Consultant
  employment_status         VARCHAR(30) DEFAULT 'Active', -- Active/Resigned/Terminated/On Notice
  first_name                VARCHAR(100) NOT NULL,
  middle_name               VARCHAR(100),
  last_name                 VARCHAR(100),
  gender                    VARCHAR(20),
  date_of_birth             DATE,
  blood_group               VARCHAR(10),
  marital_status            VARCHAR(20),
  nationality               VARCHAR(50),
  aadhaar_number            VARCHAR(20),
  pan_number                VARCHAR(20),
  passport_number           VARCHAR(30),
  driving_license           VARCHAR(30),
  voter_id                  VARCHAR(30),
  uan_number                VARCHAR(30),
  esic_number               VARCHAR(30),
  passport_expiry           DATE,
  mobile_number             VARCHAR(20) NOT NULL,
  alternate_mobile          VARCHAR(20),
  personal_email            VARCHAR(150),
  official_email            VARCHAR(150),
  emergency_contact_name    VARCHAR(100),
  emergency_contact_number  VARCHAR(20),
  relationship              VARCHAR(50),
  photograph_file           VARCHAR(255),

  -- Address Details
  current_address           TEXT,
  permanent_address         TEXT,
  city                      VARCHAR(100),
  district                  VARCHAR(100),
  state                     VARCHAR(100),
  country                   VARCHAR(100) DEFAULT 'India',
  pincode                   VARCHAR(10),

  -- Employment Details
  department_id             INT NULL,     -- soft-reference -> departments.id
  designation_id             INT NULL,    -- soft-reference -> designations.id
  reporting_manager_id       INT NULL,    -- soft-reference -> employees.id
  branch                     VARCHAR(100),
  office_location            VARCHAR(150),
  date_of_joining            DATE,
  date_of_confirmation       DATE,
  employee_grade             VARCHAR(30),
  employment_category        VARCHAR(50),
  work_shift                 VARCHAR(50),
  weekly_off                 VARCHAR(50),
  probation_period           VARCHAR(30),
  notice_period               VARCHAR(30),
  ctc                         DECIMAL(15,2),
  basic_salary                DECIMAL(15,2),
  -- Auto-calculated Salary Breakup (see hrms_sales.js computeSalaryBreakup) --
  -- Every earning/deduction head below is derived from Basic Salary and the
  -- employee's Metro/Non-Metro city (Delhi/Mumbai/Kolkata/Chennai = Metro):
  --   HRA          50% (Metro) / 40% (Non-Metro) of Basic
  --   DA           10% of Basic
  --   Conveyance   ₹1,600/month (Metro) / ₹1,000/month (Non-Metro)
  --   Medical Allowance  ₹1,250/month flat
  --   Special Allowance  5% (Metro) / 3% (Non-Metro) of Basic
  --   PF           12% of Basic, capped at the statutory ₹15,000 wage ceiling
  --   ESIC         0.75% of Gross when Gross <= ₹21,000/month, else 0
  --   Professional Tax  flat ₹200/month slab when Gross > ₹15,000 (varies by state)
  -- Everything here is MONTHLY; the Yearly/Annual figures shown on the
  -- Employee form and HRMS > Salary are simply these values x 12 and are
  -- not stored separately. Kept as real columns (not extra_data) so every
  -- "Salary" lookup can read them fast, and every value stays editable so
  -- HR can override per state/company policy.
  hra                          DECIMAL(15,2),
  da                           DECIMAL(15,2),
  conveyance                   DECIMAL(15,2),
  medical_allowance            DECIMAL(15,2),
  special_allowance            DECIMAL(15,2),
  pf                           DECIMAL(15,2),
  esic                         DECIMAL(15,2),
  professional_tax             DECIMAL(15,2),
  gross_salary                 DECIMAL(15,2),
  net_salary                   DECIMAL(15,2),
  bank_name                   VARCHAR(100),
  account_number              VARCHAR(50),
  ifsc_code                   VARCHAR(20),

  -- Repeatable sections stored as JSON (Educational Qualification[],
  -- Work Experience[]) — same pattern generic_records.extra_data uses.
  education_json              LONGTEXT,
  experience_json              LONGTEXT,

  status                       VARCHAR(20) DEFAULT 'Active',

  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_employee_code (employee_code)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- sales_orders  (Sales > Sales Order) — line items + financial
-- summary stored as JSON, header fields as real columns so the
-- Customer/Employee links stay queryable, and so Proforma
-- Invoice / Invoice / Receipt / Payment forms can look up a
-- Sales Order live by number.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS sales_orders (
  id                     INT AUTO_INCREMENT PRIMARY KEY,

  sales_order_number     VARCHAR(50) NOT NULL,
  order_date             DATE,
  quotation_number       VARCHAR(50),
  customer_id            INT NULL,        -- soft-reference -> customers.id
  contact_person         VARCHAR(150),
  customer_po_number     VARCHAR(100),
  customer_po_date       DATE,
  project_name           VARCHAR(150),
  project_code           VARCHAR(50),
  site_location          VARCHAR(200),
  sales_executive_id     INT NULL,        -- soft-reference -> employees.id
  department_id          INT NULL,        -- soft-reference -> departments.id
  branch                 VARCHAR(100),
  currency               VARCHAR(10) DEFAULT 'INR',
  payment_terms          VARCHAR(100),
  delivery_terms         VARCHAR(100),
  delivery_address       TEXT,
  billing_address        TEXT,
  shipping_address       TEXT,
  freight_terms          VARCHAR(100),
  insurance              VARCHAR(10),
  warranty               VARCHAR(150),
  installation_required  VARCHAR(10),
  amc_required           VARCHAR(10),
  expected_delivery_date DATE,
  priority               VARCHAR(20) DEFAULT 'Medium',
  order_status           VARCHAR(30) DEFAULT 'Pending',
  internal_notes         TEXT,
  customer_notes         TEXT,

  items_json             LONGTEXT,        -- Sales Order Items[]
  attachments_json        LONGTEXT,       -- which attachment types are included

  sub_total               DECIMAL(15,2) DEFAULT 0,
  discount_total           DECIMAL(15,2) DEFAULT 0,
  tax_amount               DECIMAL(15,2) DEFAULT 0,
  freight_charges          DECIMAL(15,2) DEFAULT 0,
  installation_charges     DECIMAL(15,2) DEFAULT 0,
  packing_charges          DECIMAL(15,2) DEFAULT 0,
  insurance_charges        DECIMAL(15,2) DEFAULT 0,
  other_charges            DECIMAL(15,2) DEFAULT 0,
  round_off                DECIMAL(10,2) DEFAULT 0,
  grand_total              DECIMAL(15,2) DEFAULT 0,

  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_sales_order_number (sales_order_number)
) ENGINE=InnoDB;
