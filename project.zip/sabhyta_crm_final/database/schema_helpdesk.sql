-- =========================================================
-- SABHYTACRM · HELPDESK MODULE SCHEMA
-- Import this AFTER database/schema.sql (same way schema_leads.sql
-- is imported for Lead Management — phpMyAdmin > Import, or:
--   mysql -u root sabhytacrm < database/schema_helpdesk.sql
--
-- Covers every sidebar leaf under "Helpdesk":
--   Tickets, Complaints, Support, AMC, Remote Support,
--   Priority, SLA, Resolution
-- Mirrors the flow/fields in HelpDesk_Management.pdf exactly.
-- =========================================================

USE sabhytacrm;

-- ---------------------------------------------------------
-- 6. PRIORITY (master) — Low/Medium/High/Critical with the
-- default response/resolution targets from the PDF. Admin
-- can edit these, so nothing is hard-coded in PHP/JS.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS helpdesk_priorities (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  name                VARCHAR(30)  NOT NULL UNIQUE,   -- Low / Medium / High / Critical
  response_minutes    INT NOT NULL DEFAULT 480,
  resolution_minutes  INT NOT NULL DEFAULT 1440,
  color               VARCHAR(20)  DEFAULT '#8f97a8',
  sort_order          INT DEFAULT 0,
  status              VARCHAR(20)  DEFAULT 'Active',
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO helpdesk_priorities (name, response_minutes, resolution_minutes, color, sort_order) VALUES
  ('Low',      480, 1440, '#14b8a6', 1),
  ('Medium',   120,  480, '#e08c1c', 2),
  ('High',      30,  240, '#ff6b4a', 3),
  ('Critical',  15,  120, '#e0384c', 4)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- ---------------------------------------------------------
-- 7. SLA (master) — Service Level Agreements, optionally
-- overriding the plain priority targets per customer type.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS helpdesk_sla (
  id                   INT AUTO_INCREMENT PRIMARY KEY,
  sla_code             VARCHAR(30) NOT NULL UNIQUE,      -- SLA-001
  sla_name             VARCHAR(100) NOT NULL,             -- Premium Support
  customer_type        VARCHAR(50),                       -- Premium / Standard / Basic
  priority_id          INT,
  response_minutes     INT NOT NULL,
  resolution_minutes   INT NOT NULL,
  working_hours        VARCHAR(50) DEFAULT '9 AM-6 PM',
  working_days         VARCHAR(50) DEFAULT 'Mon-Sat',
  escalation_level1    VARCHAR(100) DEFAULT 'Support Manager',
  escalation_level2    VARCHAR(100) DEFAULT 'Department Head',
  escalation_level3    VARCHAR(100) DEFAULT 'Management',
  status               VARCHAR(20) DEFAULT 'Active',
  created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_sla_priority FOREIGN KEY (priority_id) REFERENCES helpdesk_priorities(id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO helpdesk_sla (sla_code, sla_name, customer_type, priority_id, response_minutes, resolution_minutes)
SELECT 'SLA-001', 'Standard Support', 'Standard', id, response_minutes, resolution_minutes
FROM helpdesk_priorities WHERE name = 'Medium'
ON DUPLICATE KEY UPDATE sla_code = VALUES(sla_code);

-- ---------------------------------------------------------
-- 4. AMC — Annual Maintenance Contract (created before
-- tickets so helpdesk_tickets can reference it)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS helpdesk_amc_contracts (
  id                 INT AUTO_INCREMENT PRIMARY KEY,
  amc_code           VARCHAR(30) NOT NULL UNIQUE,        -- AMC-2026-001
  customer_id        INT NULL,
  customer_name      VARCHAR(150) NOT NULL,
  contract_no        VARCHAR(60),
  start_date         DATE NOT NULL,
  end_date           DATE NOT NULL,
  amc_value          DECIMAL(15,2) DEFAULT 0,
  billing_frequency  VARCHAR(20) DEFAULT 'Annual',        -- Monthly/Quarterly/Annual
  service_type       VARCHAR(100),
  covered_products   VARCHAR(255),
  support_hours      VARCHAR(50) DEFAULT '9 AM-6 PM',
  visit_included     TINYINT(1) DEFAULT 1,
  remote_support     TINYINT(1) DEFAULT 1,
  onsite_support     TINYINT(1) DEFAULT 1,
  number_of_visits   INT DEFAULT 0,
  sla_id             INT NULL,
  assigned_team      VARCHAR(100),
  contract_status    VARCHAR(20) DEFAULT 'Active',         -- Active/Expired
  renewal_date       DATE,
  created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_amc_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
  CONSTRAINT fk_amc_sla FOREIGN KEY (sla_id) REFERENCES helpdesk_sla(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- 1. TICKETS — the central record. Ticket flow, SLA
-- calculation and AMC linkage all hang off this table.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS helpdesk_tickets (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  ticket_no           VARCHAR(30) NOT NULL UNIQUE,         -- TKT-2026-00001
  customer_id         INT NULL,
  customer_name       VARCHAR(150) NOT NULL,
  contact_person      VARCHAR(100),
  contact_number      VARCHAR(20),
  email               VARCHAR(150),
  product_service     VARCHAR(150),
  category            VARCHAR(30) DEFAULT 'Other',          -- Software/Hardware/Network/Website/Other
  subject             VARCHAR(200) NOT NULL,
  description         TEXT,
  attachment_path     VARCHAR(255),
  source              VARCHAR(30) DEFAULT 'Phone',           -- Phone/Email/WhatsApp/Website/Portal
  priority_id         INT NULL,
  assigned_department VARCHAR(100),
  assigned_employee   VARCHAR(100),
  amc_id              INT NULL,
  sla_id              INT NULL,
  ticket_status       VARCHAR(20) DEFAULT 'Open',            -- Open/Assigned/In Progress/Pending/Resolved/Closed
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  due_at              DATETIME NULL,
  resolved_at         DATETIME NULL,
  closed_at           DATETIME NULL,
  resolution          TEXT,
  customer_feedback   VARCHAR(255),
  updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_ticket_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
  CONSTRAINT fk_ticket_priority FOREIGN KEY (priority_id) REFERENCES helpdesk_priorities(id) ON DELETE SET NULL,
  CONSTRAINT fk_ticket_amc      FOREIGN KEY (amc_id)      REFERENCES helpdesk_amc_contracts(id) ON DELETE SET NULL,
  CONSTRAINT fk_ticket_sla      FOREIGN KEY (sla_id)      REFERENCES helpdesk_sla(id) ON DELETE SET NULL,
  INDEX idx_ticket_status (ticket_status),
  INDEX idx_ticket_due (due_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- 2. COMPLAINTS — formal dissatisfaction reports, normally
-- linked to a Ticket.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS helpdesk_complaints (
  id                       INT AUTO_INCREMENT PRIMARY KEY,
  complaint_no             VARCHAR(30) NOT NULL UNIQUE,      -- CMP-2026-00001
  customer_id              INT NULL,
  customer_name            VARCHAR(150) NOT NULL,
  contact_person           VARCHAR(100),
  complaint_date           DATE NOT NULL,
  complaint_type           VARCHAR(50),
  subject                  VARCHAR(200) NOT NULL,
  description              TEXT,
  related_ticket_id        INT NULL,
  product_service          VARCHAR(150),
  complaint_source         VARCHAR(30) DEFAULT 'Phone',
  priority_id              INT NULL,
  assigned_employee        VARCHAR(100),
  department                VARCHAR(100),
  expected_resolution_date  DATE,
  complaint_status          VARCHAR(20) DEFAULT 'New',        -- New/Under Review/Assigned/Investigation/Action Taken/Resolved/Closed
  escalation_level          VARCHAR(20) DEFAULT 'None',
  resolution                 TEXT,
  customer_remarks           VARCHAR(255),
  attachment_path             VARCHAR(255),
  created_by                  VARCHAR(100),
  created_at                  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  closed_at                   DATETIME NULL,
  CONSTRAINT fk_complaint_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
  CONSTRAINT fk_complaint_ticket   FOREIGN KEY (related_ticket_id) REFERENCES helpdesk_tickets(id) ON DELETE SET NULL,
  CONSTRAINT fk_complaint_priority FOREIGN KEY (priority_id) REFERENCES helpdesk_priorities(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- 3. SUPPORT — the operational work log tied to a ticket.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS helpdesk_support_activities (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  support_no          VARCHAR(30) NOT NULL UNIQUE,          -- SUP-2026-00001
  ticket_id           INT NOT NULL,
  customer_name       VARCHAR(150),
  assigned_employee   VARCHAR(100),
  support_type        VARCHAR(40) DEFAULT 'Technical Support',
  start_time          DATETIME,
  end_time            DATETIME,
  work_description    TEXT,
  time_spent_minutes  INT DEFAULT 0,
  action_taken        TEXT,
  parts_used          VARCHAR(255),
  internal_remarks    TEXT,
  customer_remarks    VARCHAR(255),
  attachment_path     VARCHAR(255),
  next_followup_date  DATE,
  support_status      VARCHAR(20) DEFAULT 'Open',            -- Open/In Progress/Resolved/On Hold
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_support_ticket FOREIGN KEY (ticket_id) REFERENCES helpdesk_tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- 5. REMOTE SUPPORT sessions.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS helpdesk_remote_sessions (
  id                   INT AUTO_INCREMENT PRIMARY KEY,
  session_no           VARCHAR(30) NOT NULL UNIQUE,          -- RS-2026-00001
  ticket_id            INT NOT NULL,
  customer_name        VARCHAR(150),
  contact_person       VARCHAR(100),
  support_engineer     VARCHAR(100),
  remote_tool          VARCHAR(60),                           -- AnyDesk/TeamViewer/Chrome Remote Desktop/Phone...
  start_time           DATETIME,
  end_time             DATETIME,
  duration_minutes     INT DEFAULT 0,
  customer_permission  TINYINT(1) DEFAULT 0,
  problem_description  TEXT,
  action_taken         TEXT,
  files_transferred    VARCHAR(255),
  attachment_path      VARCHAR(255),
  resolution           TEXT,
  customer_confirmation TINYINT(1) DEFAULT 0,
  session_status        VARCHAR(20) DEFAULT 'Scheduled',      -- Scheduled/In Progress/Completed/Cancelled
  created_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_remote_ticket FOREIGN KEY (ticket_id) REFERENCES helpdesk_tickets(id) ON DELETE CASCADE
  -- NOTE per PDF: never add a "remote access password" column here.
  -- If a credential must be captured, store it in a proper secrets
  -- manager / vault, never in this table.
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- 8. RESOLUTION — final technical solution per ticket.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS helpdesk_resolutions (
  id                    INT AUTO_INCREMENT PRIMARY KEY,
  resolution_no         VARCHAR(30) NOT NULL UNIQUE,          -- RES-2026-00001
  ticket_id             INT NOT NULL,
  customer_name         VARCHAR(150),
  problem_summary       TEXT,
  root_cause            TEXT,
  troubleshooting       TEXT,
  action_taken          TEXT,
  final_solution        TEXT,
  technician            VARCHAR(100),
  start_time            DATETIME,
  end_time              DATETIME,
  total_time_minutes    INT DEFAULT 0,
  parts_used            VARCHAR(255),
  attachment_path       VARCHAR(255),
  kb_article             VARCHAR(255),
  customer_confirmation  TINYINT(1) DEFAULT 0,
  customer_rating         TINYINT NULL,
  resolution_date          DATE,
  closed_by                VARCHAR(100),
  created_at                TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_resolution_ticket FOREIGN KEY (ticket_id) REFERENCES helpdesk_tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Helper view: ticket + priority + SLA + live breach flag,
-- used by the Tickets list and the dashboard KPI cards so
-- "SLA Breached" is calculated dynamically, not stored.
-- ---------------------------------------------------------
CREATE OR REPLACE VIEW v_helpdesk_tickets AS
SELECT
  t.*,
  p.name AS priority_name,
  s.sla_name,
  CASE
    WHEN t.ticket_status IN ('Resolved','Closed') THEN 'Met'
    WHEN t.due_at IS NOT NULL AND NOW() > t.due_at THEN 'Breached'
    WHEN t.due_at IS NOT NULL AND TIMESTAMPDIFF(MINUTE, NOW(), t.due_at) <= 60 THEN 'Nearing Breach'
    ELSE 'On Track'
  END AS sla_flag
FROM helpdesk_tickets t
LEFT JOIN helpdesk_priorities p ON p.id = t.priority_id
LEFT JOIN helpdesk_sla s ON s.id = t.sla_id;
