-- =========================================================
-- Migration: add Salary Breakup columns to employees
-- ---------------------------------------------------------
-- Run this ONCE against your existing sabhytacrm database
-- (phpMyAdmin -> SQL tab, or
-- `mysql -u USER -p sabhytacrm < database/migration_add_salary_breakup.sql`).
--
-- Needed for the new "Salary Breakup (Auto-Calculated)" panel on the
-- Employee form (Employment Details -> Basic Salary / CTC), and for
-- HRMS > Salary to pull each employee's saved Basic/HRA/DA/PF/Net
-- straight from here. Safe to run even on a fresh install created from
-- the latest schema_hrms_sales.sql -- MySQL will just report "duplicate
-- column" for anything already present, which you can ignore.
-- =========================================================

USE sabhytacrm;

ALTER TABLE employees
  ADD COLUMN hra          DECIMAL(15,2) NULL AFTER basic_salary,
  ADD COLUMN da           DECIMAL(15,2) NULL AFTER hra,
  ADD COLUMN pf           DECIMAL(15,2) NULL AFTER da,
  ADD COLUMN gross_salary DECIMAL(15,2) NULL AFTER pf,
  ADD COLUMN net_salary   DECIMAL(15,2) NULL AFTER gross_salary;
