-- Extended User Profile and Employee Self Service

-- My Profile/Employee Master Extended
CREATE TABLE IF NOT EXISTS employee_profiles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE,
    employee_id INT UNIQUE,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    middle_name VARCHAR(100),
    date_of_birth DATE,
    gender VARCHAR(20),
    personal_email VARCHAR(100),
    personal_phone VARCHAR(15),
    work_email VARCHAR(100) UNIQUE,
    work_phone VARCHAR(15),
    personal_address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    postal_code VARCHAR(10),
    country VARCHAR(100),
    emergency_contact_name VARCHAR(100),
    emergency_contact_phone VARCHAR(15),
    emergency_contact_relation VARCHAR(50),
    bank_account_number VARCHAR(50),
    bank_name VARCHAR(100),
    bank_ifsc VARCHAR(10),
    pan_number VARCHAR(10),
    aadhar_number VARCHAR(12),
    passport_number VARCHAR(30),
    profile_photo VARCHAR(255),
    department_id INT,
    designation_id INT,
    manager_id INT,
    employment_type VARCHAR(50),
    joining_date DATE,
    exit_date DATE,
    employment_status ENUM('active','on_leave','terminated','resigned') DEFAULT 'active',
    created_by INT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_by INT,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (employee_id), INDEX (user_id), INDEX (employment_status)
);

-- Password Management
CREATE TABLE IF NOT EXISTS password_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    password_hash VARCHAR(255),
    changed_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    changed_by INT,
    is_current BOOLEAN DEFAULT TRUE,
    INDEX (user_id),
    INDEX (changed_date)
);

-- Password Reset Tokens
CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    token VARCHAR(255) UNIQUE,
    token_hash VARCHAR(255),
    expires_at TIMESTAMP,
    used BOOLEAN DEFAULT FALSE,
    used_date DATETIME,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (user_id), INDEX (expires_at)
);

-- Attendance Records
CREATE TABLE IF NOT EXISTS attendance_records (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    shift_id INT,
    check_in_time DATETIME,
    check_out_time DATETIME,
    break_start DATETIME,
    break_end DATETIME,
    total_hours DECIMAL(5,2),
    work_mode VARCHAR(50),
    location VARCHAR(255),
    status ENUM('present','absent','on_leave','holiday','late','incomplete') DEFAULT 'present',
    is_regularized BOOLEAN DEFAULT FALSE,
    original_check_in DATETIME,
    original_check_out DATETIME,
    regularization_reason TEXT,
    regularization_date DATETIME,
    regularization_approver_id INT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_attendance (employee_id, attendance_date),
    INDEX (employee_id), INDEX (attendance_date), INDEX (status)
);

-- Shift Master
CREATE TABLE IF NOT EXISTS shifts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    company_id INT NOT NULL,
    shift_name VARCHAR(100),
    shift_code VARCHAR(20),
    start_time TIME,
    end_time TIME,
    break_duration INT,
    working_hours DECIMAL(5,2),
    is_flexible BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (company_id)
);

-- Holiday Calendar
CREATE TABLE IF NOT EXISTS holiday_calendar (
    id INT PRIMARY KEY AUTO_INCREMENT,
    company_id INT NOT NULL,
    branch_id INT,
    holiday_date DATE NOT NULL,
    holiday_name VARCHAR(100),
    holiday_type VARCHAR(50),
    is_paid BOOLEAN DEFAULT TRUE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_holiday (company_id, holiday_date),
    INDEX (company_id), INDEX (holiday_date)
);

-- Leave Types
CREATE TABLE IF NOT EXISTS leave_types (
    id INT PRIMARY KEY AUTO_INCREMENT,
    company_id INT NOT NULL,
    leave_type_name VARCHAR(100),
    leave_code VARCHAR(20),
    is_paid BOOLEAN DEFAULT TRUE,
    max_days_per_year INT,
    max_continuous_days INT,
    requires_document BOOLEAN DEFAULT FALSE,
    applicable_employee_type VARCHAR(100),
    carryforward_allowed BOOLEAN DEFAULT FALSE,
    carryforward_limit INT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (company_id)
);

-- Leave Requests
CREATE TABLE IF NOT EXISTS leave_requests (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    is_full_day BOOLEAN DEFAULT TRUE,
    half_day_type VARCHAR(20),
    duration_days DECIMAL(5,2),
    reason TEXT,
    attachments VARCHAR(255),
    approver_id INT,
    approval_date DATETIME,
    approval_status ENUM('pending','approved','rejected','cancelled','withdrawal_pending') DEFAULT 'pending',
    approval_reason TEXT,
    balance_before DECIMAL(5,2),
    balance_after DECIMAL(5,2),
    created_by INT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_by INT,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (employee_id), INDEX (start_date), INDEX (approval_status)
);

-- Leave Balance Ledger
CREATE TABLE IF NOT EXISTS leave_balance_ledger (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    financial_year VARCHAR(10),
    opening_balance DECIMAL(5,2),
    earned DECIMAL(5,2),
    carryforward DECIMAL(5,2),
    used DECIMAL(5,2),
    closing_balance DECIMAL(5,2),
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_leave_balance (employee_id, leave_type_id, financial_year),
    INDEX (employee_id), INDEX (financial_year)
);

-- My Tasks/Task Management
CREATE TABLE IF NOT EXISTS employee_tasks (
    id INT PRIMARY KEY AUTO_INCREMENT,
    task_code VARCHAR(50),
    task_title VARCHAR(255),
    task_description TEXT,
    project_id INT,
    customer_id INT,
    assigned_to INT,
    assigned_by INT,
    priority ENUM('low','medium','high','critical') DEFAULT 'medium',
    status ENUM('assigned','in_progress','submitted_for_review','completed','blocked','rejected') DEFAULT 'assigned',
    due_date DATE,
    estimated_hours DECIMAL(10,2),
    actual_hours DECIMAL(10,2),
    dependencies INT,
    blocked_reason TEXT,
    rejection_reason TEXT,
    parent_task_id INT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_date DATETIME,
    review_submitted_date DATETIME,
    review_accepted_date DATETIME,
    accepted_by INT,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (assigned_to), INDEX (status), INDEX (due_date), INDEX (project_id)
);

-- Time Entries
CREATE TABLE IF NOT EXISTS time_entries (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    task_id INT NOT NULL,
    project_id INT,
    work_date DATE NOT NULL,
    hours_logged DECIMAL(10,2),
    is_billable BOOLEAN DEFAULT TRUE,
    description TEXT,
    status ENUM('draft','submitted','approved','rejected') DEFAULT 'draft',
    approved_by INT,
    approved_date DATETIME,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_time_entry (employee_id, task_id, work_date),
    INDEX (employee_id), INDEX (work_date), INDEX (status)
);

-- Notifications
CREATE TABLE IF NOT EXISTS notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    recipient_user_id INT NOT NULL,
    event_type VARCHAR(100),
    related_record_type VARCHAR(50),
    related_record_id INT,
    message_template_id INT,
    message_content TEXT,
    message_title VARCHAR(255),
    priority ENUM('low','medium','high','critical') DEFAULT 'medium',
    notification_channel VARCHAR(50),
    is_read BOOLEAN DEFAULT FALSE,
    read_date DATETIME,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    delivery_status ENUM('pending','sent','failed','bounced') DEFAULT 'pending',
    sent_date DATETIME,
    action_link VARCHAR(255),
    action_required BOOLEAN DEFAULT FALSE,
    preference_id INT,
    INDEX (recipient_user_id), INDEX (event_type), INDEX (is_read), INDEX (created_date)
);

-- Notification Preferences
CREATE TABLE IF NOT EXISTS notification_preferences (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL UNIQUE,
    email_notifications BOOLEAN DEFAULT TRUE,
    sms_notifications BOOLEAN DEFAULT FALSE,
    in_app_notifications BOOLEAN DEFAULT TRUE,
    daily_digest BOOLEAN DEFAULT FALSE,
    weekly_digest BOOLEAN DEFAULT TRUE,
    preferred_time TIME,
    quiet_hours_start TIME,
    quiet_hours_end TIME,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (user_id)
);

-- Profile Change Requests (for HR approval)
CREATE TABLE IF NOT EXISTS profile_change_requests (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    change_type VARCHAR(50),
    old_value TEXT,
    new_value TEXT,
    reason TEXT,
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    requested_by INT,
    requested_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_by INT,
    approval_date DATETIME,
    approval_comments TEXT,
    applied_date DATETIME,
    INDEX (employee_id), INDEX (status), INDEX (requested_date)
);
