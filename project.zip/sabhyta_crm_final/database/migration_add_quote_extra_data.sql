-- =========================================================
-- Migration: add extra_data column to generic_records
-- ---------------------------------------------------------
-- Run this ONCE against your existing sabhytacrm database
-- (phpMyAdmin -> SQL tab, or `mysql -u USER -p sabhytacrm <
-- database/migration_add_quote_extra_data.sql`).
--
-- It's needed for the new Create Quote form, which stores the
-- product/service line items, financial summary and other
-- quote-specific fields as JSON in this column. Safe to run
-- even if you already recreated the table from the latest
-- schema.sql (MySQL will just report "duplicate column" and
-- you can ignore that).
-- =========================================================

USE sabhytacrm;

ALTER TABLE generic_records
  ADD COLUMN extra_data LONGTEXT NULL AFTER notes;
