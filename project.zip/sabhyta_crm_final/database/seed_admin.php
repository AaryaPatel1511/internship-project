<?php
// Deprecated endpoint. Never create an account with a shared fixed password.
http_response_code(410);
header('Content-Type: text/plain; charset=utf-8');
echo 'This legacy seeder is disabled. Run setup.html, then create your own administrator at login.html.';