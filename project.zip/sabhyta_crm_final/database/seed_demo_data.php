<?php
/**
 * SABHYTACRM — Full Demo Data Seeder
 * =========================================================
 * Populates 20-25 realistic test records into EVERY sidebar
 * section (169 generic_records-backed modules + Employees,
 * Departments, Designations, Customers, Sales Orders) so the
 * whole app can be clicked through and tested end-to-end.
 *
 * SAFE / IDEMPOTENT:
 *   - Any table/module that already has data is left completely
 *     untouched (only empty ones get seeded). Run this as many
 *     times as you like — it will never duplicate or overwrite
 *     anything you (or a previous run) already entered.
 *
 * HOW TO RUN (once):
 *   Open in your browser:  http://localhost/<project>/database/seed_demo_data.php
 *   or from CLI:           php database/seed_demo_data.php
 * =========================================================
 */

require_once __DIR__ . '/../api/db.php'; // gives us $pdo

header('Content-Type: text/plain; charset=utf-8');
echo "SABHYTACRM demo data seeder\n============================\n\n";

mt_srand(42); // reproducible "random" data across runs

// ---------------------------------------------------------
// Shared word banks
// ---------------------------------------------------------
$firstNames = ['Rohan','Priya','Amit','Sneha','Vikram','Ananya','Karan','Neha','Arjun','Pooja',
  'Rahul','Divya','Sanjay','Kavita','Manoj','Ritu','Suresh','Anjali','Deepak','Meera',
  'Nikhil','Shreya','Ajay','Swati','Vivek','Isha','Rajesh','Nisha','Aditya','Payal'];
$lastNames = ['Sharma','Verma','Patel','Gupta','Reddy','Nair','Iyer','Singh','Mehta','Joshi',
  'Kapoor','Malhotra','Chopra','Agarwal','Bansal','Rao','Pillai','Desai','Kulkarni','Trivedi'];
$companies = ['Vertex Systems','Bluepeak Technologies','Nimbus Retail Pvt Ltd','Orion Manufacturing',
  'Skyline Logistics','Everest Traders','Solaris Energy','Meridian Pharma','Crestline Builders',
  'Novatech Industries','Pinnacle Foods','Zenith Textiles','Harborview Exports','Silverline Motors',
  'Coral Bay Hospitality','Granite Infra','Wavefront Electronics','Sundial Furnishings',
  'Ironclad Steel','Aurelia Cosmetics','Brightpath Consulting','Redwood Realty','Falcon Freight',
  'Lumina Interiors','Stratos Aviation Services'];
$cities = ['Mumbai','Delhi','Kolkata','Chennai','Pune','Bengaluru','Hyderabad','Ahmedabad','Jaipur',
  'Surat','Lucknow','Nagpur','Indore','Coimbatore','Chandigarh'];
$states = ['Maharashtra','Delhi','West Bengal','Tamil Nadu','Maharashtra','Karnataka','Telangana',
  'Gujarat','Rajasthan','Gujarat','Uttar Pradesh','Maharashtra','Madhya Pradesh','Tamil Nadu','Punjab'];
$statuses = ['Active','Pending','Completed','In Progress','Approved','Cancelled'];
$notesBank = [
  'Follow up required next week.', 'Awaiting client confirmation.', 'Processed as per standard SOP.',
  'Escalated to team lead for review.', 'Documentation attached and verified.',
  'Client requested a revised timeline.', 'On track, no blockers currently.',
  'Pending final sign-off from finance.', 'Reviewed and closed successfully.',
  'Needs additional information from customer.',
];

function pick($arr) { return $arr[array_rand($arr)]; }
function randDate($daysBack = 300) { return date('Y-m-d', strtotime('-' . rand(0, $daysBack) . ' days')); }
function randAmount($min, $max) { return rand($min, $max); }
function tableCount(PDO $pdo, $table) {
  return (int) $pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
}

// =========================================================
// 1) DEPARTMENTS
// =========================================================
$deptNames = ['Sales & Marketing','Human Resources','Finance & Accounts','Information Technology',
  'Operations','Customer Support','Procurement','Legal & Compliance','Research & Development',
  'Quality Assurance','Administration','Logistics & Supply Chain'];

if (tableCount($pdo, 'departments') === 0) {
  echo "Seeding departments...\n";
  $stmt = $pdo->prepare("INSERT INTO departments (department_code, department_name, description, status) VALUES (?,?,?,?)");
  foreach ($deptNames as $i => $name) {
    $stmt->execute(['DEPT-' . str_pad($i + 1, 3, '0', STR_PAD_LEFT), $name, "$name department handling all related operations.", 'Active']);
  }
  echo "  -> " . count($deptNames) . " departments added.\n";
} else {
  echo "departments already has data — skipped.\n";
}
$deptIds = $pdo->query("SELECT id, department_name FROM departments")->fetchAll();

// =========================================================
// 2) DESIGNATIONS
// =========================================================
$designationNames = ['Software Engineer','Senior Software Engineer','HR Executive','HR Manager',
  'Accounts Executive','Finance Manager','Sales Executive','Sales Manager','Business Development Manager',
  'Operations Executive','Operations Manager','Customer Support Executive','Procurement Officer',
  'Legal Advisor','QA Engineer','Team Lead','Project Manager','Managing Director'];

if (tableCount($pdo, 'designations') === 0 && $deptIds) {
  echo "Seeding designations...\n";
  $stmt = $pdo->prepare("INSERT INTO designations (designation_name, department_id, salary_grade, job_description, status) VALUES (?,?,?,?,?)");
  foreach ($designationNames as $i => $name) {
    $dept = $deptIds[$i % count($deptIds)];
    $stmt->execute([$name, $dept['id'], 'G' . (1 + $i % 5), "Responsible for $name duties in {$dept['department_name']}.", 'Active']);
  }
  echo "  -> " . count($designationNames) . " designations added.\n";
} else {
  echo "designations already has data — skipped.\n";
}
$desigRows = $pdo->query("SELECT id, designation_name, department_id FROM designations")->fetchAll();

// =========================================================
// 3) EMPLOYEES (with live-computed salary breakup, same
//    formula as computeSalaryBreakup() in hrms_sales.js)
// =========================================================
function computeSalaryBreakupPHP($basic, $metro) {
  $basic = (float) $basic;
  $hra = round($basic * ($metro ? 0.50 : 0.40), 2);
  $da = round($basic * 0.10, 2);
  $conveyance = $metro ? 1600 : 1000;
  $medical = 1250;
  $special = round($basic * ($metro ? 0.05 : 0.03), 2);
  $gross = round($basic + $hra + $da + $conveyance + $medical + $special, 2);
  $pf = round(min($basic, 15000) * 0.12, 2);
  $esic = ($gross > 0 && $gross <= 21000) ? round($gross * 0.0075, 2) : 0;
  $pt = $gross > 15000 ? 200 : 0;
  $net = round($gross - ($pf + $esic + $pt), 2);
  return compact('hra', 'da', 'conveyance', 'medical', 'special', 'gross', 'pf', 'esic', 'pt', 'net');
}

$METRO_CITIES = ['Mumbai', 'Delhi', 'Kolkata', 'Chennai'];
$empIds = [];

if (tableCount($pdo, 'employees') === 0 && $desigRows) {
  echo "Seeding employees...\n";
  $stmt = $pdo->prepare("INSERT INTO employees
    (employee_code, employee_type, employment_status, first_name, last_name, gender, date_of_birth,
     mobile_number, personal_email, official_email, current_address, city, state, country, pincode,
     department_id, designation_id, branch, office_location, date_of_joining, employee_grade,
     employment_category, work_shift, ctc, basic_salary, hra, da, conveyance, medical_allowance,
     special_allowance, pf, esic, professional_tax, gross_salary, net_salary, bank_name, account_number,
     ifsc_code, status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

  for ($i = 0; $i < 24; $i++) {
    $fn = pick($GLOBALS['firstNames']);
    $ln = pick($GLOBALS['lastNames']);
    $desig = $desigRows[$i % count($desigRows)];
    $city = $GLOBALS['cities'][$i % count($GLOBALS['cities'])];
    $metro = in_array($city, $METRO_CITIES);
    $basic = [18000, 22000, 25000, 30000, 35000, 40000, 50000, 60000][($i) % 8];
    $calc = computeSalaryBreakupPHP($basic, $metro);
    $ctc = round(($calc['gross'] + 500) * 12, -2); // rough annual CTC estimate
    $code = 'EMP-' . str_pad($i + 1, 4, '0', STR_PAD_LEFT);
    $stmt->execute([
      $code, pick(['Permanent', 'Contract', 'Permanent', 'Permanent']), 'Active',
      $fn, $ln, $i % 2 === 0 ? 'Male' : 'Female', date('Y-m-d', strtotime('-' . (22 + $i) . ' years')),
      '9' . rand(100000000, 999999999),
      strtolower($fn . '.' . $ln . $i . '@gmail.com'), strtolower($fn . '.' . $ln . '@sabhytacrm.com'),
      rand(1, 200) . ' MG Road', $city, $GLOBALS['states'][$i % count($GLOBALS['states'])], 'India',
      (string) rand(400001, 700099),
      $desig['department_id'], $desig['id'], $city . ' Branch', $city,
      randDate(1200), 'G' . (1 + $i % 5), pick(['Full-Time', 'Full-Time', 'Part-Time']),
      pick(['Day Shift', 'Day Shift', 'General Shift']),
      $ctc, $basic, $calc['hra'], $calc['da'], $calc['conveyance'], $calc['medical'], $calc['special'],
      $calc['pf'], $calc['esic'], $calc['pt'], $calc['gross'], $calc['net'],
      pick(['HDFC Bank', 'ICICI Bank', 'State Bank of India', 'Axis Bank']),
      (string) rand(100000000000, 999999999999),
      pick(['HDFC0001234', 'ICIC0005678', 'SBIN0011223', 'UTIB0009988']),
      'Active',
    ]);
  }
  echo "  -> 24 employees added (with live-computed salary breakup).\n";
} else {
  echo "employees already has data — skipped.\n";
}
$empRows = $pdo->query("SELECT id, first_name, last_name, employee_code FROM employees")->fetchAll();
function empName($e) { return trim($e['first_name'] . ' ' . $e['last_name']); }

// =========================================================
// 4) CUSTOMERS
// =========================================================
if (tableCount($pdo, 'customers') === 0) {
  echo "Seeding customers...\n";
  $stmt = $pdo->prepare("INSERT INTO customers
    (customer_code, customer_type, customer_category, customer_name, company_name, display_name,
     gst_number, pan_number, industry, turnover, website, email, mobile, status, lead_source,
     customer_since, rating, sales_executive, branch, address_line1, city, state, country, pincode)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

  for ($i = 0; $i < 23; $i++) {
    $company = $GLOBALS['companies'][$i % count($GLOBALS['companies'])];
    $fn = pick($GLOBALS['firstNames']);
    $ln = pick($GLOBALS['lastNames']);
    $city = $GLOBALS['cities'][$i % count($GLOBALS['cities'])];
    $exec = $empRows ? empName($empRows[$i % count($empRows)]) : $fn . ' ' . $ln;
    $stmt->execute([
      'CUST-' . str_pad($i + 1, 4, '0', STR_PAD_LEFT),
      pick(['Business', 'Individual', 'Business', 'Business']),
      pick(['Retail', 'Wholesale', 'Corporate', 'Government']),
      "$fn $ln", $company, $company,
      '27ABCDE' . rand(1000, 9999) . 'F1Z' . rand(1, 9),
      strtoupper(substr($ln, 0, 5)) . rand(1000, 9999) . 'K',
      pick(['Manufacturing', 'IT Services', 'Retail', 'Pharma', 'Logistics', 'Textiles']),
      randAmount(500000, 50000000), strtolower(str_replace(' ', '', $company)) . '.com',
      strtolower($fn . '.' . $ln . $i . '@' . strtolower(str_replace(' ', '', $company)) . '.com'),
      '9' . rand(100000000, 999999999),
      pick($GLOBALS['statuses']), pick(['Website', 'Referral', 'Cold Call', 'Exhibition', 'Google Ads']),
      randDate(900), rand(3, 5), $exec, $city . ' Branch',
      rand(1, 99) . ' Industrial Area', $city, $GLOBALS['states'][$i % count($GLOBALS['states'])], 'India',
      (string) rand(400001, 700099),
    ]);
  }
  echo "  -> 23 customers added.\n";
} else {
  echo "customers already has data — skipped.\n";
}
$custRows = $pdo->query("SELECT id, customer_name, company_name FROM customers")->fetchAll();

// =========================================================
// 5) SALES ORDERS
// =========================================================
if (tableCount($pdo, 'sales_orders') === 0 && $custRows && $empRows) {
  echo "Seeding sales orders...\n";
  $stmt = $pdo->prepare("INSERT INTO sales_orders
    (sales_order_number, order_date, customer_id, contact_person, project_name, sales_executive_id,
     department_id, branch, currency, payment_terms, delivery_terms, priority, order_status,
     sub_total, tax_amount, grand_total)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

  for ($i = 0; $i < 22; $i++) {
    $cust = $custRows[$i % count($custRows)];
    $emp = $empRows[$i % count($empRows)];
    $subtotal = randAmount(20000, 500000);
    $tax = round($subtotal * 0.18, 2);
    $stmt->execute([
      'SO-2026-' . str_pad($i + 1, 4, '0', STR_PAD_LEFT), randDate(400), $cust['id'],
      $cust['customer_name'], $cust['company_name'] . ' — Project ' . ($i + 1), $emp['id'],
      null, pick($GLOBALS['cities']) . ' Branch', 'INR', pick(['Net 30', 'Net 45', 'Advance 50%', 'Net 15']),
      pick(['Ex-Works', 'FOR Destination']), pick(['High', 'Medium', 'Low']),
      pick(['Pending', 'Confirmed', 'In Progress', 'Delivered', 'Completed']),
      $subtotal, $tax, $subtotal + $tax,
    ]);
  }
  echo "  -> 22 sales orders added.\n";
} else {
  echo "sales_orders already has data — skipped.\n";
}

// =========================================================
// 6) EVERY GENERIC_RECORDS-BACKED SIDEBAR MODULE (169 of them)
// =========================================================
$moduleMap = require __DIR__ . '/seed_module_map.php';
echo "\nSeeding " . count($moduleMap) . " sidebar modules (generic_records)...\n";

$existing = $pdo->query("SELECT module_key, COUNT(*) c FROM generic_records GROUP BY module_key")
  ->fetchAll(PDO::FETCH_KEY_PAIR);

$insStmt = $pdo->prepare("INSERT INTO generic_records
  (module_key, module_label, title, party_name, assigned_to, record_date, amount, status, notes, extra_data)
  VALUES (?,?,?,?,?,?,?,?,?,?)");

$seededModules = 0;
$seededRows = 0;
$pdo->beginTransaction();
foreach ($moduleMap as $m) {
  $key = $m['module_key'];
  if (!empty($existing[$key]) && $existing[$key] >= 5) continue; // already has real data — don't touch

  $rowCount = rand(20, 25);
  for ($i = 1; $i <= $rowCount; $i++) {
    $person = pick($GLOBALS['firstNames']) . ' ' . pick($GLOBALS['lastNames']);
    $company = pick($GLOBALS['companies']);
    $assignedTo = $empRows ? empName($empRows[array_rand($empRows)]) : $person;
    $title = $m['module_label'] . ' — ' . ($i <= 12 ? $company : $person) . ' #' . str_pad($i, 3, '0', STR_PAD_LEFT);

    $extra = null;
    if ($key === 'hrms__salary') {
      $extra = json_encode([
        'employeeName' => $assignedTo, 'month' => pick(['January','February','March','April','May','June']) . ' 2026',
        'basicSalary' => randAmount(18000, 60000),
      ]);
    } elseif ($key === 'hrms__leave') {
      $extra = json_encode([
        'employeeName' => $assignedTo, 'leaveType' => pick(['Casual Leave', 'Sick Leave', 'Earned Leave', 'Unpaid Leave']),
        'fromDate' => randDate(200), 'days' => rand(1, 5),
      ]);
    }

    $insStmt->execute([
      $key, $m['module_label'], $title, $company, $assignedTo, randDate(300),
      randAmount(1000, 250000), pick($GLOBALS['statuses']), pick($GLOBALS['notesBank']), $extra,
    ]);
    $seededRows++;
  }
  $seededModules++;
}
$pdo->commit();

echo "  -> $seededModules modules seeded, $seededRows total records inserted.\n";
echo "\nDone! Open the app and browse the sidebar — every section now has demo data to test with.\n";
