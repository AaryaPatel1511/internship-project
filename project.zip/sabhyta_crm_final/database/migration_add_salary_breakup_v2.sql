-- =========================================================
-- Migration: extend Salary Breakup columns on employees
-- ---------------------------------------------------------
-- Run this ONCE against your existing sabhytacrm database, AFTER
-- migration_add_salary_breakup.sql has already been applied
-- (phpMyAdmin -> SQL tab, or
-- `mysql -u USER -p sabhytacrm < database/migration_add_salary_breakup_v2.sql`).
--
-- Adds the remaining earning/deduction heads (Conveyance, Medical
-- Allowance, Special Allowance, ESIC, Professional Tax) so the full
-- Metro/Non-Metro salary calculation on the Employee form and in
-- HRMS > Salary is stored as real columns, not just HRA/DA/PF/Gross/Net.
-- Yearly figures are NOT stored — they are simply these monthly values
-- x 12, computed live in the UI. Safe to run even if some columns
-- already exist; MySQL will just report "duplicate column" for those,
-- which you can ignore.
-- =========================================================

USE sabhytacrm;

ALTER TABLE employees
  ADD COLUMN conveyance        DECIMAL(15,2) NULL AFTER da,
  ADD COLUMN medical_allowance DECIMAL(15,2) NULL AFTER conveyance,
  ADD COLUMN special_allowance DECIMAL(15,2) NULL AFTER medical_allowance,
  ADD COLUMN esic              DECIMAL(15,2) NULL AFTER pf,
  ADD COLUMN professional_tax  DECIMAL(15,2) NULL AFTER esic;
