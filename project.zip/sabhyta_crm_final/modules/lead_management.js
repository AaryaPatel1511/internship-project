/* =========================================================
   LEAD MANAGEMENT MODULE
   Covers every leaf under the "Lead Management" sidebar
   section: Add Lead, Import Leads, Website/Facebook/Google
   Ads/WhatsApp Leads, Assigned Leads, Follow-up, Lead Status,
   Lost Leads, Converted Leads.
   Shares globals (mainContent, money, statusClass, destroyCharts,
   renderBarChartData, renderDonutChartData, legendHTML,
   CHART_COLORS) defined in script.js.
   ========================================================= */

const LEAD_ITEM_NAMES = new Set([
  'Add Lead', 'Import Leads', 'Website Leads', 'Facebook Leads',
  'Google Ads Leads', 'WhatsApp Leads', 'Assigned Leads', 'Follow-up',
  'Lead Status', 'Lost Leads', 'Converted Leads'
]);

const LEAD_STATUS_FLOW = [
  'New Lead', 'Assigned', 'Contacted', 'Follow-up', 'Interested',
  'Test Drive', 'Quotation Sent', 'Finance', 'Booking', 'Delivered',
  'Converted', 'Closed'
];
const LEAD_LOST_STATUS = 'Lost';

const LEAD_SOURCES = [
  'Walk-in', 'Website', 'Facebook', 'Google Ads', 'WhatsApp', 'Instagram',
  'Referral', 'Telecalling', 'Exhibition', 'Dealer', 'Existing Customer'
];
const LOST_REASONS = [
  'Purchased Other Brand', 'Budget Issue', 'Finance Rejected', 'No Response',
  'Wrong Number', 'Duplicate', 'Delayed Purchase', 'Dealer Issue',
  'Stock Not Available', 'Service Concern'
];
const FOLLOWUP_STATUSES = [
  'Interested', 'Not Interested', 'Busy', 'Call Later', 'Test Drive',
  'Finance Required', 'Booking Expected', 'Lost'
];

function routeLeadLeaf(itemLabel, sectionLabel, backAction, backLabel) {
  if (!LEAD_ITEM_NAMES.has(itemLabel)) return false;

  const back = backAction || (() => renderDashboardHome());
  const backTo = backLabel || 'Dashboard';

  switch (itemLabel) {
    case 'Add Lead': renderLeadForm(null, back, backTo); break;
    case 'Import Leads': renderImportLeadsPage(back, backTo); break;
    case 'Website Leads': renderLeadSourcePage('Website', 'website', back, backTo); break;
    case 'Facebook Leads': renderLeadSourcePage('Facebook', 'facebook', back, backTo); break;
    case 'Google Ads Leads': renderLeadSourcePage('Google Ads', 'google_ads', back, backTo); break;
    case 'WhatsApp Leads': renderLeadSourcePage('WhatsApp', 'whatsapp', back, backTo); break;
    case 'Assigned Leads': renderAssignedLeadsPage(back, backTo); break;
    case 'Follow-up': renderFollowupPage(back, backTo); break;
    case 'Lead Status': renderLeadStatusPage(back, backTo); break;
    case 'Lost Leads': renderLostLeadsPage(back, backTo); break;
    case 'Converted Leads': renderConvertedLeadsPage(back, backTo); break;
  }
  return true;
}

/* ---------------------------------------------------------
   Small shared helpers: toast, modal, escaping
   --------------------------------------------------------- */
function lmEsc(v) {
  if (v === null || v === undefined) return '';
  return String(v).replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}

function lmToast(message, type = 'success') {
  let host = document.getElementById('lmToastHost');
  if (!host) {
    host = document.createElement('div');
    host.id = 'lmToastHost';
    host.style.cssText = 'position:fixed;top:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:8px;';
    document.body.appendChild(host);
  }
  const el = document.createElement('div');
  el.textContent = message;
  el.style.cssText = `padding:11px 16px;border-radius:8px;font-size:.85rem;font-weight:600;color:#fff;
    box-shadow:0 8px 24px rgba(15,23,42,.18);background:${type === 'error' ? '#d3312f' : '#16a34a'};max-width:320px;`;
  host.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

function lmModal(titleHtml, bodyHtml, { wide = false } = {}) {
  const old = document.getElementById('lmModalBackdrop');
  if (old) old.remove();
  const backdrop = document.createElement('div');
  backdrop.id = 'lmModalBackdrop';
  backdrop.style.cssText = 'position:fixed;inset:0;background:rgba(15,23,42,.45);z-index:500;display:flex;align-items:center;justify-content:center;padding:20px;';
  backdrop.innerHTML = `
    <div class="form-card" style="max-width:${wide ? 720 : 480}px;width:100%;max-height:88vh;overflow-y:auto;margin:0;">
      <div class="card-title" style="display:flex;justify-content:space-between;align-items:center;">
        <h3>${titleHtml}</h3>
        <button type="button" id="lmModalClose" style="background:none;border:none;font-size:1.1rem;cursor:pointer;color:#8f97a8;">✕</button>
      </div>
      <div id="lmModalBody">${bodyHtml}</div>
    </div>`;
  document.body.appendChild(backdrop);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) backdrop.remove(); });
  document.getElementById('lmModalClose').addEventListener('click', () => backdrop.remove());
  return backdrop;
}

function lmPriorityChip(p) {
  const cls = p === 'Hot' ? 'lm-priority-hot' : p === 'Cold' ? 'lm-priority-cold' : 'lm-priority-warm';
  return `<span class="${cls}">${lmEsc(p || 'Warm')}</span>`;
}

function lmFieldOptions(list, selected) {
  return list.map(v => `<option value="${lmEsc(v)}" ${v === selected ? 'selected' : ''}>${lmEsc(v)}</option>`).join('');
}

/* ---------------------------------------------------------
   Shared: fetch + render a filterable leads table
   config: { source, status, title, icon, eyebrow, showSourceCol }
   --------------------------------------------------------- */
async function lmFetchLeads(params) {
  const qs = new URLSearchParams(params).toString();
  const res = await fetch('api/leads.php?action=list&' + qs);
  const json = await res.json();
  if (!json.success) throw new Error(json.message || 'Failed to load leads.');
  return json;
}

function lmRowsHTML(rows, { showSource = true } = {}) {
  if (!rows.length) return `<tr><td colspan="9">No leads found.</td></tr>`;
  return rows.map(l => `
    <tr>
      <td class="cell-strong">${lmEsc(l.lead_code)}</td>
      <td>${lmEsc(l.customer_name)}<div style="font-size:.74rem;color:#8f97a8;">${lmEsc(l.mobile)}</div></td>
      <td>${lmEsc([l.vehicle_brand, l.vehicle_model].filter(Boolean).join(' ')) || '—'}</td>
      ${showSource ? `<td>${lmEsc(l.lead_source)}</td>` : ''}
      <td>${lmEsc(l.sales_executive) || '—'}</td>
      <td>${lmPriorityChip(l.priority)}</td>
      <td><span class="status-chip ${statusClass(l.status || 'New Lead')}">${lmEsc(l.status)}</span></td>
      <td>${l.next_followup_date ? lmEsc(l.next_followup_date) : '—'}</td>
      <td>
        <button type="button" class="btn-secondary lm-view" data-id="${l.id}">View</button>
        <button type="button" class="btn-secondary lm-delete" data-id="${l.id}">Delete</button>
      </td>
    </tr>`).join('');
}

function lmWireRowActions(tbody, onReload, back, backTo) {
  tbody.querySelectorAll('.lm-view').forEach(btn => btn.addEventListener('click', () =>
    renderLeadForm(btn.dataset.id, back, backTo)));
  tbody.querySelectorAll('.lm-delete').forEach(btn => btn.addEventListener('click', async () => {
    if (!confirm('Delete this lead permanently?')) return;
    try {
      const res = await fetch(`api/leads.php?action=delete&id=${btn.dataset.id}`, { method: 'POST' });
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      lmToast('Lead deleted.');
      onReload();
    } catch (err) { lmToast('Delete failed: ' + err.message, 'error'); }
  }));
}

/* =========================================================
   1. ADD LEAD  (also the shared Lead Detail / Edit screen)
   ========================================================= */
async function renderLeadForm(editId, backAction, backLabel) {
  destroyCharts();
  const isEdit = !!editId;

  mainContent.innerHTML = `
    <button class="back-btn" id="lmFormBackBtn"><i class="fas fa-arrow-left"></i> Back to ${lmEsc(backLabel)}</button>
    <div class="eyebrow">Lead Management <span class="crumb-sep">/</span> <span class="crumb-current">${isEdit ? 'Lead Detail' : 'Add Lead'}</span></div>
    <div class="page-title"><span>${isEdit ? 'Lead Detail' : 'Add Lead'}</span></div>

    <form id="leadForm">
      <div class="form-card">
        <div class="card-title"><h3>Basic Information</h3></div>
        <div class="form-grid">
          <div class="form-group"><label>Lead ID</label><input type="text" id="lmLeadCode" disabled placeholder="Auto-generated"></div>
          <div class="form-group"><label>Lead Date <span class="required">*</span></label><input type="datetime-local" id="lmLeadDate"></div>
          <div class="form-group"><label>Customer Name <span class="required">*</span></label><input type="text" id="lmCustomerName" required></div>
          <div class="form-group"><label>Mobile Number <span class="required">*</span></label><input type="text" id="lmMobile" required placeholder="10-digit mobile"></div>
          <div class="form-group"><label>Alternate Mobile Number</label><input type="text" id="lmAltMobile"></div>
          <div class="form-group"><label>Email ID</label><input type="email" id="lmEmail"></div>
          <div class="form-group"><label>Gender</label><select id="lmGender"><option value="">Select</option><option>Male</option><option>Female</option><option>Other</option></select></div>
          <div class="form-group"><label>Date of Birth</label><input type="date" id="lmDob"></div>
        </div>
      </div>

      <div class="form-card">
        <div class="card-title"><h3>Address</h3></div>
        <div class="form-grid">
          <div class="form-group full-width"><label>Address Line</label><input type="text" id="lmAddressLine"></div>
          <div class="form-group"><label>Landmark</label><input type="text" id="lmLandmark"></div>
          <div class="form-group"><label>City</label><input type="text" id="lmCity"></div>
          <div class="form-group"><label>District</label><input type="text" id="lmDistrict"></div>
          <div class="form-group"><label>State</label><input type="text" id="lmState"></div>
          <div class="form-group"><label>Country</label><input type="text" id="lmCountry" value="India"></div>
          <div class="form-group"><label>Pincode</label><input type="text" id="lmPincode"></div>
        </div>
      </div>

      <div class="form-card">
        <div class="card-title"><h3>Vehicle Requirement</h3></div>
        <div class="form-grid">
          <div class="form-group"><label>Brand</label><input type="text" id="lmVehicleBrand"></div>
          <div class="form-group"><label>Model</label><input type="text" id="lmVehicleModel"></div>
          <div class="form-group"><label>Variant</label><input type="text" id="lmVariant"></div>
          <div class="form-group"><label>Fuel Type</label><select id="lmFuelType"><option value="">Select</option><option>Petrol</option><option>Diesel</option><option>CNG</option><option>Electric</option><option>Hybrid</option></select></div>
          <div class="form-group"><label>Transmission</label><select id="lmTransmission"><option value="">Select</option><option>Manual</option><option>Automatic</option></select></div>
          <div class="form-group"><label>Colour Preference</label><input type="text" id="lmColorPreference"></div>
          <div class="form-group"><label>Budget (₹)</label><input type="number" id="lmBudget" min="0"></div>
          <div class="form-group"><label>Expected Purchase Date</label><input type="date" id="lmExpectedPurchaseDate"></div>
        </div>
      </div>

      <div class="form-card">
        <div class="card-title"><h3>Purchase Details</h3></div>
        <div class="form-grid">
          <div class="form-group"><label>Finance Required</label><select id="lmFinanceRequired"><option>No</option><option>Yes</option></select></div>
          <div class="form-group"><label>Exchange Vehicle</label><select id="lmExchangeRequired"><option>No</option><option>Yes</option></select></div>
          <div class="form-group"><label>Test Drive Required</label><select id="lmTestDriveRequired"><option>No</option><option>Yes</option></select></div>
          <div class="form-group"><label>Corporate Customer</label><select id="lmCorporateCustomer"><option>No</option><option>Yes</option></select></div>
          <div class="form-group"><label>Existing Customer</label><select id="lmExistingCustomer"><option>No</option><option>Yes</option></select></div>
        </div>
      </div>

      <div class="form-card">
        <div class="card-title"><h3>Lead Source &amp; Sales Assignment</h3></div>
        <div class="form-grid">
          <div class="form-group"><label>Lead Source</label><select id="lmLeadSource">${lmFieldOptions(LEAD_SOURCES, 'Walk-in')}</select></div>
          <div class="form-group"><label>Branch</label><input type="text" id="lmBranch"></div>
          <div class="form-group"><label>Sales Executive</label><input type="text" id="lmSalesExecutive"></div>
          <div class="form-group"><label>Team Leader</label><input type="text" id="lmTeamLeader"></div>
          <div class="form-group"><label>Priority</label><select id="lmPriority"><option>Warm</option><option>Hot</option><option>Cold</option></select></div>
          ${isEdit ? `<div class="form-group"><label>Status</label><select id="lmStatus">${lmFieldOptions([...LEAD_STATUS_FLOW, LEAD_LOST_STATUS], 'New Lead')}</select></div>` : ''}
          ${isEdit ? `<div class="form-group"><label>Next Follow-up Date</label><input type="date" id="lmNextFollowupDate"></div>` : ''}
        </div>
      </div>

      <div class="form-card" id="lmLostCard" style="display:none;">
        <div class="card-title"><h3>Lost Lead Details</h3></div>
        <div class="form-grid">
          <div class="form-group"><label>Lost Date</label><input type="date" id="lmLostDate"></div>
          <div class="form-group"><label>Lost Reason</label><select id="lmLostReason"><option value="">Select</option>${lmFieldOptions(LOST_REASONS)}</select></div>
          <div class="form-group"><label>Competitor Name</label><input type="text" id="lmCompetitorName"></div>
          <div class="form-group"><label>Price Difference (₹)</label><input type="number" id="lmPriceDifference"></div>
        </div>
      </div>

      <div class="form-card" id="lmConvertedCard" style="display:none;">
        <div class="card-title"><h3>Booking / Converted Details</h3></div>
        <div class="form-grid">
          <div class="form-group"><label>Booking Number</label><input type="text" id="lmBookingNumber"></div>
          <div class="form-group"><label>Invoice Number</label><input type="text" id="lmInvoiceNumber"></div>
          <div class="form-group"><label>Booking Date</label><input type="date" id="lmBookingDate"></div>
          <div class="form-group"><label>Delivery Date</label><input type="date" id="lmDeliveryDate"></div>
          <div class="form-group"><label>Finance Company</label><input type="text" id="lmFinanceCompany"></div>
          <div class="form-group"><label>Loan Amount (₹)</label><input type="number" id="lmLoanAmount"></div>
          <div class="form-group"><label>Final Amount (₹)</label><input type="number" id="lmFinalAmount"></div>
          <div class="form-group"><label>Payment Mode</label><input type="text" id="lmPaymentMode"></div>
          <div class="form-group"><label>Booking Amount (₹)</label><input type="number" id="lmBookingAmount"></div>
          <div class="form-group"><label>Discount Given (₹)</label><input type="number" id="lmDiscountGiven"></div>
          <div class="form-group"><label>Exchange Value (₹)</label><input type="number" id="lmExchangeValue"></div>
          <div class="form-group"><label>Accessories Sold (₹)</label><input type="number" id="lmAccessoriesSold"></div>
          <div class="form-group"><label>Insurance (₹)</label><input type="number" id="lmInsuranceAmount"></div>
          <div class="form-group"><label>Extended Warranty (₹)</label><input type="number" id="lmExtendedWarranty"></div>
          <div class="form-group"><label>RTO Charges (₹)</label><input type="number" id="lmRtoCharges"></div>
          <div class="form-group"><label>Accessories Package</label><input type="text" id="lmAccessoriesPackage"></div>
          <div class="form-group"><label>Delivery Executive</label><input type="text" id="lmDeliveryExecutive"></div>
        </div>
      </div>

      <div class="form-card">
        <div class="card-title"><h3>Remarks</h3></div>
        <div class="form-grid">
          <div class="form-group full-width"><label>Customer Requirement</label><textarea rows="2" id="lmRequirementNotes"></textarea></div>
          <div class="form-group full-width"><label>Notes</label><textarea rows="2" id="lmNotes"></textarea></div>
          <div class="form-group full-width">
            <label>Attachment</label>
            <input type="file" id="lmAttachmentFile">
            <div id="lmAttachmentInfo" style="font-size:.78rem;color:#8f97a8;margin-top:6px;"></div>
            <input type="hidden" id="lmAttachmentPath">
          </div>
        </div>
      </div>

      <div class="form-actions">
        <button type="submit" class="btn-primary" id="lmSaveBtn">${isEdit ? 'Update Lead' : 'Save Lead'}</button>
        <button type="reset" class="btn-secondary">Clear</button>
        <span id="lmStatusMsg" style="margin-left:14px;font-size:14px;"></span>
      </div>
    </form>

    ${isEdit ? `
    <div class="form-card" id="lmFollowupHistoryCard">
      <div class="card-title" style="display:flex;justify-content:space-between;align-items:center;">
        <h3>Follow-up History</h3>
        <button type="button" class="btn-secondary" id="lmAddFollowupBtn"><i class="fas fa-plus"></i> Add Follow-up</button>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>Date</th><th>Executive</th><th>Discussion</th><th>Feedback</th><th>Status</th><th>Next Follow-up</th></tr></thead>
          <tbody id="lmFollowupTbody"><tr><td colspan="6">Loading…</td></tr></tbody>
        </table>
      </div>
    </div>` : ''}
  `;

  document.getElementById('lmFormBackBtn').addEventListener('click', backAction);

  const lostCard = document.getElementById('lmLostCard');
  const convertedCard = document.getElementById('lmConvertedCard');
  const statusSelect = document.getElementById('lmStatus');
  function syncConditionalCards() {
    if (!statusSelect) return;
    lostCard.style.display = statusSelect.value === 'Lost' ? 'block' : 'none';
    convertedCard.style.display = statusSelect.value === 'Converted' ? 'block' : 'none';
  }
  if (statusSelect) { statusSelect.addEventListener('change', syncConditionalCards); }

  document.getElementById('lmAttachmentFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const info = document.getElementById('lmAttachmentInfo');
    info.textContent = 'Uploading…';
    const fd = new FormData(); fd.append('file', file);
    try {
      const res = await fetch('api/leads.php?action=upload_attachment', { method: 'POST', body: fd });
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      document.getElementById('lmAttachmentPath').value = json.path;
      info.innerHTML = `<i class="fas fa-paperclip"></i> ${lmEsc(json.name)} uploaded`;
    } catch (err) { info.textContent = 'Upload failed: ' + err.message; }
  });

  if (isEdit) {
    try {
      const res = await fetch('api/leads.php?action=get&id=' + editId);
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      const l = json.data;
      document.getElementById('lmLeadCode').value = l.lead_code || '';
      if (l.lead_date) document.getElementById('lmLeadDate').value = l.lead_date.replace(' ', 'T').slice(0, 16);
      document.getElementById('lmCustomerName').value = l.customer_name || '';
      document.getElementById('lmMobile').value = l.mobile || '';
      document.getElementById('lmAltMobile').value = l.alternate_mobile || '';
      document.getElementById('lmEmail').value = l.email || '';
      document.getElementById('lmGender').value = l.gender || '';
      document.getElementById('lmDob').value = l.dob || '';
      document.getElementById('lmAddressLine').value = l.address_line || '';
      document.getElementById('lmLandmark').value = l.landmark || '';
      document.getElementById('lmCity').value = l.city || '';
      document.getElementById('lmDistrict').value = l.district || '';
      document.getElementById('lmState').value = l.state || '';
      document.getElementById('lmCountry').value = l.country || 'India';
      document.getElementById('lmPincode').value = l.pincode || '';
      document.getElementById('lmVehicleBrand').value = l.vehicle_brand || '';
      document.getElementById('lmVehicleModel').value = l.vehicle_model || '';
      document.getElementById('lmVariant').value = l.variant || '';
      document.getElementById('lmFuelType').value = l.fuel_type || '';
      document.getElementById('lmTransmission').value = l.transmission || '';
      document.getElementById('lmColorPreference').value = l.color_preference || '';
      document.getElementById('lmBudget').value = l.budget || '';
      document.getElementById('lmExpectedPurchaseDate').value = l.expected_purchase_date || '';
      document.getElementById('lmFinanceRequired').value = l.finance_required || 'No';
      document.getElementById('lmExchangeRequired').value = l.exchange_required || 'No';
      document.getElementById('lmTestDriveRequired').value = l.test_drive_required || 'No';
      document.getElementById('lmCorporateCustomer').value = l.corporate_customer || 'No';
      document.getElementById('lmExistingCustomer').value = l.existing_customer || 'No';
      document.getElementById('lmLeadSource').value = l.lead_source || 'Walk-in';
      document.getElementById('lmBranch').value = l.branch || '';
      document.getElementById('lmSalesExecutive').value = l.sales_executive || '';
      document.getElementById('lmTeamLeader').value = l.team_leader || '';
      document.getElementById('lmPriority').value = l.priority || 'Warm';
      document.getElementById('lmStatus').value = l.status || 'New Lead';
      document.getElementById('lmNextFollowupDate').value = l.next_followup_date || '';
      document.getElementById('lmLostDate').value = l.lost_date || '';
      document.getElementById('lmLostReason').value = l.lost_reason || '';
      document.getElementById('lmCompetitorName').value = l.competitor_name || '';
      document.getElementById('lmPriceDifference').value = l.price_difference || '';
      document.getElementById('lmBookingNumber').value = l.booking_number || '';
      document.getElementById('lmInvoiceNumber').value = l.invoice_number || '';
      document.getElementById('lmBookingDate').value = l.booking_date || '';
      document.getElementById('lmDeliveryDate').value = l.delivery_date || '';
      document.getElementById('lmFinanceCompany').value = l.finance_company || '';
      document.getElementById('lmLoanAmount').value = l.loan_amount || '';
      document.getElementById('lmFinalAmount').value = l.final_amount || '';
      document.getElementById('lmPaymentMode').value = l.payment_mode || '';
      document.getElementById('lmBookingAmount').value = l.booking_amount || '';
      document.getElementById('lmDiscountGiven').value = l.discount_given || '';
      document.getElementById('lmExchangeValue').value = l.exchange_value || '';
      document.getElementById('lmAccessoriesSold').value = l.accessories_sold || '';
      document.getElementById('lmInsuranceAmount').value = l.insurance_amount || '';
      document.getElementById('lmExtendedWarranty').value = l.extended_warranty || '';
      document.getElementById('lmRtoCharges').value = l.rto_charges || '';
      document.getElementById('lmAccessoriesPackage').value = l.accessories_package || '';
      document.getElementById('lmDeliveryExecutive').value = l.delivery_executive || '';
      document.getElementById('lmRequirementNotes').value = l.requirement_notes || '';
      document.getElementById('lmNotes').value = l.notes || '';
      if (l.attachment) {
        document.getElementById('lmAttachmentPath').value = l.attachment;
        document.getElementById('lmAttachmentInfo').innerHTML = `<i class="fas fa-paperclip"></i> <a href="${lmEsc(l.attachment)}" target="_blank">View current attachment</a>`;
      }
      syncConditionalCards();
      loadFollowupHistory(editId);
    } catch (err) {
      document.getElementById('lmStatusMsg').style.color = '#d33';
      document.getElementById('lmStatusMsg').textContent = 'Could not load lead: ' + err.message;
    }

    document.getElementById('lmAddFollowupBtn').addEventListener('click', () => openAddFollowupModal(editId, () => loadFollowupHistory(editId)));
  } else {
    document.getElementById('lmLeadDate').value = new Date().toISOString().slice(0, 16);
  }

  document.getElementById('leadForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const saveBtn = document.getElementById('lmSaveBtn');
    const statusMsg = document.getElementById('lmStatusMsg');
    statusMsg.textContent = ''; saveBtn.disabled = true; saveBtn.textContent = isEdit ? 'Updating…' : 'Saving…';

    const payload = {
      leadDate: document.getElementById('lmLeadDate').value ? document.getElementById('lmLeadDate').value.replace('T', ' ') + ':00' : '',
      customerName: document.getElementById('lmCustomerName').value.trim(),
      mobile: document.getElementById('lmMobile').value.trim(),
      alternateMobile: document.getElementById('lmAltMobile').value.trim(),
      email: document.getElementById('lmEmail').value.trim(),
      gender: document.getElementById('lmGender').value,
      dob: document.getElementById('lmDob').value,
      addressLine: document.getElementById('lmAddressLine').value,
      landmark: document.getElementById('lmLandmark').value,
      city: document.getElementById('lmCity').value,
      district: document.getElementById('lmDistrict').value,
      state: document.getElementById('lmState').value,
      country: document.getElementById('lmCountry').value,
      pincode: document.getElementById('lmPincode').value,
      vehicleBrand: document.getElementById('lmVehicleBrand').value,
      vehicleModel: document.getElementById('lmVehicleModel').value,
      variant: document.getElementById('lmVariant').value,
      fuelType: document.getElementById('lmFuelType').value,
      transmission: document.getElementById('lmTransmission').value,
      colorPreference: document.getElementById('lmColorPreference').value,
      budget: document.getElementById('lmBudget').value,
      expectedPurchaseDate: document.getElementById('lmExpectedPurchaseDate').value,
      financeRequired: document.getElementById('lmFinanceRequired').value,
      exchangeRequired: document.getElementById('lmExchangeRequired').value,
      testDriveRequired: document.getElementById('lmTestDriveRequired').value,
      corporateCustomer: document.getElementById('lmCorporateCustomer').value,
      existingCustomer: document.getElementById('lmExistingCustomer').value,
      leadSource: document.getElementById('lmLeadSource').value,
      branch: document.getElementById('lmBranch').value,
      salesExecutive: document.getElementById('lmSalesExecutive').value,
      teamLeader: document.getElementById('lmTeamLeader').value,
      priority: document.getElementById('lmPriority').value,
      requirementNotes: document.getElementById('lmRequirementNotes').value,
      notes: document.getElementById('lmNotes').value,
      attachment: document.getElementById('lmAttachmentPath').value,
    };

    if (isEdit) {
      payload.status = document.getElementById('lmStatus').value;
      payload.nextFollowupDate = document.getElementById('lmNextFollowupDate').value;
      payload.lostDate = document.getElementById('lmLostDate').value;
      payload.lostReason = document.getElementById('lmLostReason').value;
      payload.competitorName = document.getElementById('lmCompetitorName').value;
      payload.priceDifference = document.getElementById('lmPriceDifference').value;
      payload.bookingNumber = document.getElementById('lmBookingNumber').value;
      payload.invoiceNumber = document.getElementById('lmInvoiceNumber').value;
      payload.bookingDate = document.getElementById('lmBookingDate').value;
      payload.deliveryDate = document.getElementById('lmDeliveryDate').value;
      payload.financeCompany = document.getElementById('lmFinanceCompany').value;
      payload.loanAmount = document.getElementById('lmLoanAmount').value;
      payload.finalAmount = document.getElementById('lmFinalAmount').value;
      payload.paymentMode = document.getElementById('lmPaymentMode').value;
      payload.bookingAmount = document.getElementById('lmBookingAmount').value;
      payload.discountGiven = document.getElementById('lmDiscountGiven').value;
      payload.exchangeValue = document.getElementById('lmExchangeValue').value;
      payload.accessoriesSold = document.getElementById('lmAccessoriesSold').value;
      payload.insuranceAmount = document.getElementById('lmInsuranceAmount').value;
      payload.extendedWarranty = document.getElementById('lmExtendedWarranty').value;
      payload.rtoCharges = document.getElementById('lmRtoCharges').value;
      payload.accessoriesPackage = document.getElementById('lmAccessoriesPackage').value;
      payload.deliveryExecutive = document.getElementById('lmDeliveryExecutive').value;
    }

    try {
      const url = isEdit ? `api/leads.php?action=update&id=${editId}` : 'api/leads.php?action=create';
      const res = await fetch(url, { method: 'POST', body: JSON.stringify(payload) });
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      statusMsg.style.color = 'green';
      statusMsg.textContent = isEdit ? 'Updated successfully.' : 'Saved successfully.';
      lmToast(isEdit ? 'Lead updated.' : 'Lead saved.');
      if (!isEdit) setTimeout(() => renderLeadForm(json.id, backAction, backLabel), 500);
    } catch (err) {
      statusMsg.style.color = '#d33'; statusMsg.textContent = 'Error: ' + err.message;
      lmToast('Save failed: ' + err.message, 'error');
    } finally {
      saveBtn.disabled = false; saveBtn.textContent = isEdit ? 'Update Lead' : 'Save Lead';
    }
  });
}

async function loadFollowupHistory(leadId) {
  const tbody = document.getElementById('lmFollowupTbody');
  if (!tbody) return;
  try {
    const res = await fetch('api/lead_followups.php?action=list&lead_id=' + leadId);
    const json = await res.json();
    if (!json.success) throw new Error(json.message);
    if (!json.data.length) { tbody.innerHTML = `<tr><td colspan="6">No follow-ups logged yet.</td></tr>`; return; }
    tbody.innerHTML = json.data.map(f => `
      <tr>
        <td>${lmEsc(f.followup_date)} ${f.followup_time ? lmEsc(f.followup_time) : ''}</td>
        <td>${lmEsc(f.executive) || '—'}</td>
        <td>${lmEsc(f.discussion) || '—'}</td>
        <td>${lmEsc(f.customer_feedback) || '—'}</td>
        <td><span class="status-chip ${statusClass(f.status)}">${lmEsc(f.status)}</span></td>
        <td>${lmEsc(f.next_followup_date) || '—'}</td>
      </tr>`).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6">Failed to load: ${lmEsc(err.message)}</td></tr>`;
  }
}

function openAddFollowupModal(leadId, onSaved) {
  const backdrop = lmModal('Add Follow-up', `
    <form id="lmFollowupForm">
      <div class="form-grid">
        <div class="form-group"><label>Follow-up Date <span class="required">*</span></label><input type="date" id="fuDate" required value="${new Date().toISOString().slice(0,10)}"></div>
        <div class="form-group"><label>Follow-up Time</label><input type="time" id="fuTime"></div>
        <div class="form-group"><label>Next Follow-up Date</label><input type="date" id="fuNextDate"></div>
        <div class="form-group"><label>Executive</label><input type="text" id="fuExecutive"></div>
        <div class="form-group"><label>Status</label><select id="fuStatus">${lmFieldOptions(FOLLOWUP_STATUSES, 'Call Later')}</select></div>
        <div class="form-group full-width"><label>Discussion</label><textarea rows="2" id="fuDiscussion"></textarea></div>
        <div class="form-group full-width"><label>Customer Feedback</label><textarea rows="2" id="fuFeedback"></textarea></div>
        <div class="form-group full-width">
          <label>Reminder</label>
          <div style="display:flex;gap:14px;flex-wrap:wrap;font-size:.85rem;">
            ${['SMS','WhatsApp','Email','CRM Notification'].map(c => `<label style="display:flex;gap:6px;align-items:center;"><input type="checkbox" class="fuReminder" value="${c}"> ${c}</label>`).join('')}
          </div>
        </div>
      </div>
      <div class="form-actions">
        <button type="submit" class="btn-primary">Save Follow-up</button>
        <span id="fuMsg" style="margin-left:12px;font-size:.85rem;"></span>
      </div>
    </form>
  `);

  document.getElementById('lmFollowupForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const msg = document.getElementById('fuMsg');
    const channels = Array.from(document.querySelectorAll('.fuReminder:checked')).map(c => c.value);
    const payload = {
      leadId, followupDate: document.getElementById('fuDate').value,
      followupTime: document.getElementById('fuTime').value,
      nextFollowupDate: document.getElementById('fuNextDate').value,
      executive: document.getElementById('fuExecutive').value,
      discussion: document.getElementById('fuDiscussion').value,
      customerFeedback: document.getElementById('fuFeedback').value,
      status: document.getElementById('fuStatus').value,
      reminderChannels: channels,
    };
    try {
      const res = await fetch('api/lead_followups.php?action=create', { method: 'POST', body: JSON.stringify(payload) });
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      lmToast('Follow-up saved.');
      backdrop.remove();
      if (onSaved) onSaved();
    } catch (err) { msg.style.color = '#d33'; msg.textContent = err.message; }
  });
}

/* =========================================================
   2. IMPORT LEADS
   ========================================================= */
function renderImportLeadsPage(backAction, backLabel) {
  destroyCharts();
  mainContent.innerHTML = `
    <button class="back-btn" id="lmImpBack"><i class="fas fa-arrow-left"></i> Back to ${lmEsc(backLabel)}</button>
    <div class="eyebrow">Lead Management <span class="crumb-sep">/</span> <span class="crumb-current">Import Leads</span></div>
    <div class="page-title"><span>Import Leads</span></div>

    <div class="form-card">
      <div class="card-title"><h3>Bulk Upload via CSV</h3></div>
      <p style="color:#64748b;font-size:.88rem;margin:-6px 0 16px;">
        Accepted columns: Customer Name, Mobile Number, Email, City, Vehicle Interested, Budget, Source, Sales Executive, Remarks.
        Export your Excel sheet as <strong>CSV (UTF-8)</strong> before uploading.
      </p>
      <div style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap;">
        <a class="btn-secondary" href="api/leads.php?action=sample_csv"><i class="fas fa-download"></i> Download Sample Excel/CSV</a>
      </div>
      <label class="lm-import-drop" id="lmDropZone" for="lmCsvFile">
        <i class="fas fa-file-csv" style="font-size:1.8rem;color:#ff6b4a;"></i>
        <div style="margin-top:8px;font-weight:600;">Click to choose a CSV file</div>
        <div id="lmChosenFileName" style="font-size:.8rem;margin-top:4px;"></div>
      </label>
      <input type="file" id="lmCsvFile" accept=".csv" style="display:none;">
      <div class="form-actions">
        <button type="button" class="btn-primary" id="lmUploadBtn"><i class="fas fa-upload"></i> Upload &amp; Import</button>
        <span id="lmImportMsg" style="margin-left:12px;font-size:.85rem;"></span>
      </div>
    </div>

    <div class="form-card" id="lmImportResultCard" style="display:none;">
      <div class="card-title"><h3>Import Result</h3></div>
      <div class="lm-kpi-strip">
        <div class="lm-kpi-chip"><div class="lm-kpi-value" id="lmResTotal">0</div><div class="lm-kpi-label">Total Records</div></div>
        <div class="lm-kpi-chip"><div class="lm-kpi-value" id="lmResImported">0</div><div class="lm-kpi-label">Imported Successfully</div></div>
        <div class="lm-kpi-chip"><div class="lm-kpi-value" id="lmResDup">0</div><div class="lm-kpi-label">Duplicate Leads</div></div>
        <div class="lm-kpi-chip"><div class="lm-kpi-value" id="lmResFailed">0</div><div class="lm-kpi-label">Failed Records</div></div>
      </div>
      <a class="btn-secondary" id="lmErrorFileLink" href="api/leads.php?action=error_csv" style="display:none;"><i class="fas fa-download"></i> Download Error File</a>
    </div>
  `;
  document.getElementById('lmImpBack').addEventListener('click', backAction);

  const fileInput = document.getElementById('lmCsvFile');
  fileInput.addEventListener('change', () => {
    document.getElementById('lmChosenFileName').textContent = fileInput.files[0]?.name || '';
  });

  document.getElementById('lmUploadBtn').addEventListener('click', async () => {
    const msg = document.getElementById('lmImportMsg');
    if (!fileInput.files[0]) { msg.style.color = '#d33'; msg.textContent = 'Please choose a CSV file first.'; return; }
    msg.style.color = '#64748b'; msg.textContent = 'Importing…';
    const fd = new FormData(); fd.append('file', fileInput.files[0]);
    try {
      const res = await fetch('api/leads.php?action=import', { method: 'POST', body: fd });
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      msg.style.color = 'green'; msg.textContent = 'Import complete.';
      const d = json.data;
      document.getElementById('lmImportResultCard').style.display = 'block';
      document.getElementById('lmResTotal').textContent = d.total;
      document.getElementById('lmResImported').textContent = d.imported;
      document.getElementById('lmResDup').textContent = d.duplicates;
      document.getElementById('lmResFailed').textContent = d.failed;
      document.getElementById('lmErrorFileLink').style.display = d.has_errors ? 'inline-flex' : 'none';
      lmToast(`Imported ${d.imported} of ${d.total} leads.`);
    } catch (err) {
      msg.style.color = '#d33'; msg.textContent = 'Import failed: ' + err.message;
    }
  });
}

/* =========================================================
   3. SOURCE PAGES: Website / Facebook / Google Ads / WhatsApp
   ========================================================= */
const LEAD_SOURCE_CONFIG_FIELDS = {
  facebook: [
    { key: 'pageId', label: 'Facebook Page ID' },
    { key: 'appId', label: 'App ID' },
    { key: 'appSecret', label: 'App Secret', type: 'password' },
    { key: 'accessToken', label: 'Page Access Token', type: 'password' },
  ],
  google_ads: [
    { key: 'developerToken', label: 'Developer Token', type: 'password' },
    { key: 'customerId', label: 'Customer ID' },
    { key: 'oauthClientId', label: 'OAuth Client ID' },
    { key: 'oauthClientSecret', label: 'OAuth Client Secret', type: 'password' },
  ],
  whatsapp: [
    { key: 'phoneNumberId', label: 'Phone Number ID' },
    { key: 'businessAccountId', label: 'WhatsApp Business Account ID' },
    { key: 'accessToken', label: 'Access Token', type: 'password' },
  ],
  website: [],
};

async function renderLeadSourcePage(sourceLabel, sourceKey, backAction, backLabel) {
  destroyCharts();
  const cfgFields = LEAD_SOURCE_CONFIG_FIELDS[sourceKey] || [];

  mainContent.innerHTML = `
    <button class="back-btn" id="lmSrcBack"><i class="fas fa-arrow-left"></i> Back to ${lmEsc(backLabel)}</button>
    <div class="eyebrow">Lead Management <span class="crumb-sep">/</span> <span class="crumb-current">${lmEsc(sourceLabel)} Leads</span></div>
    <div class="page-title"><span>${lmEsc(sourceLabel)} Leads</span><div class="actions"><button class="btn btn-primary" id="lmSrcAddBtn"><i class="fas fa-plus"></i> Add Lead</button></div></div>

    <div class="lm-source-panel" id="lmIntegrationPanel">
      <div class="lm-source-head" id="lmIntegrationToggle">
        <h3><i class="fas fa-plug"></i> Integration Settings</h3>
        <i class="fas fa-chevron-down"></i>
      </div>
      <div class="lm-source-body">
        <label style="font-size:.8rem;font-weight:600;">Webhook URL — point ${lmEsc(sourceLabel)}'s lead notifications here</label>
        <div class="lm-webhook-box" style="margin-top:6px;">
          <span id="lmWebhookUrl">Loading…</span>
          <button type="button" class="btn-secondary" id="lmCopyWebhook">Copy</button>
          <button type="button" class="btn-secondary" id="lmRegenToken">Regenerate</button>
        </div>
        ${cfgFields.length ? `
        <div class="form-grid" style="margin-top:16px;">
          ${cfgFields.map(f => `<div class="form-group"><label>${f.label}</label><input type="${f.type || 'text'}" id="lmCfg_${f.key}"></div>`).join('')}
        </div>` : `<p style="font-size:.82rem;color:#64748b;margin-top:12px;">No external credentials needed — your website's enquiry form posts straight to the webhook URL above as JSON (<code>name, mobile, email, city, vehicle, message</code>).</p>`}
        <div class="form-actions" style="margin-top:14px;">
          ${cfgFields.length ? `<button type="button" class="btn-primary" id="lmSaveIntegration">Save Settings</button>` : ''}
          <button type="button" class="btn-secondary" id="lmTestIntegration"><i class="fas fa-satellite-dish"></i> Test Connection</button>
          <span id="lmIntegrationMsg" style="margin-left:10px;font-size:.82rem;"></span>
        </div>
      </div>
    </div>

    <div class="lm-filters">
      <input type="text" id="lmSrcSearch" placeholder="Search name / mobile / lead ID">
      <select id="lmSrcStatus"><option value="">All statuses</option>${lmFieldOptions([...LEAD_STATUS_FLOW, LEAD_LOST_STATUS])}</select>
    </div>

    <div class="table-panel">
      <div class="panel-head"><div><div class="panel-title">${lmEsc(sourceLabel)} Leads</div><div class="panel-sub">Live records from the database</div></div></div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>Lead ID</th><th>Customer</th><th>Vehicle</th><th>Executive</th><th>Priority</th><th>Status</th><th>Next Follow-up</th><th>Actions</th></tr></thead>
          <tbody id="lmSrcTbody"><tr><td colspan="8">Loading…</td></tr></tbody>
        </table>
      </div>
    </div>
  `;

  document.getElementById('lmSrcBack').addEventListener('click', backAction);
  document.getElementById('lmSrcAddBtn').addEventListener('click', () => renderLeadForm(null, () => renderLeadSourcePage(sourceLabel, sourceKey, backAction, backLabel), `${sourceLabel} Leads`));

  const toggle = document.getElementById('lmIntegrationToggle');
  const panel = document.getElementById('lmIntegrationPanel');
  toggle.addEventListener('click', () => panel.classList.toggle('open'));

  async function loadIntegration() {
    try {
      const res = await fetch(`api/lead_settings.php?action=get&source=${sourceKey}`);
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      document.getElementById('lmWebhookUrl').textContent = json.data.webhookUrl;
      cfgFields.forEach(f => {
        const el = document.getElementById(`lmCfg_${f.key}`);
        if (el && json.data.config[f.key]) el.value = json.data.config[f.key];
      });
      if (json.data.lastTestResult) {
        document.getElementById('lmIntegrationMsg').textContent = json.data.lastTestResult;
      }
    } catch (err) {
      document.getElementById('lmWebhookUrl').textContent = 'Could not load: ' + err.message;
    }
  }
  loadIntegration();

  document.getElementById('lmCopyWebhook').addEventListener('click', () => {
    const text = document.getElementById('lmWebhookUrl').textContent;
    navigator.clipboard?.writeText(text);
    lmToast('Webhook URL copied.');
  });
  document.getElementById('lmRegenToken').addEventListener('click', async () => {
    if (!confirm('Regenerating the token will invalidate the old webhook URL. Continue?')) return;
    const res = await fetch(`api/lead_settings.php?action=regenerate_token&source=${sourceKey}`, { method: 'POST' });
    const json = await res.json();
    if (json.success) { document.getElementById('lmWebhookUrl').textContent = json.data.webhookUrl; lmToast('Webhook token regenerated.'); }
  });
  const saveBtn = document.getElementById('lmSaveIntegration');
  if (saveBtn) saveBtn.addEventListener('click', async () => {
    const config = {};
    cfgFields.forEach(f => { config[f.key] = document.getElementById(`lmCfg_${f.key}`).value; });
    const res = await fetch(`api/lead_settings.php?action=save&source=${sourceKey}`, { method: 'POST', body: JSON.stringify(config) });
    const json = await res.json();
    document.getElementById('lmIntegrationMsg').textContent = json.message || '';
    if (json.success) lmToast('Integration settings saved.');
  });
  document.getElementById('lmTestIntegration').addEventListener('click', async () => {
    const msgEl = document.getElementById('lmIntegrationMsg');
    msgEl.style.color = '#64748b'; msgEl.textContent = 'Testing…';
    const res = await fetch(`api/lead_settings.php?action=test&source=${sourceKey}`, { method: 'POST' });
    const json = await res.json();
    msgEl.style.color = json.success ? '#16a34a' : '#d3312f';
    msgEl.textContent = json.message;
  });

  async function loadTable() {
    const tbody = document.getElementById('lmSrcTbody');
    tbody.innerHTML = `<tr><td colspan="8">Loading…</td></tr>`;
    try {
      const params = { source: sourceLabel };
      const q = document.getElementById('lmSrcSearch').value.trim();
      const st = document.getElementById('lmSrcStatus').value;
      if (q) params.q = q;
      if (st) params.status = st;
      const json = await lmFetchLeads(params);
      tbody.innerHTML = lmRowsHTML(json.data, { showSource: false });
      lmWireRowActions(tbody, loadTable, () => renderLeadSourcePage(sourceLabel, sourceKey, backAction, backLabel), `${sourceLabel} Leads`);
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="8">Failed to load: ${lmEsc(err.message)}</td></tr>`;
    }
  }
  document.getElementById('lmSrcSearch').addEventListener('input', debounceLm(loadTable, 400));
  document.getElementById('lmSrcStatus').addEventListener('change', loadTable);
  loadTable();
}

function debounceLm(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

/* =========================================================
   4. ASSIGNED LEADS
   ========================================================= */
async function renderAssignedLeadsPage(backAction, backLabel) {
  destroyCharts();
  mainContent.innerHTML = `
    <button class="back-btn" id="lmAsgBack"><i class="fas fa-arrow-left"></i> Back to ${lmEsc(backLabel)}</button>
    <div class="eyebrow">Lead Management <span class="crumb-sep">/</span> <span class="crumb-current">Assigned Leads</span></div>
    <div class="page-title"><span>Assigned Leads</span></div>

    <div class="lm-filters">
      <input type="text" id="lmAsgExec" placeholder="Executive">
      <input type="text" id="lmAsgBranch" placeholder="Branch">
      <select id="lmAsgStatus"><option value="">All statuses</option>${lmFieldOptions([...LEAD_STATUS_FLOW, LEAD_LOST_STATUS])}</select>
      <select id="lmAsgPriority"><option value="">All priorities</option><option>Hot</option><option>Warm</option><option>Cold</option></select>
      <input type="date" id="lmAsgDate">
    </div>

    <div class="table-panel">
      <div class="panel-head"><div><div class="panel-title">Assigned Leads</div><div class="panel-sub">Every lead currently owned by a sales executive</div></div></div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>Lead ID</th><th>Customer</th><th>Vehicle</th><th>Source</th><th>Executive</th><th>Priority</th><th>Status</th><th>Next Follow-up</th><th>Actions</th></tr></thead>
          <tbody id="lmAsgTbody"><tr><td colspan="9">Loading…</td></tr></tbody>
        </table>
      </div>
    </div>
  `;
  document.getElementById('lmAsgBack').addEventListener('click', backAction);

  async function loadTable() {
    const tbody = document.getElementById('lmAsgTbody');
    tbody.innerHTML = `<tr><td colspan="9">Loading…</td></tr>`;
    try {
      const params = {};
      const exec = document.getElementById('lmAsgExec').value.trim();
      const branch = document.getElementById('lmAsgBranch').value.trim();
      const status = document.getElementById('lmAsgStatus').value;
      const priority = document.getElementById('lmAsgPriority').value;
      const date = document.getElementById('lmAsgDate').value;
      if (exec) params.executive = exec;
      if (branch) params.branch = branch;
      if (status) params.status = status;
      if (priority) params.priority = priority;
      if (date) { params.date_from = date; params.date_to = date; }
      const json = await lmFetchLeads(params);
      tbody.innerHTML = lmRowsHTML(json.data, { showSource: true });
      lmWireRowActions(tbody, loadTable, () => renderAssignedLeadsPage(backAction, backLabel), 'Assigned Leads');
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="9">Failed to load: ${lmEsc(err.message)}</td></tr>`;
    }
  }
  ['lmAsgExec', 'lmAsgBranch'].forEach(id => document.getElementById(id).addEventListener('input', debounceLm(loadTable, 400)));
  ['lmAsgStatus', 'lmAsgPriority', 'lmAsgDate'].forEach(id => document.getElementById(id).addEventListener('change', loadTable));
  loadTable();
}

/* =========================================================
   5. FOLLOW-UP
   ========================================================= */
async function renderFollowupPage(backAction, backLabel) {
  destroyCharts();
  mainContent.innerHTML = `
    <button class="back-btn" id="lmFuBack"><i class="fas fa-arrow-left"></i> Back to ${lmEsc(backLabel)}</button>
    <div class="eyebrow">Lead Management <span class="crumb-sep">/</span> <span class="crumb-current">Follow-up</span></div>
    <div class="page-title"><span>Follow-up</span></div>

    <div class="table-panel">
      <div class="panel-head"><div><div class="panel-title">Due Today &amp; Overdue</div><div class="panel-sub">Leads waiting on their next follow-up</div></div></div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>Lead ID</th><th>Customer</th><th>Mobile</th><th>Executive</th><th>Priority</th><th>Next Follow-up</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody id="lmFuTbody"><tr><td colspan="8">Loading…</td></tr></tbody>
        </table>
      </div>
    </div>
  `;
  document.getElementById('lmFuBack').addEventListener('click', backAction);

  async function loadDue() {
    const tbody = document.getElementById('lmFuTbody');
    try {
      const res = await fetch('api/lead_followups.php?action=due');
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      if (!json.data.length) { tbody.innerHTML = `<tr><td colspan="8">Nothing due — you're all caught up.</td></tr>`; return; }
      tbody.innerHTML = json.data.map(l => `
        <tr>
          <td class="cell-strong">${lmEsc(l.lead_code)}</td>
          <td>${lmEsc(l.customer_name)}</td>
          <td>${lmEsc(l.mobile)}</td>
          <td>${lmEsc(l.sales_executive) || '—'}</td>
          <td>${lmPriorityChip(l.priority)}</td>
          <td>${lmEsc(l.next_followup_date)}</td>
          <td><span class="status-chip ${statusClass(l.status)}">${lmEsc(l.status)}</span></td>
          <td>
            <button type="button" class="btn-primary lm-fu-add" data-id="${l.id}">Add Follow-up</button>
            <button type="button" class="btn-secondary lm-fu-view" data-id="${l.id}">Open Lead</button>
          </td>
        </tr>`).join('');
      tbody.querySelectorAll('.lm-fu-add').forEach(btn => btn.addEventListener('click', () =>
        openAddFollowupModal(btn.dataset.id, loadDue)));
      tbody.querySelectorAll('.lm-fu-view').forEach(btn => btn.addEventListener('click', () =>
        renderLeadForm(btn.dataset.id, () => renderFollowupPage(backAction, backLabel), 'Follow-up')));
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="8">Failed to load: ${lmEsc(err.message)}</td></tr>`;
    }
  }
  loadDue();
}

/* =========================================================
   6. LEAD STATUS  (KPI dashboard + kanban pipeline)
   ========================================================= */
async function renderLeadStatusPage(backAction, backLabel) {
  destroyCharts();
  mainContent.innerHTML = `
    <button class="back-btn" id="lmStBack"><i class="fas fa-arrow-left"></i> Back to ${lmEsc(backLabel)}</button>
    <div class="eyebrow">Lead Management <span class="crumb-sep">/</span> <span class="crumb-current">Lead Status</span></div>
    <div class="page-title"><span>Lead Status</span></div>

    <div class="lm-kpi-strip" id="lmStKpis">
      <div class="lm-kpi-chip"><div class="lm-kpi-value">…</div><div class="lm-kpi-label">Loading</div></div>
    </div>

    <div class="lm-kanban" id="lmKanban"></div>
  `;
  document.getElementById('lmStBack').addEventListener('click', backAction);

  try {
    const res = await fetch('api/leads.php?action=stats');
    const json = await res.json();
    if (!json.success) throw new Error(json.message);
    const d = json.data;
    const kpis = [
      ['Total New Leads', d.by_status['New Lead'] || 0],
      ["Today's Leads", d.today_leads],
      ['Pending Follow-ups', d.pending_followups],
      ['Test Drives', d.test_drives],
      ['Quotations Sent', d.quotations_sent],
      ['Booking Done', d.booking_done],
      ['Delivered', d.delivered],
      ['Lost Leads', d.lost_leads],
    ];
    document.getElementById('lmStKpis').innerHTML = kpis.map(([label, val]) =>
      `<div class="lm-kpi-chip"><div class="lm-kpi-value">${val}</div><div class="lm-kpi-label">${label}</div></div>`).join('');

    const kanban = document.getElementById('lmKanban');
    const columns = [...LEAD_STATUS_FLOW, LEAD_LOST_STATUS];
    kanban.innerHTML = columns.map(status => `
      <div class="lm-kanban-col" data-status="${lmEsc(status)}">
        <h4><span>${lmEsc(status)}</span><span>${d.by_status[status] || 0}</span></h4>
        <div class="lm-kanban-cards" id="lmCol_${status.replace(/\s+/g, '_')}"><div style="font-size:.75rem;color:#8f97a8;">Loading…</div></div>
      </div>`).join('');

    for (const status of columns) {
      const params = { status, per_page: 15 };
      try {
        const json2 = await lmFetchLeads(params);
        const col = document.getElementById(`lmCol_${status.replace(/\s+/g, '_')}`);
        if (!json2.data.length) { col.innerHTML = `<div style="font-size:.75rem;color:#8f97a8;">None</div>`; continue; }
        col.innerHTML = json2.data.map(l => `
          <div class="lm-kanban-card" data-id="${l.id}">
            <div class="lm-kc-name">${lmEsc(l.customer_name)}</div>
            <div class="lm-kc-meta">${lmEsc(l.lead_code)} · ${lmPriorityChip(l.priority)}</div>
          </div>`).join('');
        col.querySelectorAll('.lm-kanban-card').forEach(card => card.addEventListener('click', () =>
          renderLeadForm(card.dataset.id, () => renderLeadStatusPage(backAction, backLabel), 'Lead Status')));
      } catch (err) { /* leave column silent on individual failure */ }
    }
  } catch (err) {
    document.getElementById('lmStKpis').innerHTML = `<div class="lm-kpi-chip">Failed to load: ${lmEsc(err.message)}</div>`;
  }
}

/* =========================================================
   7. LOST LEADS  (list + reports)
   ========================================================= */
async function renderLostLeadsPage(backAction, backLabel) {
  destroyCharts();
  mainContent.innerHTML = `
    <button class="back-btn" id="lmLostBack"><i class="fas fa-arrow-left"></i> Back to ${lmEsc(backLabel)}</button>
    <div class="eyebrow">Lead Management <span class="crumb-sep">/</span> <span class="crumb-current">Lost Leads</span></div>
    <div class="page-title"><span>Lost Leads</span></div>

    <div class="table-panel">
      <div class="panel-head"><div><div class="panel-title">Lost Leads</div><div class="panel-sub">Leads that did not convert</div></div></div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>Lead ID</th><th>Customer</th><th>Vehicle</th><th>Lost Date</th><th>Reason</th><th>Competitor</th><th>Executive</th><th>Actions</th></tr></thead>
          <tbody id="lmLostTbody"><tr><td colspan="8">Loading…</td></tr></tbody>
        </table>
      </div>
    </div>

    <div class="form-card">
      <div class="card-title"><h3>Lost Lead Reports</h3></div>
      <div class="chart-grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px;">
        <div><h4 style="font-size:.85rem;margin-bottom:8px;">By Reason</h4><div style="height:220px;"><canvas id="lmLostByReason"></canvas></div></div>
        <div><h4 style="font-size:.85rem;margin-bottom:8px;">By Executive</h4><div style="height:220px;"><canvas id="lmLostByExec"></canvas></div></div>
        <div><h4 style="font-size:.85rem;margin-bottom:8px;">By Brand</h4><div style="height:220px;"><canvas id="lmLostByBrand"></canvas></div></div>
        <div><h4 style="font-size:.85rem;margin-bottom:8px;">By Model</h4><div style="height:220px;"><canvas id="lmLostByModel"></canvas></div></div>
        <div><h4 style="font-size:.85rem;margin-bottom:8px;">By City</h4><div style="height:220px;"><canvas id="lmLostByCity"></canvas></div></div>
        <div><h4 style="font-size:.85rem;margin-bottom:8px;">By Month</h4><div style="height:220px;"><canvas id="lmLostByMonth"></canvas></div></div>
      </div>
    </div>
  `;
  document.getElementById('lmLostBack').addEventListener('click', backAction);

  async function loadTable() {
    const tbody = document.getElementById('lmLostTbody');
    try {
      const json = await lmFetchLeads({ status: 'Lost' });
      if (!json.data.length) { tbody.innerHTML = `<tr><td colspan="8">No lost leads recorded.</td></tr>`; return; }
      tbody.innerHTML = json.data.map(l => `
        <tr>
          <td class="cell-strong">${lmEsc(l.lead_code)}</td>
          <td>${lmEsc(l.customer_name)}</td>
          <td>${lmEsc([l.vehicle_brand, l.vehicle_model].filter(Boolean).join(' ')) || '—'}</td>
          <td>${lmEsc(l.lost_date) || '—'}</td>
          <td>${lmEsc(l.lost_reason) || '—'}</td>
          <td>${lmEsc(l.competitor_name) || '—'}</td>
          <td>${lmEsc(l.sales_executive) || '—'}</td>
          <td><button type="button" class="btn-secondary lm-view" data-id="${l.id}">View</button></td>
        </tr>`).join('');
      tbody.querySelectorAll('.lm-view').forEach(btn => btn.addEventListener('click', () =>
        renderLeadForm(btn.dataset.id, () => renderLostLeadsPage(backAction, backLabel), 'Lost Leads')));
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="8">Failed to load: ${lmEsc(err.message)}</td></tr>`;
    }
  }
  loadTable();

  try {
    const res = await fetch('api/leads.php?action=lost_reports');
    const json = await res.json();
    if (!json.success) throw new Error(json.message);
    const d = json.data;
    renderDonutChartData('lmLostByReason', d.by_reason.map(r => r.label), d.by_reason.map(r => r.count));
    renderBarChartData('lmLostByExec', d.by_executive.map(r => r.label), d.by_executive.map(r => r.count), '#ff6b4a');
    renderBarChartData('lmLostByBrand', d.by_brand.map(r => r.label), d.by_brand.map(r => r.count), '#7c5cff');
    renderBarChartData('lmLostByModel', d.by_model.map(r => r.label), d.by_model.map(r => r.count), '#14b8a6');
    renderBarChartData('lmLostByCity', d.by_city.map(r => r.label), d.by_city.map(r => r.count), '#e08c1c');
    renderBarChartData('lmLostByMonth', d.by_month.map(r => r.label), d.by_month.map(r => r.count), '#2563eb');
  } catch (err) { /* charts are supplementary — table above still works */ }
}

/* =========================================================
   8. CONVERTED LEADS  (list + reports)
   ========================================================= */
async function renderConvertedLeadsPage(backAction, backLabel) {
  destroyCharts();
  mainContent.innerHTML = `
    <button class="back-btn" id="lmConvBack"><i class="fas fa-arrow-left"></i> Back to ${lmEsc(backLabel)}</button>
    <div class="eyebrow">Lead Management <span class="crumb-sep">/</span> <span class="crumb-current">Converted Leads</span></div>
    <div class="page-title"><span>Converted Leads</span></div>

    <div class="lm-kpi-strip" id="lmConvKpis">
      <div class="lm-kpi-chip"><div class="lm-kpi-value">…</div><div class="lm-kpi-label">Loading</div></div>
    </div>

    <div class="table-panel">
      <div class="panel-head"><div><div class="panel-title">Converted Leads</div><div class="panel-sub">Bookings and deliveries</div></div></div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>Lead ID</th><th>Customer</th><th>Vehicle</th><th>Booking No.</th><th>Booking Date</th><th>Delivery Date</th><th>Final Amount</th><th>Executive</th><th>Actions</th></tr></thead>
          <tbody id="lmConvTbody"><tr><td colspan="9">Loading…</td></tr></tbody>
        </table>
      </div>
    </div>

    <div class="form-card">
      <div class="card-title"><h3>Sales Reports</h3></div>
      <div class="chart-grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px;">
        <div><h4 style="font-size:.85rem;margin-bottom:8px;">Executive Performance (₹)</h4><div style="height:220px;"><canvas id="lmConvByExec"></canvas></div></div>
        <div><h4 style="font-size:.85rem;margin-bottom:8px;">Branch Performance (₹)</h4><div style="height:220px;"><canvas id="lmConvByBranch"></canvas></div></div>
        <div><h4 style="font-size:.85rem;margin-bottom:8px;">Vehicle-wise Sales (₹)</h4><div style="height:220px;"><canvas id="lmConvByVehicle"></canvas></div></div>
        <div><h4 style="font-size:.85rem;margin-bottom:8px;">Monthly Revenue (₹)</h4><div style="height:220px;"><canvas id="lmConvMonthly"></canvas></div></div>
      </div>
    </div>
  `;
  document.getElementById('lmConvBack').addEventListener('click', backAction);

  async function loadTable() {
    const tbody = document.getElementById('lmConvTbody');
    try {
      const json = await lmFetchLeads({ status: 'Converted' });
      if (!json.data.length) { tbody.innerHTML = `<tr><td colspan="9">No converted leads yet.</td></tr>`; return; }
      tbody.innerHTML = json.data.map(l => `
        <tr>
          <td class="cell-strong">${lmEsc(l.lead_code)}</td>
          <td>${lmEsc(l.customer_name)}</td>
          <td>${lmEsc([l.vehicle_brand, l.vehicle_model, l.variant].filter(Boolean).join(' ')) || '—'}</td>
          <td>${lmEsc(l.booking_number) || '—'}</td>
          <td>${lmEsc(l.booking_date) || '—'}</td>
          <td>${lmEsc(l.delivery_date) || '—'}</td>
          <td>${l.final_amount ? money(l.final_amount) : '—'}</td>
          <td>${lmEsc(l.sales_executive) || '—'}</td>
          <td><button type="button" class="btn-secondary lm-view" data-id="${l.id}">View</button></td>
        </tr>`).join('');
      tbody.querySelectorAll('.lm-view').forEach(btn => btn.addEventListener('click', () =>
        renderLeadForm(btn.dataset.id, () => renderConvertedLeadsPage(backAction, backLabel), 'Converted Leads')));
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="9">Failed to load: ${lmEsc(err.message)}</td></tr>`;
    }
  }
  loadTable();

  try {
    const res = await fetch('api/leads.php?action=sales_reports');
    const json = await res.json();
    if (!json.success) throw new Error(json.message);
    const d = json.data;
    document.getElementById('lmConvKpis').innerHTML = [
      ['Total Revenue', money(d.total_revenue)],
      ['Converted', d.converted_total],
      ['Finance Conversion', d.finance_count],
      ['Exchange Conversion', d.exchange_count],
    ].map(([label, val]) => `<div class="lm-kpi-chip"><div class="lm-kpi-value">${val}</div><div class="lm-kpi-label">${label}</div></div>`).join('');

    renderBarChartData('lmConvByExec', d.by_executive.map(r => r.label), d.by_executive.map(r => r.amount), '#ff6b4a');
    renderBarChartData('lmConvByBranch', d.by_branch.map(r => r.label), d.by_branch.map(r => r.amount), '#7c5cff');
    renderBarChartData('lmConvByVehicle', d.by_vehicle.map(r => r.label), d.by_vehicle.map(r => r.amount), '#14b8a6');
    renderBarChartData('lmConvMonthly', d.monthly.map(r => r.label), d.monthly.map(r => r.amount), '#2563eb');
  } catch (err) { /* charts are supplementary */ }
}
