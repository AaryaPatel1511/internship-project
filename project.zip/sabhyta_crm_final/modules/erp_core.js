/* =========================================================
   ERP CORE (front end)
   Schema-driven forms and lists for Marketing, Project Mgmt,
   Asset Mgmt, Document Mgmt and Administration.
   The field definitions come from api/erp.php?action=meta so the
   browser and the server always agree about every form.
   Depends on globals from script.js: mainContent, money, destroyCharts
   ========================================================= */

const ERP = { meta: null, metaPromise: null, lk: {} };

/* ---------------------------------------------------------
   Basics
   --------------------------------------------------------- */
function erpEsc(v) {
  if (v === null || v === undefined) return '';
  return String(v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function erpToast(message, type = 'success') {
  let host = document.getElementById('erpToastHost');
  if (!host) {
    host = document.createElement('div');
    host.id = 'erpToastHost';
    host.style.cssText = 'position:fixed;top:20px;right:20px;z-index:99999;display:flex;flex-direction:column;gap:8px;max-width:380px;';
    document.body.appendChild(host);
  }
  const bg = { success: '#16a34a', error: '#d3312f', info: '#3556d6', warn: '#c77a0b' }[type] || '#16a34a';
  const el = document.createElement('div');
  el.textContent = message;
  el.style.cssText = `padding:11px 16px;border-radius:8px;font-size:.84rem;font-weight:600;color:#fff;box-shadow:0 8px 24px rgba(15,23,42,.22);background:${bg};line-height:1.4;`;
  host.appendChild(el);
  setTimeout(() => el.remove(), type === 'error' ? 7000 : 4500);
}
function erpNotices(res) { (res && res.notices || []).forEach(n => erpToast(n, 'info')); }

async function erpReq(method, action, params = {}, body = null) {
  const qs = new URLSearchParams({ action });
  Object.entries(params || {}).forEach(([k, v]) => { if (v !== null && v !== undefined && v !== '') qs.set(k, v); });
  const opt = { method, credentials: 'same-origin' };
  if (body) {
    const hasFile = Object.values(body).some(v => v instanceof File || v instanceof Blob);
    if (hasFile) {
      const fd = new FormData();
      Object.entries(body).forEach(([k, v]) => {
        if (Array.isArray(v)) v.forEach(x => fd.append(k + '[]', x));
        else if (v instanceof Blob) fd.append(k, v, v.name || 'upload');
        else if (v !== null && v !== undefined) fd.append(k, v);
      });
      opt.body = fd;
    } else {
      opt.headers = { 'Content-Type': 'application/json' };
      opt.body = JSON.stringify(body);
    }
  }
  const res = await fetch('api/erp.php?' + qs.toString(), opt);
  let json;
  try { json = await res.json(); } catch (e) { throw new Error('The server returned an unexpected response (HTTP ' + res.status + ').'); }
  if (!json.success) {
    const err = new Error(json.message || 'Request failed');
    err.status = res.status; err.payload = json;
    throw err;
  }
  return json;
}
const erpGet = (action, params) => erpReq('GET', action, params);
const erpPost = (action, body, params) => erpReq('POST', action, params, body || {});
function erpUrl(action, params = {}) {
  const qs = new URLSearchParams({ action });
  Object.entries(params).forEach(([k, v]) => { if (v !== null && v !== undefined && v !== '') qs.set(k, v); });
  return 'api/erp.php?' + qs.toString();
}

function erpMeta() {
  if (ERP.meta) return Promise.resolve(ERP.meta);
  if (!ERP.metaPromise) {
    ERP.metaPromise = erpGet('meta').then(r => (ERP.meta = r.data)).catch(e => { ERP.metaPromise = null; throw e; });
  }
  return ERP.metaPromise;
}
function erpLookup(src, params = {}) {
  const key = src + '|' + JSON.stringify(params);
  if (!ERP.lk[key]) ERP.lk[key] = erpGet('lookup', Object.assign({ src }, params)).then(r => r.data).catch(e => { delete ERP.lk[key]; throw e; });
  return ERP.lk[key];
}
function erpClearLookups() { ERP.lk = {}; }

/* ---------------------------------------------------------
   Formatting
   --------------------------------------------------------- */
const ERP_CHIPS = {
  green: ['active', 'approved', 'completed', 'done', 'resolved', 'reached', 'success', 'closed', 'in use', 'returned', 'running', 'paid', 'clean', 'reached', 'production', 'ahead of schedule', 'on track'],
  amber: ['pending', 'in progress', 'scheduled', 'planning', 'open', 'fixing', 'logged', 'submitted', 'pending review', 'paused', 'in repair', 'testing', 'medium', 'major', 'renewal due', 'needs review', 'to do'],
  red: ['rejected', 'failed', 'critical', 'overdue', 'expired', 'cancelled', 'high', 'high spam risk', 'behind schedule', 'suspended', 'bounced', 'unsubscribed'],
  blue: ['in stock', 'staging', 'new', 'draft', 'purchased', 'assigned', 'ip_whitelist'],
  purple: ['ip_blacklist', 'depreciated', 'maintenance'],
};
function erpChipClass(v) {
  const s = String(v).toLowerCase();
  for (const [c, list] of Object.entries(ERP_CHIPS)) if (list.includes(s)) return 'erp-c-' + c;
  return 'erp-c-grey';
}
function erpChip(v) {
  if (v === null || v === undefined || v === '') return '<span class="erp-muted">—</span>';
  return `<span class="erp-chip ${erpChipClass(v)}">${erpEsc(String(v).replace('IP_', 'IP '))}</span>`;
}
const ERP_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function erpFmtDate(v) {
  if (!v) return '';
  const m = String(v).match(/^(\d{4})-(\d{2})-(\d{2})/);
  return m ? `${parseInt(m[3], 10)} ${ERP_MONTHS[parseInt(m[2], 10) - 1]} ${m[1]}` : erpEsc(v);
}
function erpFmtDateTime(v) {
  if (!v) return '';
  const m = String(v).match(/^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})/);
  return m ? `${erpFmtDate(m[1])}, ${m[2]}` : erpFmtDate(v);
}
function erpMoney(v, dec = 2) {
  const n = Number(v);
  if (!isFinite(n)) return '';
  return '₹' + n.toLocaleString('en-IN', { minimumFractionDigits: n % 1 ? dec : 0, maximumFractionDigits: dec });
}
function erpBytes(n) {
  n = Number(n);
  if (!n) return '';
  return n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB';
}
function erpFmtCell(fmt, v, row) {
  if (v === null || v === undefined || v === '') {
    if (fmt === 'hours' && row && Number(row.is_running) === 1) return '<span class="erp-chip erp-c-green">Running</span>';
    return '<span class="erp-muted">—</span>';
  }
  switch (fmt) {
    case 'chip': return erpChip(v);
    case 'money': return erpMoney(v);
    case 'date': return erpEsc(erpFmtDate(v));
    case 'datetime': return erpEsc(erpFmtDateTime(v));
    case 'bool': return Number(v) === 1 ? '<i class="fas fa-check" style="color:#16a34a"></i>' : '<span class="erp-muted">—</span>';
    case 'num': return Number(v).toLocaleString('en-IN');
    case 'pct': return erpEsc(v) + '%';
    case 'x': return erpEsc(v) + '×';
    case 'hours': return Number(v).toFixed(2) + ' h';
    case 'bytes': return erpEsc(erpBytes(v));
    case 'trunc': return `<span class="erp-trunc" title="${erpEsc(v)}">${erpEsc(v)}</span>`;
    case 'masked': return `<span class="erp-mono">${erpEsc(v)}</span>`;
    case 'link': return `<a class="erp-link erp-trunc" href="${erpEsc(v)}" target="_blank" rel="noopener noreferrer" title="${erpEsc(v)}">${erpEsc(v)}</a>`;
    case 'days': {
      const d = Number(v);
      if (d < 0) return `<span class="erp-chip erp-c-red">Expired ${-d}d ago</span>`;
      if (d <= 30) return `<span class="erp-chip erp-c-amber">${d}d left</span>`;
      return `<span class="erp-muted">${d}d</span>`;
    }
    case 'progress': {
      const p = Math.max(0, Math.min(100, Number(row && row.progress != null ? row.progress : v) || 0));
      return `<div class="erp-prog"><div class="erp-prog-bar"><span style="width:${p}%"></span></div><small>${p}%</small></div>`;
    }
    default: return erpEsc(v);
  }
}
function erpProgressCell(row) { return erpFmtCell('progress', row.progress, row); }

/* ---------------------------------------------------------
   Dialogs
   --------------------------------------------------------- */
function erpModal({ title, body = '', footer = [], wide = false, onClose }) {
  const ov = document.createElement('div');
  ov.className = 'erp-overlay';
  ov.innerHTML = `<div class="erp-modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">
      <div class="erp-modal-head"><h3>${erpEsc(title)}</h3><button type="button" class="erp-x" aria-label="Close">&times;</button></div>
      <div class="erp-modal-body"></div>
      <div class="erp-modal-foot"></div>
    </div>`;
  document.body.appendChild(ov);
  const bodyEl = ov.querySelector('.erp-modal-body');
  const footEl = ov.querySelector('.erp-modal-foot');
  if (typeof body === 'string') bodyEl.innerHTML = body; else bodyEl.appendChild(body);
  const api = {
    el: ov, body: bodyEl, foot: footEl,
    close() { ov.remove(); document.removeEventListener('keydown', onKey); if (onClose) onClose(); },
  };
  function onKey(e) { if (e.key === 'Escape') api.close(); }
  document.addEventListener('keydown', onKey);
  ov.querySelector('.erp-x').addEventListener('click', () => api.close());
  ov.addEventListener('mousedown', e => { if (e.target === ov) api.close(); });
  footer.forEach(b => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = b.cls || 'btn-secondary';
    btn.textContent = b.label;
    btn.addEventListener('click', () => b.onClick && b.onClick(api, btn));
    footEl.appendChild(btn);
  });
  if (!footer.length) footEl.remove();
  return api;
}

function erpConfirm(message, { okLabel = 'Confirm', danger = false, title = 'Please confirm' } = {}) {
  return new Promise(resolve => {
    let done = false;
    const m = erpModal({
      title, body: `<p style="margin:0;font-size:.92rem;line-height:1.5;color:#333">${erpEsc(message)}</p>`,
      footer: [
        { label: 'Cancel', cls: 'btn-secondary', onClick: a => { done = true; a.close(); resolve(false); } },
        { label: okLabel, cls: 'btn-primary', onClick: a => { done = true; a.close(); resolve(true); } },
      ],
      onClose: () => { if (!done) resolve(false); },
    });
    if (danger) m.foot.lastChild.style.background = '#d3312f';
  });
}

/** Small input dialog. fields: [{k,l,t,req,opts,def,help,src,rows}]. onSubmit(values) may throw to keep the dialog open. */
function erpDialog({ title, fields = [], okLabel = 'Save', note = '', wide = false, onSubmit }) {
  return new Promise(resolve => {
    let finished = false;
    const wrap = document.createElement('div');
    wrap.innerHTML = `${note ? `<p style="margin:0 0 14px;font-size:.85rem;color:#555;line-height:1.5">${note}</p>` : ''}
      <div class="erp-fgrid ${fields.length > 3 && wide ? 'two' : ''}">${fields.map(f => erpDialogField(f)).join('')}</div>
      <div class="erp-form-msg err" id="erpDlgErr" style="margin-top:12px"></div>`;
    const m = erpModal({
      title, body: wrap, wide,
      footer: [
        { label: 'Cancel', cls: 'btn-secondary', onClick: a => { finished = true; a.close(); resolve(false); } },
        {
          label: okLabel, cls: 'btn-primary', onClick: async (a, btn) => {
            const err = wrap.querySelector('#erpDlgErr'); err.textContent = '';
            const vals = {};
            for (const f of fields) {
              const el = wrap.querySelector('#erpd_' + f.k);
              let v;
              if (f.t === 'checkbox') v = el.checked ? 1 : 0;
              else if (f.t === 'file') v = el.files[0] || null;
              else if (f.t === 'multiselect') v = [...el.selectedOptions].map(o => o.value);
              else v = el.value;
              if (f.req && (v === '' || v === null || (Array.isArray(v) && !v.length) || (f.t === 'checkbox' && !v))) { err.textContent = `${f.l} is required.`; el.focus(); return; }
              vals[f.k] = v;
            }
            btn.disabled = true; btn.textContent = 'Please wait…';
            try {
              if (onSubmit) await onSubmit(vals, a);
              finished = true; a.close(); resolve(true);
            } catch (e) { err.textContent = e.message; btn.disabled = false; btn.textContent = okLabel; }
          },
        },
      ],
      onClose: () => { if (!finished) resolve(false); },
    });
    // lookups
    fields.filter(f => f.src || f.optsAsync).forEach(async f => {
      const el = wrap.querySelector('#erpd_' + f.k);
      try {
        const rows = f.optsAsync ? await f.optsAsync() : await erpLookup(f.src, f.srcParams || {});
        el.insertAdjacentHTML('beforeend', rows.map(r => `<option value="${erpEsc(r.id)}">${erpEsc(r.label)}</option>`).join(''));
        if (f.def) el.value = f.def;
      } catch (e) { /* leave empty */ }
    });
    const first = wrap.querySelector('input,select,textarea'); if (first) setTimeout(() => first.focus(), 30);
  });
}
function erpDialogField(f) {
  const id = 'erpd_' + f.k, req = f.req ? ' <span class="erp-req">*</span>' : '';
  const help = f.help ? `<div class="erp-help">${f.help}</div>` : '';
  const dv = f.def !== undefined && f.def !== null ? erpEsc(f.def) : '';
  let ctl;
  if (f.t === 'select') ctl = `<select id="${id}">${f.req ? '' : '<option value="">— Select —</option>'}${(f.opts || []).map(o => `<option ${String(o) === String(f.def) ? 'selected' : ''}>${erpEsc(o)}</option>`).join('')}</select>`;
  else if (f.src || f.optsAsync) ctl = `<select id="${id}"><option value="">— Select —</option></select>`;
  else if (f.t === 'multiselect') ctl = `<select id="${id}" multiple size="6"></select>`;
  else if (f.t === 'textarea') ctl = `<textarea id="${id}" rows="${f.rows || 3}">${dv}</textarea>`;
  else if (f.t === 'checkbox') return `<div class="erp-field"><label class="erp-check"><input type="checkbox" id="${id}" ${f.def ? 'checked' : ''}> ${f.l}${req}</label>${help}</div>`;
  else if (f.t === 'file') ctl = `<input type="file" id="${id}" ${f.accept ? `accept="${f.accept}"` : ''}>`;
  else ctl = `<input type="${f.t || 'text'}" id="${id}" value="${dv}" ${f.ph ? `placeholder="${erpEsc(f.ph)}"` : ''} ${f.min !== undefined ? `min="${f.min}"` : ''} ${f.autocomplete ? `autocomplete="${f.autocomplete}"` : ''}>`;
  return `<div class="erp-field"><label for="${id}">${f.l}${req}</label>${ctl}${help}</div>`;
}

/* ---------------------------------------------------------
   Form control rendering (schema driven)
   --------------------------------------------------------- */
function erpDtLocal(v) {
  if (!v) return '';
  const m = String(v).match(/^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})/);
  return m ? `${m[1]}T${m[2]}` : '';
}
function erpNowLocal() {
  const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 16);
}
function erpControlHtml(f, value, ctx) {
  const id = 'erpf_' + f.k;
  const dis = ctx.locked.has(f.k) ? 'disabled' : '';
  const req = f.req && !f.virtual ? 'required' : (f.req && f.virtual ? 'required' : '');
  const v = value === null || value === undefined ? '' : value;
  const ph = f.ph ? `placeholder="${erpEsc(f.ph)}"` : '';
  const lim = (f.min !== undefined ? `min="${f.min}" ` : '') + (f.max !== undefined && f.t !== 'text' && f.t !== 'textarea' ? `max="${f.max}" ` : '') + (f.max !== undefined && (f.t === 'text' || f.t === 'textarea') ? `maxlength="${f.max}" ` : '');
  if (f.ro) return `<input type="text" id="${id}" value="${erpEsc(v)}" readonly>`;
  switch (f.t) {
    case 'textarea': return `<textarea id="${id}" rows="${f.rows || 3}" ${req} ${dis} ${ph} ${lim}>${erpEsc(v)}</textarea>`;
    case 'number': return `<input type="number" step="1" id="${id}" value="${erpEsc(v)}" ${req} ${dis} ${lim} ${ph}>`;
    case 'decimal': return `<input type="number" step="any" id="${id}" value="${erpEsc(v)}" ${req} ${dis} ${lim} ${ph}>`;
    case 'date': return `<input type="date" id="${id}" value="${erpEsc(String(v).slice(0, 10))}" ${req} ${dis}>`;
    case 'datetime': return `<input type="datetime-local" id="${id}" value="${erpEsc(erpDtLocal(v))}" ${req} ${dis}>`;
    case 'email': return `<input type="email" id="${id}" value="${erpEsc(v)}" ${req} ${dis} ${ph}>`;
    case 'url': return `<input type="url" id="${id}" value="${erpEsc(v)}" ${req} ${dis} ${ph || 'placeholder="https://"'}>`;
    case 'tel': return `<input type="tel" id="${id}" value="${erpEsc(v)}" ${req} ${dis} ${ph}>`;
    case 'password': return `<input type="password" id="${id}" value="" autocomplete="new-password" ${dis} placeholder="${ctx.isEdit ? 'Leave blank to keep the saved value' : ''}">`;
    case 'bool': return `<label class="erp-check"><input type="checkbox" id="${id}" ${Number(v) === 1 || v === true ? 'checked' : ''} ${dis}> ${erpEsc(f.cbLabel || 'Yes')}</label>`;
    case 'select': {
      const opts = (f.opts || []).map(o => `<option value="${erpEsc(o)}" ${String(o) === String(v !== '' ? v : '') ? 'selected' : ''}>${erpEsc(String(o).replace('IP_', 'IP '))}</option>`).join('');
      return `<select id="${id}" ${req} ${dis}>${f.req || f.def !== undefined ? '' : '<option value="">— Select —</option>'}${opts}</select>`;
    }
    case 'lookup': return `<select id="${id}" ${req} ${dis} ${f.multi ? 'multiple size="6"' : ''} data-src="${f.src}" data-val="${erpEsc(Array.isArray(v) ? v.join(',') : v)}"><option value="">— Select —</option></select>`;
    case 'combo': return `<input type="text" id="${id}" value="${erpEsc(v)}" list="${id}_dl" ${dis} ${ph} ${lim}><datalist id="${id}_dl"></datalist>`;
    case 'file': {
      let cur = '';
      if (ctx.row && ctx.row[f.k]) {
        const href = erpUrl('file', { entity: ctx.entity, id: ctx.id, field: f.k, inline: 1 });
        const nm = (ctx.row[f.fileMeta && f.fileMeta.name] || String(ctx.row[f.k]).split('/').pop());
        const isImg = /\.(png|jpe?g|gif|webp)$/i.test(String(ctx.row[f.k]));
        cur = `<div class="erp-file-cur"><i class="fas fa-paperclip"></i>
            ${isImg ? `<img class="erp-preview" src="${href}" alt="">` : ''}
            <a class="erp-link" href="${href}" target="_blank" rel="noopener">${erpEsc(nm)}</a>
            ${f.req ? '' : `<label class="erp-check" style="margin-left:auto;font-size:.76rem"><input type="checkbox" id="${id}_rm"> remove</label>`}</div>`;
      }
      return `${cur}<input type="file" id="${id}" ${f.accept ? `accept="${f.accept}"` : ''} ${dis}>`;
    }
    default: return `<input type="text" id="${id}" value="${erpEsc(v)}" ${req} ${dis} ${ph} ${lim}>`;
  }
}

/* ---------------------------------------------------------
   FORM PAGE
   cfg: entity, id, container, title, crumb, defaults{}, lock[], hide[], extra[], onSaved(row,res), onCancel(), cancelLabel
   --------------------------------------------------------- */
async function erpForm(cfg) {
  destroyCharts();
  const container = cfg.container || mainContent;
  container.innerHTML = '<div class="erp-empty"><i class="fas fa-spinner fa-spin"></i>Loading form…</div>';
  let meta;
  try { meta = await erpMeta(); } catch (e) { container.innerHTML = `<div class="erp-banner bad"><i class="fas fa-circle-exclamation"></i>${erpEsc(e.message)}</div>`; return; }
  const E = meta.entities[cfg.entity];
  const isEdit = !!cfg.id;
  let row = {};
  if (isEdit) {
    try { row = (await erpGet('get', { entity: cfg.entity, id: cfg.id })).data; }
    catch (e) { container.innerHTML = `<div class="erp-banner bad"><i class="fas fa-circle-exclamation"></i>${erpEsc(e.message)}</div>`; return; }
  }
  const defaults = cfg.defaults || {};
  const locked = new Set(cfg.lock || []);
  const hidden = new Set(cfg.hide || []);
  const byKey = {}; E.fields.forEach(f => byKey[f.k] = f);
  const ctx = { entity: cfg.entity, id: cfg.id, row, isEdit, locked };
  const initial = f => {
    if (isEdit) return row[f.k] !== undefined ? row[f.k] : '';
    if (defaults[f.k] !== undefined) return defaults[f.k];
    if (f.t === 'datetime' && ['deployment_date', 'request_date', 'start_time'].includes(f.k)) return erpNowLocal().replace('T', ' ');
    if (f.t === 'date' && ['allocated_date', 'service_date', 'start_date'].includes(f.k) && f.req) return new Date().toISOString().slice(0, 10);
    return f.def !== undefined ? f.def : '';
  };
  const sections = cfg.sections || E.sections;
  const title = cfg.title || E.label;

  const sectHtml = sections.map(([sTitle, keys]) => {
    const items = keys.filter(k => byKey[k] && !hidden.has(k)).map(k => {
      const f = byKey[k];
      if (f.ro && (!isEdit || row[k] === null || row[k] === undefined || row[k] === '')) return '';      // nothing to show yet
      const wide = f.full || f.t === 'textarea' || f.t === 'file' && f.full;
      return `<div class="erp-field ${wide ? 'erp-full' : ''}" data-field="${k}">
          ${f.t === 'bool' ? '' : `<label for="erpf_${k}">${erpEsc(f.l)}${f.req ? ' <span class="erp-req">*</span>' : ''}</label>`}
          ${f.t === 'bool' ? `<label for="erpf_${k}" style="display:block;font-size:.8rem;font-weight:700;color:#444;margin-bottom:6px">${erpEsc(f.l)}</label>` : ''}
          ${erpControlHtml(f, initial(f), ctx)}
          ${f.help ? `<div class="erp-help">${erpEsc(f.help)}</div>` : ''}
        </div>`;
    }).join('');
    return items.trim() ? `<div class="erp-form-card"><h3>${erpEsc(sTitle)}</h3><div class="erp-form-grid">${items}</div></div>` : '';
  }).join('');

  container.innerHTML = `
    <button type="button" class="back-btn" id="erpFormBack"><i class="fas fa-arrow-left"></i> ${erpEsc(cfg.cancelLabel || 'Back')}</button>
    <div class="eyebrow">${erpEsc(cfg.crumb || E.plural)} <span class="crumb-sep">/</span> <span class="crumb-current">${isEdit ? 'Edit' : 'New'} ${erpEsc(title)}</span></div>
    <div class="page-title"><span>${isEdit ? 'Edit' : 'New'} ${erpEsc(title)}</span></div>
    ${cfg.banner || ''}
    <form id="erpForm" novalidate>
      ${sectHtml}
      <div class="erp-form-actions">
        <button type="submit" class="btn-primary" id="erpSave"><i class="fas fa-floppy-disk"></i> ${isEdit ? 'Update' : 'Save'}</button>
        ${(cfg.extra || []).map((x, i) => `<button type="button" class="btn-secondary erp-extra" data-i="${i}">${x.icon ? `<i class="fas ${x.icon}"></i> ` : ''}${erpEsc(x.label)}</button>`).join('')}
        <button type="button" class="btn-secondary" id="erpCancel">Cancel</button>
        <span class="erp-form-msg" id="erpFormMsg"></span>
      </div>
    </form>`;

  const form = container.querySelector('#erpForm');
  const msg = container.querySelector('#erpFormMsg');
  const goBack = () => (cfg.onCancel ? cfg.onCancel() : null);
  container.querySelector('#erpFormBack').addEventListener('click', goBack);
  container.querySelector('#erpCancel').addEventListener('click', goBack);

  const el = k => container.querySelector('#erpf_' + k);
  const val = k => {
    const f = byKey[k], c = el(k);
    if (!c) return defaults[k] !== undefined ? defaults[k] : '';
    if (f.t === 'bool') return c.checked ? 1 : 0;
    if (f.t === 'file') return c.files[0] || null;
    if (f.t === 'lookup' && f.multi) return [...c.selectedOptions].map(o => o.value).filter(Boolean);
    return c.value;
  };

  /* ---- lookups, cascades, combos ---- */
  const lookupFields = E.fields.filter(f => (f.t === 'lookup' || f.t === 'combo') && el(f.k));
  const optionRows = {};
  const fillLookup = (f, keepValue) => {
    const c = el(f.k); if (!c) return;
    let rows = optionRows[f.k] || [];
    if (f.dep) {
      Object.entries(f.dep).forEach(([attr, parentKey]) => {
        const pv = val(parentKey);
        if (pv !== '' && pv !== null && pv !== undefined && !Array.isArray(pv)) rows = rows.filter(r => String(r[attr]) === String(pv));
      });
    }
    if (f.excludeSelf && cfg.id) rows = rows.filter(r => String(r.id) !== String(cfg.id));
    const wanted = keepValue !== undefined ? keepValue : (c.dataset.val || '');
    const wantedSet = new Set(String(wanted).split(',').filter(Boolean));
    if (f.t === 'combo') {
      const dl = container.querySelector('#erpf_' + f.k + '_dl');
      dl.innerHTML = rows.map(r => `<option value="${erpEsc(r.label)}"></option>`).join('');
      return;
    }
    c.innerHTML = (f.multi ? '' : '<option value="">— Select —</option>') + rows.map(r => `<option value="${erpEsc(r.id)}" ${wantedSet.has(String(r.id)) ? 'selected' : ''}>${erpEsc(r.label)}</option>`).join('');
    if (!rows.length) c.innerHTML += f.multi ? '' : '';
  };
  await Promise.all(lookupFields.map(async f => {
    const params = {};
    Object.entries(f.srcFilter || {}).forEach(([a, v]) => params['a_' + a] = v);
    if (f.avail && !isEdit) params.avail = 1;
    if (f.notRetired) params.not_retired = 1;
    try { optionRows[f.k] = await erpLookup(f.src, params); } catch (e) { optionRows[f.k] = []; }
    fillLookup(f);
  }));
  // for edit of virtual cascade parents (e.g. project of a task) make sure they are set before children filter
  lookupFields.forEach(f => {
    if (!f.dep) return;
    Object.values(f.dep).forEach(parentKey => {
      const p = el(parentKey); if (!p) return;
      p.addEventListener('change', () => {
        const keep = val(f.k);
        fillLookup(f, Array.isArray(keep) ? keep.join(',') : keep);
        const c = el(f.k); if (c && !c.multiple && keep && c.value !== String(keep)) c.dispatchEvent(new Event('change'));
      });
    });
  });
  // re-apply dependent filtering once all initial values are in (child selects were filled before parents had values)
  lookupFields.forEach(f => { if (f.dep) fillLookup(f); });

  /* ---- conditional fields ---- */
  const applyShowIf = () => {
    E.fields.forEach(f => {
      if (!f.showIf) return;
      const wrap = container.querySelector(`[data-field="${f.k}"]`); if (!wrap) return;
      const on = f.showIf.in.map(String).includes(String(val(f.showIf.field)));
      wrap.style.display = on ? '' : 'none';
    });
  };
  E.fields.filter(f => f.showIf).forEach(f => { const p = el(f.showIf.field); if (p) p.addEventListener('change', applyShowIf); });
  applyShowIf();

  /* ---- helper handed to extra buttons ---- */
  const api = {
    values: () => { const o = {}; E.fields.forEach(f => { if (el(f.k)) o[f.k] = val(f.k); }); return o; },
    set: (k, v) => { const c = el(k); if (c) c.value = v; },
    message: (t, kind = 'ok') => { msg.className = 'erp-form-msg ' + (kind === 'err' ? 'err' : 'ok'); msg.textContent = t; },
    row,
  };
  container.querySelectorAll('.erp-extra').forEach(b => b.addEventListener('click', () => cfg.extra[b.dataset.i].onClick(api, b)));
  if (cfg.afterRender) cfg.afterRender(container, api, { el, val });

  /* ---- submit ---- */
  form.addEventListener('submit', async ev => {
    ev.preventDefault();
    msg.textContent = '';
    if (!form.reportValidity()) return;
    const body = {};
    for (const f of E.fields) {
      if (f.ro) continue;
      const c = el(f.k);
      if (!c) { if (locked.has(f.k) || hidden.has(f.k)) { if (defaults[f.k] !== undefined) body[f.k] = defaults[f.k]; } continue; }
      if (c.closest('[data-field]') && c.closest('[data-field]').style.display === 'none') continue;
      if (locked.has(f.k)) { body[f.k] = defaults[f.k] !== undefined ? defaults[f.k] : c.value; continue; }
      if (f.t === 'file') {
        const file = c.files[0];
        if (file) body[f.k] = file;
        const rm = container.querySelector('#erpf_' + f.k + '_rm');
        if (rm && rm.checked) body['remove_' + f.k] = 1;
        continue;
      }
      if (f.t === 'password') { const pv = c.value; if (pv !== '') body[f.k] = pv; continue; }
      const v = val(f.k);
      if (!isEdit && (v === '' || (Array.isArray(v) && !v.length))) continue;
      body[f.k] = v;
    }
    if (cfg.beforeSave) { try { cfg.beforeSave(body); } catch (e) { api.message(e.message, 'err'); return; } }
    const btn = container.querySelector('#erpSave');
    btn.disabled = true; const label = btn.innerHTML; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving…';
    try {
      const res = await erpPost('save', body, { entity: cfg.entity, id: cfg.id });
      erpClearLookups();
      erpToast(res.message || 'Saved');
      erpNotices(res);
      if (cfg.onSaved) cfg.onSaved(res.data, res);
    } catch (e) {
      api.message(e.message, 'err');
      erpToast(e.message, 'error');
      btn.disabled = false; btn.innerHTML = label;
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  });
}

/* ---------------------------------------------------------
   LIST PAGE
   cfg: entity, title, sectionLabel, back:{fn,label}, container, embedded, fixed{}, columns, kpis(), toolbar[],
        rowActions(row)->[{label,cls,onClick(row,ctx),show}], noAdd, addLabel, formOpts{}, rerender(), filterOptions{},
        dateRange, readOnly, noEdit, noDelete, onRowClick(row), canEdit(row), canDelete(row), subtitle
   --------------------------------------------------------- */
async function erpListPage(cfg) {
  destroyCharts();
  const meta = await erpMeta();
  const E = meta.entities[cfg.entity];
  const container = cfg.container || mainContent;
  const fixed = cfg.fixed || {};
  const readOnly = cfg.readOnly || E.readOnly;
  const cols = cfg.columns || E.list;
  const state = { q: '', page: 1, f: {}, from: '', to: '', per: cfg.perPage || 25 };
  const rerender = cfg.rerender || (() => erpListPage(cfg));

  const addBtn = (!cfg.noAdd && !readOnly) ? `<button type="button" class="btn btn-primary" id="erpAdd"><i class="fas fa-plus"></i> ${erpEsc(cfg.addLabel || 'Add ' + E.label)}</button>` : '';
  const extraBtns = (cfg.toolbar || []).map((b, i) => `<button type="button" class="btn ${b.primary ? 'btn-primary' : 'btn-secondary'} erp-tb" data-i="${i}" style="${b.primary ? '' : 'padding:9px 14px;border-radius:8px;cursor:pointer;font-weight:600'}">${b.icon ? `<i class="fas ${b.icon}"></i> ` : ''}${erpEsc(b.label)}</button>`).join(' ');
  const head = cfg.embedded ? '' : `
    ${cfg.back ? `<button type="button" class="back-btn" id="erpBack"><i class="fas fa-arrow-left"></i> Back to ${erpEsc(cfg.back.label)}</button>` : ''}
    <div class="eyebrow">${erpEsc(cfg.sectionLabel || '')} <span class="crumb-sep">/</span> <span class="crumb-current">${erpEsc(cfg.title || E.plural)}</span></div>
    <div class="page-title"><span>${erpEsc(cfg.title || E.plural)}</span><div class="actions">${extraBtns} ${addBtn}</div></div>
    ${cfg.banner || ''}`;
  const showFilters = (cfg.filters || E.filters || []).filter(k => !(k in fixed));
  container.innerHTML = `${head}
    <div id="erpKpi"></div>
    <div class="table-panel">
      <div class="erp-toolbar">
        <div class="erp-search"><i class="fas fa-search"></i><input type="search" id="erpQ" placeholder="Search ${erpEsc((cfg.title || E.plural).toLowerCase())}…"></div>
        <span id="erpFilters" style="display:contents"></span>
        ${E.dateField && cfg.dateRange !== false ? `<input type="date" class="erp-date" id="erpFrom" title="From date"><input type="date" class="erp-date" id="erpTo" title="To date">` : ''}
        <span class="erp-grow"></span>
        ${cfg.embedded ? `${extraBtns} ${addBtn}` : ''}
        <button type="button" class="btn-secondary" id="erpExport" style="padding:8px 13px;border-radius:8px;cursor:pointer;font-weight:600;font-size:.8rem" title="Download the filtered list as CSV"><i class="fas fa-download"></i> CSV</button>
      </div>
      <div class="table-scroll"><table class="data-table">
        <thead><tr>${cols.map(c => `<th>${erpEsc(c[1])}</th>`).join('')}${readOnly && !cfg.rowActions ? '' : '<th>Actions</th>'}</tr></thead>
        <tbody id="erpBody"><tr><td colspan="${cols.length + 1}"><div class="erp-empty"><i class="fas fa-spinner fa-spin"></i>Loading…</div></td></tr></tbody>
      </table></div>
      <div class="erp-pager" id="erpPager"></div>
    </div>`;

  const body = container.querySelector('#erpBody');
  const pager = container.querySelector('#erpPager');
  if (cfg.back) container.querySelector('#erpBack').addEventListener('click', cfg.back.fn);

  const openForm = id => {
    erpForm(Object.assign({
      entity: cfg.entity, id, defaults: Object.assign({}, fixed), lock: Object.keys(fixed),
      crumb: cfg.sectionLabel ? cfg.sectionLabel + ' / ' + (cfg.title || E.plural) : (cfg.title || E.plural),
      cancelLabel: 'Back to ' + (cfg.title || E.plural),
      onCancel: rerender, onSaved: () => rerender(),
    }, cfg.formOpts || {}, id ? (cfg.editOpts || {}) : {}));
  };
  const addEl = container.querySelector('#erpAdd'); if (addEl) addEl.addEventListener('click', () => openForm(null));
  container.querySelectorAll('.erp-tb').forEach(b => b.addEventListener('click', () => cfg.toolbar[b.dataset.i].onClick({ reload, openForm, state }, b)));

  /* filters */
  const fHost = container.querySelector('#erpFilters');
  await Promise.all(showFilters.map(async k => {
    const f = E.fields.find(x => x.k === k);
    let opts = null;
    try {
      if (cfg.filterOptions && cfg.filterOptions[k]) opts = cfg.filterOptions[k].map(o => (typeof o === 'object' ? o : { id: o, label: o }));
      else if (f && f.t === 'select') opts = f.opts.map(o => ({ id: o, label: String(o).replace('IP_', 'IP ') }));
      else if (f && f.t === 'lookup') opts = await erpLookup(f.src);
      else if (f && f.t === 'bool') opts = [{ id: 1, label: 'Yes' }, { id: 0, label: 'No' }];
    } catch (e) { /* skip filter */ }
    if (!opts) return;
    const sel = document.createElement('select');
    sel.className = 'erp-filter'; sel.dataset.k = k;
    sel.innerHTML = `<option value="">All ${erpEsc(f ? f.l : k)}</option>` + opts.map(o => `<option value="${erpEsc(o.id)}">${erpEsc(o.label)}</option>`).join('');
    sel.addEventListener('change', () => { state.f[k] = sel.value; state.page = 1; reload(); });
    fHost.appendChild(sel);
  }));
  let tmr;
  container.querySelector('#erpQ').addEventListener('input', e => { clearTimeout(tmr); tmr = setTimeout(() => { state.q = e.target.value.trim(); state.page = 1; reload(); }, 300); });
  const fr = container.querySelector('#erpFrom'), to = container.querySelector('#erpTo');
  if (fr) fr.addEventListener('change', () => { state.from = fr.value; state.page = 1; reload(); });
  if (to) to.addEventListener('change', () => { state.to = to.value; state.page = 1; reload(); });
  const params = () => {
    const p = { entity: cfg.entity, q: state.q, page: state.page, per: state.per, from: state.from, to: state.to };
    Object.entries(fixed).forEach(([k, v]) => p['f_' + k] = v);
    Object.entries(state.f).forEach(([k, v]) => { if (v !== '') p['f_' + k] = v; });
    return p;
  };
  container.querySelector('#erpExport').addEventListener('click', () => { const p = params(); delete p.page; delete p.per; window.location.href = erpUrl('export', p); });

  let rows = [];
  async function reload() {
    body.style.opacity = '.55';
    try {
      const res = await erpGet('list', params());
      rows = res.data;
      if (cfg.afterLoad) cfg.afterLoad(rows, res);
      const colSpan = cols.length + 1;
      if (!rows.length) {
        const filtered = state.q || state.from || state.to || Object.values(state.f).some(v => v !== '');
        body.innerHTML = `<tr><td colspan="${colSpan}"><div class="erp-empty"><i class="fas fa-inbox"></i>${filtered ? 'Nothing matches your search or filters.' : `No ${erpEsc((cfg.title || E.plural).toLowerCase())} yet.${addEl ? ' Click “' + erpEsc(cfg.addLabel || 'Add ' + E.label) + '” to create one.' : ''}`}</div></td></tr>`;
      } else {
        body.innerHTML = rows.map((r, i) => `<tr data-i="${i}" ${cfg.onRowClick ? 'style="cursor:pointer"' : ''}>
          ${cols.map(c => `<td>${(cfg.cellRender && cfg.cellRender[c[0]]) ? cfg.cellRender[c[0]](r) : erpFmtCell(c[2], r[c[0]], r)}</td>`).join('')}
          ${readOnly && !cfg.rowActions ? '' : `<td class="erp-acts">${rowActionHtml(r, i)}</td>`}</tr>`).join('');
      }
      const total = res.total != null ? res.total : rows.length;
      const from = total ? (state.page - 1) * state.per + 1 : 0, last = Math.min(total, state.page * state.per);
      pager.innerHTML = `<span>${total ? `Showing ${from}–${last} of ${total.toLocaleString('en-IN')}` : '0 records'}</span>
        <span><button type="button" class="erp-btn-sm" id="erpPrev" ${state.page <= 1 ? 'disabled' : ''}>‹ Prev</button>
        <button type="button" class="erp-btn-sm" id="erpNext" ${last >= total ? 'disabled' : ''}>Next ›</button></span>`;
      pager.querySelector('#erpPrev').onclick = () => { state.page--; reload(); };
      pager.querySelector('#erpNext').onclick = () => { state.page++; reload(); };
    } catch (e) {
      body.innerHTML = `<tr><td colspan="${cols.length + 1}"><div class="erp-banner bad" style="margin:12px"><i class="fas fa-circle-exclamation"></i><div>${erpEsc(e.message)}</div></div></td></tr>`;
    }
    body.style.opacity = '';
    if (cfg.kpis) loadKpis();
  }
  async function loadKpis() {
    const host = container.querySelector('#erpKpi'); if (!host) return;
    try {
      const k = await cfg.kpis();
      host.innerHTML = k && k.length ? `<div class="erp-kpis">${k.map(x => `<div class="erp-kpi" style="--c:${x.c || '#ff6b4a'}"><div class="l">${erpEsc(x.l)}</div><div class="v">${x.v}</div>${x.s ? `<div class="s">${erpEsc(x.s)}</div>` : ''}</div>`).join('')}</div>` : '';
    } catch (e) { host.innerHTML = ''; }
  }

  function rowActionHtml(r, i) {
    const acts = [];
    (cfg.rowActions ? cfg.rowActions(r) : []).forEach((a, j) => { if (a.show === false) return; acts.push(`<button type="button" class="erp-btn-sm ${a.cls || ''}" data-i="${i}" data-a="${j}" title="${erpEsc(a.title || '')}">${a.icon ? `<i class="fas ${a.icon}"></i> ` : ''}${erpEsc(a.label)}</button>`); });
    if (!readOnly && !cfg.noEdit && (!cfg.canEdit || cfg.canEdit(r))) acts.push(`<button type="button" class="erp-btn-sm" data-i="${i}" data-edit="1"><i class="fas fa-pen"></i> Edit</button>`);
    if (!readOnly && !cfg.noDelete && (!cfg.canDelete || cfg.canDelete(r))) acts.push(`<button type="button" class="erp-btn-sm erp-danger" data-i="${i}" data-del="1"><i class="fas fa-trash"></i></button>`);
    return acts.join('');
  }
  body.addEventListener('click', async ev => {
    const b = ev.target.closest('button');
    if (!b) { const tr = ev.target.closest('tr[data-i]'); if (tr && cfg.onRowClick && !ev.target.closest('a')) cfg.onRowClick(rows[tr.dataset.i]); return; }
    const r = rows[b.dataset.i]; if (!r) return;
    if (b.dataset.edit) return openForm(r.id);
    if (b.dataset.del) {
      const name = r[cols[0][0]] || E.label;
      if (!await erpConfirm(`Delete “${name}”? This cannot be undone.`, { okLabel: 'Delete', danger: true, title: 'Delete ' + E.label })) return;
      try { await erpPost('delete', {}, { entity: cfg.entity, id: r.id }); erpClearLookups(); erpToast('Deleted'); reload(); }
      catch (e) { erpToast(e.message, 'error'); }
      return;
    }
    if (b.dataset.a !== undefined) {
      const a = cfg.rowActions(r)[b.dataset.a];
      b.disabled = true;
      try { await a.onClick(r, { reload, openForm, rerender }); } catch (e) { erpToast(e.message, 'error'); }
      b.disabled = false;
    }
  });
  await reload();
  return { reload, state, openForm };
}

/* ---------------------------------------------------------
   Tabs page shell
   --------------------------------------------------------- */
const ERP_TAB_STATE = {};
function erpTabsPage({ id, title, sectionLabel, back, tabs, banner = '' }) {
  destroyCharts();
  const active = ERP_TAB_STATE[id] && tabs.find(t => t.key === ERP_TAB_STATE[id]) ? ERP_TAB_STATE[id] : tabs[0].key;
  mainContent.innerHTML = `
    ${back ? `<button type="button" class="back-btn" id="erpBack"><i class="fas fa-arrow-left"></i> Back to ${erpEsc(back.label)}</button>` : ''}
    <div class="eyebrow">${erpEsc(sectionLabel)} <span class="crumb-sep">/</span> <span class="crumb-current">${erpEsc(title)}</span></div>
    <div class="page-title"><span>${erpEsc(title)}</span></div>
    ${banner}
    <div class="erp-tabs">${tabs.map(t => `<button type="button" class="erp-tab ${t.key === active ? 'active' : ''}" data-k="${t.key}">${erpEsc(t.label)}</button>`).join('')}</div>
    <div id="erpTabBody"></div>`;
  if (back) mainContent.querySelector('#erpBack').addEventListener('click', back.fn);
  const rerender = () => erpTabsPage({ id, title, sectionLabel, back, tabs, banner });
  const show = key => {
    ERP_TAB_STATE[id] = key;
    mainContent.querySelectorAll('.erp-tab').forEach(b => b.classList.toggle('active', b.dataset.k === key));
    const host = mainContent.querySelector('#erpTabBody');
    host.innerHTML = '';
    destroyCharts();
    tabs.find(t => t.key === key).render(host, rerender);
  };
  mainContent.querySelectorAll('.erp-tab').forEach(b => b.addEventListener('click', () => show(b.dataset.k)));
  show(active);
}

/** Download helper for file endpoints */
function erpDownload(url) { window.location.href = url; }
function erpErrorBox(e) { return `<div class="erp-banner bad"><i class="fas fa-circle-exclamation"></i><div>${erpEsc(e.message || e)}</div></div>`; }
