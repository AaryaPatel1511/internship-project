/* =========================================================
   ERP PAGES - part B
   Asset Management + Document Management + Administration
   ========================================================= */

/* Which sidebar sections the signed-in person may see.
   - Administration            : Admin / Super Admin only (every Administration action is admin-only on the server).
   - User Management           : Admin / Super Admin, OR anyone whose role holds the permissions
                                 Manage Users (Users, Departments, Designations), Manage Roles (Roles)
                                 or Manage Permissions (Permissions). Only the pages they may use are shown.
   `user.access` comes from api/auth.php (see api/access.php) so the server and the menu always agree.
   Role names are compared ignoring case/extra spaces ("super admin" == "Super Admin"). */
function erpApplyRoleMenu(user) {
  const role = String((user && user.role) || '').trim().toLowerCase();
  const isAdmin = role === 'super admin' || role === 'admin';
  const pages = ((user && user.access) || {}).pages || {};
  const hide = el => { el.style.display = 'none'; el.dataset.aclHidden = '1'; };

  document.querySelectorAll('.main-heading').forEach(li => {
    const head = li.querySelector(':scope > .menu-header span');
    const title = head ? head.textContent.trim() : '';
    if (title === 'Administration') {
      if (!isAdmin) hide(li);
    } else if (title === 'User Management') {
      if (isAdmin) return;
      let shown = 0;
      li.querySelectorAll(':scope > ul > li').forEach(item => {
        if (pages[item.textContent.trim()]) shown++; else hide(item);
      });
      if (!shown) hide(li);
    }
  });

  // keep the global search box from offering pages that are hidden from this person
  if (typeof searchIndex !== 'undefined') {
    for (let i = searchIndex.length - 1; i >= 0; i--) {
      const el = searchIndex[i].el;
      if (el && el.closest('[data-acl-hidden="1"]')) searchIndex.splice(i, 1);
    }
  }
}

/* =========================================================
   ASSET MANAGEMENT
   ========================================================= */
async function amAssetsPage(type, b, s) {
  let sum = null;
  try { sum = (await erpGet('am_finance_summary')).data; } catch (e) { /* page still works */ }
  const banners = [];
  if (sum && !type) {
    if (!sum.mapping_ready) banners.push(`<div class="erp-banner warn"><i class="fas fa-triangle-exclamation"></i><div><b>Accounting is not mapped yet.</b> Purchases, depreciation and repairs are recorded here but cannot be posted to Accounts until you choose the ledger accounts in <b>Administration › Company Settings › Accounting Mapping</b>.</div></div>`);
    if (sum.pending_postings > 0) banners.push(`<div class="erp-banner warn"><i class="fas fa-hourglass-half"></i><div><b>${sum.pending_postings}</b> ledger entr${sum.pending_postings == 1 ? 'y is' : 'ies are'} waiting to be posted to Accounts.</div></div>`);
    if (sum.overdue_returns > 0) banners.push(`<div class="erp-banner bad"><i class="fas fa-clock"></i><div><b>${sum.overdue_returns}</b> asset${sum.overdue_returns > 1 ? 's are' : ' is'} overdue for return.</div></div>`);
  }
  const title = type ? type + 's' : 'Company Assets';
  const rerender = () => amAssetsPage(type, b, s);
  return erpListPage({
    entity: 'am_assets', title, sectionLabel: s, back: b, fixed: type ? { asset_type: type } : {}, addLabel: type ? 'Add ' + type : 'Add Asset',
    rerender, banner: banners.join(''),
    columns: type ? undefined : undefined,
    kpis: async () => {
      const d = (await erpGet('am_finance_summary')).data;
      return type ? null : [
        { l: 'Assets', v: d.total_assets, c: '#3556d6' }, { l: 'In use', v: d.in_use, c: '#16a34a' }, { l: 'In stock', v: d.in_stock, c: '#14b8a6' },
        { l: 'In repair', v: d.in_repair, c: '#e08c1c' }, { l: 'Retired', v: d.retired, c: '#8f97a8' },
        { l: 'Gross cost', v: erpMoney(d.gross_cost, 0), c: '#7c5cff' }, { l: 'Book value', v: erpMoney(d.book_value, 0), c: '#ff6b4a', s: 'after ' + erpMoney(d.accumulated_dep, 0) + ' depreciation' },
      ];
    },
    toolbar: type ? [] : [
      { label: 'Run Depreciation', icon: 'fa-chart-line', onClick: ctx => amDepreciationDialog(ctx.reload, rerender) },
      { label: 'Post Pending to Accounts', icon: 'fa-book', onClick: async ctx => { const r = await erpPost('am_post_pending'); erpToast(r.message, r.data.pending ? 'warn' : 'success'); erpNotices(r); rerender(); } },
    ],
    rowActions: r => [
      { label: 'Timeline', icon: 'fa-timeline', onClick: row => amTimeline(row.id) },
      { label: 'Allocate', icon: 'fa-user-plus', cls: 'erp-go', show: r.status === 'In Stock' && r.asset_type !== 'Software', onClick: row => erpForm({ entity: 'am_asset_allocations', defaults: { asset_id: row.id }, lock: ['asset_id'], crumb: 'Asset Management', cancelLabel: 'Back to ' + title, onCancel: rerender, onSaved: () => rerender() }) },
      { label: 'Service', icon: 'fa-wrench', show: r.status !== 'Retired', onClick: row => erpForm({ entity: 'am_maintenance_logs', defaults: { asset_id: row.id }, lock: ['asset_id'], crumb: 'Asset Management', cancelLabel: 'Back to ' + title, onCancel: rerender, onSaved: () => rerender() }) },
      { label: 'Retire', icon: 'fa-box-archive', cls: 'erp-warn', show: r.status !== 'Retired', onClick: row => amRetireDialog(row, rerender) },
    ],
    canEdit: r => r.status !== 'Retired',
    cellRender: { warranty_expiry: r => r.warranty_expiry ? erpEsc(erpFmtDate(r.warranty_expiry)) + (Number(r.warranty_expired) ? ' <span class="erp-chip erp-c-red">expired</span>' : '') : '<span class="erp-muted">—</span>' },
  });
}
function amDepreciationDialog(reload, rerender) {
  return erpDialog({
    title: 'Run depreciation', okLabel: 'Run now',
    note: 'Books depreciation for every full month up to the date below, for every asset with a depreciation method. It is safe to run repeatedly — a month is never booked twice. Straight-line = (cost − salvage) ÷ life; declining balance = book value × 2 ÷ life, never below salvage.',
    fields: [{ k: 'as_of', l: 'Depreciate up to', t: 'date', req: true, def: new Date().toISOString().slice(0, 10) }],
    onSubmit: async v => { const r = await erpPost('am_run_depreciation', { as_of: v.as_of }); erpToast(r.message, r.data.assets ? 'success' : 'info'); erpNotices(r); erpClearLookups(); rerender(); },
  });
}
function amRetireDialog(row, rerender) {
  return erpDialog({
    title: 'Retire ' + row.asset_tag + ' — ' + row.brand_model, okLabel: 'Retire asset',
    note: 'The asset is closed out: open allocations are returned, and the remaining book value is written off in Accounts (a loss on disposal, or a gain if the sale proceeds exceed it).',
    fields: [
      { k: 'date', l: 'Retirement date', t: 'date', req: true, def: new Date().toISOString().slice(0, 10) },
      { k: 'salvage', l: 'Sale / salvage proceeds (INR)', t: 'number', def: 0, min: 0, help: 'Enter 0 if the asset was scrapped.' },
      { k: 'reason', l: 'Reason', t: 'textarea', req: true },
    ],
    onSubmit: async v => { const r = await erpPost('am_retire', v ? { id: row.id, date: v.date, salvage: v.salvage || 0, reason: v.reason } : {}); erpToast(r.message); erpNotices(r); erpClearLookups(); rerender(); },
  });
}
async function amTimeline(id) {
  const m = erpModal({ title: 'Asset timeline', wide: true, body: '<div class="erp-empty"><i class="fas fa-spinner fa-spin"></i>Loading…</div>', footer: [{ label: 'Close', cls: 'btn-primary', onClick: a => a.close() }] });
  try {
    const d = (await erpGet('am_timeline', { id })).data, a = d.asset, dep = d.depreciation;
    m.body.innerHTML = `
      <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:12px"><div><div style="font-size:1.1rem;font-weight:800">${erpEsc(a.brand_model)}</div><div class="erp-muted">${erpEsc(a.asset_tag)} · ${erpEsc(a.asset_type)} · S/N ${erpEsc(a.serial_number || '—')}</div></div>${erpChip(a.status)}</div>
      <dl class="erp-kv" style="margin-bottom:16px"><dt>Purchased</dt><dd>${erpEsc(erpFmtDate(a.purchase_date) || '—')} for ${erpMoney(a.purchase_cost)}</dd><dt>Vendor</dt><dd>${erpEsc(a.vendor_name || '—')}</dd><dt>Warranty until</dt><dd>${erpEsc(erpFmtDate(a.warranty_expiry) || '—')}</dd>
      <dt>Depreciation</dt><dd>${dep ? `${erpEsc(dep.depreciation_method)} over ${dep.useful_life_months} months, salvage ${erpMoney(dep.salvage_value)}<br>Accumulated <b>${erpMoney(dep.accumulated_depreciation)}</b> · Book value <b>${erpMoney(dep.current_book_value)}</b>${dep.last_calculated ? ' (to ' + erpEsc(erpFmtDate(dep.last_calculated)) + ')' : ''}` : 'Not depreciated'}</dd></dl>
      <h4 style="margin:0 0 6px;font-size:.9rem">History</h4>
      <ul class="erp-tl">${d.history.map(h => `<li><span class="t">${erpEsc(erpFmtDateTime(h.action_date))}</span><span>${erpChip(h.action_type)} ${erpEsc(h.remarks || '')} <span class="erp-muted">${h.performed_by_name ? '— ' + erpEsc(h.performed_by_name) : ''}</span></span></li>`).join('') || '<li class="erp-muted">No history</li>'}</ul>
      <h4 style="margin:16px 0 6px;font-size:.9rem">Accounts postings</h4>
      <div class="table-scroll"><table class="data-table"><thead><tr><th>Date</th><th>Event</th><th>Detail</th><th>Amount</th><th>Journal</th></tr></thead><tbody>
      ${d.postings.length ? d.postings.map(p => `<tr><td>${erpEsc(erpFmtDate(p.entry_date))}</td><td>${erpEsc(p.event_type)}</td><td>${erpEsc(p.period_key || '')}</td><td>${erpMoney(p.amount)}</td><td>${p.journal_record_id ? '<span class="erp-chip erp-c-green">Posted</span>' : '<span class="erp-chip erp-c-amber">Pending</span>'}</td></tr>`).join('') : '<tr><td colspan="5"><div class="erp-empty">Nothing posted yet</div></td></tr>'}</tbody></table></div>`;
  } catch (e) { m.body.innerHTML = erpErrorBox(e); }
}

const AM_PAGES = {
  'Company Assets': (b, s) => amAssetsPage(null, b, s),
  'Laptop': (b, s) => amAssetsPage('Laptop', b, s),
  'Desktop': (b, s) => amAssetsPage('Desktop', b, s),
  'Printer': (b, s) => amAssetsPage('Printer', b, s),
  'Server': (b, s) => amAssetsPage('Server', b, s),
  'Software License': (b, s) => erpListPage({
    entity: 'am_software_licenses', title: 'Software Licenses', sectionLabel: s, back: b, addLabel: 'Add License', rerender: () => AM_PAGES['Software License'](b, s),
    kpis: async () => { const d = (await erpGet('am_finance_summary')).data; return [{ l: 'Expiring in 30 days', v: d.licenses_expiring, c: '#e08c1c' }]; },
    rowActions: r => [{ label: 'Renew', icon: 'fa-rotate', cls: 'erp-go', onClick: (row, ctx) => erpDialog({
      title: 'Renew ' + row.software_name, okLabel: 'Renew', note: 'Extends the expiry date. If a renewal cost is set it is posted to the IT maintenance expense account.',
      fields: [{ k: 'months', l: 'Renew for', t: 'select', opts: ['1', '3', '6', '12', '24', '36'], def: '12', req: true }],
      onSubmit: async v => { const res = await erpPost('am_renew_license', { id: row.id, months: v.months }); erpToast(res.message); erpNotices(res); ctx.reload(); },
    }) }],
  }),
  'Asset Allocation': (b, s) => erpListPage({
    entity: 'am_asset_allocations', title: 'Asset Allocation', sectionLabel: s, back: b, addLabel: 'Allocate Asset', rerender: () => AM_PAGES['Asset Allocation'](b, s),
    kpis: async () => { const [a, o, r] = await Promise.all([erpCount('am_asset_allocations', { allocation_status: 'Active' }), erpCount('am_asset_allocations', { allocation_status: 'Overdue' }), erpCount('am_asset_allocations', { allocation_status: 'Returned' })]); return [{ l: 'Active', v: a, c: '#16a34a' }, { l: 'Overdue', v: o, c: '#e0384c' }, { l: 'Returned', v: r, c: '#8f97a8' }]; },
    canEdit: r => !r.actual_return_date,
    rowActions: r => [{ label: 'Return', icon: 'fa-rotate-left', cls: 'erp-go', show: !r.actual_return_date, onClick: (row, ctx) => erpDialog({
      title: 'Return ' + row.asset_tag, okLabel: 'Mark returned',
      fields: [{ k: 'date', l: 'Return date', t: 'date', req: true, def: new Date().toISOString().slice(0, 10) }, { k: 'condition', l: 'Condition on return', t: 'text', def: 'Good' }],
      onSubmit: async v => { const res = await erpPost('am_return', { id: row.id, date: v.date, condition: v.condition }); erpToast(res.message); erpClearLookups(); ctx.reload(); },
    }) }],
  }),
  'Maintenance': (b, s) => erpListPage({
    entity: 'am_maintenance_logs', title: 'Asset Maintenance', sectionLabel: s, back: b, addLabel: 'Log Maintenance', rerender: () => AM_PAGES['Maintenance'](b, s),
    kpis: async () => { const [a, c, d] = await Promise.all(['Scheduled', 'In Progress', 'Completed'].map(x => erpCount('am_maintenance_logs', { status: x }))); return [{ l: 'Scheduled', v: a, c: '#8f97a8' }, { l: 'In progress', v: c, c: '#e08c1c' }, { l: 'Completed', v: d, c: '#16a34a' }]; },
    rowActions: r => [
      pmQuick('am_maintenance_logs', 'status', 'In Progress', 'Start', { icon: 'fa-play', show: r.status === 'Scheduled' }),
      pmQuick('am_maintenance_logs', 'status', 'Completed', 'Complete', { icon: 'fa-check', cls: 'erp-go', show: r.status !== 'Completed' }),
    ],
  }),
  'Asset History': (b, s) => erpListPage({ entity: 'am_asset_history', title: 'Asset History', sectionLabel: s, back: b, readOnly: true, rerender: () => AM_PAGES['Asset History'](b, s) }),
};

/* =========================================================
   DOCUMENT MANAGEMENT
   ========================================================= */
const DM_CATEGORIES = {
  'Contracts': 'Contract', 'NDA': 'NDA', 'Agreements': 'Agreement', 'Proposal': 'Proposal',
  'Company Documents': 'Company', 'Employee Documents': 'Employee', 'Client Documents': 'Client',
};
function dmDocsPage(label, category) {
  return async (b, s) => {
    let alerts = [];
    try { alerts = (await erpGet('dms_alerts')).data.filter(a => a.category === category); } catch (e) { /* optional */ }
    const banner = alerts.length ? `<div class="erp-banner warn"><i class="fas fa-bell"></i><div><b>${alerts.length} document${alerts.length > 1 ? 's need' : ' needs'} attention:</b> ${alerts.slice(0, 4).map(a => `${erpEsc(a.title)} (${a.days_left < 0 ? 'expired ' + (-a.days_left) + ' days ago' : 'expires in ' + a.days_left + ' days'})`).join('; ')}${alerts.length > 4 ? '…' : ''}</div></div>` : '';
    const party = category === 'Employee' ? 'Employee' : 'Client';
    const columns = [['title', 'Title'], ['owner_name', 'Owner']];
    if (category !== 'Company') columns.push(['party', party]);
    columns.push(['version', 'Version'], ['expiry_date', 'Expiry', 'date'], ['days_left', 'Expires In', 'days'], ['signature_count', 'Signed', 'num'], ['updated_at', 'Updated', 'date'], ['status', 'Status', 'chip']);
    const rerender = () => dmDocsPage(label, category)(b, s);
    return erpListPage({
      entity: 'dms_documents', title: label, sectionLabel: s, back: b, fixed: { category }, addLabel: 'Upload ' + (category === 'Company' ? 'Document' : category), rerender, banner, columns,
      onRowClick: r => dmDetailPage(r.id, { fn: rerender, label }),
      canEdit: r => r.access >= 3, canDelete: r => r.access >= 4,
      formOpts: {
        hide: category === 'Company' ? ['client_id', 'employee_id'] : (category === 'Employee' ? ['client_id'] : ['employee_id']),
        afterRender: (cont, api) => { if (api.row && api.row.doc_id) { const l = cont.querySelector('[data-field="file"] label'); if (l) l.textContent = 'Replace file (saved as a new version)'; } },
      },
      rowActions: r => [
        { label: 'Open', icon: 'fa-folder-open', onClick: row => dmDetailPage(row.id, { fn: rerender, label }) },
        { label: 'Download', icon: 'fa-download', show: !!r.version, onClick: row => erpDownload(erpUrl('dms_download', { id: row.id })) },
      ],
    });
  };
}

function dmVersionControlPage(b, s) {
  const rerender = () => dmVersionControlPage(b, s);
  return erpListPage({
    entity: 'dms_documents', title: 'Version Control', sectionLabel: s, back: b, noAdd: true, noEdit: true, noDelete: true, rerender,
    banner: `<div class="erp-banner info"><i class="fas fa-circle-info"></i><div>Files are never overwritten. Every upload becomes a new version (v1.0 → v1.1 → v2.0) and earlier versions stay available for legal and historical reference. Open a document to see its versions, restore an old one, or upload a new one.</div></div>`,
    columns: [['title', 'Document'], ['category', 'Category'], ['version', 'Current'], ['version_count', 'Versions', 'num'], ['file_name', 'Current File', 'trunc'], ['updated_at', 'Last Updated', 'date'], ['status', 'Status', 'chip']],
    onRowClick: r => dmDetailPage(r.id, { fn: rerender, label: 'Version Control' }, 'versions'),
    rowActions: r => [{ label: 'Versions', icon: 'fa-code-branch', onClick: row => dmDetailPage(row.id, { fn: rerender, label: 'Version Control' }, 'versions') }],
  });
}

async function dmDetailPage(docId, back, tab = 'versions') {
  destroyCharts();
  mainContent.innerHTML = '<div class="erp-empty"><i class="fas fa-spinner fa-spin"></i>Opening document…</div>';
  let d;
  try { d = (await erpGet('dms_detail', { id: docId })).data; } catch (e) { mainContent.innerHTML = `<button type="button" class="back-btn" id="dBack"><i class="fas fa-arrow-left"></i> Back to ${erpEsc(back.label)}</button>${erpErrorBox(e)}`; document.getElementById('dBack').addEventListener('click', back.fn); return; }
  const doc = d.doc, acc = d.access;
  const reload = (t) => dmDetailPage(docId, back, t || tab);
  const party = doc.category === 'Employee' ? doc.employee_name : doc.client_name;
  const tabs = [['versions', 'Versions (' + d.versions.length + ')'], ['signatures', 'Signatures (' + d.signatures.length + ')']];
  if (acc >= 4) tabs.push(['access', 'Access'], ['audit', 'Audit Trail']);
  tabs.push(['details', 'Details']);
  if (!tabs.find(t => t[0] === tab)) tab = 'versions';

  mainContent.innerHTML = `
    <button type="button" class="back-btn" id="dBack"><i class="fas fa-arrow-left"></i> Back to ${erpEsc(back.label)}</button>
    <div class="eyebrow">Document Management <span class="crumb-sep">/</span> <span class="crumb-current">${erpEsc(doc.title)}</span></div>
    <div class="erp-card" style="margin-top:6px"><div style="display:flex;flex-wrap:wrap;gap:14px;align-items:flex-start;justify-content:space-between">
      <div><div style="font-size:1.25rem;font-weight:800;color:#1b2440">${erpEsc(doc.title)}</div>
        <div class="erp-muted" style="margin-top:4px">${erpEsc(doc.category)}${party ? ' · ' + erpEsc(party) : ''} · current <b>${erpEsc(doc.version || '—')}</b> · owner ${erpEsc(doc.owner_name || '—')}</div>
        <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">${erpChip(doc.status)}${doc.expiry_date ? (Number(doc.days_left) < 0 ? '<span class="erp-chip erp-c-red">Expired ' + erpEsc(erpFmtDate(doc.expiry_date)) + '</span>' : Number(doc.days_left) <= Number(doc.renewal_alert_days) ? '<span class="erp-chip erp-c-amber">Renews ' + erpEsc(erpFmtDate(doc.expiry_date)) + '</span>' : '<span class="erp-chip erp-c-grey">Valid to ' + erpEsc(erpFmtDate(doc.expiry_date)) + '</span>') : ''}${d.signed_current ? '<span class="erp-chip erp-c-green">You signed this version</span>' : ''}</div></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${doc.current_version_id ? `<button type="button" class="erp-btn-sm erp-prim" id="dDl"><i class="fas fa-download"></i> Download</button><button type="button" class="erp-btn-sm" id="dPrev"><i class="fas fa-eye"></i> Preview</button>` : ''}
        ${doc.current_version_id && !d.signed_current && doc.status !== 'Archived' ? `<button type="button" class="erp-btn-sm erp-go" id="dSign"><i class="fas fa-signature"></i> Sign</button>` : ''}
        ${acc >= 3 ? `<button type="button" class="erp-btn-sm" id="dAddV"><i class="fas fa-upload"></i> New version</button><button type="button" class="erp-btn-sm" id="dEdit"><i class="fas fa-pen"></i> Edit</button>` : ''}
      </div></div></div>
    ${d.baseline ? '<div class="erp-banner info"><i class="fas fa-users"></i><div>This is a company document with no specific access rules, so every user can view it.</div></div>' : ''}
    <div class="erp-tabs">${tabs.map(t => `<button type="button" class="erp-tab ${t[0] === tab ? 'active' : ''}" data-t="${t[0]}">${t[1]}</button>`).join('')}</div>
    <div id="dTab" class="erp-card"></div>`;

  document.getElementById('dBack').addEventListener('click', back.fn);
  mainContent.querySelectorAll('[data-t]').forEach(x => x.addEventListener('click', () => { tab = x.dataset.t; mainContent.querySelectorAll('.erp-tab').forEach(y => y.classList.toggle('active', y === x)); drawTab(); }));
  const on = (id, fn) => { const e = document.getElementById(id); if (e) e.addEventListener('click', fn); };
  on('dDl', () => erpDownload(erpUrl('dms_download', { id: docId })));
  on('dPrev', () => window.open(erpUrl('dms_download', { id: docId, inline: 1 }), '_blank'));
  on('dSign', () => erpDialog({ title: 'Sign “' + doc.title + '”', okLabel: 'Sign document',
    note: `You are signing version <b>${erpEsc(doc.version)}</b> as <b>${erpEsc((window.currentUser || {}).name || 'you')}</b>. Your name, the time and your IP address are recorded.`,
    fields: [{ k: 'confirm', l: 'I have read this document and agree to sign it.', t: 'checkbox', req: true }, { k: 'remarks', l: 'Remarks (optional)', t: 'text' }],
    onSubmit: async v => { const r = await erpPost('dms_sign', { doc_id: docId, confirm: 1, remarks: v.remarks }); erpToast(r.message); erpNotices(r); reload('signatures'); } }));
  on('dAddV', () => dmVersionDialog(docId, doc, () => reload('versions')));
  on('dEdit', () => erpForm({ entity: 'dms_documents', id: docId, title: 'Document', crumb: 'Document Management', cancelLabel: 'Back to document', onCancel: () => reload(), onSaved: () => reload(),
    hide: doc.category === 'Company' ? ['client_id', 'employee_id', 'category'] : (doc.category === 'Employee' ? ['client_id', 'category'] : ['employee_id', 'category']), defaults: { category: doc.category },
    afterRender: cont => { const l = cont.querySelector('[data-field="file"] label'); if (l) l.textContent = 'Replace file (saved as a new version)'; } }));

  function drawTab() {
    const host = document.getElementById('dTab');
    if (tab === 'versions') {
      host.innerHTML = `<h3>Version history</h3><div class="sub">Each upload is kept forever. Download any version or restore it as the new current one.</div><div class="table-scroll"><table class="data-table"><thead><tr><th>Version</th><th>File</th><th>Size</th><th>Uploaded by</th><th>Date</th><th>Change note</th><th></th></tr></thead><tbody>
        ${d.versions.map(v => `<tr><td><b>${erpEsc(v.version_number)}</b> ${v.is_current ? '<span class="erp-chip erp-c-green">current</span>' : ''}</td><td>${erpEsc(v.file_name)}</td><td>${erpEsc(erpBytes(v.file_size))}</td><td>${erpEsc(v.uploaded_by_name || '—')}</td><td>${erpEsc(erpFmtDateTime(v.upload_date))}</td><td>${erpEsc(v.change_log || '')}</td>
          <td class="erp-acts"><button type="button" class="erp-btn-sm" data-dl="${v.version_id}"><i class="fas fa-download"></i></button>${acc >= 3 && !v.is_current ? `<button type="button" class="erp-btn-sm erp-warn" data-rs="${v.version_id}" data-vn="${erpEsc(v.version_number)}">Restore</button>` : ''}</td></tr>`).join('')}</tbody></table></div>`;
      host.querySelectorAll('[data-dl]').forEach(x => x.addEventListener('click', () => erpDownload(erpUrl('dms_download', { id: docId, version_id: x.dataset.dl }))));
      host.querySelectorAll('[data-rs]').forEach(x => x.addEventListener('click', async () => {
        if (!await erpConfirm(`Restore ${x.dataset.vn} as the new current version? Nothing is deleted — it is saved as a new version.`, { okLabel: 'Restore' })) return;
        try { const r = await erpPost('dms_restore_version', { version_id: x.dataset.rs }); erpToast(r.message); reload('versions'); } catch (e) { erpToast(e.message, 'error'); }
      }));
    } else if (tab === 'signatures') {
      host.innerHTML = `<h3>Signatures</h3><div class="sub">Digital sign-off records for this document.</div><div class="table-scroll"><table class="data-table"><thead><tr><th>Signer</th><th>Version</th><th>Signed at</th><th>IP address</th><th>Remarks</th></tr></thead><tbody>
        ${d.signatures.length ? d.signatures.map(x => `<tr><td><b>${erpEsc(x.signer_name)}</b></td><td>${erpEsc(x.version_number)}</td><td>${erpEsc(erpFmtDateTime(x.signed_at))}</td><td class="erp-mono">${erpEsc(x.ip_address || '')}</td><td>${erpEsc(x.remarks || '')}</td></tr>`).join('') : '<tr><td colspan="5"><div class="erp-empty"><i class="fas fa-signature"></i>Not signed yet.</div></td></tr>'}</tbody></table></div>`;
    } else if (tab === 'access') {
      host.innerHTML = `<h3>Who can access this document</h3><div class="sub">Administrators, the owner and the uploader always have full access. Everyone else needs a rule below — for a person, or for a role (which applies to everyone holding that role in <b>User Management</b>).</div>
        <div class="table-scroll"><table class="data-table"><thead><tr><th>Who</th><th>Type</th><th>Access</th><th></th></tr></thead><tbody>
        ${d.permissions.length ? d.permissions.map(p => `<tr><td><b>${erpEsc(p.employee_name || p.role_name)}</b></td><td>${p.user_id ? 'Employee' : 'Role'}</td><td>${erpChip(p.access_level)}</td><td><button type="button" class="erp-btn-sm erp-danger" data-rm="${p.permission_id}">Remove</button></td></tr>`).join('') : '<tr><td colspan="4"><div class="erp-empty"><i class="fas fa-lock"></i>No rules — only administrators, the owner and the uploader can open this document.</div></td></tr>'}</tbody></table></div>
        <h4 style="margin:18px 0 8px;font-size:.9rem">Grant access</h4>
        <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:end">
          <div class="erp-field"><label>Grant to</label><select id="pType"><option value="e">An employee</option><option value="r">A role</option></select></div>
          <div class="erp-field" style="min-width:240px"><label>Who</label><select id="pWho"><option value="">Loading…</option></select></div>
          <div class="erp-field"><label>Level</label><select id="pLvl"><option>View</option><option>Comment</option><option>Edit</option><option>Admin</option></select></div>
          <button type="button" class="btn-primary" id="pGo" style="padding:10px 20px;border-radius:8px;cursor:pointer;font-weight:700">Grant</button></div>
        <div class="erp-help" style="margin-top:8px;font-size:.76rem;color:#8a93a6">View = open &amp; download · Comment = View + comment · Edit = upload versions &amp; edit details · Admin = also manage access and delete.</div>`;
      const fill = async () => { const t = document.getElementById('pType').value; const rows = await erpLookup(t === 'e' ? 'employees' : 'roles'); document.getElementById('pWho').innerHTML = '<option value="">— Select —</option>' + rows.map(r => `<option value="${r.id}">${erpEsc(r.label)}</option>`).join(''); };
      fill(); document.getElementById('pType').addEventListener('change', fill);
      document.getElementById('pGo').addEventListener('click', async () => {
        const t = document.getElementById('pType').value, who = document.getElementById('pWho').value;
        if (!who) return erpToast('Choose who to grant access to.', 'error');
        try { const r = await erpPost('dms_set_permission', { doc_id: docId, [t === 'e' ? 'user_id' : 'role_id']: who, access_level: document.getElementById('pLvl').value }); erpToast(r.message); reload('access'); } catch (e) { erpToast(e.message, 'error'); }
      });
      host.querySelectorAll('[data-rm]').forEach(x => x.addEventListener('click', async () => {
        if (!await erpConfirm('Remove this access rule?', { okLabel: 'Remove', danger: true })) return;
        try { await erpPost('dms_remove_permission', { permission_id: x.dataset.rm }); erpToast('Access removed'); reload('access'); } catch (e) { erpToast(e.message, 'error'); }
      }));
    } else if (tab === 'audit') {
      host.innerHTML = `<h3>Audit trail</h3><div class="sub">Every view, download, change and signature — newest first (last 100).</div><div class="table-scroll"><table class="data-table"><thead><tr><th>When</th><th>User</th><th>Action</th><th>Details</th><th>IP</th></tr></thead><tbody>
        ${d.audit.map(a => `<tr><td>${erpEsc(erpFmtDateTime(a.timestamp))}</td><td>${erpEsc(a.user_name || '—')}</td><td>${erpChip(a.action)}</td><td>${erpEsc(a.details || '')}</td><td class="erp-mono">${erpEsc(a.ip_address || '')}</td></tr>`).join('') || '<tr><td colspan="5"><div class="erp-empty">No activity</div></td></tr>'}</tbody></table></div>`;
    } else {
      host.innerHTML = `<h3>Details</h3><dl class="erp-kv" style="margin-top:12px"><dt>Title</dt><dd>${erpEsc(doc.title)}</dd><dt>Category</dt><dd>${erpEsc(doc.category)}</dd><dt>Status</dt><dd>${erpChip(doc.status)}</dd><dt>Owner</dt><dd>${erpEsc(doc.owner_name || '—')}</dd>
        <dt>${doc.category === 'Employee' ? 'Employee' : 'Client'}</dt><dd>${erpEsc(party || '—')}</dd><dt>Effective</dt><dd>${erpEsc(erpFmtDate(doc.effective_date) || '—')}</dd><dt>Expiry</dt><dd>${erpEsc(erpFmtDate(doc.expiry_date) || '—')} ${doc.expiry_date ? '(alert ' + doc.renewal_alert_days + ' days before)' : ''}</dd>
        <dt>Description</dt><dd>${erpEsc(doc.description || '—')}</dd><dt>Created</dt><dd>${erpEsc(erpFmtDateTime(doc.created_at))}</dd><dt>Your access</dt><dd>${['', 'View', 'Comment', 'Edit', 'Admin'][acc]}</dd></dl>`;
    }
  }
  drawTab();
}
function dmVersionDialog(docId, doc, after) {
  return erpDialog({
    title: 'Upload a new version of “' + doc.title + '”', okLabel: 'Upload',
    note: `Current version is <b>${erpEsc(doc.version)}</b>. The new file is saved as the next version; earlier versions are kept.`,
    fields: [
      { k: 'file', l: 'New file', t: 'file', req: true },
      { k: 'change_log', l: 'What changed?', t: 'text', req: true, ph: 'e.g. Updated payment terms in clause 4' },
      { k: 'major', l: 'Major revision (v2.0 instead of v1.1)', t: 'checkbox' },
    ],
    onSubmit: async v => { const r = await erpPost('dms_add_version', { doc_id: docId, file: v.file, change_log: v.change_log, major: v.major ? 1 : 0 }); erpToast(r.message); erpNotices(r); after(); },
  });
}

const DM_PAGES = { 'Version Control': dmVersionControlPage };
Object.entries(DM_CATEGORIES).forEach(([label, cat]) => { DM_PAGES[label] = dmDocsPage(label, cat); });

/* =========================================================
   ADMINISTRATION
   ========================================================= */
async function admSettingsPage(b, s, title, groups, opts = {}) {
  destroyCharts();
  mainContent.innerHTML = `<button type="button" class="back-btn" id="sBack"><i class="fas fa-arrow-left"></i> Back to ${erpEsc(b.label)}</button>
    <div class="eyebrow">Administration <span class="crumb-sep">/</span> <span class="crumb-current">${erpEsc(title)}</span></div>
    <div class="page-title"><span>${erpEsc(title)}</span></div><div id="sBody"><div class="erp-empty"><i class="fas fa-spinner fa-spin"></i>Loading…</div></div>`;
  document.getElementById('sBack').addEventListener('click', b.fn);
  const host = document.getElementById('sBody');
  let data;
  try { data = (await erpGet('adm_settings_get', { groups: groups.join(',') })).data; } catch (e) { host.innerHTML = erpErrorBox(e); return; }
  const accounts = groups.includes('Finance') ? await erpLookup('chart_accounts').catch(() => []) : [];
  host.innerHTML = (opts.intro ? `<div class="erp-banner info"><i class="fas fa-circle-info"></i><div>${opts.intro}</div></div>` : '') + groups.map(g => {
    const G = data[g];
    return `<div class="erp-card" data-g="${g}"><h3>${erpEsc(G.title)}</h3><div class="sub">${g === 'Finance' ? (accounts.length ? 'Choose the Chart of Accounts ledgers used when assets are bought, depreciated, repaired and retired.' : '<span style="color:#c77a0b">No accounts found. Add them under Accounts › Chart of Accounts first.</span>') : 'Secrets (passwords, tokens, keys) are stored encrypted and are never shown again.'}</div>
      <div class="erp-form-grid">${G.fields.map(f => `<div class="erp-field ${f.full || f.t === 'textarea' ? 'erp-full' : ''}"><label for="st_${f.k}">${erpEsc(f.l)}${f.req ? ' <span class="erp-req">*</span>' : ''}${f.t === 'password' && G.values[f.k].set ? '<span class="erp-secret-set"><i class="fas fa-lock"></i> saved</span>' : ''}</label>${admSettingCtl(f, G.values[f.k], accounts)}${f.help ? `<div class="erp-help">${erpEsc(f.help)}</div>` : ''}</div>`).join('')}</div>
      ${g === 'Company' ? `<div class="erp-field" style="margin-top:16px"><label>Company logo</label><div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap"><img id="stLogo" src="${erpUrl('adm_logo')}&t=${Date.now()}" alt="" style="max-height:56px;border-radius:6px;border:1px solid #e2e5ee;background:#f7f8fb;min-width:56px;min-height:56px" onerror="this.style.display='none'"><input type="file" id="stLogoFile" accept="image/*" style="max-width:260px"><button type="button" class="erp-btn-sm" id="stLogoGo">Upload logo</button></div></div>` : ''}
      <div class="erp-form-actions" style="margin:18px 0 0"><button type="button" class="btn-primary stSave" data-g="${g}"><i class="fas fa-floppy-disk"></i> Save</button>
        <button type="button" class="btn-secondary stCheck" data-g="${g}">Check configuration</button>${opts.extraButtons ? opts.extraButtons(g) : ''}<span class="erp-form-msg" id="stMsg_${g}"></span></div></div>`;
  }).join('');

  host.querySelectorAll('.stSave').forEach(btn => btn.addEventListener('click', async () => {
    const g = btn.dataset.g, card = host.querySelector(`[data-g="${g}"].erp-card`), msg = host.querySelector('#stMsg_' + g);
    const values = {}, clear = {};
    data[g].fields.forEach(f => {
      const c = card.querySelector('#st_' + f.k); if (!c) return;
      values[f.k] = f.t === 'bool' ? (c.checked ? '1' : '0') : c.value;
      const cl = card.querySelector('#stClr_' + f.k); if (cl && cl.checked) clear[f.k] = 1;
    });
    btn.disabled = true; msg.className = 'erp-form-msg'; msg.textContent = 'Saving…';
    try { const r = await erpPost('adm_settings_save', { group: g, values, clear }); msg.className = 'erp-form-msg ok'; msg.textContent = r.message; erpToast(r.message); setTimeout(() => admSettingsPage(b, s, title, groups, opts), 600); }
    catch (e) { msg.className = 'erp-form-msg err'; msg.textContent = e.message; erpToast(e.message, 'error'); btn.disabled = false; }
  }));
  host.querySelectorAll('.stCheck').forEach(btn => btn.addEventListener('click', async () => {
    try { const r = await erpGet('adm_check_settings', { group: btn.dataset.g }); erpToast(r.message, r.data.ready ? 'success' : 'warn'); } catch (e) { erpToast(e.message, 'error'); }
  }));
  const lg = document.getElementById('stLogoGo');
  if (lg) lg.addEventListener('click', async () => {
    const f = document.getElementById('stLogoFile').files[0]; if (!f) return erpToast('Choose an image first.', 'error');
    try { const r = await erpPost('adm_logo_upload', { logo: f }); erpToast(r.message); const im = document.getElementById('stLogo'); im.style.display = ''; im.src = erpUrl('adm_logo') + '&t=' + Date.now(); } catch (e) { erpToast(e.message, 'error'); }
  });
  if (opts.after) opts.after(host);
}
function admSettingCtl(f, v, accounts) {
  const id = 'st_' + f.k;
  if (f.t === 'password') return `<input type="password" id="${id}" autocomplete="new-password" placeholder="${v.set ? v.masked + '  (leave blank to keep)' : 'Not set'}">${v.set ? `<label class="erp-check" style="margin-top:6px;font-size:.76rem;font-weight:600"><input type="checkbox" id="stClr_${f.k}"> clear the saved value</label>` : ''}`;
  if (f.t === 'bool') return `<label class="erp-check"><input type="checkbox" id="${id}" ${String(v) === '1' ? 'checked' : ''}> Enabled</label>`;
  if (f.t === 'textarea') return `<textarea id="${id}" rows="3">${erpEsc(v)}</textarea>`;
  if (f.t === 'select') {
    const items = f.optsMap ? Object.entries(f.optsMap) : f.opts.map(o => [o, o]);
    return `<select id="${id}">${items.map(([val, lab]) => `<option value="${erpEsc(val)}" ${String(val) === String(v) ? 'selected' : ''}>${erpEsc(lab)}</option>`).join('')}</select>`;
  }
  if (f.t === 'lookup') return `<select id="${id}"><option value="">— Not mapped —</option>${accounts.map(a => `<option value="${a.id}" ${String(a.id) === String(v) ? 'selected' : ''}>${erpEsc(a.label)}</option>`).join('')}</select>`;
  const type = { email: 'email', url: 'url', tel: 'tel', number: 'number' }[f.t] || 'text';
  return `<input type="${type}" id="${id}" value="${erpEsc(v)}" ${f.ph ? `placeholder="${erpEsc(f.ph)}"` : ''} ${f.max ? `maxlength="${f.max}"` : ''}>`;
}

/* ---- login accounts ---- */
async function admAccountsPage(b, s) {
  destroyCharts();
  mainContent.innerHTML = `<button type="button" class="back-btn" id="aBack"><i class="fas fa-arrow-left"></i> Back to ${erpEsc(b.label)}</button>
    <div class="eyebrow">Administration <span class="crumb-sep">/</span> <span class="crumb-current">Login Accounts</span></div>
    <div class="page-title"><span>Login Accounts</span><div class="actions"><button type="button" class="btn btn-secondary" id="aEmp" style="padding:9px 14px;border-radius:8px;cursor:pointer;font-weight:600"><i class="fas fa-user-tag"></i> Employees &amp; Roles</button> <button type="button" class="btn btn-primary" id="aNew"><i class="fas fa-plus"></i> New Login Account</button></div></div>
    <div class="erp-banner info"><i class="fas fa-circle-info"></i><div>A login account lets a person sign in. The <b>role</b> chosen here controls whether they can see Administration. Fine-grained roles for each employee are assigned under <b>Employees &amp; Roles</b>, and passwords follow the policy in <b>Security</b>.</div></div>
    <div class="table-panel"><div class="table-scroll"><table class="data-table"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Employee</th><th>Roles assigned</th><th>Last sign-in</th><th>Status</th><th>Actions</th></tr></thead><tbody id="aBody"><tr><td colspan="8"><div class="erp-empty"><i class="fas fa-spinner fa-spin"></i>Loading…</div></td></tr></tbody></table></div></div>`;
  document.getElementById('aBack').addEventListener('click', b.fn);
  document.getElementById('aEmp').addEventListener('click', () => ADM_PAGES['Users'](b, s));
  let D;
  const load = async () => {
    D = (await erpGet('adm_accounts')).data;
    document.getElementById('aBody').innerHTML = D.accounts.map(a => `<tr><td><b>${erpEsc(a.name)}</b>${a.id === D.me ? ' <span class="erp-chip erp-c-blue">you</span>' : ''}</td><td>${erpEsc(a.email)}</td><td>${erpChip(a.role)}</td><td>${erpEsc(a.employee_name || '—')}</td><td>${erpEsc(a.assigned_roles || '—')}</td><td>${erpEsc(erpFmtDateTime(a.last_login_at) || 'never')}</td><td>${erpChip(a.status)}</td>
      <td class="erp-acts"><button type="button" class="erp-btn-sm" data-e="${a.id}"><i class="fas fa-pen"></i></button><button type="button" class="erp-btn-sm" data-pw="${a.id}">Reset password</button>
      ${a.id !== D.me ? `<button type="button" class="erp-btn-sm ${a.status === 'Active' ? 'erp-warn' : 'erp-go'}" data-st="${a.id}" data-to="${a.status === 'Active' ? 'Suspended' : 'Active'}">${a.status === 'Active' ? 'Suspend' : 'Activate'}</button><button type="button" class="erp-btn-sm erp-danger" data-del="${a.id}"><i class="fas fa-trash"></i></button>` : ''}</td></tr>`).join('');
    const body = document.getElementById('aBody');
    body.querySelectorAll('[data-e]').forEach(x => x.addEventListener('click', () => acctDialog(D.accounts.find(a => String(a.id) === x.dataset.e))));
    body.querySelectorAll('[data-pw]').forEach(x => x.addEventListener('click', () => pwDialog(D.accounts.find(a => String(a.id) === x.dataset.pw))));
    body.querySelectorAll('[data-st]').forEach(x => x.addEventListener('click', async () => {
      if (!await erpConfirm(x.dataset.to === 'Suspended' ? 'Suspend this account? The person will be unable to sign in.' : 'Re-activate this account?', { okLabel: x.dataset.to === 'Suspended' ? 'Suspend' : 'Activate' })) return;
      try { const r = await erpPost('adm_account_status', { id: x.dataset.st, status: x.dataset.to }); erpToast(r.message); load(); } catch (e) { erpToast(e.message, 'error'); }
    }));
    body.querySelectorAll('[data-del]').forEach(x => x.addEventListener('click', async () => {
      if (!await erpConfirm('Delete this login account permanently?', { okLabel: 'Delete', danger: true })) return;
      try { await erpPost('adm_account_delete', { id: x.dataset.del }); erpToast('Account deleted'); load(); } catch (e) { erpToast(e.message, 'error'); }
    }));
  };
  const pwHelp = () => { const p = D.policy; return `Minimum ${p.min_length} characters${p.require_upper ? ', an uppercase letter' : ''}${p.require_lower ? ', a lowercase letter' : ''}${p.require_number ? ', a number' : ''}${p.require_special ? ', a special character' : ''}.`; };
  function acctDialog(acc) {
    const emps = acc && acc.employee_id ? [] : D.employees;
    return erpDialog({
      title: acc ? 'Edit login account' : 'New login account', okLabel: acc ? 'Save' : 'Create account', wide: true,
      note: acc ? '' : 'Pick an employee to prefill their name and email, or enter the details by hand.',
      fields: [
        ...(acc ? [] : [{ k: 'employee_id', l: 'Employee (optional)', t: 'select', opts: [''].concat(emps.map(e => e.id + ' — ' + e.name)), def: '' }]),
        { k: 'name', l: 'Full name', t: 'text', req: true, def: acc ? acc.name : '' },
        { k: 'email', l: 'Email (used to sign in)', t: 'email', req: true, def: acc ? acc.email : '' },
        { k: 'role', l: 'Role', t: 'select', opts: D.roles, req: true, def: acc ? acc.role : 'Executive' },
        ...(acc ? [] : [{ k: 'password', l: 'Password', t: 'password', req: true, help: pwHelp(), autocomplete: 'new-password' }, { k: 'confirm', l: 'Confirm password', t: 'password', req: true, autocomplete: 'new-password' }]),
      ],
      onSubmit: async v => {
        const body = { id: acc ? acc.id : undefined, name: v.name, email: v.email, role: v.role, employee_id: acc ? (acc.employee_id || '') : '' };
        if (!acc) { const e = (v.employee_id || '').split(' — ')[0]; body.employee_id = e || ''; body.password = v.password; body.confirm = v.confirm; }
        const r = await erpPost('adm_account_save', body); erpToast(r.message); load();
      },
    }).then(() => {});
  }
  function pwDialog(acc) {
    return erpDialog({ title: 'Reset password — ' + acc.name, okLabel: 'Reset password', note: pwHelp(), fields: [{ k: 'password', l: 'New password', t: 'password', req: true, autocomplete: 'new-password' }],
      onSubmit: async v => { const r = await erpPost('adm_account_reset', { id: acc.id, password: v.password }); erpToast(r.message); } });
  }
  document.getElementById('aNew').addEventListener('click', () => acctDialog(null));
  // prefill name/email when an employee is chosen
  document.addEventListener('change', function onSel(e) {
    if (e.target && e.target.id === 'erpd_employee_id') {
      const id = e.target.value.split(' — ')[0]; const emp = D.employees.find(x => String(x.id) === id);
      if (emp) { const n = document.getElementById('erpd_name'), m = document.getElementById('erpd_email'); if (n && !n.value) n.value = emp.name; if (m && !m.value && emp.email) m.value = emp.email; }
    }
    if (!document.getElementById('aBody')) document.removeEventListener('change', onSel);
  });
  try { await load(); } catch (e) { document.getElementById('aBody').innerHTML = `<tr><td colspan="8">${erpErrorBox(e)}</td></tr>`; }
}

/* ---- backup ---- */
async function admBackupPage(b, s) {
  destroyCharts();
  mainContent.innerHTML = `<button type="button" class="back-btn" id="bBack"><i class="fas fa-arrow-left"></i> Back to ${erpEsc(b.label)}</button>
    <div class="eyebrow">Administration <span class="crumb-sep">/</span> <span class="crumb-current">Backup</span></div>
    <div class="page-title"><span>Backup &amp; Restore</span><div class="actions"><button type="button" class="btn btn-primary" id="bRun"><i class="fas fa-database"></i> Back up now</button></div></div><div id="bBody"><div class="erp-empty"><i class="fas fa-spinner fa-spin"></i>Loading…</div></div>`;
  document.getElementById('bBack').addEventListener('click', b.fn);
  const isSuper = (window.currentUser || {}).role === 'Super Admin';
  const load = async () => {
    const d = (await erpGet('adm_backup_list')).data;
    const last = d.history.find(h => h.status === 'Success');
    document.getElementById('bBody').innerHTML = `
      <div class="erp-kpis"><div class="erp-kpi" style="--c:#16a34a"><div class="l">Last good backup</div><div class="v" style="font-size:1.05rem">${last ? erpEsc(erpFmtDateTime(last.executed_at)) : 'None yet'}</div></div>
        <div class="erp-kpi" style="--c:#3556d6"><div class="l">Backups stored</div><div class="v">${d.history.filter(h => h.file_exists).length}</div></div>
        <div class="erp-kpi" style="--c:#7c5cff"><div class="l">Free disk space</div><div class="v">${d.free_gb !== null ? d.free_gb + ' GB' : '—'}</div></div></div>
      <div class="erp-two"><div class="erp-card"><h3>Automatic daily backup</h3><div class="sub">Schedule this command with the Windows Task Scheduler (XAMPP) or cron (Linux), e.g. daily at 2 AM.</div>
        <div class="erp-mono" style="background:#f5f7fa;border-radius:8px;padding:10px 12px;word-break:break-all;font-size:.76rem">"${erpEsc(d.php)}" "${erpEsc(d.cron_path)}"</div>
        <div class="erp-help" style="margin-top:8px;font-size:.76rem;color:#8a93a6">Linux cron: <span class="erp-mono">0 2 * * * ${erpEsc(d.php)} ${erpEsc(d.cron_path)}</span><br>Each run is listed below as “Scheduled”. Copy the files off the server (e.g. to cloud storage) for disaster recovery.</div></div>
        <div class="erp-card"><h3>Retention</h3><div class="sub">Old backup files are deleted automatically after each new backup.</div>
        <div style="display:flex;gap:10px;align-items:end"><div class="erp-field"><label>Keep backups for (days, 0 = forever)</label><input type="number" id="bRet" min="0" max="3650" value="${d.retention_days}" style="max-width:160px"></div><button type="button" class="btn-primary" id="bRetGo" style="padding:10px 18px;border-radius:8px;cursor:pointer;font-weight:700">Save</button></div></div></div>
      <div class="table-panel"><div class="panel-head"><div><div class="panel-title">Backup history</div><div class="panel-sub">${d.gzip ? 'Compressed (.sql.gz)' : 'Plain SQL'} · restoring replaces ALL current data</div></div></div><div class="table-scroll"><table class="data-table"><thead><tr><th>When</th><th>File</th><th>Size</th><th>Type</th><th>By</th><th>Status</th><th>Details</th><th>Actions</th></tr></thead><tbody>
      ${d.history.length ? d.history.map(h => `<tr><td>${erpEsc(erpFmtDateTime(h.executed_at))}</td><td class="erp-mono">${erpEsc(h.file_name)}</td><td>${Number(h.file_size_mb).toFixed(2)} MB</td><td>${erpEsc(h.backup_type)}</td><td>${erpEsc(h.executed_by || '')}</td><td>${erpChip(h.status)}</td><td>${erpEsc(h.message || '')}</td>
        <td class="erp-acts">${h.file_exists ? `<button type="button" class="erp-btn-sm" data-dl="${h.backup_id}"><i class="fas fa-download"></i></button>${isSuper && h.status === 'Success' ? `<button type="button" class="erp-btn-sm erp-warn" data-rs="${h.backup_id}" data-f="${erpEsc(h.file_name)}">Restore</button>` : ''}` : '<span class="erp-muted">file removed</span>'}<button type="button" class="erp-btn-sm erp-danger" data-del="${h.backup_id}"><i class="fas fa-trash"></i></button></td></tr>`).join('') : '<tr><td colspan="8"><div class="erp-empty"><i class="fas fa-database"></i>No backups yet. Click “Back up now”.</div></td></tr>'}</tbody></table></div></div>`;
    const bb = document.getElementById('bBody');
    document.getElementById('bRetGo').addEventListener('click', async () => { try { const r = await erpPost('adm_backup_retention', { days: document.getElementById('bRet').value }); erpToast(r.message); } catch (e) { erpToast(e.message, 'error'); } });
    bb.querySelectorAll('[data-dl]').forEach(x => x.addEventListener('click', () => erpDownload(erpUrl('adm_backup_download', { id: x.dataset.dl }))));
    bb.querySelectorAll('[data-del]').forEach(x => x.addEventListener('click', async () => { if (!await erpConfirm('Delete this backup and its file?', { okLabel: 'Delete', danger: true })) return; try { await erpPost('adm_backup_delete', { id: x.dataset.del }); erpToast('Backup deleted'); load(); } catch (e) { erpToast(e.message, 'error'); } }));
    bb.querySelectorAll('[data-rs]').forEach(x => x.addEventListener('click', () => erpDialog({
      title: 'Restore ' + x.dataset.f, okLabel: 'Restore database',
      note: '<b style="color:#d3312f">This replaces ALL current data with the contents of this backup.</b> A safety copy of the current data is taken first. Everyone should be signed out while this runs.',
      fields: [{ k: 'confirm', l: 'Type RESTORE to confirm', t: 'text', req: true, ph: 'RESTORE' }],
      onSubmit: async v => { const r = await erpPost('adm_backup_restore', { id: x.dataset.rs, confirm: v.confirm }); erpToast(r.message, 'success'); load(); },
    })));
  };
  document.getElementById('bRun').addEventListener('click', async e => {
    const btn = e.currentTarget; btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Backing up…';
    try { const r = await erpPost('adm_backup_run'); erpToast(r.message); await load(); } catch (er) { erpToast(er.message, 'error'); }
    btn.disabled = false; btn.innerHTML = '<i class="fas fa-database"></i> Back up now';
  });
  try { await load(); } catch (e) { document.getElementById('bBody').innerHTML = erpErrorBox(e); }
}

/* ---- audit logs ---- */
async function admAuditPage(b, s) {
  let st = null;
  try { st = (await erpGet('adm_audit_stats')).data; } catch (e) { mainContent.innerHTML = erpErrorBox(e); return; }
  return erpListPage({
    entity: 'adm_audit_logs', title: 'Audit Logs', sectionLabel: s, back: b, readOnly: true, perPage: 50, rerender: () => admAuditPage(b, s),
    banner: `<div class="erp-banner info"><i class="fas fa-circle-info"></i><div>Every create, update and delete made anywhere in the CRM is recorded here automatically — who, what, which module and from which IP address. Passwords and request contents are never stored.</div></div>`,
    kpis: async () => { const x = (await erpGet('adm_audit_stats')).data; return [{ l: 'Total events', v: x.total.toLocaleString('en-IN'), c: '#3556d6' }, { l: 'Today', v: x.today, c: '#16a34a' }, { l: 'Sign-ins today', v: x.logins, c: '#14b8a6' }, { l: 'Failed (7 days)', v: x.failed, c: '#e0384c' }]; },
    filterOptions: { table_affected: st.tables },
    filters: ['outcome', 'request_method', 'table_affected'],
  });
}

/* ---- security ---- */
async function admSecurityPage(b, s) {
  destroyCharts();
  mainContent.innerHTML = `<button type="button" class="back-btn" id="xBack"><i class="fas fa-arrow-left"></i> Back to ${erpEsc(b.label)}</button>
    <div class="eyebrow">Administration <span class="crumb-sep">/</span> <span class="crumb-current">Security</span></div>
    <div class="page-title"><span>Security</span></div><div id="xBody"><div class="erp-empty"><i class="fas fa-spinner fa-spin"></i>Loading…</div></div>`;
  document.getElementById('xBack').addEventListener('click', b.fn);
  let st;
  try { st = (await erpGet('adm_security_status')).data; } catch (e) { document.getElementById('xBody').innerHTML = erpErrorBox(e); return; }
  const p = st.policy;
  document.getElementById('xBody').innerHTML = `
    <div class="erp-kpis"><div class="erp-kpi" style="--c:#3556d6"><div class="l">Your IP address</div><div class="v" style="font-size:1.1rem">${erpEsc(st.your_ip || '—')}</div></div>
      <div class="erp-kpi" style="--c:#16a34a"><div class="l">Whitelist rules</div><div class="v">${st.whitelist}</div><div class="s">${st.whitelist ? 'ONLY these IPs can sign in' : 'no restriction'}</div></div>
      <div class="erp-kpi" style="--c:#7c5cff"><div class="l">Blacklist rules</div><div class="v">${st.blacklist}</div></div>
      <div class="erp-kpi" style="--c:#e08c1c"><div class="l">Failed sign-ins (24h)</div><div class="v">${st.failed_logins_24h}</div></div>
      <div class="erp-kpi" style="--c:#e0384c"><div class="l">Blocked requests (24h)</div><div class="v">${st.blocked_24h}</div></div></div>
    <div class="erp-card"><h3>Password &amp; sign-in policy</h3><div class="sub">Applies when passwords are created or reset for login accounts. The lock-out is off while the limit is 0.</div>
      <div class="erp-form-grid">
        <div class="erp-field"><label>Minimum length</label><input type="number" id="pl_min" min="4" max="64" value="${p.min_length}"></div>
        <div class="erp-field"><label>Lock after failed sign-ins (0 = off)</label><input type="number" id="pl_max" min="0" max="50" value="${p.max_login_attempts}"></div>
        <div class="erp-field"><label>Lock duration (minutes)</label><input type="number" id="pl_lock" min="1" max="1440" value="${p.lock_minutes}"></div>
        <div class="erp-field"><label>Password expiry (days, 0 = never)</label><input type="number" id="pl_exp" min="0" max="3650" value="${p.expiry_days}" disabled title="Stored for reference - expiry is not enforced yet"></div>
        <div class="erp-field"><label class="erp-check"><input type="checkbox" id="pl_up" ${p.require_upper ? 'checked' : ''}> Require an uppercase letter</label></div>
        <div class="erp-field"><label class="erp-check"><input type="checkbox" id="pl_lo" ${p.require_lower ? 'checked' : ''}> Require a lowercase letter</label></div>
        <div class="erp-field"><label class="erp-check"><input type="checkbox" id="pl_nu" ${p.require_number ? 'checked' : ''}> Require a number</label></div>
        <div class="erp-field"><label class="erp-check"><input type="checkbox" id="pl_sp" ${p.require_special ? 'checked' : ''}> Require a special character</label></div></div>
      <div class="erp-form-actions" style="margin:16px 0 0"><button type="button" class="btn-primary" id="plSave"><i class="fas fa-floppy-disk"></i> Save policy</button><span class="erp-form-msg" id="plMsg"></span></div></div>
    <div id="xRules"></div>
    <div class="erp-card"><h3>Recent security events</h3><div class="sub">Failed sign-ins and blocked requests</div><div class="table-scroll"><table class="data-table"><thead><tr><th>When</th><th>Event</th><th>IP</th></tr></thead><tbody>
      ${st.recent_failed.length ? st.recent_failed.map(r => `<tr><td>${erpEsc(erpFmtDateTime(r.created_at))}</td><td>${erpEsc(r.action_performed)}</td><td class="erp-mono">${erpEsc(r.ip_address || '')}</td></tr>`).join('') : '<tr><td colspan="3"><div class="erp-empty">Nothing to report.</div></td></tr>'}</tbody></table></div></div>`;
  document.getElementById('plSave').addEventListener('click', async e => {
    const g = id => document.getElementById(id), msg = g('plMsg');
    const policy = { min_length: +g('pl_min').value, max_login_attempts: +g('pl_max').value, lock_minutes: +g('pl_lock').value, require_upper: g('pl_up').checked ? 1 : 0, require_lower: g('pl_lo').checked ? 1 : 0, require_number: g('pl_nu').checked ? 1 : 0, require_special: g('pl_sp').checked ? 1 : 0 };
    try { const r = await erpPost('adm_policy_save', { policy }); msg.className = 'erp-form-msg ok'; msg.textContent = r.message; erpToast(r.message); } catch (er) { msg.className = 'erp-form-msg err'; msg.textContent = er.message; erpToast(er.message, 'error'); }
  });
  const rules = document.getElementById('xRules');
  const rerender = () => admSecurityPage(b, s);
  erpListPage({ entity: 'adm_security_rules', title: 'IP Access Rules', sectionLabel: 'Administration', embedded: true, container: rules, rerender, addLabel: 'Add IP Rule',
    banner: '',
    formOpts: { banner: `<div class="erp-banner warn"><i class="fas fa-triangle-exclamation"></i><div>Your current address is <b>${erpEsc(st.your_ip)}</b>. A <b>whitelist</b> allows ONLY the listed addresses to use the CRM (webhooks from lead sources are exempt). The system refuses any rule that would lock you out.</div></div>` } }).then(() => {
    rules.insertAdjacentHTML('afterbegin', '<div class="erp-card" style="margin-bottom:0;border-radius:14px 14px 0 0;padding-bottom:6px"><h3>IP access rules</h3><div class="sub" style="margin-bottom:0">Whitelist = only these addresses may sign in. Blacklist = these addresses are blocked. Supports a single IP, a CIDR range (203.0.113.0/24) or a wildcard (203.0.113.*).</div></div>');
  });
}

/* ---- Users page (existing employee/role assignment) + shortcut to login accounts ---- */
async function admUsersPage(b, s) {
  if (typeof renderUsersPage !== 'function') return admAccountsPage(b, s);
  await renderUsersPage();
  mainContent.insertAdjacentHTML('afterbegin', `<div class="erp-banner info" style="margin-bottom:14px"><i class="fas fa-key"></i><div>This page assigns <b>roles to employees</b>. To create <b>sign-in accounts</b>, suspend a user or reset a password, use Login Accounts.</div><button type="button" class="erp-btn-sm erp-prim" id="admToAcc">Login Accounts</button></div>`);
  document.getElementById('admToAcc').addEventListener('click', () => admAccountsPage(b, s));
}

const ADM_PAGES = {
  'Users': admUsersPage,
  'Roles': async () => { await renderRolesPage(); },
  'Permissions': async () => { if (typeof renderPermissionsPage === 'function') await renderPermissionsPage(); else await renderRolesPage(); },
  'Branch': (b) => renderRichList(RICH_MODULES['Master||Branch'], 'Branch', 'Master', b.fn, b.label),
  'Company Settings': (b, s) => admSettingsPage(b, s, 'Company Settings', ['Company', 'Finance'], { intro: 'Company details and the accounting mapping used by Asset Management. Changes apply immediately across the CRM.' }),
  'Email Settings': (b, s) => admSettingsPage(b, s, 'Email Settings', ['Email'], {
    intro: 'SMTP details used to send email from the CRM. The password is stored encrypted.',
    extraButtons: () => '<button type="button" class="btn-secondary" id="stTest"><i class="fas fa-paper-plane"></i> Send test email</button>',
    after: host => { const t = host.querySelector('#stTest'); if (t) t.addEventListener('click', () => erpDialog({ title: 'Send a test email', okLabel: 'Send', note: 'Uses the <b>saved</b> settings (save first if you changed anything).', fields: [{ k: 'to', l: 'Send to', t: 'email', req: true, def: (window.currentUser || {}).email || '' }], onSubmit: async v => { const r = await erpPost('adm_test_email', { to: v.to }); erpToast(r.message); } })); },
  }),
  'SMS Gateway': (b, s) => admSettingsPage(b, s, 'SMS Gateway', ['SMS'], { intro: 'Credentials for your SMS provider. The default country code is also used to complete 10-digit numbers in Marketing audiences.' }),
  'WhatsApp API': (b, s) => admSettingsPage(b, s, 'WhatsApp Business API', ['WhatsApp'], { intro: 'Business API credentials. The access token is stored encrypted.' }),
  'Payment Gateway': (b, s) => admSettingsPage(b, s, 'Payment Gateway', ['Payment'], { intro: 'Keys for online payments. Secret keys are stored encrypted — use Test mode until you are ready to go live.' }),
  'Backup': admBackupPage,
  'Audit Logs': admAuditPage,
  'Security': admSecurityPage,
};
