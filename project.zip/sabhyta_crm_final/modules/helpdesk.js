/* =========================================================
   HELPDESK MODULE
   Covers every leaf under the "Helpdesk" sidebar section:
   Tickets, Complaints, Support, AMC, Remote Support,
   Priority, SLA, Resolution.
   Backed by real tables via api/helpdesk.php (not the
   generic_records fallback in script.js).
   Shares globals (mainContent, money, statusClass,
   destroyCharts, renderDashboardHome) defined in script.js.
   ========================================================= */

const HELPDESK_ITEM_NAMES = new Set([
  'Tickets', 'Complaints', 'Support', 'AMC', 'Remote Support',
  'Priority', 'SLA', 'Resolution'
]);

const HD_STATUS_OPTIONS = {
  tickets:     ['Open', 'Assigned', 'In Progress', 'Pending', 'Resolved', 'Closed'],
  complaints:  ['New', 'Under Review', 'Assigned', 'Investigation', 'Action Taken', 'Resolved', 'Closed'],
  support:     ['Open', 'In Progress', 'Resolved', 'On Hold'],
  amc:         ['Active', 'Expired'],
  remote:      ['Scheduled', 'In Progress', 'Completed', 'Cancelled'],
};

// ---------------------------------------------------------
// One config object per sidebar leaf. `list` = table columns,
// `form` = create/edit fields. `select-api` fields load their
// options live from another Helpdesk entity.
// ---------------------------------------------------------
const HD_CONFIG = {
  Tickets: {
    entity: 'tickets', title: 'Tickets', codeField: 'ticket_no', statusField: 'ticket_status',
    list: [
      ['ticket_no','Ticket ID'], ['customer_name','Customer'], ['subject','Subject'],
      ['category','Category'], ['priority_name','Priority'], ['assigned_employee','Assigned To'],
      ['ticket_status','Status'], ['due_at','Due'], ['sla_flag','SLA'],
    ],
    form: [
      { k:'customer_name', l:'Customer Name', req:true },
      { k:'contact_person', l:'Contact Person' },
      { k:'contact_number', l:'Contact Number' },
      { k:'email', l:'Email', t:'email' },
      { k:'product_service', l:'Product / Service' },
      { k:'category', l:'Category', t:'select', opt:['Software','Hardware','Network','Website','Other'] },
      { k:'subject', l:'Subject', req:true },
      { k:'description', l:'Description', t:'textarea', full:true },
      { k:'source', l:'Source', t:'select', opt:['Phone','Email','WhatsApp','Website','Portal'] },
      { k:'priority_id', l:'Priority', t:'select-api', ent:'priorities', labelField:'name' },
      { k:'sla_id', l:'SLA', t:'select-api', ent:'sla', labelField:'sla_name' },
      { k:'amc_id', l:'AMC Contract (if covered)', t:'select-api', ent:'amc', labelField:'customer_name' },
      { k:'assigned_department', l:'Assigned Department' },
      { k:'assigned_employee', l:'Assigned Employee' },
      { k:'ticket_status', l:'Status', t:'select', opt:HD_STATUS_OPTIONS.tickets },
      { k:'resolution', l:'Resolution', t:'textarea', full:true },
      { k:'customer_feedback', l:'Customer Feedback' },
    ],
  },
  Complaints: {
    entity: 'complaints', title: 'Complaints', codeField: 'complaint_no', statusField: 'complaint_status',
    list: [
      ['complaint_no','Complaint ID'], ['customer_name','Customer'], ['subject','Subject'],
      ['complaint_type','Type'], ['assigned_employee','Assigned To'], ['escalation_level','Escalation'],
      ['complaint_status','Status'], ['complaint_date','Date'],
    ],
    form: [
      { k:'customer_name', l:'Customer Name', req:true },
      { k:'contact_person', l:'Contact Person' },
      { k:'complaint_date', l:'Complaint Date', t:'date', req:true },
      { k:'complaint_type', l:'Complaint Type' },
      { k:'subject', l:'Complaint Subject', req:true },
      { k:'description', l:'Complaint Description', t:'textarea', full:true },
      { k:'related_ticket_id', l:'Related Ticket', t:'select-api', ent:'tickets', labelField:'ticket_no' },
      { k:'product_service', l:'Product / Service' },
      { k:'complaint_source', l:'Complaint Source', t:'select', opt:['Phone','Email','WhatsApp','Website','Portal'] },
      { k:'priority_id', l:'Priority', t:'select-api', ent:'priorities', labelField:'name' },
      { k:'assigned_employee', l:'Assigned Employee' },
      { k:'department', l:'Department' },
      { k:'expected_resolution_date', l:'Expected Resolution Date', t:'date' },
      { k:'complaint_status', l:'Status', t:'select', opt:HD_STATUS_OPTIONS.complaints },
      { k:'escalation_level', l:'Escalation Level', t:'select', opt:['None','Level 1','Level 2','Level 3'] },
      { k:'resolution', l:'Resolution', t:'textarea', full:true },
      { k:'customer_remarks', l:'Customer Remarks' },
      { k:'created_by', l:'Created By' },
    ],
  },
  Support: {
    entity: 'support', title: 'Support', codeField: 'support_no', statusField: 'support_status',
    list: [
      ['support_no','Support ID'], ['customer_name','Customer'], ['support_type','Type'],
      ['assigned_employee','Engineer'], ['time_spent_minutes','Time (min)'], ['support_status','Status'],
    ],
    form: [
      { k:'ticket_id', l:'Ticket', t:'select-api', ent:'tickets', labelField:'ticket_no', req:true },
      { k:'customer_name', l:'Customer Name' },
      { k:'assigned_employee', l:'Assigned Employee' },
      { k:'support_type', l:'Support Type', t:'select', opt:['Technical Support','Software Support','Hardware Support','Network Support','Website Support','Installation','Configuration','Training','Maintenance','Consultation'] },
      { k:'start_time', l:'Start Date/Time', t:'datetime-local' },
      { k:'end_time', l:'End Date/Time', t:'datetime-local' },
      { k:'work_description', l:'Work Description', t:'textarea', full:true },
      { k:'time_spent_minutes', l:'Time Spent (minutes)', t:'number' },
      { k:'action_taken', l:'Action Taken', t:'textarea', full:true },
      { k:'parts_software_used', l:'Parts / Software Used', dbKey:'parts_used' },
      { k:'internal_remarks', l:'Internal Remarks' },
      { k:'customer_remarks', l:'Customer Remarks' },
      { k:'next_followup_date', l:'Next Follow-up Date', t:'date' },
      { k:'support_status', l:'Status', t:'select', opt:HD_STATUS_OPTIONS.support },
    ],
  },
  AMC: {
    entity: 'amc', title: 'AMC', codeField: 'amc_code', statusField: 'contract_status',
    list: [
      ['amc_code','AMC ID'], ['customer_name','Customer'], ['contract_no','Contract No.'],
      ['start_date','Start'], ['end_date','End'], ['amc_value','Value'],
      ['contract_status','Status'], ['alert','Renewal Alert'],
    ],
    form: [
      { k:'customer_name', l:'Customer', req:true },
      { k:'contract_no', l:'Contract No.' },
      { k:'start_date', l:'Start Date', t:'date', req:true },
      { k:'end_date', l:'End Date', t:'date', req:true },
      { k:'amc_value', l:'AMC Value', t:'number' },
      { k:'billing_frequency', l:'Billing Frequency', t:'select', opt:['Monthly','Quarterly','Annual'] },
      { k:'service_type', l:'Service Type' },
      { k:'covered_products', l:'Covered Products', full:true },
      { k:'support_hours', l:'Support Hours' },
      { k:'visit_included', l:'Visit Included', t:'select', opt:['Yes','No'], boolField:true },
      { k:'remote_support', l:'Remote Support', t:'select', opt:['Yes','No'], boolField:true },
      { k:'onsite_support', l:'On-site Support', t:'select', opt:['Yes','No'], boolField:true },
      { k:'number_of_visits', l:'Number of Visits', t:'number' },
      { k:'sla_id', l:'SLA', t:'select-api', ent:'sla', labelField:'sla_name' },
      { k:'assigned_team', l:'Assigned Team' },
      { k:'contract_status', l:'Contract Status', t:'select', opt:HD_STATUS_OPTIONS.amc },
      { k:'renewal_date', l:'Renewal Date', t:'date' },
    ],
  },
  'Remote Support': {
    entity: 'remote', title: 'Remote Support', codeField: 'session_no', statusField: 'session_status',
    list: [
      ['session_no','Session ID'], ['customer_name','Customer'], ['support_engineer','Engineer'],
      ['remote_tool','Tool'], ['duration_minutes','Duration (min)'], ['session_status','Status'],
    ],
    form: [
      { k:'ticket_id', l:'Ticket', t:'select-api', ent:'tickets', labelField:'ticket_no', req:true },
      { k:'customer_name', l:'Customer Name' },
      { k:'contact_person', l:'Contact Person' },
      { k:'support_engineer', l:'Support Engineer' },
      { k:'remote_tool', l:'Remote Tool', t:'select', opt:['AnyDesk','TeamViewer','Chrome Remote Desktop','Phone Walkthrough','Other'] },
      { k:'start_time', l:'Session Start Time', t:'datetime-local' },
      { k:'end_time', l:'Session End Time', t:'datetime-local' },
      { k:'duration_minutes', l:'Duration (minutes)', t:'number' },
      { k:'customer_permission', l:'Customer Permission Given', t:'select', opt:['Yes','No'], boolField:true },
      { k:'problem_description', l:'Problem Description', t:'textarea', full:true },
      { k:'action_taken', l:'Action Taken', t:'textarea', full:true },
      { k:'files_transferred', l:'Files Transferred' },
      { k:'resolution', l:'Resolution', t:'textarea', full:true },
      { k:'customer_confirmation', l:'Customer Confirmation', t:'select', opt:['Yes','No'], boolField:true },
      { k:'session_status', l:'Session Status', t:'select', opt:HD_STATUS_OPTIONS.remote },
    ],
  },
  Priority: {
    entity: 'priorities', title: 'Priority', codeField: 'name', statusField: 'status',
    list: [
      ['name','Priority'], ['response_minutes','Response (min)'], ['resolution_minutes','Resolution (min)'], ['status','Status'],
    ],
    form: [
      { k:'name', l:'Priority Name', req:true },
      { k:'response_minutes', l:'Response Time (minutes)', t:'number', req:true },
      { k:'resolution_minutes', l:'Resolution Time (minutes)', t:'number', req:true },
      { k:'sort_order', l:'Sort Order', t:'number' },
      { k:'status', l:'Status', t:'select', opt:['Active','Inactive'] },
    ],
  },
  SLA: {
    entity: 'sla', title: 'SLA', codeField: 'sla_code', statusField: 'status',
    list: [
      ['sla_code','SLA ID'], ['sla_name','Name'], ['customer_type','Customer Type'],
      ['response_minutes','Response (min)'], ['resolution_minutes','Resolution (min)'], ['status','Status'],
    ],
    form: [
      { k:'sla_name', l:'SLA Name', req:true },
      { k:'customer_type', l:'Customer Type', t:'select', opt:['Premium','Standard','Basic'] },
      { k:'priority_id', l:'Priority', t:'select-api', ent:'priorities', labelField:'name' },
      { k:'response_minutes', l:'Response Time (minutes)', t:'number', req:true },
      { k:'resolution_minutes', l:'Resolution Time (minutes)', t:'number', req:true },
      { k:'working_hours', l:'Working Hours' },
      { k:'working_days', l:'Working Days' },
      { k:'escalation_level1', l:'Escalation Level 1' },
      { k:'escalation_level2', l:'Escalation Level 2' },
      { k:'escalation_level3', l:'Escalation Level 3' },
      { k:'status', l:'Status', t:'select', opt:['Active','Inactive'] },
    ],
  },
  Resolution: {
    entity: 'resolutions', title: 'Resolution', codeField: 'resolution_no', statusField: null,
    list: [
      ['resolution_no','Resolution ID'], ['customer_name','Customer'], ['technician','Technician'],
      ['total_time_minutes','Total Time (min)'], ['customer_rating','Rating'], ['resolution_date','Date'],
    ],
    form: [
      { k:'ticket_id', l:'Ticket', t:'select-api', ent:'tickets', labelField:'ticket_no', req:true },
      { k:'customer_name', l:'Customer Name' },
      { k:'problem_summary', l:'Problem Summary', t:'textarea', full:true },
      { k:'root_cause', l:'Root Cause', t:'textarea', full:true },
      { k:'troubleshooting', l:'Troubleshooting Performed', t:'textarea', full:true },
      { k:'action_taken', l:'Action Taken', t:'textarea', full:true },
      { k:'final_solution', l:'Final Solution', t:'textarea', full:true },
      { k:'technician', l:'Technician / Engineer' },
      { k:'start_time', l:'Start Time', t:'datetime-local' },
      { k:'end_time', l:'End Time', t:'datetime-local' },
      { k:'total_time_minutes', l:'Total Time (minutes)', t:'number' },
      { k:'parts_used', l:'Parts / Software Used' },
      { k:'kb_article', l:'Knowledge Base Article' },
      { k:'customer_confirmation', l:'Customer Confirmation', t:'select', opt:['Yes','No'], boolField:true },
      { k:'customer_rating', l:'Customer Rating (1-5)', t:'number' },
      { k:'resolution_date', l:'Resolution Date', t:'date' },
      { k:'closed_by', l:'Closed By' },
    ],
  },
};

function routeHelpdeskLeaf(itemLabel, sectionLabel, backAction, backLabel) {
  if (!HELPDESK_ITEM_NAMES.has(itemLabel)) return false;
  const back = backAction || (() => renderDashboardHome());
  const backTo = backLabel || 'Dashboard';
  renderHdListPage(HD_CONFIG[itemLabel], sectionLabel, back, backTo);
  return true;
}

/* ---------------------------------------------------------
   Small shared helpers: toast, escaping, api call
   --------------------------------------------------------- */
function hdEsc(v) {
  if (v === null || v === undefined) return '';
  return String(v).replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}

function hdToast(message, type = 'success') {
  let host = document.getElementById('hdToastHost');
  if (!host) {
    host = document.createElement('div');
    host.id = 'hdToastHost';
    host.style.cssText = 'position:fixed;top:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:8px;';
    document.body.appendChild(host);
  }
  const el = document.createElement('div');
  el.textContent = message;
  el.style.cssText = `padding:11px 16px;border-radius:8px;font-size:.85rem;font-weight:600;color:#fff;
    box-shadow:0 8px 24px rgba(15,23,42,.18);background:${type === 'error' ? '#d3312f' : '#16a34a'};max-width:320px;`;
  host.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

async function hdApi(path, opts = {}) {
  const res = await fetch(`api/helpdesk.php${path}`, opts);
  const json = await res.json();
  if (!json.success) throw new Error(json.message || 'Request failed');
  return json.data;
}

function hdFmtCell(key, val) {
  if (val === null || val === undefined || val === '') return '';
  if (key === 'sla_flag') {
    const cls = val === 'Breached' ? 'status-cancelled' : (val === 'Nearing Breach' ? 'status-pending' : 'status-active');
    return `<span class="status-chip ${cls}">${hdEsc(val)}</span>`;
  }
  if (key.endsWith('_status') || key === 'alert') {
    const cls = /breach|expired|cancel/i.test(val) ? 'status-cancelled' : statusClass(String(val));
    return `<span class="status-chip ${cls}">${hdEsc(val)}</span>`;
  }
  if (key === 'amc_value') return money(val);
  if ((key === 'due_at' || key.endsWith('_at')) && val) return hdEsc(String(val).replace('T',' ').slice(0,16));
  return hdEsc(val);
}

/* ---------------------------------------------------------
   LIST PAGE (config-driven, one function for all 8 leaves)
   --------------------------------------------------------- */
async function renderHdListPage(cfg, sectionLabel, backAction, backLabel) {
  destroyCharts();

  const kpiHtml = cfg.entity === 'tickets' ? `<div class="stat-grid" id="hdKpiGrid"><div class="stat-card"><div class="stat-label">Loading…</div></div></div>` : '';

  mainContent.innerHTML = `
    <button class="back-btn" id="hdBackBtn"><i class="fas fa-arrow-left"></i> Back to ${backLabel}</button>
    <div class="eyebrow">${sectionLabel} <span class="crumb-sep">/</span> <span class="crumb-current">${cfg.title}</span></div>
    <div class="page-title">
      <span>${cfg.title}</span>
      <div class="actions">
        <button class="btn btn-primary" id="hdAddBtn"><i class="fas fa-plus"></i> Add New</button>
      </div>
    </div>
    ${kpiHtml}
    <div class="table-panel">
      <div class="panel-head"><div><div class="panel-title">${cfg.title}</div><div class="panel-sub">Live records from the database</div></div></div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr>${cfg.list.map(c => `<th>${c[1]}</th>`).join('')}<th>Actions</th></tr></thead>
          <tbody id="hdTableBody"><tr><td colspan="${cfg.list.length + 1}">Loading…</td></tr></tbody>
        </table>
      </div>
    </div>
  `;

  document.getElementById('hdBackBtn').addEventListener('click', backAction);
  document.getElementById('hdAddBtn').addEventListener('click', () =>
    renderHdForm(cfg, sectionLabel, () => renderHdListPage(cfg, sectionLabel, backAction, backLabel), backAction, backLabel));

  if (cfg.entity === 'tickets') loadHdKpis();

  const tbody = document.getElementById('hdTableBody');
  try {
    const rows = await hdApi(`?action=${cfg.entity}_list`);
    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="${cfg.list.length + 1}">No records yet. Click "Add New" to create one.</td></tr>`;
      return;
    }
    tbody.innerHTML = rows.map(r => `
      <tr>
        ${cfg.list.map(c => `<td>${hdFmtCell(c[0], r[c[0]])}</td>`).join('')}
        <td>
          <button type="button" class="btn-secondary hd-edit-btn" data-id="${r.id}">Edit</button>
          <button type="button" class="btn-secondary hd-del-btn" data-id="${r.id}">Delete</button>
        </td>
      </tr>
    `).join('');

    tbody.querySelectorAll('.hd-edit-btn').forEach(btn => {
      btn.addEventListener('click', () =>
        renderHdForm(cfg, sectionLabel, () => renderHdListPage(cfg, sectionLabel, backAction, backLabel), backAction, backLabel, btn.dataset.id));
    });
    tbody.querySelectorAll('.hd-del-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        if (!confirm('Delete this record?')) return;
        try {
          await hdApi(`?action=${cfg.entity}_delete&id=${btn.dataset.id}`, { method: 'POST' });
          hdToast('Deleted');
          renderHdListPage(cfg, sectionLabel, backAction, backLabel);
        } catch (err) { hdToast('Delete failed: ' + err.message, 'error'); }
      });
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="${cfg.list.length + 1}">Failed to load: ${err.message}</td></tr>`;
  }
}

async function loadHdKpis() {
  const grid = document.getElementById('hdKpiGrid');
  if (!grid) return;
  try {
    const d = await hdApi('?action=dashboard');
    grid.innerHTML = `
      <div class="stat-card" style="--stat-accent:#ff6b4a"><div class="stat-label"><i class="fas fa-ticket"></i> Open Tickets</div><div class="stat-value">${d.open_tickets}</div></div>
      <div class="stat-card" style="--stat-accent:#e08c1c"><div class="stat-label"><i class="fas fa-spinner"></i> In Progress</div><div class="stat-value">${d.in_progress}</div></div>
      <div class="stat-card" style="--stat-accent:#16a34a"><div class="stat-label"><i class="fas fa-circle-check"></i> Resolved</div><div class="stat-value">${d.resolved}</div></div>
      <div class="stat-card" style="--stat-accent:#e0384c"><div class="stat-label"><i class="fas fa-triangle-exclamation"></i> SLA Breached</div><div class="stat-value">${d.sla_breached}</div></div>
      <div class="stat-card" style="--stat-accent:#7c5cff"><div class="stat-label"><i class="fas fa-file-contract"></i> AMC Expiring (90d)</div><div class="stat-value">${d.amc_expiring}</div></div>
    `;
  } catch (err) {
    grid.innerHTML = `<div class="stat-card"><div class="stat-label">Could not load KPIs</div></div>`;
  }
}

/* ---------------------------------------------------------
   FORM PAGE (config-driven, create + edit)
   --------------------------------------------------------- */
async function renderHdForm(cfg, sectionLabel, backToList, backAction, backLabel, editId = null) {
  destroyCharts();

  mainContent.innerHTML = `
    <div class="page-header">
      <h2>${editId ? 'Edit' : 'Add New'} — ${cfg.title}</h2>
      <p>${sectionLabel}</p>
      <button type="button" class="btn-secondary" id="hdBackToListBtn" style="margin-top:10px;">
        <i class="fas fa-arrow-left"></i> Back to List
      </button>
    </div>
    <form id="hdForm">
      <div class="form-card">
        <div class="card-title"><h3>Details</h3></div>
        <div class="form-grid" id="hdFormGrid">Loading form…</div>
      </div>
      <div class="form-actions">
        <button type="submit" class="btn-primary" id="hdSaveBtn">${editId ? 'Update' : 'Save'}</button>
        <button type="reset" class="btn-secondary">Clear</button>
        <span id="hdStatusMsg" style="margin-left:14px;font-size:14px;"></span>
      </div>
    </form>
  `;

  document.getElementById('hdBackToListBtn').addEventListener('click', backToList);

  // Pre-load any select-api dropdown source lists in parallel.
  const apiEntities = [...new Set(cfg.form.filter(f => f.t === 'select-api').map(f => f.ent))];
  const optionSets = {};
  await Promise.all(apiEntities.map(async ent => {
    try { optionSets[ent] = await hdApi(`?action=${ent}_list`); }
    catch (e) { optionSets[ent] = []; }
  }));

  let record = {};
  if (editId) {
    try { record = await hdApi(`?action=${cfg.entity}_get&id=${editId}`); }
    catch (e) { hdToast('Could not load record: ' + e.message, 'error'); }
  }

  const grid = document.getElementById('hdFormGrid');
  grid.innerHTML = cfg.form.map(f => {
    const dbKey = f.dbKey || f.k;
    const raw = record[dbKey];
    const id = 'hd_' + dbKey;
    const label = `<label>${f.l}${f.req ? ' *' : ''}</label>`;
    let input;

    if (f.t === 'textarea') {
      input = `<textarea rows="3" id="${id}" ${f.req ? 'required' : ''}>${hdEsc(raw)}</textarea>`;
    } else if (f.t === 'select') {
      const value = f.boolField ? (raw == 1 ? 'Yes' : (raw == 0 ? 'No' : '')) : (raw ?? '');
      input = `<select id="${id}" ${f.req ? 'required' : ''}>
        <option value="">-- Select --</option>
        ${f.opt.map(o => `<option value="${hdEsc(o)}" ${String(value) === o ? 'selected' : ''}>${hdEsc(o)}</option>`).join('')}
      </select>`;
    } else if (f.t === 'select-api') {
      const opts = optionSets[f.ent] || [];
      input = `<select id="${id}" ${f.req ? 'required' : ''}>
        <option value="">-- Select --</option>
        ${opts.map(o => `<option value="${o.id}" ${String(raw) === String(o.id) ? 'selected' : ''}>${hdEsc(o[f.labelField])}</option>`).join('')}
      </select>`;
    } else {
      const type = f.t || 'text';
      const value = type === 'datetime-local' && raw ? String(raw).replace(' ', 'T').slice(0,16) : (raw ?? '');
      input = `<input type="${type}" id="${id}" value="${hdEsc(value)}" ${f.req ? 'required' : ''}>`;
    }

    return `<div class="form-group${f.full ? ' full-width' : ''}">${label}${input}</div>`;
  }).join('');

  document.getElementById('hdForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const msg = document.getElementById('hdStatusMsg');
    const payload = {};
    cfg.form.forEach(f => {
      const dbKey = f.dbKey || f.k;
      const el = document.getElementById('hd_' + dbKey);
      if (!el) return;
      let v = el.value;
      if (f.boolField) v = v === 'Yes' ? 1 : (v === 'No' ? 0 : null);
      if (f.t === 'datetime-local' && v) v = v.replace('T', ' ') + ':00';
      payload[dbKey] = v;
    });

    try {
      msg.textContent = 'Saving…'; msg.style.color = '#8f97a8';
      const action = editId ? `${cfg.entity}_update&id=${editId}` : `${cfg.entity}_create`;
      await hdApi(`?action=${action}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      hdToast(editId ? 'Updated successfully' : 'Saved successfully');
      backToList();
    } catch (err) {
      msg.textContent = 'Error: ' + err.message; msg.style.color = '#d3312f';
      hdToast('Save failed: ' + err.message, 'error');
    }
  });
}
