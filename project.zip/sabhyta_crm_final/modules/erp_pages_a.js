/* =========================================================
   ERP PAGES - part A
   Router + Marketing + Project Management
   ========================================================= */

/* ---------------------------------------------------------
   Router (called from script.js dispatchLeaf)
   --------------------------------------------------------- */
function routeErpLeaf(item, section, backAction, backLabel) {
  const back = { fn: backAction, label: backLabel };
  let handler = null, crumb = section;
  if ((section === 'CRM' || section === 'Marketing') && MK_PAGES[item]) { handler = MK_PAGES[item]; crumb = 'Marketing'; }
  else if (section === 'Project Management' && PM_PAGES[item]) handler = PM_PAGES[item];
  else if (section === 'Asset Management' && AM_PAGES[item]) handler = AM_PAGES[item];
  else if (section === 'Document Management' && DM_PAGES[item]) handler = DM_PAGES[item];
  else if (section === 'Administration' && ADM_PAGES[item]) handler = ADM_PAGES[item];
  if (!handler) return false;
  destroyCharts();
  Promise.resolve().then(() => handler(back, crumb)).catch(e => {
    mainContent.innerHTML = `<button type="button" class="back-btn" id="erpBackErr"><i class="fas fa-arrow-left"></i> Back to ${erpEsc(backLabel)}</button>${erpErrorBox(e)}`;
    const b = document.getElementById('erpBackErr'); if (b) b.addEventListener('click', backAction);
  });
  return true;
}

/** Fetch the number of records for an entity under optional filters (cheap: per=1) */
async function erpCount(entity, filters = {}) {
  const p = { entity, per: 1, page: 1 };
  Object.entries(filters).forEach(([k, v]) => p['f_' + k] = v);
  return (await erpGet('list', p)).total || 0;
}
async function erpOverviewCounts(sectionLabel, keyLabel) {
  try {
    const all = (await erpGet('overview')).data;
    return all[sectionLabel] || all[keyLabel] || null;
  } catch (e) { return null; }
}
async function erpFileToCsv(file) {
  if (/\.xlsx?$/i.test(file.name) && window.XLSX) {
    const wb = XLSX.read(await file.arrayBuffer(), { type: 'array' });
    const csv = XLSX.utils.sheet_to_csv(wb.Sheets[wb.SheetNames[0]]);
    return new File([csv], file.name.replace(/\.xlsx?$/i, '.csv'), { type: 'text/csv' });
  }
  return file;
}
function erpSampleCsvLink(name, text) {
  return `<a class="erp-link" download="${name}" href="data:text/csv;charset=utf-8,${encodeURIComponent(text)}">Download a sample file</a>`;
}
function erpChartColors() { return ['#ff6b4a', '#3556d6', '#16a34a', '#7c5cff', '#e08c1c', '#14b8a6', '#e0384c', '#8f97a8']; }
function erpMakeChart(canvasId, config) {
  const el = document.getElementById(canvasId);
  if (!el || typeof Chart === 'undefined') return null;
  const c = new Chart(el, Object.assign({ options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } } }, config));
  if (typeof activeCharts !== 'undefined') activeCharts.push(c);
  return c;
}

/* =========================================================
   MARKETING
   ========================================================= */
function mkCampaignActions(entity, channel) {
  const setStatus = (status, msg) => async (r, ctx) => {
    if (!await erpConfirm(msg || `Change this campaign to ${status}?`, { okLabel: status })) return;
    const res = await erpPost('mk_set_status', { entity, id: r.id, status });
    erpToast(res.message); ctx.reload();
  };
  return r => [
    { label: 'Launch', icon: 'fa-rocket', cls: 'erp-go', show: ['Draft', 'Scheduled'].includes(r.status), onClick: async (row, ctx) => {
      if (!await erpConfirm(channel === 'Social' ? 'Mark this post / ad as live (Running or Scheduled)?' : 'Run the launch checks and resolve the recipient list now? Opted-out, unsubscribed and suppressed contacts are excluded automatically.', { okLabel: 'Launch' })) return;
      const res = await erpPost('mk_launch', { entity, id: row.id });
      erpToast(res.message, 'success'); ctx.reload();
    } },
    { label: 'Resume', show: r.status === 'Paused', cls: 'erp-go', onClick: setStatus('Running') },
    { label: 'Pause', show: r.status === 'Running', cls: 'erp-warn', onClick: setStatus('Paused') },
    { label: 'Complete', show: r.status === 'Running', onClick: setStatus('Completed', 'Mark this campaign as completed? Add its results under Campaign Analytics > Performance Data.') },
    { label: 'Recipients', icon: 'fa-file-export', title: 'Download the eligible recipient list (CSV) to upload to your platform', show: channel !== 'Social' && !!r.list_id && r.status !== 'Draft' || (channel !== 'Social' && !!r.list_id), onClick: row => erpDownload(erpUrl('mk_export_recipients', { entity, id: row.id })) },
    { label: 'Cancel', cls: 'erp-danger', show: ['Draft', 'Scheduled', 'Running', 'Paused'].includes(r.status) && r.status !== 'Draft', onClick: setStatus('Cancelled') },
  ];
}

function mkAudiencePage(channel, host, rerender, b) {
  return erpListPage({
    entity: 'mk_audience_lists', title: channel + ' Audience Lists', sectionLabel: 'Marketing', embedded: true, container: host,
    fixed: { channel }, rerender, addLabel: 'New List',
    banner: '',
    rowActions: r => [
      { label: 'Contacts', icon: 'fa-address-book', onClick: row => mkContactsPage(row, rerender) },
      { label: 'Import CSV', icon: 'fa-file-csv', onClick: row => mkImportDialog(row, rerender) },
      { label: 'From CRM', icon: 'fa-database', title: 'Add customers or leads from the CRM', onClick: row => mkBuildDialog(row, rerender) },
    ],
  });
}
function mkContactsPage(list, backToLists) {
  return erpListPage({
    entity: 'mk_audience_contacts', title: list.list_name + ' — Contacts', sectionLabel: 'Marketing / ' + list.channel + ' Audience', fixed: { list_id: list.id },
    back: { fn: backToLists, label: 'Audience Lists' }, addLabel: 'Add Contact',
    columns: [['full_name', 'Name'], ['email', 'Email'], ['phone', 'Phone'], ['city', 'City'], ['opt_in', 'Opted In', 'bool'], ['opt_in_at', 'Opt-in Time', 'datetime'], ['whatsapp_verified', 'WA Verified', 'bool'], ['status', 'Status', 'chip']],
    filters: ['status'], rerender: () => mkContactsPage(list, backToLists),
    toolbar: [{ label: 'Import CSV', icon: 'fa-file-csv', onClick: () => mkImportDialog(list, () => mkContactsPage(list, backToLists)) }],
  });
}
function mkImportDialog(list, after) {
  return erpDialog({
    title: 'Import contacts into “' + list.list_name + '”', okLabel: 'Import', wide: false,
    note: `Upload a <b>.csv</b> or <b>.xlsx</b> file with a header row. Recognised columns: <code>name, email, phone, city, state, country, opt_in, whatsapp_verified</code>. 10-digit numbers get the default country code. ${erpSampleCsvLink('contacts_sample.csv', 'name,email,phone,city,opt_in\nAsha Rao,asha@example.com,9876543210,Pune,yes\n')}`,
    fields: [
      { k: 'file', l: 'File', t: 'file', req: true, accept: '.csv,.txt,.xlsx,.xls' },
      { k: 'consent', l: 'I confirm these contacts have given consent to receive marketing messages.', t: 'checkbox', req: true },
    ],
    onSubmit: async v => {
      const file = await erpFileToCsv(v.file);
      const res = await erpPost('mk_import_contacts', { list_id: list.id, consent: 1, file });
      erpToast(res.message);
      if (res.data.invalid_samples && res.data.invalid_samples.length) erpToast('Skipped: ' + res.data.invalid_samples.join('; '), 'warn');
      erpClearLookups(); after();
    },
  });
}
function mkBuildDialog(list, after) {
  return erpDialog({
    title: 'Add CRM contacts to “' + list.list_name + '”',
    note: `Pulls contacts from the CRM that have an ${list.channel === 'Email' ? 'email address' : 'phone number'}. Duplicates are skipped.`,
    fields: [
      { k: 'source', l: 'Source', t: 'select', opts: ['Customers', 'Leads'], req: true, def: 'Customers' },
      { k: 'status', l: 'Only with status (optional)', t: 'text', ph: 'e.g. Active' },
      { k: 'city', l: 'Only in city (optional)', t: 'text' },
      ...(list.channel === 'WhatsApp' ? [{ k: 'wa_verified', l: 'These numbers are verified WhatsApp accounts', t: 'checkbox' }] : []),
      { k: 'consent', l: 'I have permission to market to these contacts.', t: 'checkbox', req: true },
    ],
    onSubmit: async v => { const res = await erpPost('mk_build_list', Object.assign({ list_id: list.id }, v)); erpToast(res.message); erpClearLookups(); after(); },
  });
}
function mkSuppressionPage(host, rerender) {
  return erpListPage({ entity: 'mk_suppression', title: 'Suppression List', sectionLabel: 'Marketing', embedded: true, container: host, rerender, addLabel: 'Add to Suppression' });
}

async function mkSpamCheckDialog(api) {
  const v = api.values();
  const res = await erpPost('mk_spam_check', v);
  const d = res.data;
  api.set('spam_score', d.score);
  const colour = d.score < 3 ? '#16a34a' : d.score <= 5 ? '#c77a0b' : '#d3312f';
  erpModal({
    title: 'Spam check result', body: `
      <div style="display:flex;align-items:center;gap:16px;margin-bottom:14px">
        <div style="font-size:2.2rem;font-weight:800;color:${colour}">${d.score}<span style="font-size:1rem;color:#8a93a6"> / 10</span></div>
        <div><div style="font-weight:800;color:${colour}">${erpEsc(d.verdict)}</div><div class="erp-muted" style="font-size:.78rem">0 = clean · the score has been filled into the form</div></div></div>
      ${d.issues.length ? `<h4 style="margin:10px 0 6px;font-size:.85rem">Fix these</h4><ul style="margin:0;padding-left:18px;font-size:.85rem;line-height:1.6">${d.issues.map(i => `<li>${erpEsc(i.text)} <span class="erp-muted">(+${i.points})</span></li>`).join('')}</ul>` : ''}
      ${d.passed.length ? `<h4 style="margin:14px 0 6px;font-size:.85rem">Looks good</h4><ul style="margin:0;padding-left:18px;font-size:.85rem;color:#117a36;line-height:1.6">${d.passed.map(i => `<li>${erpEsc(i)}</li>`).join('')}</ul>` : ''}`,
    footer: [{ label: 'Close', cls: 'btn-primary', onClick: a => a.close() }],
  });
}

function mkChannelPage(channel) {
  const cfgs = {
    Email: { entity: 'mk_email_campaigns', title: 'Email Campaign' },
    SMS: { entity: 'mk_sms_campaigns', title: 'SMS Campaign' },
    WhatsApp: { entity: 'mk_whatsapp_campaigns', title: 'WhatsApp Campaign' },
    Social: { entity: 'mk_social_campaigns', title: 'Social Media' },
  };
  return (b, crumb) => {
    const c = cfgs[channel];
    const tabs = [{
      key: 'campaigns', label: channel === 'Social' ? 'Posts & Ads' : 'Campaigns',
      render: (host, rerender) => erpListPage({
        entity: c.entity, title: c.title, sectionLabel: crumb, embedded: true, container: host, rerender,
        addLabel: channel === 'Social' ? 'New Post / Ad' : 'New Campaign',
        rowActions: mkCampaignActions(c.entity, channel),
        canDelete: r => r.status !== 'Running',
        kpis: async () => {
          const [d, s, r, cdone] = await Promise.all([erpCount(c.entity, { status: 'Draft' }), erpCount(c.entity, { status: 'Scheduled' }), erpCount(c.entity, { status: 'Running' }), erpCount(c.entity, { status: 'Completed' })]);
          return [{ l: 'Draft', v: d, c: '#8f97a8' }, { l: 'Scheduled', v: s, c: '#e08c1c' }, { l: 'Running', v: r, c: '#16a34a' }, { l: 'Completed', v: cdone, c: '#3556d6' }];
        },
        formOpts: {
          extra: channel === 'Email' ? [{ label: 'Run Spam Check', icon: 'fa-shield-halved', onClick: api => mkSpamCheckDialog(api).catch(e => erpToast(e.message, 'error')) }] : [],
          afterRender: channel === 'SMS' ? (cont, api, h) => {
            const ta = h.el('message_text'); if (!ta) return;
            const note = document.createElement('div'); note.className = 'erp-help'; note.style.fontWeight = '700'; ta.after(note);
            const upd = () => { const t = ta.value, uni = /[^\x00-\x7F]/.test(t), n = t.length, seg = n === 0 ? 1 : (n <= (uni ? 70 : 160) ? 1 : Math.ceil(n / (uni ? 67 : 153))); note.textContent = `${n} characters · ${seg} SMS segment${seg > 1 ? 's' : ''}${uni ? ' (contains non-English characters)' : ''}`; note.style.color = seg > 1 ? '#c77a0b' : '#16a34a'; };
            ta.addEventListener('input', upd); upd();
          } : undefined,
        },
      }),
    }];
    if (channel !== 'Social') tabs.push({ key: 'audience', label: 'Audience Lists', render: (host, rerender) => mkAudiencePage(channel, host, rerender, b) });
    else tabs.push({ key: 'personas', label: 'Audience Personas', render: (host, rerender) => erpListPage({ entity: 'mk_social_audiences', title: 'Audience Personas', sectionLabel: crumb, embedded: true, container: host, rerender, addLabel: 'New Persona' }) });
    if (channel === 'WhatsApp') tabs.push({ key: 'flows', label: 'Auto-reply Flows', render: (host, rerender) => erpListPage({ entity: 'mk_wa_flows', title: 'Auto-reply Flows', sectionLabel: crumb, embedded: true, container: host, rerender, addLabel: 'New Flow' }) });
    if (channel !== 'Social') tabs.push({ key: 'suppress', label: 'Suppression List', render: (host, rerender) => erpListPage({ entity: 'mk_suppression', title: 'Suppression List', sectionLabel: crumb, embedded: true, container: host, rerender, fixed: { channel }, addLabel: 'Add to Suppression' }) });
    const guide = {
      Email: 'Build the audience, write the content, set the sender and UTM tracking, run the spam check, then launch. Export the resolved recipients to your email service provider.',
      SMS: 'Keep each message to 160 characters per segment, use an approved Sender ID, and register the DLT template. Opted-out numbers are excluded automatically.',
      WhatsApp: 'Templates must be approved by WhatsApp before launch. Only contacts with a verified WhatsApp number and a recorded opt-in time receive messages.',
      Social: 'Plan posts and ads with their audience persona, creative, budget and bidding strategy. Credentials are stored encrypted.',
    }[channel];
    erpTabsPage({ id: 'mk_' + channel, title: c.title, sectionLabel: crumb, back: b, tabs, banner: `<div class="erp-banner info"><i class="fas fa-circle-info"></i><div>${guide}</div></div>` });
  };
}

/* ---- Campaign Analytics ---- */
function mkAnalyticsPage(b, crumb) {
  erpTabsPage({
    id: 'mk_analytics', title: 'Campaign Analytics', sectionLabel: crumb, back: b,
    tabs: [
      { key: 'dash', label: 'Dashboard', render: host => mkAnalyticsDashboard(host) },
      { key: 'perf', label: 'Performance Data', render: (host, rerender) => erpListPage({
        entity: 'mk_performance', title: 'Performance Data', sectionLabel: crumb, embedded: true, container: host, rerender, addLabel: 'Add Results',
        toolbar: [{ label: 'Import CSV', icon: 'fa-file-csv', onClick: () => erpDialog({
          title: 'Import performance export', okLabel: 'Import',
          note: `Export the results from your email provider, SMS gateway, WhatsApp Business API or ad platform and upload the file. Required columns: <code>channel, campaign_name</code>. Optional: <code>period_start, period_end, sent, delivered, opens, clicks, conversions, unsubscribes, bounces, impressions, spend, revenue</code>. ${erpSampleCsvLink('performance_sample.csv', 'channel,campaign_name,period_start,period_end,sent,delivered,opens,clicks,conversions,spend,revenue\nEmail,Diwali Sale,2026-09-01,2026-09-30,1000,980,300,90,12,2000,24000\n')}`,
          fields: [{ k: 'file', l: 'CSV / Excel file', t: 'file', req: true, accept: '.csv,.txt,.xlsx,.xls' }],
          onSubmit: async v => { const res = await erpPost('mk_import_performance', { file: await erpFileToCsv(v.file) }); erpToast(res.message); rerender(); },
        }) }],
      }) },
      { key: 'utm', label: 'UTM Master', render: (host, rerender) => erpListPage({ entity: 'mk_utm_links', title: 'UTM Master List', sectionLabel: crumb, embedded: true, container: host, rerender, addLabel: 'New UTM Link',
        rowActions: r => [{ label: 'Copy', icon: 'fa-copy', onClick: row => { navigator.clipboard.writeText(row.generated_url).then(() => erpToast('Link copied')).catch(() => erpToast(row.generated_url, 'info')); } }] }) },
      { key: 'ab', label: 'A/B Tests', render: (host, rerender) => erpListPage({ entity: 'mk_ab_tests', title: 'A/B Tests', sectionLabel: crumb, embedded: true, container: host, rerender, addLabel: 'New A/B Test' }) },
    ],
  });
}
async function mkAnalyticsDashboard(host) {
  host.innerHTML = '<div class="erp-empty"><i class="fas fa-spinner fa-spin"></i>Loading analytics…</div>';
  let channel = '';
  const draw = async () => {
    const d = (await erpGet('mk_analytics', { channel })).data;
    const t = d.totals, n = x => x === null || x === undefined ? '—' : x;
    const camp = d.campaigns;
    host.innerHTML = `
      <div style="display:flex;gap:10px;align-items:center;margin-bottom:14px;flex-wrap:wrap">
        <label style="font-weight:700;font-size:.82rem">Channel</label>
        <select class="erp-filter" id="mkAnCh"><option value="">All channels</option>${['Email', 'SMS', 'WhatsApp', 'Social'].map(c => `<option ${c === channel ? 'selected' : ''}>${c}</option>`).join('')}</select>
        <span class="erp-muted" style="font-size:.78rem">Benchmarks below are calculated from every result you have stored, so each campaign is compared against your own history.</span>
      </div>
      <div class="erp-kpis">
        <div class="erp-kpi"><div class="l">Sent</div><div class="v">${t.sent.toLocaleString('en-IN')}</div><div class="s">${t.delivered.toLocaleString('en-IN')} delivered</div></div>
        <div class="erp-kpi" style="--c:#16a34a"><div class="l">Open rate</div><div class="v">${n(t.open_rate)}${t.open_rate !== null ? '%' : ''}</div></div>
        <div class="erp-kpi" style="--c:#3556d6"><div class="l">Click-through</div><div class="v">${n(t.ctr)}${t.ctr !== null ? '%' : ''}</div><div class="s">${t.clicks.toLocaleString('en-IN')} clicks</div></div>
        <div class="erp-kpi" style="--c:#7c5cff"><div class="l">Conversions</div><div class="v">${t.conversions.toLocaleString('en-IN')}</div><div class="s">${n(t.conv_rate)}${t.conv_rate !== null ? '% of clicks' : ''}</div></div>
        <div class="erp-kpi" style="--c:#e08c1c"><div class="l">Cost per click</div><div class="v">${t.cpc !== null ? erpMoney(t.cpc) : '—'}</div><div class="s">Spend ${erpMoney(t.spend)}</div></div>
        <div class="erp-kpi" style="--c:#14b8a6"><div class="l">Revenue</div><div class="v">${erpMoney(t.revenue)}</div></div>
        <div class="erp-kpi" style="--c:#e0384c"><div class="l">ROAS</div><div class="v">${n(t.roas)}${t.roas !== null ? '×' : ''}</div><div class="s">return on ad spend</div></div>
        <div class="erp-kpi" style="--c:#8f97a8"><div class="l">Reachable contacts</div><div class="v">${Number(d.audience.reachable).toLocaleString('en-IN')}</div><div class="s">${d.audience.suppressed} suppressed · ${d.audience.utm_links} UTM links</div></div>
      </div>
      ${t.records === 0 ? `<div class="erp-banner warn"><i class="fas fa-triangle-exclamation"></i><div>No performance data yet. Open the <b>Performance Data</b> tab to add results or import the export from your email / SMS / WhatsApp / ad platform.</div></div>` : ''}
      <div class="erp-two">
        <div class="erp-card"><h3>Spend vs revenue by month</h3><div class="sub">Last 12 months with data</div><div class="erp-chart-box"><canvas id="mkCh1"></canvas></div></div>
        <div class="erp-card"><h3>Clicks &amp; conversions by channel</h3><div class="sub">All stored results</div><div class="erp-chart-box"><canvas id="mkCh2"></canvas></div></div>
      </div>
      <div class="erp-card"><h3>Channel benchmarks</h3><div class="sub">Use these as the baseline for the next campaign</div>
        <div class="table-scroll"><table class="data-table"><thead><tr><th>Channel</th><th>Results</th><th>Sent</th><th>Open %</th><th>CTR %</th><th>CPC</th><th>Conv. %</th><th>ROAS</th><th>Spend</th><th>Revenue</th></tr></thead><tbody>
        ${d.by_channel.length ? d.by_channel.map(r => `<tr><td><b>${r.channel}</b></td><td>${r.records}</td><td>${r.sent.toLocaleString('en-IN')}</td><td>${n(r.open_rate)}</td><td>${n(r.ctr)}</td><td>${r.cpc !== null ? erpMoney(r.cpc) : '—'}</td><td>${n(r.conv_rate)}</td><td>${n(r.roas)}</td><td>${erpMoney(r.spend)}</td><td>${erpMoney(r.revenue)}</td></tr>`).join('') : '<tr><td colspan="10"><div class="erp-empty">No data</div></td></tr>'}
        </tbody></table></div></div>
      <div class="erp-two">
        <div class="erp-card"><h3>Best campaigns by ROAS</h3><div class="sub">Top 5</div>
          <div class="table-scroll"><table class="data-table"><thead><tr><th>Campaign</th><th>Channel</th><th>ROAS</th><th>Revenue</th></tr></thead><tbody>
          ${d.top.length ? d.top.map(r => `<tr><td>${erpEsc(r.campaign_name)}</td><td>${r.channel}</td><td>${n(r.roas)}</td><td>${erpMoney(r.revenue)}</td></tr>`).join('') : '<tr><td colspan="4"><div class="erp-empty">No data</div></td></tr>'}</tbody></table></div></div>
        <div class="erp-card"><h3>Campaigns by status</h3><div class="sub">Across all channels</div>
          <div class="table-scroll"><table class="data-table"><thead><tr><th>Channel</th><th>Draft</th><th>Scheduled</th><th>Running</th><th>Paused</th><th>Completed</th></tr></thead><tbody>
          ${Object.entries(camp).map(([ch, st]) => `<tr><td><b>${ch}</b></td>${['Draft', 'Scheduled', 'Running', 'Paused', 'Completed'].map(s => `<td>${st[s] || 0}</td>`).join('')}</tr>`).join('')}</tbody></table></div>
          <div class="erp-muted" style="font-size:.78rem;margin-top:10px">A/B tests: ${d.ab.total || 0} total, ${d.ab.done || 0} completed.</div></div>
      </div>`;
    host.querySelector('#mkAnCh').addEventListener('change', e => { channel = e.target.value; destroyCharts(); draw().catch(err => host.innerHTML = erpErrorBox(err)); });
    const col = erpChartColors();
    erpMakeChart('mkCh1', { type: 'bar', data: { labels: d.trend.map(x => x.ym), datasets: [{ label: 'Spend', data: d.trend.map(x => +x.spend), backgroundColor: col[0] }, { label: 'Revenue', data: d.trend.map(x => +x.revenue), backgroundColor: col[2] }] } });
    erpMakeChart('mkCh2', { type: 'bar', data: { labels: d.by_channel.map(x => x.channel), datasets: [{ label: 'Clicks', data: d.by_channel.map(x => x.clicks), backgroundColor: col[1] }, { label: 'Conversions', data: d.by_channel.map(x => x.conversions), backgroundColor: col[3] }] } });
  };
  await draw();
}

const MK_PAGES = {
  'Email Campaign': mkChannelPage('Email'),
  'SMS Campaign': mkChannelPage('SMS'),
  'WhatsApp Campaign': mkChannelPage('WhatsApp'),
  'Social Media': mkChannelPage('Social'),
  'Campaign Analytics': mkAnalyticsPage,
};

/* =========================================================
   PROJECT MANAGEMENT
   ========================================================= */
function pmList(entity, title, extra = {}) {
  return (b, s) => erpListPage(Object.assign({ entity, title, sectionLabel: s, back: b, rerender: () => pmList(entity, title, extra)(b, s) }, typeof extra === 'function' ? extra(b, s) : extra));
}
function pmQuick(entity, field, value, label, opts = {}) {
  return { label, icon: opts.icon, cls: opts.cls, show: opts.show, onClick: async (r, ctx) => { const res = await erpPost('quick', { entity, id: r.id, field, value }); erpToast('Updated'); erpNotices(res); ctx.reload(); } };
}

const PM_PAGES = {
  'Projects': (b, s) => erpListPage({
    entity: 'pm_projects', title: 'Projects', sectionLabel: s, back: b, addLabel: 'New Project',
    rerender: () => PM_PAGES['Projects'](b, s),
    kpis: async () => { const [p, a, t, c] = await Promise.all(['Planning', 'Active', 'Testing', 'Completed'].map(x => erpCount('pm_projects', { status: x }))); return [{ l: 'Planning', v: p, c: '#8f97a8' }, { l: 'Active', v: a, c: '#16a34a' }, { l: 'Testing', v: t, c: '#e08c1c' }, { l: 'Completed', v: c, c: '#3556d6' }]; },
    cellRender: { progress: r => erpProgressCell(r) },
    rowActions: r => [
      { label: 'Gantt', icon: 'fa-chart-gantt', onClick: row => pmGanttPage(b, s, row.id) },
      { label: 'Report', icon: 'fa-chart-pie', onClick: row => pmReportPage(b, s, row.id) },
    ],
  }),
  'Create Project': (b, s) => erpForm({
    entity: 'pm_projects', crumb: s, cancelLabel: 'Back to ' + b.label, title: 'Project', onCancel: b.fn,
    banner: `<div class="erp-banner info"><i class="fas fa-circle-info"></i><div>Enter the client, budget and timeline. Upload briefs and contracts afterwards under <b>Files</b>; then break the project into <b>Milestones</b> and <b>Modules</b>.</div></div>`,
    onSaved: row => { erpToast('Project ' + row.project_code + ' created'); PM_PAGES['Projects'](b, s); },
  }),
  'Milestones': pmList('pm_milestones', 'Milestones', { rowActions: r => [pmQuick('pm_milestones', 'status', 'Reached', 'Mark Reached', { cls: 'erp-go', icon: 'fa-flag-checkered', show: r.status === 'Pending' })].map(x => x), kpis: async () => { const [p, r] = await Promise.all([erpCount('pm_milestones', { status: 'Pending' }), erpCount('pm_milestones', { status: 'Reached' })]); return [{ l: 'Pending', v: p, c: '#e08c1c' }, { l: 'Reached', v: r, c: '#16a34a' }]; } }),
  'Modules': pmList('pm_modules', 'Modules'),
  'Tasks': pmList('pm_tasks', 'Tasks', (b, s) => ({
    kpis: async () => { const [t, i, d] = await Promise.all(['To Do', 'In Progress', 'Done'].map(x => erpCount('pm_tasks', { status: x }))); return [{ l: 'To Do', v: t, c: '#8f97a8' }, { l: 'In Progress', v: i, c: '#3556d6' }, { l: 'Done', v: d, c: '#16a34a' }]; },
    rowActions: r => [
      pmQuick('pm_tasks', 'status', 'In Progress', 'Start', { icon: 'fa-play', show: r.status === 'To Do' }),
      pmQuick('pm_tasks', 'status', 'Done', 'Done', { icon: 'fa-check', cls: 'erp-go', show: r.status !== 'Done' }),
    ],
  })),
  'Sub Tasks': pmList('pm_sub_tasks', 'Sub Tasks', {
    rowActions: r => [pmQuick('pm_sub_tasks', 'is_completed', Number(r.is_completed) === 1 ? 0 : 1, Number(r.is_completed) === 1 ? 'Reopen' : 'Complete', { cls: Number(r.is_completed) === 1 ? '' : 'erp-go' })],
  }),
  'Assign Team': pmList('pm_team_assignments', 'Assign Team', { addLabel: 'Assign Team' }),
  'Time Tracking': (b, s) => erpListPage({
    entity: 'pm_time_tracking', title: 'Time Tracking', sectionLabel: s, back: b, addLabel: 'Add Time Log', rerender: () => PM_PAGES['Time Tracking'](b, s),
    toolbar: [{ label: 'Clock In', icon: 'fa-clock', primary: false, onClick: (ctx) => pmClockInDialog(ctx.reload) }],
    kpis: async () => { const hrs = (await erpGet('list', { entity: 'pm_time_tracking', per: 200 })).data; const tot = hrs.reduce((a, x) => a + (+x.total_hours || 0), 0); const run = hrs.filter(x => Number(x.is_running) === 1).length; return [{ l: 'Running clocks', v: run, c: '#16a34a' }, { l: 'Hours (latest 200 logs)', v: tot.toFixed(1), c: '#3556d6' }]; },
    rowActions: r => [{ label: 'Clock Out', icon: 'fa-stop', cls: 'erp-warn', show: Number(r.is_running) === 1, onClick: async (row, ctx) => { const res = await erpPost('pm_clock_out', { id: row.id }); erpToast(res.message); ctx.reload(); } }],
  }),
  'Gantt Chart': (b, s) => pmGanttPage(b, s),
  'Files': pmList('pm_files', 'Files', { addLabel: 'Upload File', rowActions: r => [{ label: 'Download', icon: 'fa-download', onClick: row => erpDownload(erpUrl('file', { entity: 'pm_files', id: row.id })) }] }),
  'Client Approval': pmList('pm_client_approvals', 'Client Approval', {
    addLabel: 'Request Approval',
    rowActions: r => r.status !== 'Pending' ? [] : [
      { label: 'Approve', icon: 'fa-check', cls: 'erp-go', onClick: (row, ctx) => pmDecideDialog(row, 'Approved', ctx.reload) },
      { label: 'Reject', icon: 'fa-xmark', cls: 'erp-danger', onClick: (row, ctx) => pmDecideDialog(row, 'Rejected', ctx.reload) },
    ],
  }),
  'Testing': pmList('pm_testing_bugs', 'Testing', {
    addLabel: 'Report Bug',
    kpis: async () => { const [o, f, r, c] = await Promise.all([erpCount('pm_testing_bugs', { status: 'Open' }), erpCount('pm_testing_bugs', { status: 'Fixing' }), erpCount('pm_testing_bugs', { status: 'Resolved' }), erpCount('pm_testing_bugs', { severity: 'Critical', status: 'Open' })]); return [{ l: 'Open', v: o, c: '#e0384c' }, { l: 'Fixing', v: f, c: '#e08c1c' }, { l: 'Resolved', v: r, c: '#16a34a' }, { l: 'Critical & open', v: c, c: '#a1232f' }]; },
    rowActions: r => [pmQuick('pm_testing_bugs', 'status', 'Fixing', 'Fixing', { show: r.status === 'Open' }), pmQuick('pm_testing_bugs', 'status', 'Resolved', 'Resolve', { cls: 'erp-go', icon: 'fa-check', show: r.status !== 'Resolved' })],
  }),
  'Deployment': pmList('pm_deployments', 'Deployment', { addLabel: 'Record Deployment' }),
  'Maintenance': pmList('pm_maintenance', 'Maintenance', {
    addLabel: 'Log Request',
    rowActions: r => [
      pmQuick('pm_maintenance', 'resolution_status', 'In Progress', 'Start', { show: r.resolution_status === 'Logged' }),
      { label: 'Close', icon: 'fa-check', cls: 'erp-go', show: r.resolution_status !== 'Closed', onClick: (row, ctx) => erpDialog({ title: 'Close request', okLabel: 'Close request', fields: [{ k: 'notes', l: 'Resolution notes', t: 'textarea', req: true }], onSubmit: async v => { await erpPost('save', { resolution_status: 'Closed', resolution_notes: v.notes }, { entity: 'pm_maintenance', id: row.id }); erpToast('Request closed'); ctx.reload(); } }) },
    ],
  }),
  'Project Reports': (b, s) => pmReportPage(b, s),
};

function pmDecideDialog(row, decision, reload) {
  return erpDialog({
    title: (decision === 'Approved' ? 'Approve' : 'Reject') + ' — ' + row.project_name + ' (' + row.approval_type + ')',
    okLabel: decision === 'Approved' ? 'Record approval' : 'Record rejection',
    note: decision === 'Rejected' ? 'A High-priority rework task is created automatically from the feedback.' : 'This is recorded as the client sign-off.',
    fields: [{ k: 'signed_by', l: 'Client signatory name', t: 'text', req: true }, { k: 'feedback_notes', l: decision === 'Rejected' ? 'Feedback (what must change)' : 'Notes (optional)', t: 'textarea', req: decision === 'Rejected' }],
    onSubmit: async v => { const res = await erpPost('save', { status: decision, signed_by: v.signed_by, feedback_notes: v.feedback_notes }, { entity: 'pm_client_approvals', id: row.id }); erpToast('Recorded'); erpNotices(res); reload(); },
  });
}

async function pmClockInDialog(reload) {
  const [projects, emps] = await Promise.all([erpLookup('projects'), erpLookup('employees')]);
  const wrap = document.createElement('div');
  wrap.innerHTML = `<div class="erp-fgrid">
    <div class="erp-field"><label>Project</label><select id="ciP"><option value="">— Select —</option>${projects.map(p => `<option value="${p.id}">${erpEsc(p.label)}</option>`).join('')}</select></div>
    <div class="erp-field"><label>Task</label><select id="ciT"><option value="">— Select a project first —</option></select></div>
    <div class="erp-field"><label>Employee</label><select id="ciE"><option value="">— Select —</option>${emps.map(p => `<option value="${p.id}">${erpEsc(p.label)}</option>`).join('')}</select></div>
    <div class="erp-field"><label>Notes (optional)</label><input id="ciN" type="text"></div>
    <div class="erp-form-msg err" id="ciErr"></div></div>`;
  const tasks = await erpLookup('tasks');
  wrap.querySelector('#ciP').addEventListener('change', e => {
    const list = tasks.filter(t => String(t.project_id) === e.target.value && t.status !== 'Done');
    wrap.querySelector('#ciT').innerHTML = '<option value="">— Select —</option>' + list.map(t => `<option value="${t.id}">${erpEsc(t.label)}</option>`).join('');
  });
  erpModal({ title: 'Clock in', body: wrap, footer: [
    { label: 'Cancel', cls: 'btn-secondary', onClick: a => a.close() },
    { label: 'Start timer', cls: 'btn-primary', onClick: async (a, btn) => {
      const err = wrap.querySelector('#ciErr'); err.textContent = '';
      const body = { task_id: wrap.querySelector('#ciT').value, user_id: wrap.querySelector('#ciE').value, notes: wrap.querySelector('#ciN').value };
      if (!body.task_id || !body.user_id) { err.textContent = 'Choose a task and an employee.'; return; }
      btn.disabled = true;
      try { const res = await erpPost('pm_clock_in', body); erpToast('Clocked in'); a.close(); reload(); } catch (e) { err.textContent = e.message; btn.disabled = false; }
    } }] });
}

/* ---- Gantt ---- */
async function pmGanttPage(b, s, projectId, zoom = 'week') {
  destroyCharts();
  const projects = await erpLookup('projects');
  mainContent.innerHTML = `<button type="button" class="back-btn" id="gBack"><i class="fas fa-arrow-left"></i> Back to ${erpEsc(b.label)}</button>
    <div class="eyebrow">${erpEsc(s)} <span class="crumb-sep">/</span> <span class="crumb-current">Gantt Chart</span></div>
    <div class="page-title"><span>Gantt Chart</span></div><div id="gBody"></div>`;
  document.getElementById('gBack').addEventListener('click', b.fn);
  const body = document.getElementById('gBody');
  if (!projects.length) { body.innerHTML = '<div class="erp-card"><div class="erp-empty"><i class="fas fa-diagram-project"></i>Create a project first, then add modules, tasks and milestones to see its schedule here.</div></div>'; return; }
  projectId = projectId || projects[0].id;
  let g;
  try { g = (await erpGet('pm_gantt', { project_id: projectId })).data; } catch (e) { body.innerHTML = erpErrorBox(e); return; }
  const P = g.project, sch = g.schedule;
  const stateChip = { 'On track': 'green', 'Ahead of schedule': 'green', 'Behind schedule': 'red', 'Completed': 'blue', 'Not started': 'grey', 'No dates': 'grey' }[sch.state] || 'grey';
  const toolbar = `<div class="erp-card" style="padding:14px 18px"><div style="display:flex;flex-wrap:wrap;gap:14px;align-items:center">
      <select class="erp-filter" id="gProj" style="max-width:340px">${projects.map(p => `<option value="${p.id}" ${String(p.id) === String(projectId) ? 'selected' : ''}>${erpEsc(p.label)}</option>`).join('')}</select>
      <span class="erp-chip erp-c-${stateChip}">${erpEsc(sch.state)}</span>
      <div style="min-width:220px"><div class="erp-muted" style="font-size:.7rem;font-weight:700">PLANNED ${sch.planned_pct === null ? '—' : sch.planned_pct + '%'} · ACTUAL ${sch.actual_pct}%</div>
        <div class="erp-prog-bar" style="margin-top:4px;position:relative"><span style="width:${sch.actual_pct}%"></span><i style="position:absolute;top:-2px;bottom:-2px;left:${sch.planned_pct || 0}%;width:2px;background:#ff6b4a"></i></div></div>
      ${sch.overdue_tasks ? `<span class="erp-chip erp-c-red">${sch.overdue_tasks} overdue task${sch.overdue_tasks > 1 ? 's' : ''}</span>` : ''}
      <span class="erp-grow" style="flex:1"></span>
      <div class="erp-tabs" style="margin:0;border:0">${['day', 'week', 'month'].map(z => `<button type="button" class="erp-tab ${z === zoom ? 'active' : ''}" data-z="${z}" style="padding:6px 12px">${z[0].toUpperCase() + z.slice(1)}</button>`).join('')}</div>
    </div>
    <div class="erp-muted" style="font-size:.76rem;margin-top:8px">${erpEsc(P.project_code)} · ${erpEsc(P.customer_name || 'No client')} · ${P.start_date ? erpFmtDate(P.start_date) : '—'} → ${P.end_date ? erpFmtDate(P.end_date) : '—'} · Planned % is the share of the schedule elapsed; actual % weights each task by its estimated hours (Done = 100%, sub-task ratio or hours logged otherwise, In Progress with no data = 50%).</div></div>`;

  const tasksAll = g.modules.flatMap(m => m.tasks);
  if (!g.range.start || !g.range.end) { body.innerHTML = toolbar + '<div class="erp-card"><div class="erp-empty"><i class="fas fa-calendar-xmark"></i>Add a start and end date to the project, and dates to its tasks, to draw the schedule.</div></div>'; wireGanttToolbar(); return; }

  const px = { day: 30, week: 13, month: 5 }[zoom];
  const toUTC = d => { const [y, m, dd] = d.split('-').map(Number); return Date.UTC(y, m - 1, dd); };
  const DAY = 86400000;
  const pad = 3;
  const startMs = toUTC(g.range.start) - pad * DAY, endMs = toUTC(g.range.end) + pad * DAY;
  const days = Math.round((endMs - startMs) / DAY) + 1;
  const idx = d => Math.round((toUTC(d) - startMs) / DAY);
  const W = days * px, LBL = 270, HEAD = 46, ROW = 36;

  // header
  const months = []; let cur = null;
  for (let i = 0; i < days; i++) {
    const dt = new Date(startMs + i * DAY); const key = dt.getUTCFullYear() + '-' + dt.getUTCMonth();
    if (!cur || cur.key !== key) { cur = { key, label: ERP_MONTHS[dt.getUTCMonth()] + ' ' + dt.getUTCFullYear(), n: 0 }; months.push(cur); }
    cur.n++;
  }
  const dayCells = [];
  for (let i = 0; i < days; i++) {
    const dt = new Date(startMs + i * DAY), wd = dt.getUTCDay();
    const show = zoom === 'day' ? true : (zoom === 'week' ? wd === 1 : false);
    dayCells.push(`<div class="erp-g-d ${wd === 0 || wd === 6 ? 'we' : ''}" style="width:${px}px">${show ? dt.getUTCDate() : ''}</div>`);
  }
  // rows
  const rows = []; // {type, ...}
  rows.push({ type: 'ms', title: 'Milestones' });
  g.modules.forEach(m => { rows.push({ type: 'mod', title: m.module_name }); m.tasks.forEach(t => rows.push({ type: 'task', t })); });
  const rowOfTask = {}; rows.forEach((r, i) => { if (r.type === 'task') rowOfTask[r.t.task_id] = i; });
  const today = idx(g.today);
  let html = '';
  rows.forEach(r => {
    if (r.type === 'ms') {
      html += `<div class="erp-g-row mod"><div class="erp-g-label"><span class="n"><i class="fas fa-flag" style="color:#7c5cff;margin-right:6px"></i>Milestones</span></div><div class="erp-g-track" style="width:${W}px">${g.milestones.filter(m => m.due_date).map(m => `<div class="erp-g-ms ${m.status === 'Reached' ? 'reached' : ''}" style="left:${idx(m.due_date) * px + px / 2 - 8}px" title="${erpEsc(m.milestone_title)} — ${erpFmtDate(m.due_date)} — ${m.status}${m.deliverable_amount ? ' — ' + erpMoney(m.deliverable_amount) : ''}"></div>`).join('')}</div></div>`;
    } else if (r.type === 'mod') {
      html += `<div class="erp-g-row mod"><div class="erp-g-label"><span class="n"><i class="fas fa-cube" style="color:#8f97a8;margin-right:6px"></i>${erpEsc(r.title)}</span></div><div class="erp-g-track" style="width:${W}px"></div></div>`;
    } else {
      const t = r.t; let bar = '';
      if (t.start_date || t.due_date) {
        const sd = t.start_date || t.due_date, ed = t.due_date || t.start_date;
        const left = idx(sd) * px, width = Math.max(px, (idx(ed) - idx(sd) + 1) * px);
        const cls = t.status === 'Done' ? 'done' : (t.overdue ? 'late' : (t.status === 'In Progress' ? 'prog' : 'todo'));
        bar = `<div class="erp-g-bar ${cls}" style="left:${left}px;width:${width}px" title="${erpEsc(t.task_name)}\n${erpFmtDate(sd)} → ${erpFmtDate(ed)}\n${t.status} · ${t.progress}%\n${t.assignees ? 'Team: ' + erpEsc(t.assignees) : 'No team assigned'}${Number(t.estimated_hours) ? '\nEst ' + t.estimated_hours + ' h · logged ' + Number(t.hours_logged).toFixed(1) + ' h' : ''}"><div class="fill" style="width:${t.progress}%"></div><span class="txt">${width > 60 ? t.progress + '%' : ''}</span></div>`;
      }
      html += `<div class="erp-g-row"><div class="erp-g-label" title="${erpEsc(t.task_name)}"><span class="n" style="padding-left:18px">${erpEsc(t.task_name)}${!t.start_date && !t.due_date ? ' <span class="erp-muted">(no dates)</span>' : ''}</span></div><div class="erp-g-track" style="width:${W}px">${bar}</div></div>`;
    }
  });
  // dependency arrows
  let svg = '';
  tasksAll.forEach(t => {
    if (!t.depends_on_task_id) return;
    const dep = tasksAll.find(x => String(x.task_id) === String(t.depends_on_task_id)); if (!dep) return;
    if (!(dep.start_date || dep.due_date) || !(t.start_date || t.due_date)) return;
    const y1 = HEAD + rowOfTask[dep.task_id] * ROW + ROW / 2, y2 = HEAD + rowOfTask[t.task_id] * ROW + ROW / 2;
    const x1 = (idx(dep.due_date || dep.start_date) + 1) * px, x2 = idx(t.start_date || t.due_date) * px;
    const mid = x1 + 7;
    const path = x2 >= x1 + 10 ? `M${x1},${y1} H${mid} V${y2} H${x2 - 2}` : `M${x1},${y1} H${x1 + 6} V${(y1 + y2) / 2} H${x2 - 8} V${y2} H${x2 - 2}`;
    svg += `<path d="${path}" fill="none" stroke="#6b7488" stroke-width="1.4" marker-end="url(#gArrow)"/>`;
  });
  body.innerHTML = toolbar + `<div class="erp-gantt-wrap"><div class="erp-gantt-scroll" id="gScroll"><div class="erp-g-grid" style="width:${LBL + W}px">
      <div class="erp-g-head" style="height:${HEAD}px"><div class="erp-g-label" style="height:${HEAD}px">Module / Task</div>
        <div class="erp-g-months"><div class="erp-g-mrow" style="height:24px">${months.map(m => `<div class="erp-g-m" style="width:${m.n * px}px">${m.label}</div>`).join('')}</div><div class="erp-g-drow" style="height:22px">${dayCells.join('')}</div></div></div>
      ${html}
      <svg class="erp-g-svg" width="${W}" height="${HEAD + rows.length * ROW}" style="top:0"><defs><marker id="gArrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 z" fill="#6b7488"/></marker></defs><g transform="translate(0,0)">${svg}</g></svg>
      ${today >= 0 && today < days ? `<div class="erp-g-today" style="left:${LBL + today * px + px / 2}px" title="Today"></div>` : ''}
    </div></div>
    <div class="erp-g-legend"><span><i style="background:#8f97a8"></i>To do</span><span><i style="background:#3556d6"></i>In progress</span><span><i style="background:#16a34a"></i>Done</span><span><i style="background:#d3312f"></i>Overdue</span><span><i style="background:#7c5cff;transform:rotate(45deg)"></i>Milestone</span><span><i style="background:#16a34a;transform:rotate(45deg)"></i>Milestone reached</span><span><i style="background:#ff6b4a;width:3px"></i>Today</span><span>Arrows show task dependencies</span></div></div>`;
  const sc = document.getElementById('gScroll');
  if (today > 8) sc.scrollLeft = Math.max(0, today * px - 120);
  wireGanttToolbar();
  function wireGanttToolbar() {
    document.getElementById('gProj').addEventListener('change', e => pmGanttPage(b, s, e.target.value, zoom));
    mainContent.querySelectorAll('[data-z]').forEach(x => x.addEventListener('click', () => pmGanttPage(b, s, projectId, x.dataset.z)));
  }
}

/* ---- Project reports ---- */
async function pmReportPage(b, s, projectId = '') {
  destroyCharts();
  const projects = await erpLookup('projects');
  mainContent.innerHTML = `<button type="button" class="back-btn" id="rBack"><i class="fas fa-arrow-left"></i> Back to ${erpEsc(b.label)}</button>
    <div class="eyebrow">${erpEsc(s)} <span class="crumb-sep">/</span> <span class="crumb-current">Project Reports</span></div>
    <div class="page-title"><span>Project Reports</span><div class="actions"><button type="button" class="btn btn-secondary" id="rXls" style="padding:9px 14px;border-radius:8px;cursor:pointer;font-weight:600"><i class="fas fa-file-excel"></i> Excel</button> <button type="button" class="btn btn-secondary" id="rPdf" style="padding:9px 14px;border-radius:8px;cursor:pointer;font-weight:600"><i class="fas fa-file-pdf"></i> PDF</button></div></div>
    <div id="rBody"><div class="erp-empty"><i class="fas fa-spinner fa-spin"></i>Building report…</div></div>`;
  document.getElementById('rBack').addEventListener('click', b.fn);
  const body = document.getElementById('rBody');
  let rep;
  try { rep = (await erpGet('pm_report', { project_id: projectId })).data; } catch (e) { body.innerHTML = erpErrorBox(e); return; }
  const P = rep.projects, D = rep.detail;
  const sum = k => P.reduce((a, x) => a + (+x[k] || 0), 0);
  const kpis = `<div class="erp-kpis">
    <div class="erp-kpi"><div class="l">Projects</div><div class="v">${P.length}</div></div>
    <div class="erp-kpi" style="--c:#3556d6"><div class="l">Hours logged</div><div class="v">${sum('actual_hours').toFixed(1)}</div><div class="s">of ${sum('estimated_hours').toFixed(0)} h estimated</div></div>
    <div class="erp-kpi" style="--c:#7c5cff"><div class="l">Labour cost (est.)</div><div class="v">${erpMoney(sum('labour_cost'), 0)}</div><div class="s">from CTC ÷ 2112 h/yr</div></div>
    <div class="erp-kpi" style="--c:#16a34a"><div class="l">Billed (milestones reached)</div><div class="v">${erpMoney(sum('billed'), 0)}</div><div class="s">${erpMoney(sum('billing_pending'), 0)} pending</div></div>
    <div class="erp-kpi" style="--c:#e0384c"><div class="l">Open bugs</div><div class="v">${sum('bugs_open')}</div><div class="s">${sum('bugs_critical')} critical</div></div>
    <div class="erp-kpi" style="--c:#e08c1c"><div class="l">Overdue tasks</div><div class="v">${sum('tasks_overdue')}</div></div></div>`;
  body.innerHTML = `
    <div class="erp-card" style="padding:14px 18px"><label style="font-weight:700;font-size:.82rem;margin-right:10px">Project</label>
      <select class="erp-filter" id="rProj"><option value="">All projects</option>${projects.map(p => `<option value="${p.id}" ${String(p.id) === String(projectId) ? 'selected' : ''}>${erpEsc(p.label)}</option>`).join('')}</select></div>
    ${kpis}
    <div class="erp-two">
      <div class="erp-card"><h3>Estimated vs actual hours</h3><div class="sub">Per project</div><div class="erp-chart-box"><canvas id="rCh1"></canvas></div></div>
      <div class="erp-card"><h3>${D ? 'Task status' : 'Projects by status'}</h3><div class="sub">${D ? 'This project' : 'All projects'}</div><div class="erp-chart-box"><canvas id="rCh2"></canvas></div></div>
    </div>
    ${D ? `<div class="erp-two">
      <div class="erp-card"><h3>Hours by team member</h3><div class="erp-chart-box"><canvas id="rCh3"></canvas></div></div>
      <div class="erp-card"><h3>Hours by module</h3><div class="erp-chart-box"><canvas id="rCh4"></canvas></div></div></div>` : ''}
    <div class="erp-card"><h3>Time, cost &amp; efficiency</h3><div class="sub">Efficiency = estimated ÷ actual hours on <b>completed</b> tasks (above 100% means faster than estimated). Burn = hours logged vs the project estimate.</div>
    <div class="table-scroll"><table class="data-table"><thead><tr><th>Project</th><th>Client</th><th>Status</th><th>Done</th><th>Est. h</th><th>Actual h</th><th>Burn</th><th>Efficiency</th><th>Labour cost</th><th>Budget</th><th>Billed</th><th>Open bugs</th><th>Overdue</th></tr></thead><tbody>
      ${P.length ? P.map(r => `<tr><td><b>${erpEsc(r.project_code)}</b> ${erpEsc(r.project_name)}</td><td>${erpEsc(r.client_name || '')}</td><td>${erpChip(r.status)}</td><td>${erpFmtCell('progress', r.completion_pct, r)}</td><td>${Number(r.estimated_hours || 0).toFixed(0)}</td><td>${Number(r.actual_hours).toFixed(1)}</td><td>${r.hours_burn_pct === null ? '—' : r.hours_burn_pct + '%'}</td><td>${r.efficiency_pct === null ? '<span class="erp-muted">n/a</span>' : r.efficiency_pct + '%'}</td><td>${erpMoney(r.labour_cost, 0)}</td><td>${r.budget ? erpMoney(r.budget, 0) : '—'}</td><td>${erpMoney(r.billed, 0)}</td><td>${r.bugs_open}</td><td>${r.tasks_overdue}</td></tr>`).join('') : '<tr><td colspan="13"><div class="erp-empty">No projects yet.</div></td></tr>'}
    </tbody></table></div></div>`;
  document.getElementById('rProj').addEventListener('change', e => pmReportPage(b, s, e.target.value));
  const col = erpChartColors();
  erpMakeChart('rCh1', { type: 'bar', data: { labels: P.map(x => x.project_code), datasets: [{ label: 'Estimated', data: P.map(x => +x.estimated_hours || 0), backgroundColor: col[1] }, { label: 'Actual', data: P.map(x => +x.actual_hours || 0), backgroundColor: col[0] }] } });
  if (D) {
    erpMakeChart('rCh2', { type: 'doughnut', data: { labels: D.task_status.map(x => x.status), datasets: [{ data: D.task_status.map(x => +x.n), backgroundColor: col }] } });
    erpMakeChart('rCh3', { type: 'bar', data: { labels: D.hours_by_employee.map(x => x.name), datasets: [{ label: 'Hours', data: D.hours_by_employee.map(x => +x.hours), backgroundColor: col[2] }] }, options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } } });
    erpMakeChart('rCh4', { type: 'bar', data: { labels: D.hours_by_module.map(x => x.name), datasets: [{ label: 'Hours', data: D.hours_by_module.map(x => +x.hours), backgroundColor: col[3] }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } } });
  } else {
    const by = {}; P.forEach(x => by[x.status] = (by[x.status] || 0) + 1);
    erpMakeChart('rCh2', { type: 'doughnut', data: { labels: Object.keys(by), datasets: [{ data: Object.values(by), backgroundColor: col }] } });
  }
  const flat = P.map(r => ({ Code: r.project_code, Project: r.project_name, Client: r.client_name, Status: r.status, 'Tasks done %': r.completion_pct, 'Estimated hours': +r.estimated_hours || 0, 'Actual hours': +r.actual_hours, 'Burn %': r.hours_burn_pct, 'Efficiency %': r.efficiency_pct, 'Labour cost': r.labour_cost, Budget: +r.budget || 0, Billed: +r.billed, 'Billing pending': +r.billing_pending, 'Open bugs': +r.bugs_open, 'Overdue tasks': +r.tasks_overdue }));
  document.getElementById('rXls').addEventListener('click', () => {
    if (!window.XLSX) return erpToast('Excel export library not loaded', 'error');
    const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(flat), 'Project Report'); XLSX.writeFile(wb, 'project_report_' + new Date().toISOString().slice(0, 10) + '.xlsx');
  });
  document.getElementById('rPdf').addEventListener('click', () => {
    if (!window.jspdf) return erpToast('PDF library not loaded', 'error');
    const doc = new window.jspdf.jsPDF({ orientation: 'landscape' });
    doc.setFontSize(14); doc.text('Project Report — ' + new Date().toLocaleDateString('en-IN'), 14, 14);
    doc.autoTable({ startY: 20, styles: { fontSize: 7 }, head: [Object.keys(flat[0] || { Project: '' })], body: flat.map(r => Object.values(r).map(v => v === null ? '' : v)) });
    doc.save('project_report.pdf');
  });
}
