/**
 * Compliance Module
 * Handles GST, TDS, PF, ESIC, Professional Tax, ROC, Licenses, ISO Documents, Reminders
 */

class ComplianceModule {
    constructor() {
        this.currentCompany = null;
        this.currentYear = new Date().getFullYear();
        this.records = {};
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadComplianceDashboard();
    }

    setupEventListeners() {
        // Tab navigation
        document.querySelectorAll('.compliance-tab').forEach(tab => {
            tab.addEventListener('click', (e) => this.switchTab(e.target.dataset.tab));
        });

        // Record actions
        document.getElementById('addGSTBtn')?.addEventListener('click', () => this.showGSTForm());
        document.getElementById('addTDSBtn')?.addEventListener('click', () => this.showTDSForm());
        document.getElementById('addPFBtn')?.addEventListener('click', () => this.showPFForm());
        document.getElementById('addESICBtn')?.addEventListener('click', () => this.showESICForm());
        document.getElementById('addROCBtn')?.addEventListener('click', () => this.showROCForm());
        document.getElementById('addLicenseBtn')?.addEventListener('click', () => this.showLicenseForm());
    }

    loadComplianceDashboard() {
        const companyId = sessionStorage.getItem('company_id') || 1;
        
        fetch(`api/compliance.php?type=dashboard&company_id=${companyId}`)
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    this.renderDashboard(data.statistics);
                }
            })
            .catch(e => console.error('Dashboard load error:', e));
    }

    renderDashboard(stats) {
        const html = `
            <div class="compliance-dashboard">
                <div class="stat-card">
                    <div class="stat-value">${stats.overdue_obligations || 0}</div>
                    <div class="stat-label">Overdue Obligations</div>
                    <div class="stat-color overdue"></div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${stats.pending_obligations || 0}</div>
                    <div class="stat-label">Pending Filings</div>
                    <div class="stat-color pending"></div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${stats.upcoming_reminders_7days || 0}</div>
                    <div class="stat-label">Reminders (7 days)</div>
                    <div class="stat-color warning"></div>
                </div>
            </div>
        `;
        document.getElementById('complianceDashboard').innerHTML = html;
    }

    switchTab(tabName) {
        document.querySelectorAll('.compliance-tab').forEach(t => t.classList.remove('active'));
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        this.loadTabData(tabName);
    }

    loadTabData(tabName) {
        const companyId = sessionStorage.getItem('company_id') || 1;
        
        const endpoints = {
            'gst': `api/compliance.php?type=gst&action=list&company_id=${companyId}`,
            'tds': `api/compliance.php?type=tds&action=list&company_id=${companyId}`,
            'pf': `api/compliance.php?type=pf&action=list&company_id=${companyId}`,
            'esic': `api/compliance.php?type=esic&action=list&company_id=${companyId}`,
            'prof_tax': `api/compliance.php?type=prof_tax&action=list&company_id=${companyId}`,
            'roc': `api/compliance.php?type=roc&action=list&company_id=${companyId}`,
            'licenses': `api/compliance.php?type=license&action=list&company_id=${companyId}`,
            'iso': `api/compliance.php?type=iso&action=list&company_id=${companyId}`,
            'reminders': `api/compliance.php?type=reminder&action=list&company_id=${companyId}`
        };

        fetch(endpoints[tabName])
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    this.renderRecordsTable(tabName, data.data);
                }
            })
            .catch(e => console.error('Load error:', e));
    }

    renderRecordsTable(type, records) {
        let html = '<table class="compliance-table"><thead><tr>';
        
        const columns = {
            'gst': ['GST ID', 'Period', 'Status', 'Filing Status', 'Amount', 'Actions'],
            'tds': ['TAN', 'Deductee', 'Amount', 'Status', 'Period', 'Actions'],
            'pf': ['Employee', 'Wage Month', 'Contribution', 'Status', 'Actions'],
            'esic': ['Employee', 'Period', 'Contribution', 'Status', 'Actions'],
            'prof_tax': ['Employee', 'Month', 'Amount', 'Status', 'Actions'],
            'roc': ['Form', 'Financial Year', 'Due Date', 'Status', 'Actions'],
            'licenses': ['License', 'Authority', 'Expiry Date', 'Status', 'Actions'],
            'iso': ['Standard', 'Scope', 'Expiry', 'Status', 'Actions'],
            'reminders': ['Obligation', 'Due Date', 'Responsible', 'Status', 'Actions']
        };

        columns[type].forEach(col => html += `<th>${col}</th>`);
        html += '</tr></thead><tbody>';

        records.forEach(record => {
            html += this.renderRecordRow(type, record);
        });

        html += '</tbody></table>';
        document.querySelector(`[data-tab="${type}"]`).nextElementSibling.innerHTML = html;
    }

    renderRecordRow(type, record) {
        let row = `<tr data-id="${record.id}">`;
        
        switch(type) {
            case 'gst':
                row += `<td>${record.id}</td>
                       <td>${record.return_period}</td>
                       <td>${record.preparation_status}</td>
                       <td>${record.filing_status}</td>
                       <td>${record.payable_amount}</td>`;
                break;
            case 'tds':
                row += `<td>${record.tan}</td>
                       <td>${record.deductee_id}</td>
                       <td>${record.deducted_amount}</td>
                       <td>${record.payment_status}</td>
                       <td>${record.statement_period}</td>`;
                break;
            // Add more cases for other types...
        }

        row += `<td>
                <button class="action-btn" onclick="complianceModule.viewRecord('${type}', ${record.id})">View</button>
                <button class="action-btn" onclick="complianceModule.editRecord('${type}', ${record.id})">Edit</button>
                <button class="action-btn delete" onclick="complianceModule.deleteRecord('${type}', ${record.id})">Delete</button>
               </td></tr>`;
        
        return row;
    }

    showGSTForm() {
        const form = `
            <div class="compliance-form-modal">
                <div class="form-header">
                    <h3>Create GST Record</h3>
                    <button class="close-btn" onclick="document.querySelector('.compliance-form-modal').remove()">×</button>
                </div>
                <form id="gstForm" class="compliance-form">
                    <div class="form-group">
                        <label>Company GSTIN</label>
                        <input type="text" name="gstin" required>
                    </div>
                    <div class="form-group">
                        <label>Return Period</label>
                        <input type="text" name="return_period" placeholder="YYYY-MM" required>
                    </div>
                    <div class="form-group">
                        <label>Taxable Value</label>
                        <input type="number" name="taxable_value" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label>CGST Amount</label>
                        <input type="number" name="cgst_amount" step="0.01">
                    </div>
                    <div class="form-group">
                        <label>SGST Amount</label>
                        <input type="number" name="sgst_amount" step="0.01">
                    </div>
                    <div class="form-group">
                        <label>ITC Amount</label>
                        <input type="number" name="itc_amount" step="0.01">
                    </div>
                    <div class="form-group">
                        <label>Payable Amount</label>
                        <input type="number" name="payable_amount" step="0.01">
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Create Record</button>
                        <button type="button" class="btn btn-secondary" onclick="document.querySelector('.compliance-form-modal').remove()">Cancel</button>
                    </div>
                </form>
            </div>
        `;

        const container = document.createElement('div');
        container.innerHTML = form;
        document.body.appendChild(container.firstElementChild);

        document.getElementById('gstForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.createRecord('gst', new FormData(e.target));
        });
    }

    showTDSForm() {
        // Similar structure for TDS form
        console.log('Show TDS form');
    }

    showPFForm() {
        console.log('Show PF form');
    }

    showESICForm() {
        console.log('Show ESIC form');
    }

    showROCForm() {
        console.log('Show ROC form');
    }

    showLicenseForm() {
        console.log('Show License form');
    }

    createRecord(type, formData) {
        const data = Object.fromEntries(formData);
        
        fetch(`api/compliance.php?type=${type}&action=create`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert('Record created successfully');
                document.querySelector('.compliance-form-modal').remove();
                this.loadTabData(type);
            } else {
                alert('Error: ' + data.error);
            }
        })
        .catch(e => alert('Error creating record: ' + e));
    }

    viewRecord(type, id) {
        fetch(`api/compliance.php?type=${type}&action=detail&id=${id}`)
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    this.showRecordDetail(type, data.data);
                }
            });
    }

    editRecord(type, id) {
        console.log('Edit record:', type, id);
    }

    deleteRecord(type, id) {
        if (confirm('Are you sure you want to delete this record?')) {
            // Implement delete logic
            console.log('Delete:', type, id);
        }
    }

    showRecordDetail(type, record) {
        const modal = `
            <div class="record-detail-modal">
                <div class="modal-header">
                    <h3>${type.toUpperCase()} Record Details</h3>
                    <button class="close-btn" onclick="this.closest('.record-detail-modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    ${JSON.stringify(record, null, 2).replace(/\n/g, '<br>')}
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" onclick="this.closest('.record-detail-modal').remove()">Close</button>
                </div>
            </div>
        `;
        
        const container = document.createElement('div');
        container.innerHTML = modal;
        document.body.appendChild(container.firstElementChild);
    }
}

// Initialize module
const complianceModule = new ComplianceModule();
