/**
 * Employee Self Service Module
 * Handles My Profile, Leave, Attendance, Tasks, Notifications
 */

class EmployeeSelfService {
    constructor() {
        this.userId = sessionStorage.getItem('user_id');
        this.employeeId = null;
        this.init();
    }

    init() {
        this.loadMyProfile();
        this.setupEventListeners();
    }

    setupEventListeners() {
        document.querySelectorAll('.self-service-tab').forEach(tab => {
            tab.addEventListener('click', (e) => this.switchTab(e.target.dataset.tab));
        });

        // Modal close buttons
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', (e) => e.target.closest('.modal').remove());
        });
    }

    switchTab(tabName) {
        document.querySelectorAll('.self-service-tab').forEach(t => t.classList.remove('active'));
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        
        switch(tabName) {
            case 'profile':
                this.loadMyProfile();
                break;
            case 'attendance':
                this.loadMyAttendance();
                break;
            case 'leave':
                this.loadMyLeave();
                break;
            case 'tasks':
                this.loadMyTasks();
                break;
            case 'notifications':
                this.loadNotifications();
                break;
        }
    }

    // Profile Management
    loadMyProfile() {
        fetch(`api/user_profile_extended.php?module=profile&action=my_profile`)
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    this.renderProfileView(data.data);
                    this.employeeId = data.data.employee_id;
                }
            })
            .catch(e => console.error('Profile load error:', e));
    }

    renderProfileView(profile) {
        const html = `
            <div class="profile-container">
                <div class="profile-header">
                    <div class="profile-photo">
                        <img src="${profile.profile_photo || 'images/avatar-default.png'}" alt="Profile">
                        <button class="change-photo-btn" onclick="empSelfService.showPhotoUpload()">Change Photo</button>
                    </div>
                    <div class="profile-info">
                        <h2>${profile.first_name} ${profile.last_name}</h2>
                        <p class="designation">${profile.designation}</p>
                        <p class="department">${profile.department}</p>
                        <p class="employee-id">ID: ${profile.employee_id}</p>
                    </div>
                </div>

                <div class="profile-content">
                    <div class="profile-section">
                        <h3>Contact Information</h3>
                        <div class="profile-editable">
                            <div class="field">
                                <label>Personal Email</label>
                                <input type="email" class="editable-field" data-field="personal_email" value="${profile.personal_email || ''}" />
                            </div>
                            <div class="field">
                                <label>Personal Phone</label>
                                <input type="tel" class="editable-field" data-field="personal_phone" value="${profile.personal_phone || ''}" />
                            </div>
                            <div class="field">
                                <label>Work Email</label>
                                <input type="email" disabled value="${profile.work_email || ''}" />
                            </div>
                            <div class="field">
                                <label>Work Phone</label>
                                <input type="tel" disabled value="${profile.work_phone || ''}" />
                            </div>
                        </div>
                    </div>

                    <div class="profile-section">
                        <h3>Address</h3>
                        <div class="profile-editable">
                            <div class="field">
                                <label>Address</label>
                                <textarea class="editable-field" data-field="personal_address">${profile.personal_address || ''}</textarea>
                            </div>
                            <div class="field">
                                <label>City</label>
                                <input type="text" class="editable-field" data-field="city" value="${profile.city || ''}" />
                            </div>
                            <div class="field">
                                <label>State</label>
                                <input type="text" class="editable-field" data-field="state" value="${profile.state || ''}" />
                            </div>
                            <div class="field">
                                <label>Postal Code</label>
                                <input type="text" class="editable-field" data-field="postal_code" value="${profile.postal_code || ''}" />
                            </div>
                        </div>
                    </div>

                    <div class="profile-section">
                        <h3>Emergency Contact</h3>
                        <div class="profile-editable">
                            <div class="field">
                                <label>Name</label>
                                <input type="text" class="editable-field" data-field="emergency_contact_name" value="${profile.emergency_contact_name || ''}" />
                            </div>
                            <div class="field">
                                <label>Phone</label>
                                <input type="tel" class="editable-field" data-field="emergency_contact_phone" value="${profile.emergency_contact_phone || ''}" />
                            </div>
                            <div class="field">
                                <label>Relation</label>
                                <input type="text" class="editable-field" data-field="emergency_contact_relation" value="${profile.emergency_contact_relation || ''}" />
                            </div>
                        </div>
                    </div>

                    <div class="profile-actions">
                        <button class="btn btn-primary" onclick="empSelfService.saveProfileChanges()">Save Changes</button>
                        <button class="btn btn-secondary" onclick="empSelfService.changePassword()">Change Password</button>
                    </div>
                </div>
            </div>
        `;

        document.getElementById('profileTab').innerHTML = html;

        // Add edit listeners
        document.querySelectorAll('.editable-field').forEach(field => {
            field.addEventListener('change', () => {
                document.querySelector('.profile-actions').classList.add('show');
            });
        });
    }

    saveProfileChanges() {
        const updates = {};
        document.querySelectorAll('.editable-field').forEach(field => {
            updates[field.dataset.field] = field.value;
        });

        fetch(`api/user_profile_extended.php?module=profile&action=update_editable_fields`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updates)
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert('Profile updated successfully');
                this.loadMyProfile();
            }
        });
    }

    changePassword() {
        const modal = `
            <div class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Change Password</h3>
                        <button class="modal-close">×</button>
                    </div>
                    <form id="changePasswordForm" class="modal-body">
                        <div class="form-group">
                            <label>Current Password</label>
                            <input type="password" name="current_password" required>
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" name="new_password" required>
                        </div>
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" name="confirm_password" required>
                        </div>
                        <div class="password-requirements">
                            <small>Password must be at least 8 characters</small>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Change Password</button>
                            <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        `;

        const container = document.createElement('div');
        container.innerHTML = modal;
        document.body.appendChild(container.firstElementChild);

        document.getElementById('changePasswordForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const data = new FormData(e.target);
            
            fetch(`api/user_profile_extended.php?module=password&action=change`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(Object.fromEntries(data))
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    alert('Password changed successfully');
                    document.querySelector('.modal').remove();
                }
            });
        });
    }

    // Attendance Management
    loadMyAttendance() {
        const month = new Date().toISOString().slice(0, 7);
        fetch(`api/user_profile_extended.php?module=attendance&action=my_attendance&month=${month}`)
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    this.renderAttendanceView(data.data);
                }
            });
    }

    renderAttendanceView(records) {
        const html = `
            <div class="attendance-container">
                <div class="attendance-controls">
                    <button class="btn btn-primary" onclick="empSelfService.checkIn()">Check In</button>
                    <button class="btn btn-danger" onclick="empSelfService.checkOut()">Check Out</button>
                    <button class="btn btn-secondary" onclick="empSelfService.showAttendanceMonth()">Select Month</button>
                </div>
                <table class="attendance-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Check In</th>
                            <th>Check Out</th>
                            <th>Total Hours</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${records.map(r => `
                            <tr>
                                <td>${r.attendance_date}</td>
                                <td>${r.check_in_time || '-'}</td>
                                <td>${r.check_out_time || '-'}</td>
                                <td>${r.total_hours || '-'}</td>
                                <td><span class="status-badge ${r.status}">${r.status}</span></td>
                                <td>
                                    ${!r.check_out_time ? '<button onclick="empSelfService.checkOut()">Check Out</button>' : ''}
                                    ${r.status === 'incomplete' ? '<button onclick="empSelfService.requestRegularization(' + r.id + ')">Request Regularization</button>' : ''}
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
        document.getElementById('attendanceTab').innerHTML = html;
    }

    checkIn() {
        fetch(`api/user_profile_extended.php?module=attendance&action=check_in`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ shift_id: 1 })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert('Checked in successfully!');
                this.loadMyAttendance();
            }
        });
    }

    checkOut() {
        fetch(`api/user_profile_extended.php?module=attendance&action=check_out`, {
            method: 'POST'
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert('Checked out successfully!');
                this.loadMyAttendance();
            }
        });
    }

    requestRegularization(attendanceId) {
        const reason = prompt('Enter reason for regularization:');
        if (reason) {
            fetch(`api/user_profile_extended.php?module=attendance&action=request_regularization`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ attendance_id: attendanceId, reason: reason })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    alert('Regularization request submitted!');
                    this.loadMyAttendance();
                }
            });
        }
    }

    // Leave Management
    loadMyLeave() {
        Promise.all([
            fetch(`api/user_profile_extended.php?module=leave&action=my_leave_balance`).then(r => r.json()),
            fetch(`api/user_profile_extended.php?module=leave&action=my_leave_requests`).then(r => r.json())
        ])
        .then(([balanceData, requestData]) => {
            this.renderLeaveView(balanceData.data, requestData.data);
        });
    }

    renderLeaveView(balances, requests) {
        const html = `
            <div class="leave-container">
                <div class="leave-controls">
                    <button class="btn btn-primary" onclick="empSelfService.showLeaveRequestForm()">Request Leave</button>
                </div>

                <div class="leave-balances">
                    <h3>Leave Balance</h3>
                    <div class="balance-grid">
                        ${balances.map(b => `
                            <div class="balance-card">
                                <div class="balance-type">${b.leave_type_name}</div>
                                <div class="balance-info">
                                    <div class="balance-item">
                                        <span class="label">Available</span>
                                        <span class="value">${b.closing_balance}</span>
                                    </div>
                                    <div class="balance-item">
                                        <span class="label">Used</span>
                                        <span class="value">${b.used}</span>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="leave-requests">
                    <h3>Leave Requests</h3>
                    <table class="requests-table">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Days</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${requests.map(r => `
                                <tr>
                                    <td>${r.leave_type_name}</td>
                                    <td>${r.start_date}</td>
                                    <td>${r.end_date}</td>
                                    <td>${r.duration_days}</td>
                                    <td><span class="status-badge ${r.approval_status}">${r.approval_status}</span></td>
                                    <td>
                                        ${r.approval_status === 'approved' ? '<button onclick="empSelfService.withdrawLeave(' + r.id + ')">Withdraw</button>' : ''}
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
        document.getElementById('leaveTab').innerHTML = html;
    }

    showLeaveRequestForm() {
        // Implementation for leave request form
        const modal = `
            <div class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Request Leave</h3>
                        <button class="modal-close">×</button>
                    </div>
                    <form id="leaveRequestForm" class="modal-body">
                        <div class="form-group">
                            <label>Leave Type</label>
                            <select name="leave_type_id" required></select>
                        </div>
                        <div class="form-group">
                            <label>Start Date</label>
                            <input type="date" name="start_date" required>
                        </div>
                        <div class="form-group">
                            <label>End Date</label>
                            <input type="date" name="end_date" required>
                        </div>
                        <div class="form-group">
                            <label>Full Day</label>
                            <input type="checkbox" name="is_full_day" checked>
                        </div>
                        <div class="form-group">
                            <label>Reason</label>
                            <textarea name="reason" required></textarea>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Submit Request</button>
                            <button type="button" class="btn btn-secondary modal-close">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        `;

        const container = document.createElement('div');
        container.innerHTML = modal;
        document.body.appendChild(container.firstElementChild);

        document.getElementById('leaveRequestForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const data = new FormData(e.target);
            
            fetch(`api/user_profile_extended.php?module=leave&action=request_leave`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(Object.fromEntries(data))
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    alert('Leave request submitted!');
                    document.querySelector('.modal').remove();
                    this.loadMyLeave();
                }
            });
        });
    }

    withdrawLeave(leaveRequestId) {
        if (confirm('Are you sure you want to withdraw this leave request?')) {
            fetch(`api/user_profile_extended.php?module=leave&action=withdraw_leave&id=${leaveRequestId}`, {
                method: 'POST'
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    alert('Leave withdrawal requested!');
                    this.loadMyLeave();
                }
            });
        }
    }

    // Tasks Management
    loadMyTasks() {
        const status = document.querySelector('[data-status-filter]')?.value || 'all';
        fetch(`api/user_profile_extended.php?module=tasks&action=my_tasks&status=${status}`)
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    this.renderTasksView(data.data);
                }
            });
    }

    renderTasksView(tasks) {
        const html = `
            <div class="tasks-container">
                <div class="tasks-controls">
                    <select data-status-filter onchange="empSelfService.loadMyTasks()">
                        <option value="all">All Tasks</option>
                        <option value="assigned">Assigned</option>
                        <option value="in_progress">In Progress</option>
                        <option value="submitted_for_review">Submitted</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
                <div class="tasks-board">
                    ${tasks.map(t => `
                        <div class="task-card" data-id="${t.id}">
                            <div class="task-header">
                                <h4>${t.task_title}</h4>
                                <span class="priority-badge ${t.priority}">${t.priority}</span>
                            </div>
                            <div class="task-body">
                                <p>${t.task_description}</p>
                                <div class="task-meta">
                                    <span>Project: ${t.project_name}</span>
                                    <span>Due: ${t.due_date}</span>
                                </div>
                            </div>
                            <div class="task-footer">
                                <span class="status-badge ${t.status}">${t.status}</span>
                                <div class="task-actions">
                                    <button onclick="empSelfService.openTaskDetail(${t.id})">View</button>
                                    ${t.status === 'assigned' ? '<button onclick="empSelfService.startTask(' + t.id + ')">Start</button>' : ''}
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        document.getElementById('tasksTab').innerHTML = html;
    }

    startTask(taskId) {
        fetch(`api/user_profile_extended.php?module=tasks&action=update_task_status&id=${taskId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'in_progress' })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                this.loadMyTasks();
            }
        });
    }

    openTaskDetail(taskId) {
        console.log('Opening task:', taskId);
    }

    // Notifications
    loadNotifications() {
        fetch(`api/user_profile_extended.php?module=notifications&action=list`)
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    this.renderNotificationsView(data.data);
                }
            });
    }

    renderNotificationsView(notifications) {
        const html = `
            <div class="notifications-container">
                <div class="notifications-list">
                    ${notifications.map(n => `
                        <div class="notification-item ${n.is_read ? 'read' : 'unread'}" data-id="${n.id}">
                            <div class="notification-content">
                                <h4>${n.message_title}</h4>
                                <p>${n.message_content}</p>
                                <small>${new Date(n.created_date).toLocaleString()}</small>
                            </div>
                            <div class="notification-actions">
                                ${!n.is_read ? '<button onclick="empSelfService.markNotificationRead(' + n.id + ')">Mark Read</button>' : ''}
                                ${n.action_link ? '<a href="' + n.action_link + '" class="btn-link">Go to</a>' : ''}
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        document.getElementById('notificationsTab').innerHTML = html;
    }

    markNotificationRead(notificationId) {
        fetch(`api/user_profile_extended.php?module=notifications&action=mark_read&id=${notificationId}`, {
            method: 'POST'
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                this.loadNotifications();
            }
        });
    }
}

// Initialize module
const empSelfService = new EmployeeSelfService();
