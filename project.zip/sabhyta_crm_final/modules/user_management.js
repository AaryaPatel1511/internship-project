/**
 * USER MANAGEMENT MODULE
 * Users come from HRMS employees table.
 * Roles (Super Admin → Executive) assigned per employee.
 * Data scopes: own / team / department / company / all
 */

function umDebounce(fn, ms) {
  let t;
  return function (...args) {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), ms);
  };
}

function umEsc(s) {
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ============================================================
// USERS (from HRMS employees)
// ============================================================
async function renderUsersPage() {
  mainContent.innerHTML = `
    <div class="user-mgmt-container">
      <div class="page-header">
        <div>
          <h2><i class="fas fa-users"></i> User Management</h2>
          <p>Users are loaded from HRMS Employees. Assign roles to control access.</p>
        </div>
        <div class="header-actions">
          <input type="text" id="userSearchInput" placeholder="Search name, email, code..." class="search-box-small">
          <select id="userStatusFilter" class="filter-select">
            <option value="Active">Active</option>
            <option value="">All Status</option>
            <option value="Resigned">Resigned</option>
            <option value="On Notice">On Notice</option>
          </select>
          <select id="userDeptFilter" class="filter-select">
            <option value="">All Departments</option>
          </select>
          <select id="userRoleFilter" class="filter-select">
            <option value="">All Roles</option>
          </select>
          <button class="btn btn-secondary" onclick="syncEmployeesWithUsers()">
            <i class="fas fa-sync-alt"></i> Refresh
          </button>
        </div>
      </div>

      <div class="tabs-container">
        <div class="tab-buttons">
          <button class="tab-btn active" data-tab="users-list"><i class="fas fa-list"></i> Users List</button>
          <button class="tab-btn" data-tab="users-tree"><i class="fas fa-sitemap"></i> By Department</button>
        </div>

        <div class="tab-content" id="users-list">
          <div class="table-wrapper">
            <table class="data-table" id="usersTable">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Name</th>
                  <th>Email / Mobile</th>
                  <th>Department</th>
                  <th>Designation</th>
                  <th>Roles</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="usersTableBody">
                <tr><td colspan="8" class="text-center">Loading users...</td></tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="tab-content" id="users-tree" style="display:none;">
          <div class="hierarchy-view" id="hierarchyView">Loading...</div>
        </div>
      </div>
    </div>

    <div id="userDetailModal" class="modal" style="display:none;">
      <div class="modal-content modal-lg">
        <div class="modal-header">
          <h3>User Detail &amp; Role Assignment</h3>
          <button class="close-btn" onclick="closeUserModal()">&times;</button>
        </div>
        <div class="modal-body" id="userDetailContent">Loading...</div>
      </div>
    </div>
  `;

  await Promise.all([loadDepartmentFilter(), loadRoleFilter()]);
  await loadUsers();

  document.getElementById('userSearchInput').addEventListener('keyup', umDebounce(loadUsers, 300));
  document.getElementById('userStatusFilter').addEventListener('change', loadUsers);
  document.getElementById('userDeptFilter').addEventListener('change', loadUsers);
  document.getElementById('userRoleFilter').addEventListener('change', loadUsers);

  document.querySelectorAll('.user-mgmt-container .tab-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      document.querySelectorAll('.user-mgmt-container .tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.user-mgmt-container .tab-content').forEach(c => c.style.display = 'none');
      this.classList.add('active');
      const tabId = this.dataset.tab;
      document.getElementById(tabId).style.display = 'block';
      if (tabId === 'users-tree') loadHierarchyTree();
    });
  });
}

async function loadUsers() {
  const search = document.getElementById('userSearchInput')?.value || '';
  const status = document.getElementById('userStatusFilter')?.value ?? 'Active';
  const department = document.getElementById('userDeptFilter')?.value || '';
  const role = document.getElementById('userRoleFilter')?.value || '';
  const tbody = document.getElementById('usersTableBody');
  if (!tbody) return;

  tbody.innerHTML = '<tr><td colspan="8" class="text-center">Loading users...</td></tr>';

  const params = new URLSearchParams({ q: search, status, department, role });

  try {
    const res = await fetch(`api/users.php?${params}`);
    const json = await res.json();

    if (!json.success) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-center text-danger">${umEsc(json.message || json.error || 'Failed to load users')}</td></tr>`;
      return;
    }

    if (!json.data || json.data.length === 0) {
      tbody.innerHTML = `
        <tr><td colspan="8" class="text-center">
          <p style="margin:16px 0 8px;">No employees found.</p>
          <p style="color:#8f97a8;font-size:13px;">Add employees under <strong>HRMS → Employee</strong>, then return here to assign roles.</p>
        </td></tr>`;
      return;
    }

    tbody.innerHTML = json.data.map(user => {
      const initial = (user.full_name || '?').charAt(0).toUpperCase();
      const rolesHtml = user.roles
        ? `<span class="badge-primary">${umEsc(user.roles)}</span>`
        : '<span class="badge-light">No role</span>';
      const st = (user.employment_status || 'Active').toLowerCase().replace(/\s+/g, '-');
      return `
        <tr>
          <td><span class="badge-code">${umEsc(user.employee_code)}</span></td>
          <td>
            <div class="user-cell">
              <div class="user-avatar">${umEsc(initial)}</div>
              <div><strong>${umEsc(user.full_name)}</strong></div>
            </div>
          </td>
          <td>
            <div>${umEsc(user.official_email || '-')}</div>
            <small style="color:#8f97a8;">${umEsc(user.mobile_number || '')}</small>
          </td>
          <td>${umEsc(user.department || '-')}</td>
          <td>${umEsc(user.designation || '-')}</td>
          <td>${rolesHtml}</td>
          <td><span class="status status-${umEsc(st)}">${umEsc(user.employment_status)}</span></td>
          <td>
            <button class="action-btn" onclick="openUserDetail(${user.user_id})" title="Assign / manage roles">
              <i class="fas fa-user-tag"></i>
            </button>
          </td>
        </tr>`;
    }).join('');
  } catch (err) {
    console.error(err);
    tbody.innerHTML = '<tr><td colspan="8" class="text-center text-danger">Error loading users. Ensure you are logged in and the database is set up.</td></tr>';
  }
}

async function openUserDetail(userId) {
  const modal = document.getElementById('userDetailModal');
  const content = document.getElementById('userDetailContent');
  if (!modal || !content) return;
  content.innerHTML = 'Loading...';
  modal.style.display = 'block';

  try {
    const res = await fetch(`api/users.php?id=${userId}`);
    const json = await res.json();
    if (!json.success) {
      content.innerHTML = `<p class="text-danger">${umEsc(json.message || 'Failed to load')}</p>`;
      return;
    }
    const user = json.data;

    let rolesHTML = '';
    if (user.roles && user.roles.length) {
      rolesHTML = user.roles.map(role => `
        <div class="role-badge">
          <span class="role-name">${umEsc(role.role_name)}</span>
          <span class="role-level">Level ${role.role_level}</span>
          <button class="remove-role-btn" title="Remove role" onclick="removeRoleFromUser(${user.user_id}, ${role.id})">
            <i class="fas fa-times"></i>
          </button>
        </div>`).join('');
    } else {
      rolesHTML = '<p class="text-muted">No roles assigned yet</p>';
    }

    let permissionsHTML = '';
    if (user.permissions_by_module && Object.keys(user.permissions_by_module).length) {
      permissionsHTML = Object.entries(user.permissions_by_module).map(([module, perms]) => `
        <div class="permission-group">
          <h5>${umEsc(module)}</h5>
          <div class="permission-list">
            ${perms.map(p => `
              <div class="permission-item">
                <span class="perm-name">${umEsc(p.permission_name)}</span>
                <span class="perm-action">${umEsc(p.action_type)}</span>
                <span class="perm-scope">${umEsc(p.data_scope)}</span>
              </div>`).join('')}
          </div>
        </div>`).join('');
    } else {
      permissionsHTML = '<p class="text-muted">No permissions (assign a role first)</p>';
    }

    const joinDate = user.date_of_joining
      ? new Date(user.date_of_joining).toLocaleDateString()
      : '-';

    content.innerHTML = `
      <div class="user-detail-grid">
        <div class="detail-column">
          <div class="detail-section">
            <h4>Employee Information</h4>
            <div class="info-group"><label>Name</label><p>${umEsc(user.full_name)}</p></div>
            <div class="info-group"><label>Employee Code</label><p>${umEsc(user.employee_code)}</p></div>
            <div class="info-group"><label>Email</label><p>${umEsc(user.official_email || '-')}</p></div>
            <div class="info-group"><label>Mobile</label><p>${umEsc(user.mobile_number || '-')}</p></div>
            <div class="info-group"><label>Department</label><p>${umEsc(user.department || '-')}</p></div>
            <div class="info-group"><label>Designation</label><p>${umEsc(user.designation || '-')}</p></div>
            <div class="info-group"><label>Reporting Manager</label><p>${umEsc(user.reporting_manager_name || '-')}</p></div>
            <div class="info-group"><label>Date of Joining</label><p>${umEsc(joinDate)}</p></div>
            <div class="info-group"><label>Status</label><p>${umEsc(user.employment_status)}</p></div>
          </div>
        </div>
        <div class="detail-column">
          <div class="detail-section">
            <div class="section-header">
              <h4>Assigned Roles</h4>
              <button class="btn btn-sm btn-primary" onclick="showAssignRoleForm(${user.user_id})">
                <i class="fas fa-plus"></i> Assign Role
              </button>
            </div>
            <div class="roles-list">${rolesHTML}</div>
          </div>
          <div class="detail-section">
            <h4>Effective Permissions</h4>
            <div class="permissions-view">${permissionsHTML}</div>
          </div>
        </div>
      </div>
      <div id="assignRoleForm" style="display:none;margin-top:20px;padding:15px;background:#f5f7fa;border-radius:8px;">
        <h5>Assign Role to this Employee</h5>
        <div class="form-group">
          <label>Select Role</label>
          <select id="roleSelect" class="form-control">
            <option value="">-- Select Role --</option>
          </select>
        </div>
        <div class="form-actions" style="margin-top:12px;display:flex;gap:10px;">
          <button class="btn btn-primary" onclick="assignRoleToUser(${user.user_id})">Assign</button>
          <button class="btn btn-outline" onclick="hideAssignRoleForm()">Cancel</button>
        </div>
      </div>`;

    const rolesRes = await fetch('api/user_roles.php');
    const rolesJson = await rolesRes.json();
    if (rolesJson.success) {
      const assignedIds = new Set((user.roles || []).map(r => String(r.role_id)));
      const sel = document.getElementById('roleSelect');
      sel.innerHTML = '<option value="">-- Select Role --</option>' +
        rolesJson.data
          .filter(r => !assignedIds.has(String(r.id)))
          .map(r => `<option value="${r.id}">${umEsc(r.role_name)} (Level ${r.role_level})</option>`)
          .join('');
    }
  } catch (err) {
    console.error(err);
    content.innerHTML = '<p class="text-danger">Error loading user details</p>';
  }
}

function showAssignRoleForm() {
  const el = document.getElementById('assignRoleForm');
  if (el) {
    el.style.display = 'block';
    el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

function hideAssignRoleForm() {
  const el = document.getElementById('assignRoleForm');
  if (el) el.style.display = 'none';
}

function closeUserModal() {
  const m = document.getElementById('userDetailModal');
  if (m) m.style.display = 'none';
}

async function assignRoleToUser(userId) {
  const roleId = document.getElementById('roleSelect')?.value;
  if (!roleId) {
    alert('Please select a role');
    return;
  }
  try {
    const res = await fetch('api/users.php?action=assign_role', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ employee_id: userId, role_id: parseInt(roleId, 10) })
    });
    const json = await res.json();
    if (json.success) {
      openUserDetail(userId);
      loadUsers();
    } else {
      alert(json.message || 'Failed to assign role');
    }
  } catch (err) {
    console.error(err);
    alert('Error assigning role');
  }
}

async function removeRoleFromUser(userId, userRoleId) {
  if (!confirm('Remove this role from the user?')) return;
  try {
    const res = await fetch('api/users.php?action=remove_role', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_role_id: userRoleId })
    });
    const json = await res.json();
    if (json.success) {
      openUserDetail(userId);
      loadUsers();
    } else {
      alert(json.message || 'Failed to remove role');
    }
  } catch (err) {
    console.error(err);
    alert('Error removing role');
  }
}

async function syncEmployeesWithUsers() {
  try {
    const res = await fetch('api/users.php?action=sync_employees', { method: 'POST' });
    const json = await res.json();
    if (json.success) {
      const s = json.summary || {};
      alert(`Synced.\nActive employees: ${s.total_employees || 0}\nWith roles: ${s.users_with_roles || 0}\nRoles defined: ${s.total_roles || 0}`);
      loadUsers();
    } else {
      alert(json.error || json.message || 'Sync failed');
    }
  } catch (err) {
    console.error(err);
    alert('Error refreshing');
  }
}

async function loadDepartmentFilter() {
  try {
    const res = await fetch('api/user_masters.php?type=departments');
    const json = await res.json();
    const select = document.getElementById('userDeptFilter');
    if (!select) return;
    if (json.success && json.data) {
      select.innerHTML = '<option value="">All Departments</option>' +
        json.data.map(d => {
          const name = d.dept_name || d.department_name || '';
          return `<option value="${umEsc(name)}">${umEsc(name)}</option>`;
        }).join('');
    }
  } catch (e) {
    console.error(e);
  }
}

async function loadRoleFilter() {
  try {
    const res = await fetch('api/user_roles.php');
    const json = await res.json();
    const select = document.getElementById('userRoleFilter');
    if (!select) return;
    if (json.success && json.data) {
      select.innerHTML = '<option value="">All Roles</option>' +
        json.data.map(r => `<option value="${umEsc(r.role_name)}">${umEsc(r.role_name)}</option>`).join('');
    }
  } catch (e) {
    console.error(e);
  }
}

async function loadHierarchyTree() {
  const view = document.getElementById('hierarchyView');
  if (!view) return;
  view.innerHTML = '<div class="text-center">Loading...</div>';
  try {
    const res = await fetch('api/users.php?status=Active');
    const json = await res.json();
    if (!json.success) {
      view.innerHTML = `<p class="text-danger">${umEsc(json.message || 'Failed')}</p>`;
      return;
    }
    const byDept = {};
    (json.data || []).forEach(u => {
      const d = u.department || 'Unassigned';
      if (!byDept[d]) byDept[d] = [];
      byDept[d].push(u);
    });
    const html = Object.entries(byDept).map(([dept, emps]) => `
      <div class="hierarchy-section">
        <h4 class="hierarchy-title"><i class="fas fa-building"></i> ${umEsc(dept)} <small>(${emps.length})</small></h4>
        <div class="hierarchy-members">
          ${emps.map(emp => `
            <div class="hierarchy-member" onclick="openUserDetail(${emp.user_id})" style="cursor:pointer;">
              <div class="member-badge">${umEsc((emp.full_name || '?').charAt(0))}</div>
              <div class="member-info">
                <strong>${umEsc(emp.full_name)}</strong>
                <small>${umEsc(emp.designation || 'N/A')} · ${umEsc(emp.roles || 'No Role')}</small>
              </div>
            </div>`).join('')}
        </div>
      </div>`).join('');
    view.innerHTML = html || '<p class="text-muted">No active employees</p>';
  } catch (e) {
    console.error(e);
    view.innerHTML = '<p class="text-danger">Error loading hierarchy</p>';
  }
}

// ============================================================
// ROLES
// ============================================================
async function renderRolesPage() {
  mainContent.innerHTML = `
    <div class="roles-mgmt-container">
      <div class="page-header">
        <div>
          <h2><i class="fas fa-shield-alt"></i> Roles</h2>
          <p>Five-level authority: Super Admin → Admin → Manager → Supervisor → Executive</p>
        </div>
      </div>
      <div class="roles-grid" id="rolesGrid">Loading roles...</div>
    </div>
    <div id="roleDetailModal" class="modal" style="display:none;">
      <div class="modal-content modal-lg">
        <div class="modal-header">
          <h3>Role Details</h3>
          <button class="close-btn" onclick="closeRoleModal()">&times;</button>
        </div>
        <div class="modal-body" id="roleDetailContent">Loading...</div>
      </div>
    </div>
  `;
  await loadRoles();
}

async function loadRoles() {
  const grid = document.getElementById('rolesGrid');
  if (!grid) return;
  grid.innerHTML = 'Loading roles...';
  try {
    const res = await fetch('api/user_roles.php');
    const json = await res.json();
    if (!json.success) {
      grid.innerHTML = `<p class="text-danger">${umEsc(json.message || json.error || 'Failed to load roles')}</p>`;
      return;
    }
    const levelColors = { 1: '#e74c3c', 2: '#e67e22', 3: '#3498db', 4: '#9b59b6', 5: '#1abc9c' };
    grid.innerHTML = (json.data || []).map(r => `
      <div class="role-card" onclick="openRoleDetail(${r.id})" style="cursor:pointer;border-left:4px solid ${levelColors[r.role_level] || '#95a5a6'};">
        <div class="role-card-header">
          <h3>${umEsc(r.role_name)}</h3>
          <span class="role-level-badge">Level ${r.role_level}</span>
        </div>
        <p class="role-desc">${umEsc(r.description || '')}</p>
        <div class="role-stats">
          <span><i class="fas fa-users"></i> ${r.user_count || 0} users</span>
          <span><i class="fas fa-key"></i> ${r.permission_count || 0} permissions</span>
        </div>
      </div>`).join('') || '<p class="text-muted">No roles defined</p>';
  } catch (e) {
    console.error(e);
    grid.innerHTML = '<p class="text-danger">Error loading roles. Check login session.</p>';
  }
}

async function openRoleDetail(roleId) {
  const modal = document.getElementById('roleDetailModal');
  const content = document.getElementById('roleDetailContent');
  if (!modal || !content) return;
  content.innerHTML = 'Loading...';
  modal.style.display = 'block';
  try {
    const res = await fetch(`api/user_roles.php?id=${roleId}`);
    const json = await res.json();
    if (!json.success) {
      content.innerHTML = `<p class="text-danger">${umEsc(json.message || 'Failed')}</p>`;
      return;
    }
    const role = json.data;
    const byMod = role.permissions_by_module || {};
    const permsHtml = Object.keys(byMod).length
      ? Object.entries(byMod).map(([mod, list]) => `
          <div class="permission-group">
            <h5>${umEsc(mod)}</h5>
            <div class="permission-list">
              ${list.map(p => `
                <div class="permission-item">
                  <span class="perm-name">${umEsc(p.permission_name)}</span>
                  <span class="perm-action">${umEsc(p.action_type)}</span>
                  <span class="perm-scope">${umEsc(p.data_scope || 'own')}</span>
                </div>`).join('')}
            </div>
          </div>`).join('')
      : '<p class="text-muted">No permissions linked</p>';

    const usersHtml = (role.assigned_users_list || []).length
      ? `<ul class="simple-list">${role.assigned_users_list.map(u =>
          `<li>${umEsc(u.full_name)} <small>(${umEsc(u.employee_code)} · ${umEsc(u.dept_name || '')})</small></li>`
        ).join('')}</ul>`
      : '<p class="text-muted">No users assigned this role yet</p>';

    content.innerHTML = `
      <div class="detail-section">
        <h4>${umEsc(role.role_name)} <span class="role-level-badge">Level ${role.role_level}</span></h4>
        <p>${umEsc(role.description || '')}</p>
      </div>
      <div class="detail-section">
        <h4>Permissions</h4>
        ${permsHtml}
      </div>
      <div class="detail-section">
        <h4>Assigned Users</h4>
        ${usersHtml}
      </div>`;
  } catch (e) {
    console.error(e);
    content.innerHTML = '<p class="text-danger">Error loading role</p>';
  }
}

function closeRoleModal() {
  const m = document.getElementById('roleDetailModal');
  if (m) m.style.display = 'none';
}

// ============================================================
// PERMISSIONS
// ============================================================
async function renderPermissionsPage() {
  mainContent.innerHTML = `
    <div class="roles-mgmt-container">
      <div class="page-header">
        <div>
          <h2><i class="fas fa-key"></i> Permissions</h2>
          <p>Module → Action permissions with data scope (own / team / department / company / all)</p>
        </div>
      </div>
      <div id="permissionsGrid">Loading permissions...</div>
    </div>
  `;
  await loadPermissionsPage();
}

async function loadPermissionsPage() {
  const grid = document.getElementById('permissionsGrid');
  if (!grid) return;
  try {
    const res = await fetch('api/user_permissions.php');
    const json = await res.json();
    if (!json.success) {
      grid.innerHTML = `<p class="text-danger">${umEsc(json.message || json.error || 'Failed')}</p>`;
      return;
    }
    const groups = json.by_module || [];
    if (!groups.length) {
      grid.innerHTML = '<p class="text-muted">No permissions seeded yet. Open Roles once to auto-seed.</p>';
      return;
    }
    grid.innerHTML = groups.map(g => `
      <div class="permission-module-card" style="margin-bottom:20px;background:#fff;border:1px solid #e0e6f2;border-radius:10px;padding:16px;">
        <h3 style="margin:0 0 12px;"><i class="fas ${umEsc(g.module_icon || 'fa-folder')}"></i> ${umEsc(g.module_name)}</h3>
        <div class="permission-list">
          ${(g.permissions || []).map(p => `
            <div class="permission-item">
              <span class="perm-name">${umEsc(p.permission_name)}</span>
              <span class="perm-action">${umEsc(p.action_type)}</span>
            </div>`).join('')}
        </div>
      </div>`).join('');
  } catch (e) {
    console.error(e);
    grid.innerHTML = '<p class="text-danger">Error loading permissions</p>';
  }
}

// ============================================================
// DEPARTMENTS & DESIGNATIONS (read from HRMS masters)
// ============================================================
async function renderDepartmentsPage() {
  mainContent.innerHTML = `
    <div class="masters-container">
      <div class="page-header">
        <div>
          <h2><i class="fas fa-building"></i> Departments</h2>
          <p>From HRMS. Used for department-scoped access.</p>
        </div>
      </div>
      <div class="table-wrapper">
        <table class="data-table">
          <thead>
            <tr>
              <th>Code</th>
              <th>Name</th>
              <th>Employees</th>
              <th>Designations</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody id="deptTableBody"><tr><td colspan="5" class="text-center">Loading...</td></tr></tbody>
        </table>
      </div>
    </div>
  `;
  await loadDepartmentsTable();
}

async function loadDepartmentsTable() {
  const tbody = document.getElementById('deptTableBody');
  if (!tbody) return;
  try {
    const res = await fetch('api/user_masters.php?type=departments');
    const json = await res.json();
    if (!json.success) {
      tbody.innerHTML = `<tr><td colspan="5" class="text-center text-danger">${umEsc(json.message || 'Failed')}</td></tr>`;
      return;
    }
    if (!json.data.length) {
      tbody.innerHTML = '<tr><td colspan="5" class="text-center">No departments. Create them under HRMS → Department.</td></tr>';
      return;
    }
    tbody.innerHTML = json.data.map(d => `
      <tr>
        <td><span class="badge-code">${umEsc(d.dept_code || d.department_code || d.id)}</span></td>
        <td><strong>${umEsc(d.dept_name || d.department_name)}</strong></td>
        <td>${d.employee_count || 0}</td>
        <td>${d.designation_count || 0}</td>
        <td><span class="status status-${umEsc((d.status || 'Active').toLowerCase())}">${umEsc(d.status || 'Active')}</span></td>
      </tr>`).join('');
  } catch (e) {
    console.error(e);
    tbody.innerHTML = '<tr><td colspan="5" class="text-center text-danger">Error loading departments</td></tr>';
  }
}

async function renderDesignationsPage() {
  mainContent.innerHTML = `
    <div class="masters-container">
      <div class="page-header">
        <div>
          <h2><i class="fas fa-id-badge"></i> Designations</h2>
          <p>Positions within departments (e.g. Sales Manager, HR Executive). From HRMS.</p>
        </div>
      </div>
      <div class="table-wrapper">
        <table class="data-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Department</th>
              <th>Employees</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody id="desigTableBody"><tr><td colspan="4" class="text-center">Loading...</td></tr></tbody>
        </table>
      </div>
    </div>
  `;
  await loadDesignationsTable();
}

async function loadDesignationsTable() {
  const tbody = document.getElementById('desigTableBody');
  if (!tbody) return;
  try {
    const res = await fetch('api/user_masters.php?type=designations');
    const json = await res.json();
    if (!json.success) {
      tbody.innerHTML = `<tr><td colspan="4" class="text-center text-danger">${umEsc(json.message || 'Failed')}</td></tr>`;
      return;
    }
    if (!json.data.length) {
      tbody.innerHTML = '<tr><td colspan="4" class="text-center">No designations. Create them under HRMS → Designation.</td></tr>';
      return;
    }
    tbody.innerHTML = json.data.map(d => `
      <tr>
        <td><strong>${umEsc(d.desig_name || d.designation_name)}</strong></td>
        <td>${umEsc(d.dept_name || d.department_name || '-')}</td>
        <td>${d.employee_count || 0}</td>
        <td><span class="status status-${umEsc((d.status || 'Active').toLowerCase())}">${umEsc(d.status || 'Active')}</span></td>
      </tr>`).join('');
  } catch (e) {
    console.error(e);
    tbody.innerHTML = '<tr><td colspan="4" class="text-center text-danger">Error loading designations</td></tr>';
  }
}

// Close modals on outside click
document.addEventListener('click', function (e) {
  if (e.target && e.target.classList && e.target.classList.contains('modal')) {
    e.target.style.display = 'none';
  }
});
