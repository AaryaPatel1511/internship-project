/**
 * ENHANCED USER MANAGEMENT MODULE
 * Fixes for loading states and role assignment functionality
 * This should be loaded AFTER the main user_management.js
 */

// Override the loadRoles function with better error handling
async function loadRoles() {
    try {
        const res = await fetch('api/user_roles_fixed.php');
        const json = await res.json();
        
        const grid = document.getElementById('rolesGrid');
        
        if (!json.success) {
            grid.innerHTML = `<div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <p>Failed to load roles: ${json.error || 'Unknown error'}</p>
            </div>`;
            return;
        }
        
        if (!json.data || json.data.length === 0) {
            grid.innerHTML = `<div class="empty-state">
                <i class="fas fa-inbox"></i>
                <p>No roles found</p>
            </div>`;
            return;
        }
        
        grid.innerHTML = json.data.map(role => `
            <div class="role-card">
                <div class="role-header">
                    <div>
                        <h4>${role.role_name}</h4>
                        <p class="text-muted">Level ${role.role_level}</p>
                    </div>
                    <span class="badge-primary">${role.user_count || 0} users</span>
                </div>
                <p class="role-description">${role.description || 'No description'}</p>
                <div class="role-footer">
                    <small>${role.permission_count || 0} permissions</small>
                    <button class="btn btn-sm btn-secondary" onclick="openRoleDetail(${role.id})">
                        Manage
                    </button>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading roles:', error);
        const grid = document.getElementById('rolesGrid');
        if (grid) {
            grid.innerHTML = `<div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <p>Error loading roles: ${error.message}</p>
            </div>`;
        }
    }
}

// Override loadDepartments with fixed API
async function loadDepartments() {
    try {
        const res = await fetch('api/departments_fixed.php');
        const json = await res.json();
        
        if (!json.success) {
            console.error('Failed to load departments:', json.error);
            return;
        }
        
        const depts = json.data || [];
        
        // Update filters
        const deptFilter = document.getElementById('userDeptFilter');
        if (deptFilter) {
            deptFilter.innerHTML = '<option value="">All Departments</option>' +
                depts.map(d => `<option value="${d.dept_name}">${d.dept_name}</option>`).join('');
        }
        
        // Update department list if on that tab
        const deptGrid = document.getElementById('departmentsGrid');
        if (deptGrid) {
            if (depts.length === 0) {
                deptGrid.innerHTML = '<div class="empty-state"><p>No departments found</p></div>';
            } else {
                deptGrid.innerHTML = depts.map(dept => `
                    <div class="dept-card">
                        <h4>${dept.dept_name}</h4>
                        <p class="text-muted">${dept.dept_head || 'No head assigned'}</p>
                        <small class="status status-${dept.status?.toLowerCase()}">${dept.status}</small>
                    </div>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading departments:', error);
    }
}

// Override loadDesignations with fixed API
async function loadDesignations() {
    try {
        const res = await fetch('api/designations_fixed.php');
        const json = await res.json();
        
        if (!json.success) {
            console.error('Failed to load designations:', json.error);
            return;
        }
        
        const desigs = json.data || [];
        
        // Update designations list if on that tab
        const desiGrid = document.getElementById('designationsGrid');
        if (desiGrid) {
            if (desigs.length === 0) {
                desiGrid.innerHTML = '<div class="empty-state"><p>No designations found</p></div>';
            } else {
                desiGrid.innerHTML = desigs.map(desg => `
                    <div class="desg-card">
                        <h4>${desg.designation_name}</h4>
                        <p class="text-muted">Pay Level ${desg.pay_level || '-'}</p>
                        <small class="status status-${desg.status?.toLowerCase()}">${desg.status}</small>
                    </div>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading designations:', error);
    }
}

// New function to open user detail with role assignment
async function openUserDetailWithRoles(userId) {
    try {
        const res = await fetch(`api/users.php?id=${userId}`);
        const json = await res.json();
        
        if (!json.success) {
            alert('Failed to load user details');
            return;
        }
        
        const user = json.data;
        
        // Get available roles
        const rolesRes = await fetch('api/user_roles_fixed.php');
        const rolesJson = await rolesRes.json();
        const availableRoles = rolesJson.data || [];
        
        const userRoleIds = user.roles ? user.roles.map(r => r.role_id) : [];
        
        let rolesHTML = '<div class="role-assignment-section">';
        rolesHTML += '<h5 style="margin-top: 20px; margin-bottom: 10px;">Assign Roles</h5>';
        
        if (availableRoles.length === 0) {
            rolesHTML += '<p class="text-muted">No roles available</p>';
        } else {
            rolesHTML += '<div class="role-checkboxes">';
            rolesHTML += availableRoles.map(role => {
                const isChecked = userRoleIds.includes(role.id);
                return `
                    <div class="checkbox-item">
                        <input type="checkbox" id="role_${role.id}" value="${role.id}" 
                            ${isChecked ? 'checked' : ''} 
                            onchange="updateUserRole(${userId}, ${role.id}, this.checked)">
                        <label for="role_${role.id}">
                            <strong>${role.role_name}</strong>
                            <span class="badge-info">${role.user_count} users</span>
                        </label>
                    </div>
                `;
            }).join('');
            rolesHTML += '</div>';
        }
        rolesHTML += '</div>';
        
        // Display modal with enhanced content
        const modal = document.getElementById('userDetailModal');
        if (modal) {
            const modalContent = modal.querySelector('.modal-body');
            if (modalContent) {
                // Add roles section to existing content
                const existingHTML = modalContent.innerHTML;
                modalContent.innerHTML = existingHTML + rolesHTML;
            }
        }
    } catch (error) {
        console.error('Error loading user details:', error);
    }
}

// Function to update user role
async function updateUserRole(employeeId, roleId, assign) {
    try {
        const action = assign ? 'assign_user_role' : 'remove_user_role';
        const res = await fetch(`api/user_roles_fixed.php?action=${action}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                employee_id: employeeId,
                role_id: roleId
            })
        });
        
        const json = await res.json();
        
        if (!json.success) {
            alert('Error: ' + json.message);
            return;
        }
        
        alert(json.message);
        
        // Reload the users list
        if (typeof loadUsers === 'function') {
            loadUsers();
        }
    } catch (error) {
        console.error('Error updating role:', error);
        alert('Error updating role: ' + error.message);
    }
}

// Enhanced renderRolesPage with better structure
async function renderRolesPageEnhanced() {
    const mainContent = document.getElementById('mainContent') || document.querySelector('.main-content');
    
    if (!mainContent) return;
    
    mainContent.innerHTML = `
        <div class="user-mgmt-container">
            <div class="page-header">
                <div>
                    <h2><i class="fas fa-badge"></i> Roles & Permissions</h2>
                    <p>Manage user roles and their permissions</p>
                </div>
            </div>

            <div class="tabs-container">
                <div class="tab-buttons">
                    <button class="tab-btn active" data-tab="roles-grid">
                        <i class="fas fa-grid"></i> Roles
                    </button>
                    <button class="tab-btn" data-tab="roles-permissions">
                        <i class="fas fa-lock"></i> Permissions
                    </button>
                </div>

                <div class="tab-content" id="roles-grid">
                    <div class="page-actions">
                        <button class="btn btn-primary" onclick="showCreateRoleModal()">
                            <i class="fas fa-plus"></i> Create Role
                        </button>
                    </div>
                    <div class="roles-grid" id="rolesGrid">
                        <div class="loading">
                            <div class="spinner"></div>
                            <p>Loading roles...</p>
                        </div>
                    </div>
                </div>

                <div class="tab-content" id="roles-permissions">
                    <p>Permissions management coming soon...</p>
                </div>
            </div>
        </div>
    `;
    
    // Setup tab navigation
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
            
            btn.classList.add('active');
            const tabId = btn.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });
    
    // Make first tab active
    document.querySelectorAll('.tab-content')[0].classList.add('active');
    
    // Load roles
    await loadRoles();
}

// Enhanced renderDepartmentsPage
async function renderDepartmentsPageEnhanced() {
    const mainContent = document.getElementById('mainContent') || document.querySelector('.main-content');
    
    if (!mainContent) return;
    
    mainContent.innerHTML = `
        <div class="user-mgmt-container">
            <div class="page-header">
                <div>
                    <h2><i class="fas fa-building"></i> Departments</h2>
                    <p>Manage departments and department heads</p>
                </div>
            </div>

            <div class="page-actions">
                <button class="btn btn-primary" onclick="showCreateDepartmentModal()">
                    <i class="fas fa-plus"></i> Create Department
                </button>
            </div>

            <div class="departments-grid" id="departmentsGrid">
                <div class="loading">
                    <div class="spinner"></div>
                    <p>Loading departments...</p>
                </div>
            </div>
        </div>
    `;
    
    await loadDepartments();
}

// Enhanced renderDesignationsPage
async function renderDesignationsPageEnhanced() {
    const mainContent = document.getElementById('mainContent') || document.querySelector('.main-content');
    
    if (!mainContent) return;
    
    mainContent.innerHTML = `
        <div class="user-mgmt-container">
            <div class="page-header">
                <div>
                    <h2><i class="fas fa-id-badge"></i> Designations</h2>
                    <p>Manage employee designations and pay levels</p>
                </div>
            </div>

            <div class="page-actions">
                <button class="btn btn-primary" onclick="showCreateDesignationModal()">
                    <i class="fas fa-plus"></i> Create Designation
                </button>
            </div>

            <div class="designations-grid" id="designationsGrid">
                <div class="loading">
                    <div class="spinner"></div>
                    <p>Loading designations...</p>
                </div>
            </div>
        </div>
    `;
    
    await loadDesignations();
}

// CSS for enhancements
const enhancedStyles = `
.loading {
    text-align: center;
    padding: 40px 20px;
    color: #95a5a6;
}

.spinner {
    border: 4px solid #f3f3f3;
    border-top: 4px solid #3498db;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    animation: spin 1s linear infinite;
    margin: 0 auto 20px;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.error-message {
    background: #f8d7da;
    border: 1px solid #f5c6cb;
    border-radius: 4px;
    padding: 20px;
    text-align: center;
    color: #721c24;
}

.error-message i {
    font-size: 32px;
    margin-bottom: 10px;
    display: block;
}

.empty-state {
    background: #e7f3ff;
    border: 1px solid #b3d9ff;
    border-radius: 4px;
    padding: 40px 20px;
    text-align: center;
    color: #004085;
}

.empty-state i {
    font-size: 48px;
    display: block;
    margin-bottom: 15px;
    opacity: 0.5;
}

.role-checkboxes {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin-top: 15px;
}

.checkbox-item {
    display: flex;
    align-items: center;
    padding: 10px;
    border: 1px solid #e0e0e0;
    border-radius: 4px;
    gap: 10px;
}

.checkbox-item input[type="checkbox"] {
    width: 18px;
    height: 18px;
    cursor: pointer;
}

.checkbox-item label {
    cursor: pointer;
    flex: 1;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.checkbox-item strong {
    font-weight: 600;
}

.role-assignment-section {
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #e0e0e0;
}

.page-actions {
    margin-bottom: 20px;
}

.dept-card, .desg-card {
    background: white;
    border-radius: 8px;
    padding: 15px;
    border: 1px solid #e0e0e0;
    transition: all 0.3s;
}

.dept-card:hover, .desg-card:hover {
    border-color: #3498db;
    box-shadow: 0 2px 8px rgba(52, 152, 219, 0.15);
}

.departments-grid, .designations-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
}
`;

// Inject enhanced styles
const styleSheet = document.createElement('style');
styleSheet.textContent = enhancedStyles;
document.head.appendChild(styleSheet);
