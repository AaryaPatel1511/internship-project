/**
 * AI Tools Module
 * Chat Assistant, Email Generator, Proposal Generator, OCR, Voice Notes, Analytics
 */

class AITools {
    constructor() {
        this.userId = sessionStorage.getItem('user_id');
        this.init();
    }

    init() {
        this.setupEventListeners();
    }

    setupEventListeners() {
        document.querySelectorAll('.ai-tool-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tool = e.target.dataset.tool;
                this.openTool(tool);
            });
        });
    }

    openTool(tool) {
        switch(tool) {
            case 'chat':
                this.openChatAssistant();
                break;
            case 'email':
                this.openEmailGenerator();
                break;
            case 'proposal':
                this.openProposalGenerator();
                break;
            case 'ocr':
                this.openOCRScanner();
                break;
            case 'voice':
                this.openVoiceNotes();
                break;
            case 'analytics':
                this.openAnalytics();
                break;
        }
    }

    // Chat Assistant
    openChatAssistant() {
        fetch('api/ai_tools.php?tool=chat_assistant&action=start_session', {
            method: 'POST'
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                this.showChatInterface(data.session_id);
            }
        });
    }

    showChatInterface(sessionId) {
        const modal = `
            <div class="ai-modal ai-chat-modal">
                <div class="ai-modal-header">
                    <h3>AI Chat Assistant</h3>
                    <button class="close-btn" onclick="this.closest('.ai-modal').remove()">×</button>
                </div>
                <div class="chat-container">
                    <div class="chat-messages" id="chatMessages"></div>
                    <div class="chat-input-area">
                        <textarea id="chatInput" placeholder="Ask me anything..."></textarea>
                        <button onclick="aiTools.sendChatMessage('${sessionId}')">Send</button>
                    </div>
                </div>
            </div>
        `;

        const container = document.createElement('div');
        container.innerHTML = modal;
        document.body.appendChild(container.firstElementChild);
    }

    sendChatMessage(sessionId) {
        const input = document.getElementById('chatInput');
        const message = input.value;
        
        if (!message.trim()) return;

        // Add user message to chat
        this.addChatMessage('user', message);
        input.value = '';

        // Send to AI
        fetch('api/ai_tools.php?tool=chat_assistant&action=send_message', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                session_id: sessionId,
                message: message,
                permitted_records: []
            })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                this.addChatMessage('ai', data.response);
                if (data.requires_review) {
                    this.addChatAction('review', data.job_id);
                }
            }
        });
    }

    addChatMessage(sender, message) {
        const messagesDiv = document.getElementById('chatMessages');
        const msgEl = document.createElement('div');
        msgEl.className = `chat-message ${sender}`;
        msgEl.textContent = message;
        messagesDiv.appendChild(msgEl);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
    }

    addChatAction(action, jobId) {
        const messagesDiv = document.getElementById('chatMessages');
        const actionEl = document.createElement('div');
        actionEl.className = 'chat-action';
        actionEl.innerHTML = `
            <button onclick="aiTools.approveAIOutput('${jobId}')">Approve</button>
            <button onclick="aiTools.rejectAIOutput('${jobId}')">Reject</button>
        `;
        messagesDiv.appendChild(actionEl);
    }

    // Email Generator
    openEmailGenerator() {
        const modal = `
            <div class="ai-modal ai-email-modal">
                <div class="ai-modal-header">
                    <h3>AI Email Generator</h3>
                    <button class="close-btn" onclick="this.closest('.ai-modal').remove()">×</button>
                </div>
                <form id="emailForm" class="ai-modal-body">
                    <div class="form-group">
                        <label>Recipient Email</label>
                        <input type="email" name="recipient_email" required>
                    </div>
                    <div class="form-group">
                        <label>Purpose</label>
                        <select name="purpose" required>
                            <option>Sales Follow-up</option>
                            <option>Customer Support</option>
                            <option>Project Update</option>
                            <option>General</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tone</label>
                        <select name="tone">
                            <option>Professional</option>
                            <option>Friendly</option>
                            <option>Formal</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Language</label>
                        <select name="language">
                            <option value="en">English</option>
                            <option value="hi">Hindi</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Additional Context</label>
                        <textarea name="context"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Generate Email</button>
                </form>
            </div>
        `;

        const container = document.createElement('div');
        container.innerHTML = modal;
        document.body.appendChild(container.firstElementChild);

        document.getElementById('emailForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const data = new FormData(e.target);
            
            fetch('api/ai_tools.php?tool=email_generator&action=generate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(Object.fromEntries(data))
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    this.showEmailDraft(data.email_draft, data.job_id);
                }
            });
        });
    }

    showEmailDraft(draft, jobId) {
        const modal = `
            <div class="ai-modal ai-draft-modal">
                <div class="ai-modal-header">
                    <h3>Email Draft Review</h3>
                    <button class="close-btn" onclick="this.closest('.ai-modal').remove()">×</button>
                </div>
                <div class="draft-content">
                    <div class="draft-field">
                        <label>Subject</label>
                        <input type="text" id="emailSubject" value="${draft.subject}" class="editable-draft">
                    </div>
                    <div class="draft-field">
                        <label>Body</label>
                        <textarea id="emailBody" class="editable-draft">${draft.body}</textarea>
                    </div>
                    <div class="draft-actions">
                        <button class="btn btn-primary" onclick="aiTools.sendEmailDraft('${jobId}')">Send Email</button>
                        <button class="btn btn-secondary" onclick="aiTools.editEmailDraft()">Edit</button>
                        <button class="btn btn-danger" onclick="this.closest('.ai-modal').remove()">Discard</button>
                    </div>
                </div>
            </div>
        `;

        document.querySelector('.ai-email-modal').remove();
        const container = document.createElement('div');
        container.innerHTML = modal;
        document.body.appendChild(container.firstElementChild);
    }

    sendEmailDraft(jobId) {
        fetch(`api/ai_tools.php?tool=email_generator&action=send_email&id=${jobId}`, {
            method: 'POST'
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert('Email sent successfully!');
                document.querySelector('.ai-draft-modal').remove();
            }
        });
    }

    // Proposal Generator
    openProposalGenerator() {
        const modal = `
            <div class="ai-modal ai-proposal-modal">
                <div class="ai-modal-header">
                    <h3>AI Proposal Generator</h3>
                    <button class="close-btn" onclick="this.closest('.ai-modal').remove()">×</button>
                </div>
                <form id="proposalForm" class="ai-modal-body">
                    <div class="form-group">
                        <label>Customer ID</label>
                        <select name="customer_id" required></select>
                    </div>
                    <div class="form-group">
                        <label>Requirement Summary</label>
                        <textarea name="requirement_summary" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Approved Scope</label>
                        <textarea name="approved_scope" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Timeline (Days)</label>
                        <input type="number" name="timeline_days" value="30">
                    </div>
                    <button type="submit" class="btn btn-primary">Generate Proposal</button>
                </form>
            </div>
        `;

        const container = document.createElement('div');
        container.innerHTML = modal;
        document.body.appendChild(container.firstElementChild);

        document.getElementById('proposalForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const data = new FormData(e.target);
            
            fetch('api/ai_tools.php?tool=proposal_generator&action=generate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(Object.fromEntries(data))
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    alert('Proposal generated: ' + data.proposal_number);
                    document.querySelector('.ai-proposal-modal').remove();
                }
            });
        });
    }

    // OCR Scanner
    openOCRScanner() {
        const modal = `
            <div class="ai-modal ai-ocr-modal">
                <div class="ai-modal-header">
                    <h3>OCR Document Scanner</h3>
                    <button class="close-btn" onclick="this.closest('.ai-modal').remove()">×</button>
                </div>
                <form id="ocrForm" class="ai-modal-body" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Document Type</label>
                        <select name="document_type" required>
                            <option>Invoice</option>
                            <option>Receipt</option>
                            <option>License</option>
                            <option>ID</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Upload Document</label>
                        <input type="file" name="document" accept="image/*,.pdf" required>
                    </div>
                    <div class="form-group">
                        <label>Language</label>
                        <select name="language">
                            <option value="en">English</option>
                            <option value="hi">Hindi</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Scan Document</button>
                </form>
            </div>
        `;

        const container = document.createElement('div');
        container.innerHTML = modal;
        document.body.appendChild(container.firstElementChild);

        document.getElementById('ocrForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            
            fetch('api/ai_tools.php?tool=ocr_scanner&action=scan_document', {
                method: 'POST',
                body: formData
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    this.showOCRResults(data.extracted_data, data.job_id);
                }
            });
        });
    }

    showOCRResults(data, jobId) {
        const modal = `
            <div class="ai-modal ai-ocr-results">
                <div class="ai-modal-header">
                    <h3>Extracted Data</h3>
                    <button class="close-btn" onclick="this.closest('.ai-modal').remove()">×</button>
                </div>
                <div class="ocr-results">
                    ${JSON.stringify(data, null, 2).replace(/\\n/g, '<br>')}
                    <div class="ocr-actions">
                        <button class="btn btn-primary" onclick="aiTools.confirmOCRExtraction('${jobId}')">Confirm & Post</button>
                        <button class="btn btn-secondary" onclick="this.closest('.ai-modal').remove()">Cancel</button>
                    </div>
                </div>
            </div>
        `;

        document.querySelector('.ai-ocr-modal').remove();
        const container = document.createElement('div');
        container.innerHTML = modal;
        document.body.appendChild(container.firstElementChild);
    }

    confirmOCRExtraction(jobId) {
        fetch(`api/ai_tools.php?tool=ocr_scanner&action=confirm_extraction&id=${jobId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ corrections: {} })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert('Data extracted and posted!');
                document.querySelector('.ai-ocr-results').remove();
            }
        });
    }

    // Voice Notes
    openVoiceNotes() {
        const modal = `
            <div class="ai-modal ai-voice-modal">
                <div class="ai-modal-header">
                    <h3>Voice Notes</h3>
                    <button class="close-btn" onclick="this.closest('.ai-modal').remove()">×</button>
                </div>
                <div class="voice-container">
                    <div class="recording-controls">
                        <button id="recordBtn" class="btn btn-primary" onclick="aiTools.startRecording()">
                            <i class="fas fa-microphone"></i> Start Recording
                        </button>
                        <button id="stopBtn" class="btn btn-danger" onclick="aiTools.stopRecording()" disabled>
                            <i class="fas fa-stop"></i> Stop
                        </button>
                        <button id="uploadBtn" class="btn btn-success" onclick="aiTools.uploadVoiceNote()" disabled>
                            <i class="fas fa-upload"></i> Upload
                        </button>
                    </div>
                    <div id="voiceTranscript" class="voice-transcript"></div>
                </div>
            </div>
        `;

        const container = document.createElement('div');
        container.innerHTML = modal;
        document.body.appendChild(container.firstElementChild);
    }

    startRecording() {
        navigator.mediaDevices.getUserMedia({ audio: true })
            .then(stream => {
                this.audioStream = stream;
                this.mediaRecorder = new MediaRecorder(stream);
                this.audioChunks = [];
                
                this.mediaRecorder.ondataavailable = (e) => {
                    this.audioChunks.push(e.data);
                };

                this.mediaRecorder.start();
                document.getElementById('recordBtn').disabled = true;
                document.getElementById('stopBtn').disabled = false;
            });
    }

    stopRecording() {
        this.mediaRecorder.stop();
        document.getElementById('recordBtn').disabled = false;
        document.getElementById('stopBtn').disabled = true;
        document.getElementById('uploadBtn').disabled = false;
    }

    uploadVoiceNote() {
        const audioBlob = new Blob(this.audioChunks, { type: 'audio/wav' });
        const formData = new FormData();
        formData.append('audio', audioBlob);
        formData.append('language', 'en');

        fetch('api/ai_tools.php?tool=voice_notes&action=upload_recording', {
            method: 'POST',
            body: formData
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                document.getElementById('voiceTranscript').innerHTML = `
                    <h4>Transcription</h4>
                    <p>${data.transcript}</p>
                    <button class="btn btn-primary" onclick="aiTools.createFollowUpTask()">Create Task</button>
                `;
            }
        });
    }

    // Analytics
    openAnalytics() {
        const modal = `
            <div class="ai-modal ai-analytics-modal">
                <div class="ai-modal-header">
                    <h3>AI Analytics</h3>
                    <button class="close-btn" onclick="this.closest('.ai-modal').remove()">×</button>
                </div>
                <form id="analyticsForm" class="ai-modal-body">
                    <div class="form-group">
                        <label>Business Question</label>
                        <textarea name="question" placeholder="What would you like to analyze?" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Time Window</label>
                        <input type="date" name="start_date">
                        <input type="date" name="end_date">
                    </div>
                    <button type="submit" class="btn btn-primary">Analyze</button>
                </form>
            </div>
        `;

        const container = document.createElement('div');
        container.innerHTML = modal;
        document.body.appendChild(container.firstElementChild);

        document.getElementById('analyticsForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const data = new FormData(e.target);
            
            fetch('api/ai_tools.php?tool=analytics&action=analyze', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(Object.fromEntries(data))
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    this.showAnalyticsResults(data.analysis);
                }
            });
        });
    }

    showAnalyticsResults(analysis) {
        const resultsHtml = `
            <div class="ai-modal ai-results-modal">
                <div class="ai-modal-header">
                    <h3>Analysis Results</h3>
                    <button class="close-btn" onclick="this.closest('.ai-modal').remove()">×</button>
                </div>
                <div class="results-content">
                    <pre>${JSON.stringify(analysis, null, 2)}</pre>
                </div>
            </div>
        `;

        document.querySelector('.ai-analytics-modal').remove();
        const container = document.createElement('div');
        container.innerHTML = resultsHtml;
        document.body.appendChild(container.firstElementChild);
    }

    // Common methods
    approveAIOutput(jobId) {
        fetch(`api/ai_tools.php?tool=job_status&action=review&job_id=${jobId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'approved' })
        })
        .then(r => r.json())
        .then(data => alert('Output approved!'));
    }

    rejectAIOutput(jobId) {
        const reason = prompt('Reason for rejection:');
        if (reason) {
            fetch(`api/ai_tools.php?tool=job_status&action=review&job_id=${jobId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: 'rejected', comments: reason })
            })
            .then(r => r.json())
            .then(data => alert('Output rejected!'));
        }
    }
}

// Initialize
const aiTools = new AITools();
