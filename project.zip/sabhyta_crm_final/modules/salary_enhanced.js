/**
 * ENHANCED SALARY MODULE
 * Professional salary processing with multiple options
 * Includes auto-population and report generation
 */

const SALARY_MODULE = {
    currentMode: 'individual', // individual, bulk, fy_report
    
    // Initialize the salary module UI
    init: async function() {
        console.log('Initializing Enhanced Salary Module...');
        this.setupEventListeners();
        this.loadEmployeeData();
    },

    // Setup event listeners
    setupEventListeners: function() {
        const self = this;
        
        // Mode selection tabs
        document.querySelectorAll('.salary-mode-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.salary-mode-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                self.currentMode = e.target.dataset.mode;
                self.renderModeUI();
            });
        });

        // Process buttons
        if (document.getElementById('processIndividualBtn')) {
            document.getElementById('processIndividualBtn').addEventListener('click', () => self.processIndividualSalary());
        }
        if (document.getElementById('processBulkBtn')) {
            document.getElementById('processBulkBtn').addEventListener('click', () => self.processBulkSalary());
        }
        if (document.getElementById('generateReportBtn')) {
            document.getElementById('generateReportBtn').addEventListener('click', () => self.generateFinancialYearReport());
        }
    },

    // Render mode-specific UI
    renderModeUI: function() {
        const container = document.getElementById('salaryModeContainer');
        
        switch(this.currentMode) {
            case 'individual':
                container.innerHTML = this.getIndividualModeUI();
                this.setupIndividualListeners();
                break;
            case 'bulk':
                container.innerHTML = this.getBulkModeUI();
                this.setupBulkListeners();
                break;
            case 'fy_report':
                container.innerHTML = this.getFYReportModeUI();
                this.setupFYListeners();
                break;
        }
    },

    // Individual Salary Processing UI
    getIndividualModeUI: function() {
        const currentMonth = new Date().getMonth() + 1;
        const currentYear = new Date().getFullYear();

        return `
            <div class="salary-mode-card">
                <h3><i class="fas fa-user"></i> Individual Employee Salary Processing</h3>
                <p class="subtitle">Process salary for a single employee for a specific month</p>

                <div class="form-group">
                    <label>Select Employee *</label>
                    <select id="salaryEmployee" class="form-control">
                        <option value="">-- Select Employee --</option>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Month *</label>
                        <select id="salaryMonth" class="form-control">
                            ${this.generateMonthOptions(currentMonth)}
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Year *</label>
                        <select id="salaryYear" class="form-control">
                            ${this.generateYearOptions(currentYear)}
                        </select>
                    </div>
                </div>

                <div class="checklist-section">
                    <h4>Pre-Processing Checklist</h4>
                    <div class="checklist">
                        <div class="checklist-item">
                            <input type="checkbox" id="check_emp_details" class="salary-check">
                            <label for="check_emp_details">Employee details verified</label>
                        </div>
                        <div class="checklist-item">
                            <input type="checkbox" id="check_salary_comp" class="salary-check">
                            <label for="check_salary_comp">Salary components confirmed</label>
                        </div>
                        <div class="checklist-item">
                            <input type="checkbox" id="check_deductions" class="salary-check">
                            <label for="check_deductions">All deductions validated</label>
                        </div>
                        <div class="checklist-item">
                            <input type="checkbox" id="check_compliance" class="salary-check">
                            <label for="check_compliance">Statutory compliance checked</label>
                        </div>
                        <div class="checklist-item">
                            <input type="checkbox" id="check_approval" class="salary-check">
                            <label for="check_approval">Approval obtained</label>
                        </div>
                    </div>
                    <div id="checklistMsg" class="checklist-msg"></div>
                </div>

                <button type="button" id="processIndividualBtn" class="btn-primary" disabled>
                    <i class="fas fa-check-circle"></i> Process Salary
                </button>
            </div>
        `;
    },

    // Bulk Salary Processing UI
    getBulkModeUI: function() {
        const currentMonth = new Date().getMonth() + 1;
        const currentYear = new Date().getFullYear();

        return `
            <div class="salary-mode-card">
                <h3><i class="fas fa-users"></i> Bulk Salary Processing</h3>
                <p class="subtitle">Process salary for entire department or branch</p>

                <div class="form-row">
                    <div class="form-group">
                        <label>Select Department</label>
                        <select id="bulkDepartment" class="form-control">
                            <option value="">-- All Departments --</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Select Branch</label>
                        <select id="bulkBranch" class="form-control">
                            <option value="">-- All Branches --</option>
                            <option value="Mumbai">Mumbai</option>
                            <option value="Delhi">Delhi</option>
                            <option value="Bangalore">Bangalore</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Month *</label>
                        <select id="bulkMonth" class="form-control">
                            ${this.generateMonthOptions(currentMonth)}
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Year *</label>
                        <select id="bulkYear" class="form-control">
                            ${this.generateYearOptions(currentYear)}
                        </select>
                    </div>
                </div>

                <div class="info-box">
                    <i class="fas fa-info-circle"></i>
                    <span>This will process salary for all active employees matching the criteria</span>
                </div>

                <button type="button" id="processBulkBtn" class="btn-primary">
                    <i class="fas fa-cog"></i> Process Bulk Salary
                </button>

                <div id="bulkResultsContainer" style="display:none; margin-top:20px;">
                    <h4>Processing Results</h4>
                    <div id="bulkResults"></div>
                </div>
            </div>
        `;
    },

    // Financial Year Report UI
    getFYReportModeUI: function() {
        const currentYear = new Date().getFullYear();
        const fy = (new Date().getMonth() < 3) ? currentYear - 1 : currentYear;

        return `
            <div class="salary-mode-card">
                <h3><i class="fas fa-chart-bar"></i> Financial Year Report</h3>
                <p class="subtitle">Generate comprehensive FY salary summary and analysis</p>

                <div class="form-group">
                    <label>Financial Year</label>
                    <input type="text" id="fyYear" class="form-control" value="${fy}" readonly>
                    <small>FY ${fy}-${fy + 1}</small>
                </div>

                <div class="form-group">
                    <label>Employee (Optional)</label>
                    <select id="fyEmployee" class="form-control">
                        <option value="">-- All Employees --</option>
                    </select>
                </div>

                <div class="report-options">
                    <h4>Report Format</h4>
                    <div class="option-group">
                        <input type="radio" id="fmt_pdf" name="fyFormat" value="pdf" checked>
                        <label for="fmt_pdf"><i class="fas fa-file-pdf"></i> PDF Report</label>
                    </div>
                    <div class="option-group">
                        <input type="radio" id="fmt_excel" name="fyFormat" value="excel">
                        <label for="fmt_excel"><i class="fas fa-file-excel"></i> Excel Summary</label>
                    </div>
                </div>

                <button type="button" id="generateReportBtn" class="btn-primary">
                    <i class="fas fa-download"></i> Generate Report
                </button>

                <div id="reportPreview" style="display:none; margin-top:20px;">
                    <h4>Report Preview</h4>
                    <div id="reportData"></div>
                </div>
            </div>
        `;
    },

    // Helper functions
    generateMonthOptions: function(selected = null) {
        const months = ['January', 'February', 'March', 'April', 'May', 'June',
                       'July', 'August', 'September', 'October', 'November', 'December'];
        let html = '';
        months.forEach((month, index) => {
            const value = (index + 1).toString().padStart(2, '0');
            const sel = (index + 1) === selected ? 'selected' : '';
            html += `<option value="${value}" ${sel}>${month}</option>`;
        });
        return html;
    },

    generateYearOptions: function(selected = null) {
        let html = '';
        for (let year = 2020; year <= selected + 1; year++) {
            const sel = year === selected ? 'selected' : '';
            html += `<option value="${year}" ${sel}>${year}</option>`;
        }
        return html;
    },

    // Load employee data
    loadEmployeeData: async function() {
        try {
            const response = await fetch('api/salary_processing.php?action=get_employees');
            const data = await response.json();

            if (data.status === 'success') {
                const select = document.getElementById('salaryEmployee');
                if (select) {
                    select.innerHTML = '<option value="">-- Select Employee --</option>';
                    data.employees.forEach(emp => {
                        const option = document.createElement('option');
                        option.value = emp.id;
                        option.textContent = `${emp.first_name} ${emp.last_name} (${emp.employee_code})`;
                        select.appendChild(option);
                    });
                }
            }
        } catch (error) {
            console.error('Error loading employees:', error);
        }
    },

    // Setup individual listeners
    setupIndividualListeners: function() {
        const checkboxes = document.querySelectorAll('.salary-check');
        const processBtn = document.getElementById('processIndividualBtn');
        const checklistMsg = document.getElementById('checklistMsg');

        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                const allChecked = Array.from(checkboxes).every(cb => cb.checked);
                
                if (allChecked) {
                    processBtn.disabled = false;
                    processBtn.style.background = '#4caf50';
                    checklistMsg.innerHTML = '<i class="fas fa-check-circle"></i> All items verified. Ready to process.';
                    checklistMsg.style.color = '#4caf50';
                } else {
                    processBtn.disabled = true;
                    processBtn.style.background = '#ccc';
                    checklistMsg.innerHTML = '';
                }
            });
        });
    },

    // Setup bulk listeners
    setupBulkListeners: function() {
        // Load departments
        this.loadDepartmentsForBulk();
    },

    // Setup FY listeners
    setupFYListeners: function() {
        this.loadEmployeesForFY();
    },

    // Process individual salary
    processIndividualSalary: async function() {
        const employeeId = document.getElementById('salaryEmployee').value;
        const month = document.getElementById('salaryMonth').value;
        const year = document.getElementById('salaryYear').value;

        if (!employeeId || !month || !year) {
            alert('Please select employee, month, and year');
            return;
        }

        try {
            const response = await fetch('api/salary_processing.php?action=process_individual', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({employee_id: employeeId, month: month, year: year})
            });

            const data = await response.json();

            if (data.status === 'success') {
                this.showSalarySlipPreview(data);
            } else {
                alert('Error: ' + data.error);
            }
        } catch (error) {
            console.error('Error processing salary:', error);
            alert('Error processing salary');
        }
    },

    // Process bulk salary
    processBulkSalary: async function() {
        const department = document.getElementById('bulkDepartment').value;
        const branch = document.getElementById('bulkBranch').value;
        const month = document.getElementById('bulkMonth').value;
        const year = document.getElementById('bulkYear').value;

        try {
            const response = await fetch('api/salary_processing.php?action=process_bulk', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    department: department || null,
                    branch: branch || null,
                    month: month,
                    year: year
                })
            });

            const data = await response.json();

            if (data.status === 'success') {
                const resultsContainer = document.getElementById('bulkResultsContainer');
                const resultsList = data.slips.map(slip => 
                    `<div class="result-item">✓ ${slip.employee_name} - ₹${slip.net_salary}</div>`
                ).join('');

                document.getElementById('bulkResults').innerHTML = `
                    <div class="success-box">
                        <p><strong>Total Processed:</strong> ${data.total_processed}</p>
                        <p><strong>Total Net Salary:</strong> ₹${data.total_net_salary.toLocaleString()}</p>
                        <p><strong>Period:</strong> ${data.period}</p>
                        <h5>Processed Slips:</h5>
                        ${resultsList}
                    </div>
                `;
                resultsContainer.style.display = 'block';
            }
        } catch (error) {
            console.error('Error processing bulk salary:', error);
        }
    },

    // Generate financial year report
    generateFinancialYearReport: async function() {
        const fy = document.getElementById('fyYear').value;
        const employeeId = document.getElementById('fyEmployee').value;
        const format = document.querySelector('input[name="fyFormat"]:checked').value;

        try {
            const response = await fetch('api/salary_report_generator.php?action=generate_fy_summary_excel', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    financial_year: fy,
                    employee_id: employeeId || null
                })
            });

            const data = await response.json();

            if (data.status === 'success') {
                // Download the report
                const element = document.createElement('a');
                element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(data.content));
                element.setAttribute('download', data.filename);
                element.style.display = 'none';
                document.body.appendChild(element);
                element.click();
                document.body.removeChild(element);
            }
        } catch (error) {
            console.error('Error generating report:', error);
        }
    },

    // Show salary slip preview
    showSalarySlipPreview: function(data) {
        alert(`Salary Slip Created!\n\nEmployee: ${data.employee.name}\nPeriod: ${data.period}\nNet Salary: ₹${data.salary_details.net_salary}`);
        // Here you can show a detailed preview or download option
    },

    // Load departments for bulk processing
    loadDepartmentsForBulk: async function() {
        try {
            const response = await fetch('api/departments.php');
            const data = await response.json();

            if (data.success && data.data) {
                const select = document.getElementById('bulkDepartment');
                select.innerHTML = '<option value="">-- All Departments --</option>';
                data.data.forEach(dept => {
                    const option = document.createElement('option');
                    option.value = dept.id;
                    option.textContent = dept.department_name;
                    select.appendChild(option);
                });
            }
        } catch (error) {
            console.error('Error loading departments:', error);
        }
    },

    // Load employees for FY report
    loadEmployeesForFY: async function() {
        await this.loadEmployeeData();
    }
};

/**
 * QUOTATION TO SALES ORDER AUTO-POPULATION
 */

const QUOTATION_TO_ORDER = {
    currentQuotationData: null,

    // Get quotation details
    getQuotationData: async function(quotationNumber) {
        try {
            const response = await fetch(`api/quotation_to_order.php?action=get&quotation_number=${encodeURIComponent(quotationNumber)}`);
            const data = await response.json();

            if (data.status === 'success') {
                this.currentQuotationData = data.quotation;
                return data.quotation;
            }
            return null;
        } catch (error) {
            console.error('Error fetching quotation:', error);
            return null;
        }
    },

    // Auto-populate sales order from quotation
    autoPopulateOrder: async function(quotationNumber) {
        try {
            const response = await fetch('api/quotation_to_order.php?action=auto_populate', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({quotation_number: quotationNumber})
            });

            const data = await response.json();

            if (data.status === 'success') {
                this.populateFormFields(data.populatedData);
                return true;
            }
            return false;
        } catch (error) {
            console.error('Error auto-populating:', error);
            return false;
        }
    },

    // Populate form fields
    populateFormFields: function(data) {
        // Populate customer info
        if (data.customer) {
            this.setFieldValue('soCustomerName', data.customer.name);
            this.setFieldValue('soCustomerCode', data.customer.code);
            this.setFieldValue('soCustomerEmail', data.customer.email);
            this.setFieldValue('soCustomerMobile', data.customer.mobile);
            this.setFieldValue('soCustomerAddress', data.customer.address);
            this.setFieldValue('soCustomerCity', data.customer.city);
            this.setFieldValue('soCustomerState', data.customer.state);
            this.setFieldValue('soCustomerGST', data.customer.gst);
        }

        // Populate quotation reference
        if (data.quotation) {
            this.setFieldValue('soQuotationNumber', data.quotation.number);
            this.setFieldValue('soQuotationDate', data.quotation.date);
        }

        // Populate sales executive
        if (data.salesExecutive) {
            this.setFieldValue('soSalesExecutive', data.salesExecutive.name);
        }

        // Populate items
        if (data.items && data.items.length > 0) {
            this.populateItems(data.items);
        }

        // Populate commercial terms
        if (data.commercialTerms) {
            this.setFieldValue('soPaymentTerms', data.commercialTerms.paymentTerms);
            this.setFieldValue('soDeliveryTerms', data.commercialTerms.deliveryTerms);
            this.setFieldValue('soWarranty', data.commercialTerms.warranty);
            this.setFieldValue('soNotes', data.commercialTerms.notes);
        }

        // Populate totals
        if (data.totals) {
            this.setFieldValue('soSubtotal', data.totals.subtotal);
            this.setFieldValue('soDiscount', data.totals.discount);
            this.setFieldValue('soTax', data.totals.tax);
            this.setFieldValue('soTotal', data.totals.total);
            this.setFieldValue('soCurrency', data.totals.currency);
        }
    },

    // Populate line items
    populateItems: function(items) {
        const itemsContainer = document.getElementById('soItemsContainer');
        if (!itemsContainer) return;

        itemsContainer.innerHTML = '';

        items.forEach((item, index) => {
            const itemHTML = `
                <div class="order-item" data-item-id="${index}">
                    <div class="item-row">
                        <input type="text" class="item-product" value="${item.productService}" placeholder="Product/Service">
                        <input type="text" class="item-description" value="${item.description}" placeholder="Description">
                        <input type="number" class="item-qty" value="${item.quantity}" placeholder="Qty">
                        <input type="text" class="item-unit" value="${item.unit}" placeholder="Unit">
                        <input type="number" class="item-rate" value="${item.rate}" placeholder="Rate">
                        <input type="number" class="item-discount" value="${item.discount || 0}" placeholder="Discount %">
                        <span class="item-amount">${item.amount || (item.quantity * item.rate)}</span>
                        <button type="button" class="btn-remove" onclick="QUOTATION_TO_ORDER.removeItem(${index})">✕</button>
                    </div>
                </div>
            `;
            itemsContainer.innerHTML += itemHTML;
        });

        // Add item calculation listeners
        document.querySelectorAll('.item-qty, .item-rate, .item-discount').forEach(input => {
            input.addEventListener('change', () => this.calculateItemAmount(input));
        });
    },

    // Utility functions
    setFieldValue: function(fieldId, value) {
        const field = document.getElementById(fieldId);
        if (field) {
            field.value = value || '';
        }
    },

    calculateItemAmount: function(input) {
        const itemRow = input.closest('.order-item');
        const qty = parseFloat(itemRow.querySelector('.item-qty').value) || 0;
        const rate = parseFloat(itemRow.querySelector('.item-rate').value) || 0;
        const discount = parseFloat(itemRow.querySelector('.item-discount').value) || 0;

        const amount = (qty * rate) * (1 - discount / 100);
        itemRow.querySelector('.item-amount').textContent = amount.toFixed(2);
    },

    removeItem: function(index) {
        document.querySelector(`[data-item-id="${index}"]`).remove();
    },

    // Convert quotation to sales order
    convertToOrder: async function() {
        const customerId = document.getElementById('soCustomerId').value;
        const orderData = this.getFormData();

        try {
            const response = await fetch('api/quotation_to_order.php?action=convert_and_create', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    quotation_number: this.currentQuotationData.quotation.number,
                    customer_id: customerId,
                    sales_order_data: orderData
                })
            });

            const data = await response.json();

            if (data.status === 'success') {
                alert(`Sales Order ${data.sales_order_number} created successfully!`);
                window.location.reload();
            }
        } catch (error) {
            console.error('Error converting to order:', error);
        }
    },

    // Get form data
    getFormData: function() {
        return {
            items: this.getItems(),
            commercialTerms: {
                paymentTerms: document.getElementById('soPaymentTerms').value,
                deliveryTerms: document.getElementById('soDeliveryTerms').value,
                warranty: document.getElementById('soWarranty').value,
                notes: document.getElementById('soNotes').value
            },
            totals: {
                subtotal: parseFloat(document.getElementById('soSubtotal').value) || 0,
                discount: parseFloat(document.getElementById('soDiscount').value) || 0,
                tax: parseFloat(document.getElementById('soTax').value) || 0,
                total: parseFloat(document.getElementById('soTotal').value) || 0,
                currency: document.getElementById('soCurrency').value
            }
        };
    },

    // Get items from form
    getItems: function() {
        const items = [];
        document.querySelectorAll('.order-item').forEach(itemRow => {
            items.push({
                productService: itemRow.querySelector('.item-product').value,
                description: itemRow.querySelector('.item-description').value,
                quantity: parseFloat(itemRow.querySelector('.item-qty').value),
                unit: itemRow.querySelector('.item-unit').value,
                rate: parseFloat(itemRow.querySelector('.item-rate').value),
                discount: parseFloat(itemRow.querySelector('.item-discount').value) || 0,
                amount: parseFloat(itemRow.querySelector('.item-amount').textContent)
            });
        });
        return items;
    }
};

// Initialize modules when document is ready
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('salaryModeContainer')) {
        SALARY_MODULE.init();
    }
});
