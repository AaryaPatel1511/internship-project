/* =========================================================
   REPORTS MODULE
   ---------------------------------------------------------
   Powers every leaf under the "Reports" sidebar section with
   real, live data pulled from api/reports.php (which in turn
   reads the exact same tables every other module already
   writes to — leads, customers, employees, sales_orders,
   generic_records). Every report gets:
     - a filter bar (date range + relevant dropdowns)
     - a "Total / Today / This Month / Last Month / Growth%"
       summary strip plus report-specific KPI cards
     - Pie / Bar / Line(area) charts
     - a searchable, sortable, paginated table with
       column show/hide, Export Excel, Export PDF, Print and
       Email Report
   Custom Reports gets its own ad-hoc report builder.
   ========================================================= */

const REPORT_DEFS = {
  'CRM Reports':          { key: 'crm',          icon: 'fa-user-plus',        title: 'CRM Reports',          sub: 'Lead performance across the sales pipeline' },
  'Sales Reports':        { key: 'sales',        icon: 'fa-chart-line',       title: 'Sales Reports',        sub: 'Orders, revenue and collections' },
  'Customer Reports':     { key: 'customer',     icon: 'fa-user-friends',     title: 'Customer Reports',     sub: 'Customer base health and lifetime value' },
  'Employee Reports':     { key: 'employee',     icon: 'fa-users',            title: 'Employee Reports',     sub: 'Headcount, department & designation mix' },
  'Attendance Reports':   { key: 'attendance',   icon: 'fa-clipboard-check',  title: 'Attendance Reports',   sub: 'Present / absent / leave, from HRMS > Attendance' },
  'Payroll Reports':      { key: 'payroll',      icon: 'fa-sack-dollar',      title: 'Payroll Reports',      sub: 'Gross, net, PF, ESIC & professional tax' },
  'Project Reports':      { key: 'project',      icon: 'fa-diagram-project',  title: 'Project Reports',      sub: 'Projects, tasks & delivery status' },
  'Inventory Reports':    { key: 'inventory',    icon: 'fa-box-open',         title: 'Inventory Reports',    sub: 'Stock, purchases and product movement' },
  'Financial Reports':    { key: 'financial',    icon: 'fa-wallet',           title: 'Financial Reports',    sub: 'Income, expense, profit & receivables' },
  'Support Reports':      { key: 'support',      icon: 'fa-headset',         title: 'Support Reports',      sub: 'Tickets, resolution time & workload' },
  'Productivity Reports': { key: 'productivity', icon: 'fa-gauge-high',       title: 'Productivity Reports', sub: 'Task completion, attendance & follow-ups' },
  'Custom Reports':       { key: 'custom',       icon: 'fa-sliders',          title: 'Custom Reports',       sub: 'Build your own report — pick a source, columns & filters' },
};

// Which filter fields each report type shows, and how the value maps
// to the api/reports.php query param (see FIELD_RENDERERS below).
const REPORT_FILTERS = {
  crm:          ['date', 'status:lead', 'source', 'city', 'state', 'branch', 'employee:name'],
  sales:        ['date', 'status:order', 'branch', 'employee:id', 'customer:id'],
  customer:     ['date', 'status:active', 'city', 'state', 'customer_type', 'industry'],
  employee:     ['date', 'status:employment', 'department', 'designation', 'branch', 'city', 'state'],
  attendance:   ['date', 'status:attendance', 'employee:name'],
  payroll:      ['department', 'status:employment', 'branch'],
  project:      ['date', 'status:generic', 'employee:name', 'customer:name'],
  inventory:    ['date', 'status:generic'],
  financial:    ['date'],
  support:      ['date', 'status:generic', 'employee:name'],
  productivity: ['date', 'employee:name'],
};

const STATUS_OPTIONS = {
  lead: null, // populated live from filters meta (lead_statuses)
  order: null, // populated live (order_statuses)
  active: ['Active', 'Inactive'],
  employment: ['Active', 'Resigned', 'Terminated', 'On Notice'],
  attendance: ['Present', 'Absent', 'Half Day', 'On Leave', 'Holiday'],
  generic: ['Active', 'Pending', 'Completed'],
};

let RPT_FILTERS_META = null;
let RPT_STATE = { key: null, filters: {}, table: null };

async function getFiltersMeta() {
  if (RPT_FILTERS_META) return RPT_FILTERS_META;
  try {
    const res = await fetch('api/reports.php?type=filters');
    const json = await res.json();
    RPT_FILTERS_META = json.success ? json.data : {};
  } catch (e) {
    RPT_FILTERS_META = {};
  }
  return RPT_FILTERS_META;
}

function routeReportsLeaf(itemLabel, sectionLabel, backAction, backLabel) {
  if (sectionLabel !== 'Reports' || !REPORT_DEFS[itemLabel]) return false;
  const def = REPORT_DEFS[itemLabel];
  if (def.key === 'custom') {
    renderCustomReportPage(backAction, backLabel);
  } else {
    renderReportPage(def, backAction, backLabel);
  }
  return true;
}

/* ---------------------------------------------------------
   Filter bar rendering
   --------------------------------------------------------- */
function filterFieldHTML(spec, meta) {
  const [kind, mode] = spec.split(':');
  if (kind === 'date') {
    return `
      <div class="rpt-field"><label>Date From</label><input type="date" data-filter="date_from"></div>
      <div class="rpt-field"><label>Date To</label><input type="date" data-filter="date_to"></div>`;
  }
  if (kind === 'status') {
    let options = STATUS_OPTIONS[mode];
    if (mode === 'lead') options = meta.lead_statuses || [];
    if (mode === 'order') options = meta.order_statuses || [];
    return `<div class="rpt-field"><label>Status</label>
      <select data-filter="status"><option value="">All</option>
      ${(options || []).map(o => `<option value="${esc(o)}">${esc(o)}</option>`).join('')}
      </select></div>`;
  }
  if (kind === 'department') {
    return `<div class="rpt-field"><label>Department</label>
      <select data-filter="department"><option value="">All</option>
      ${(meta.departments || []).map(d => `<option value="${d.id}">${esc(d.name)}</option>`).join('')}
      </select></div>`;
  }
  if (kind === 'designation') {
    return `<div class="rpt-field"><label>Designation</label>
      <select data-filter="designation"><option value="">All</option>
      ${(meta.designations || []).map(d => `<option value="${d.id}">${esc(d.name)}</option>`).join('')}
      </select></div>`;
  }
  if (kind === 'employee') {
    const useId = mode === 'id';
    return `<div class="rpt-field"><label>Employee</label>
      <select data-filter="employee">
      <option value="">All</option>
      ${(meta.employees || []).map(e => `<option value="${esc(useId ? e.id : e.name)}">${esc(e.name)}</option>`).join('')}
      </select></div>`;
  }
  if (kind === 'customer') {
    const useId = mode === 'id';
    return `<div class="rpt-field"><label>Customer</label>
      <select data-filter="customer">
      <option value="">All</option>
      ${(meta.customers || []).map(c => `<option value="${esc(useId ? c.id : c.name)}">${esc(c.name)}</option>`).join('')}
      </select></div>`;
  }
  if (kind === 'city') {
    return `<div class="rpt-field"><label>City</label>
      <select data-filter="city"><option value="">All</option>
      ${(meta.cities || []).map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join('')}
      </select></div>`;
  }
  if (kind === 'state') {
    return `<div class="rpt-field"><label>State</label>
      <select data-filter="state"><option value="">All</option>
      ${(meta.states || []).map(s => `<option value="${esc(s)}">${esc(s)}</option>`).join('')}
      </select></div>`;
  }
  if (kind === 'branch') {
    return `<div class="rpt-field"><label>Branch</label>
      <select data-filter="branch"><option value="">All</option>
      ${(meta.branches || []).map(b => `<option value="${esc(b)}">${esc(b)}</option>`).join('')}
      </select></div>`;
  }
  if (kind === 'source') {
    return `<div class="rpt-field"><label>Source</label>
      <select data-filter="source"><option value="">All</option>
      ${(meta.sources || []).map(s => `<option value="${esc(s)}">${esc(s)}</option>`).join('')}
      </select></div>`;
  }
  if (kind === 'customer_type') {
    return `<div class="rpt-field"><label>Customer Type</label>
      <select data-filter="customer_type"><option value="">All</option>
      ${(meta.customer_types || []).map(s => `<option value="${esc(s)}">${esc(s)}</option>`).join('')}
      </select></div>`;
  }
  if (kind === 'industry') {
    return `<div class="rpt-field"><label>Industry</label>
      <select data-filter="industry"><option value="">All</option>
      ${(meta.industries || []).map(s => `<option value="${esc(s)}">${esc(s)}</option>`).join('')}
      </select></div>`;
  }
  return '';
}

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}

/* ---------------------------------------------------------
   Main report page (all 11 standard report types)
   --------------------------------------------------------- */
async function renderReportPage(def, backAction, backLabel) {
  destroyCharts();
  RPT_STATE = { key: def.key, filters: {}, table: null };

  mainContent.innerHTML = `
    <button class="back-btn" id="rptBackBtn"><i class="fas fa-arrow-left"></i> Back to ${backLabel}</button>
    <div class="eyebrow">Reports <span class="crumb-sep">/</span> <span class="crumb-current">${def.title}</span></div>
    <div class="page-title">
      <span><i class="fas ${def.icon}" style="color:var(--accent-orange);margin-right:10px;"></i>${def.title}</span>
      <div class="actions">
        <button class="rpt-btn" id="rptExcelBtn"><i class="fas fa-file-excel"></i> Export Excel</button>
        <button class="rpt-btn" id="rptPdfBtn"><i class="fas fa-file-pdf"></i> Export PDF</button>
        <button class="rpt-btn" id="rptPrintBtn"><i class="fas fa-print"></i> Print</button>
        <button class="rpt-btn" id="rptEmailBtn"><i class="fas fa-envelope"></i> Email Report</button>
      </div>
    </div>
    <div class="panel-sub" style="margin:-10px 0 16px;">${def.sub}</div>

    <div class="rpt-filter-bar" id="rptFilterBar">
      <div class="rpt-filter-head" id="rptFilterHead">
        <div class="rpt-filter-title"><i class="fas fa-filter"></i>Search Filters</div>
        <i class="fas fa-chevron-down"></i>
      </div>
      <div class="rpt-filter-body" id="rptFilterBody"><div class="muted">Loading filters…</div></div>
      <div class="rpt-filter-actions">
        <button class="rpt-btn rpt-btn-primary" id="rptApplyBtn"><i class="fas fa-magnifying-glass"></i> Apply Filters</button>
        <button class="rpt-btn" id="rptResetBtn"><i class="fas fa-rotate-left"></i> Reset</button>
      </div>
    </div>

    <div id="rptNoteWrap"></div>

    <div class="stat-grid" id="rptStatGrid"><div class="stat-card"><div class="stat-label">Loading report…</div></div></div>

    <div class="rpt-chart-grid three" id="rptChartGrid">
      <div class="panel"><div class="panel-head"><div><div class="panel-title" id="rptPieTitle">Distribution</div></div></div>
        <div class="chart-canvas-wrap donut"><canvas id="rptPieChart"></canvas></div>
        <div id="rptPieLegend"></div>
      </div>
      <div class="panel"><div class="panel-head"><div><div class="panel-title" id="rptBarTitle">Breakdown</div></div></div>
        <div class="chart-canvas-wrap"><canvas id="rptBarChart"></canvas></div>
      </div>
      <div class="panel"><div class="panel-head"><div><div class="panel-title" id="rptLineTitle">Trend</div></div></div>
        <div class="chart-canvas-wrap"><canvas id="rptLineChart"></canvas></div>
      </div>
    </div>

    <div id="rptExtraWrap"></div>

    <div class="table-panel">
      <div class="panel-head"><div><div class="panel-title">Detailed Records</div><div class="panel-sub">Live from the database — matches the filters above</div></div></div>
      <div class="rpt-toolbar">
        <div class="rpt-search"><i class="fas fa-search"></i><input type="text" id="rptTableSearch" placeholder="Search this table…"></div>
        <div class="rpt-actions">
          <div class="rpt-col-menu-wrap">
            <button class="rpt-btn" id="rptColBtn"><i class="fas fa-table-columns"></i> Columns</button>
            <div class="rpt-col-menu" id="rptColMenu"></div>
          </div>
        </div>
      </div>
      <div class="table-scroll"><table class="data-table" id="rptDataTable">
        <thead><tr id="rptTableHead"></tr></thead>
        <tbody id="rptTableBody"><tr><td>Loading…</td></tr></tbody>
      </table></div>
      <div class="rpt-pagination" id="rptPagination"></div>
    </div>
  `;

  document.getElementById('rptBackBtn').addEventListener('click', backAction);
  document.getElementById('rptFilterHead').addEventListener('click', () => {
    document.getElementById('rptFilterBar').classList.toggle('collapsed');
  });

  const meta = await getFiltersMeta();
  const fields = REPORT_FILTERS[def.key] || [];
  document.getElementById('rptFilterBody').innerHTML = fields.map(f => filterFieldHTML(f, meta)).join('') || '<div class="muted">No filters for this report.</div>';

  document.getElementById('rptApplyBtn').addEventListener('click', () => loadReportData(def));
  document.getElementById('rptResetBtn').addEventListener('click', () => {
    document.querySelectorAll('#rptFilterBody [data-filter]').forEach(el => el.value = '');
    loadReportData(def);
  });
  document.getElementById('rptExcelBtn').addEventListener('click', () => exportTableExcel(def.title));
  document.getElementById('rptPdfBtn').addEventListener('click', () => exportTablePDF(def.title));
  document.getElementById('rptPrintBtn').addEventListener('click', () => window.print());
  document.getElementById('rptEmailBtn').addEventListener('click', () => emailReport(def.title));

  await loadReportData(def);
}

function collectFilters() {
  const params = {};
  document.querySelectorAll('#rptFilterBody [data-filter]').forEach(el => {
    if (el.value) params[el.dataset.filter] = el.value;
  });
  return params;
}

async function loadReportData(def) {
  const params = collectFilters();
  RPT_STATE.filters = params;
  const qs = new URLSearchParams(Object.assign({ type: def.key }, params)).toString();

  document.getElementById('rptStatGrid').innerHTML = `<div class="stat-card"><div class="stat-label">Loading…</div></div>`;
  document.getElementById('rptTableBody').innerHTML = `<tr><td>Loading…</td></tr>`;

  let data;
  try {
    const res = await fetch(`api/reports.php?${qs}`);
    const json = await res.json();
    if (!json.success) throw new Error(json.message || 'Failed to load report');
    data = json.data;
  } catch (err) {
    document.getElementById('rptStatGrid').innerHTML = `<div class="stat-card"><div class="stat-label">Could not load report: ${esc(err.message)}</div></div>`;
    return;
  }

  // Cards
  document.getElementById('rptStatGrid').innerHTML = (data.cards || []).map(c => `
    <div class="stat-card" style="--stat-accent:${c.accent || '#2563eb'}">
      <div class="stat-label"><i class="fas ${c.icon || 'fa-chart-simple'}"></i> ${esc(c.label)}</div>
      <div class="stat-value">${c.value}</div>
    </div>`).join('') || '<div class="stat-card"><div class="stat-label">No data</div></div>';

  document.getElementById('rptNoteWrap').innerHTML = data.note
    ? `<div class="rpt-note"><i class="fas fa-circle-info"></i>${esc(data.note)}</div>` : '';

  // Charts
  destroyCharts();
  const ch = data.charts || {};
  document.getElementById('rptPieTitle').textContent = ch.pie?.title || 'Distribution';
  document.getElementById('rptBarTitle').textContent = ch.bar?.title || 'Breakdown';
  document.getElementById('rptLineTitle').textContent = ch.line?.title || 'Trend';

  if (ch.pie?.labels?.length) {
    renderDonutChartData('rptPieChart', ch.pie.labels, ch.pie.data);
    document.getElementById('rptPieLegend').innerHTML = legendHTML(ch.pie.labels);
  } else {
    document.getElementById('rptPieLegend').innerHTML = '<div class="muted" style="text-align:center;padding:16px;">No data yet</div>';
  }
  if (ch.bar?.labels?.length) {
    renderBarChartData('rptBarChart', ch.bar.labels, ch.bar.data, '#7c5cff');
  }
  if (ch.line?.labels?.length) {
    renderAreaLineChart('rptLineChart', ch.line.labels, ch.line.data, '#14b8a6');
  }

  // Extra panels (breakdowns / birthdays / top customers)
  renderExtraPanels(def.key, data);

  // Table
  RPT_STATE.table = buildDataTable('rptDataTable', 'rptTableHead', 'rptTableBody', 'rptPagination',
    'rptTableSearch', 'rptColBtn', 'rptColMenu', (data.table && data.table.columns) || [], (data.table && data.table.rows) || []);
}

function renderExtraPanels(key, data) {
  const wrap = document.getElementById('rptExtraWrap');
  let html = '';
  if (key === 'crm' && data.breakdowns) {
    html = `<div class="rpt-chart-grid" style="margin-bottom:18px;">
      ${miniListPanel('Employee-wise Leads', data.breakdowns.employee_wise)}
      ${miniListPanel('State-wise Leads', data.breakdowns.state_wise)}
    </div>`;
  } else if (key === 'customer' && data.top_customers?.length) {
    html = `<div class="panel" style="margin-bottom:18px;">
      <div class="panel-head"><div class="panel-title">Top Customers by Lifetime Value</div></div>
      <div class="table-scroll"><table class="data-table"><thead><tr><th>Customer</th><th>Company</th><th>Lifetime Value</th></tr></thead><tbody>
      ${data.top_customers.map(c => `<tr><td class="cell-strong">${esc(c.customer_name)}</td><td>${esc(c.company_name || '')}</td><td>${money(+c.ltv)}</td></tr>`).join('')}
      </tbody></table></div></div>`;
  } else if (key === 'employee' && (data.birthdays?.length || data.anniversaries?.length)) {
    html = `<div class="rpt-chart-grid" style="margin-bottom:18px;">
      ${miniListPanel('Upcoming Birthdays (30 days)', (data.birthdays || []).map(b => ({ label: `${b.name} — ${b.date_of_birth}`, cnt: '' })), true)}
      ${miniListPanel('Upcoming Work Anniversaries (30 days)', (data.anniversaries || []).map(a => ({ label: `${a.name} — ${a.date_of_joining}`, cnt: '' })), true)}
    </div>`;
  }
  wrap.innerHTML = html;
}
function miniListPanel(title, rowsArr, noCnt = false) {
  if (!rowsArr || !rowsArr.length) return `<div class="panel"><div class="panel-head"><div class="panel-title">${esc(title)}</div></div><div class="muted" style="padding:16px;">No data yet</div></div>`;
  return `<div class="panel"><div class="panel-head"><div class="panel-title">${esc(title)}</div></div>
    <div style="padding:6px 20px 16px;">
    ${rowsArr.map(r => `<div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--border-soft);font-size:.82rem;">
      <span>${esc(r.label)}</span>${noCnt ? '' : `<span class="cell-strong">${esc(r.cnt)}</span>`}</div>`).join('')}
    </div></div>`;
}

/* ---------------------------------------------------------
   Line/area chart (Chart.js) — reused by every report + a
   plain pie fallback for the custom builder's grouped view.
   --------------------------------------------------------- */
function renderAreaLineChart(canvasId, labels, data, accentHex) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  const grad = ctx.getContext('2d').createLinearGradient(0, 0, 0, 220);
  grad.addColorStop(0, accentHex + '55');
  grad.addColorStop(1, accentHex + '05');
  const chart = new Chart(ctx, {
    type: 'line',
    data: { labels, datasets: [{ data, borderColor: accentHex, backgroundColor: grad, fill: true, tension: .35, pointRadius: 3, pointBackgroundColor: accentHex }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { grid: { color: '#eef0f5' }, ticks: { font: { size: 11 }, color: '#8f97a8' } },
        x: { grid: { display: false }, ticks: { font: { size: 11 }, color: '#8f97a8' } }
      }
    }
  });
  activeCharts.push(chart);
}
function renderPlainPieChart(canvasId, labels, data) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  const chart = new Chart(ctx, {
    type: 'pie',
    data: { labels, datasets: [{ data, backgroundColor: CHART_COLORS, borderWidth: 1, borderColor: '#fff' }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 10 } } } } }
  });
  activeCharts.push(chart);
}

/* ---------------------------------------------------------
   Reusable data table engine: search + sort + pagination +
   column show/hide. Returns a handle with current filtered
   rows/columns so export buttons can read from it.
   --------------------------------------------------------- */
function buildDataTable(tableId, theadId, tbodyId, pagId, searchId, colBtnId, colMenuId, columns, rows) {
  const state = {
    columns, rows,
    visible: new Set(columns.map(c => c.key)),
    sortKey: null, sortDir: 1,
    search: '', page: 1, perPage: 25,
  };

  function filteredRows() {
    let out = state.rows;
    if (state.search) {
      const q = state.search.toLowerCase();
      out = out.filter(r => state.columns.some(c => String(r[c.key] ?? '').toLowerCase().includes(q)));
    }
    if (state.sortKey) {
      out = [...out].sort((a, b) => {
        const av = a[state.sortKey], bv = b[state.sortKey];
        const an = parseFloat(av), bn = parseFloat(bv);
        const bothNumeric = av !== null && av !== '' && bv !== null && bv !== '' && !isNaN(an) && !isNaN(bn);
        const cmp = bothNumeric ? (an - bn) : String(av ?? '').localeCompare(String(bv ?? ''));
        return cmp * state.sortDir;
      });
    }
    return out;
  }

  function renderHead() {
    const thead = document.getElementById(theadId);
    thead.innerHTML = state.columns.filter(c => state.visible.has(c.key)).map(c => {
      const sortCls = state.sortKey === c.key ? (state.sortDir === 1 ? 'sort-asc' : 'sort-desc') : '';
      return `<th class="sortable ${sortCls}" data-col="${c.key}">${esc(c.label)} <i class="fas fa-sort"></i></th>`;
    }).join('') + '<th></th>';
    thead.querySelectorAll('th.sortable').forEach(th => {
      th.addEventListener('click', () => {
        const key = th.dataset.col;
        if (state.sortKey === key) state.sortDir *= -1; else { state.sortKey = key; state.sortDir = 1; }
        state.page = 1;
        render();
      });
    });
  }

  function renderColMenu() {
    const menu = document.getElementById(colMenuId);
    menu.innerHTML = state.columns.map(c => `
      <label><input type="checkbox" data-colkey="${c.key}" ${state.visible.has(c.key) ? 'checked' : ''}> ${esc(c.label)}</label>`).join('');
    menu.querySelectorAll('input[type=checkbox]').forEach(cb => {
      cb.addEventListener('change', () => {
        if (cb.checked) state.visible.add(cb.dataset.colkey); else state.visible.delete(cb.dataset.colkey);
        render();
      });
    });
  }

  function fmtCell(col, val) {
    if (val === null || val === undefined || val === '') return '<span class="cell-faint">—</span>';
    if (col.money) return money(+val);
    return esc(val);
  }

  function render() {
    const all = filteredRows();
    const totalPages = Math.max(1, Math.ceil(all.length / state.perPage));
    if (state.page > totalPages) state.page = totalPages;
    const start = (state.page - 1) * state.perPage;
    const pageRows = all.slice(start, start + state.perPage);
    const visibleCols = state.columns.filter(c => state.visible.has(c.key));

    renderHead();
    const tbody = document.getElementById(tbodyId);
    tbody.innerHTML = pageRows.length ? pageRows.map(r => `<tr>${visibleCols.map(c => `<td>${fmtCell(c, r[c.key])}</td>`).join('')}<td></td></tr>`).join('')
      : `<tr><td colspan="${visibleCols.length + 1}">No records match your filters.</td></tr>`;

    const pag = document.getElementById(pagId);
    pag.innerHTML = `
      <div class="rpt-page-info">Showing ${all.length ? start + 1 : 0}–${Math.min(start + state.perPage, all.length)} of ${all.length}</div>
      <div class="rpt-page-btns">
        <label style="font-size:.78rem;color:var(--text-faint);margin-right:6px;">Rows:</label>
        <select id="${pagId}_pp">
          ${[25, 50, 100, 200].map(n => `<option value="${n}" ${state.perPage === n ? 'selected' : ''}>${n}</option>`).join('')}
        </select>
        <button ${state.page <= 1 ? 'disabled' : ''} id="${pagId}_prev"><i class="fas fa-chevron-left"></i></button>
        <span style="font-size:.78rem;padding:0 6px;">Page ${state.page} / ${totalPages}</span>
        <button ${state.page >= totalPages ? 'disabled' : ''} id="${pagId}_next"><i class="fas fa-chevron-right"></i></button>
      </div>`;
    document.getElementById(`${pagId}_prev`)?.addEventListener('click', () => { state.page--; render(); });
    document.getElementById(`${pagId}_next`)?.addEventListener('click', () => { state.page++; render(); });
    document.getElementById(`${pagId}_pp`)?.addEventListener('change', (e) => { state.perPage = +e.target.value; state.page = 1; render(); });

    renderColMenu();
  }

  document.getElementById(searchId).addEventListener('input', (e) => { state.search = e.target.value; state.page = 1; render(); });
  document.getElementById(colBtnId).addEventListener('click', (e) => {
    e.stopPropagation();
    document.getElementById(colMenuId).classList.toggle('open');
  });
  document.addEventListener('click', (e) => {
    const menu = document.getElementById(colMenuId);
    if (menu && !menu.contains(e.target) && e.target.id !== colBtnId) menu.classList.remove('open');
  });

  render();

  return {
    getExportData: () => {
      const cols = state.columns.filter(c => state.visible.has(c.key));
      const rows = filteredRows().map(r => cols.map(c => c.money ? (+r[c.key] || 0) : (r[c.key] ?? '')));
      return { columns: cols.map(c => c.label), rows };
    }
  };
}

/* ---------------------------------------------------------
   Export: Excel (SheetJS), PDF (jsPDF+autoTable), Print, Email
   --------------------------------------------------------- */
function exportTableExcel(title) {
  if (!RPT_STATE.table) return;
  if (!window.XLSX) { alert('Excel library failed to load. Please check your internet connection and try again.'); return; }
  const { columns, rows } = RPT_STATE.table.getExportData();
  const ws = window.XLSX.utils.aoa_to_sheet([columns, ...rows]);
  const wb = window.XLSX.utils.book_new();
  window.XLSX.utils.book_append_sheet(wb, ws, title.slice(0, 28));
  window.XLSX.writeFile(wb, `${title.replace(/\s+/g, '_')}_${dateStamp()}.xlsx`);
}

function exportTablePDF(title) {
  if (!RPT_STATE.table) return;
  if (!window.jspdf) { alert('PDF library failed to load. Please check your internet connection and try again.'); return; }
  const { jsPDF } = window.jspdf;
  const { columns, rows } = RPT_STATE.table.getExportData();
  const doc = new jsPDF('l');
  doc.setFontSize(15);
  doc.setTextColor(28, 37, 54);
  doc.text(title, 14, 16);
  doc.setFontSize(9);
  doc.setTextColor(100, 100, 100);
  doc.text(`Generated on ${new Date().toLocaleString()}`, 14, 22);
  doc.autoTable({
    startY: 28,
    head: [columns],
    body: rows,
    headStyles: { fillColor: [26, 36, 56], textColor: [255, 255, 255], fontSize: 8, fontStyle: 'bold' },
    bodyStyles: { fontSize: 7.5 },
    styles: { cellPadding: 3 },
  });
  doc.save(`${title.replace(/\s+/g, '_')}_${dateStamp()}.pdf`);
}

function emailReport(title) {
  const cards = Array.from(document.querySelectorAll('#rptStatGrid .stat-card')).map(c => {
    const label = c.querySelector('.stat-label')?.textContent?.trim() || '';
    const value = c.querySelector('.stat-value')?.textContent?.trim() || '';
    return `${label}: ${value}`;
  }).join('\n');
  const subject = encodeURIComponent(`${title} — SABHYTACRM`);
  const bodyText = `${title} summary as of ${new Date().toLocaleString()}\n\n${cards}\n\n(Export the full table as Excel or PDF and attach it before sending.)`;
  const body = encodeURIComponent(bodyText);
  window.location.href = `mailto:?subject=${subject}&body=${body}`;
}

function dateStamp() {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
}

/* =========================================================
   CUSTOM REPORTS — ad-hoc report builder
   ========================================================= */
let CUSTOM_SOURCES_CACHE = null;
let CUSTOM_STATE = { source: null, table: null };

async function renderCustomReportPage(backAction, backLabel) {
  destroyCharts();
  mainContent.innerHTML = `
    <button class="back-btn" id="crBackBtn"><i class="fas fa-arrow-left"></i> Back to ${backLabel}</button>
    <div class="eyebrow">Reports <span class="crumb-sep">/</span> <span class="crumb-current">Custom Reports</span></div>
    <div class="page-title"><span><i class="fas fa-sliders" style="color:var(--accent-orange);margin-right:10px;"></i>Custom Reports</span></div>
    <div class="panel-sub" style="margin:-10px 0 16px;">Pick a data source, choose your columns and filters, then generate</div>

    <div class="panel" style="margin-bottom:18px;">
      <div class="panel-head"><div class="panel-title">Report Builder</div></div>
      <div style="padding:0 20px 20px;">
        <div class="rpt-builder-row">
          <div class="rpt-builder-col">
            <h4>1. Select Source</h4>
            <select id="crSource" class="rpt-field-select" style="width:100%;padding:9px 10px;border:1px solid #dfe3ea;border-radius:8px;font-family:inherit;"></select>
          </div>
          <div class="rpt-builder-col">
            <h4>2. Date Range</h4>
            <div style="display:flex;gap:8px;">
              <input type="date" id="crDateFrom" style="flex:1;padding:9px 10px;border:1px solid #dfe3ea;border-radius:8px;font-family:inherit;">
              <input type="date" id="crDateTo" style="flex:1;padding:9px 10px;border:1px solid #dfe3ea;border-radius:8px;font-family:inherit;">
            </div>
          </div>
          <div class="rpt-builder-col">
            <h4>3. Search</h4>
            <input type="text" id="crSearch" placeholder="Optional keyword…" style="width:100%;padding:9px 10px;border:1px solid #dfe3ea;border-radius:8px;font-family:inherit;">
          </div>
        </div>
        <div class="rpt-builder-row">
          <div class="rpt-builder-col">
            <h4>4. Select Columns</h4>
            <div class="rpt-checkbox-list" id="crColumns"></div>
          </div>
          <div class="rpt-builder-col">
            <h4>5. Group By (optional)</h4>
            <select id="crGroupBy" style="width:100%;padding:9px 10px;border:1px solid #dfe3ea;border-radius:8px;font-family:inherit;"><option value="">No grouping — show raw rows</option></select>
            <h4 style="margin-top:14px;">6. Order By</h4>
            <div style="display:flex;gap:8px;">
              <select id="crOrderBy" style="flex:1;padding:9px 10px;border:1px solid #dfe3ea;border-radius:8px;font-family:inherit;"><option value="">Default</option></select>
              <select id="crOrderDir" style="width:110px;padding:9px 10px;border:1px solid #dfe3ea;border-radius:8px;font-family:inherit;">
                <option value="desc">Desc</option><option value="asc">Asc</option>
              </select>
            </div>
          </div>
        </div>
        <button class="rpt-btn rpt-btn-primary" id="crGenerateBtn" style="margin-top:6px;"><i class="fas fa-bolt"></i> Generate Report</button>
      </div>
    </div>

    <div id="crResultsWrap"></div>
  `;

  document.getElementById('crBackBtn').addEventListener('click', backAction);

  const res = await fetch('api/reports.php?type=custom_sources');
  const json = await res.json();
  CUSTOM_SOURCES_CACHE = json.success ? json.data : [];

  const sourceSel = document.getElementById('crSource');
  sourceSel.innerHTML = CUSTOM_SOURCES_CACHE.map(s => `<option value="${s.key}">${esc(s.label)}</option>`).join('');
  sourceSel.addEventListener('change', () => populateCustomColumns(sourceSel.value));
  populateCustomColumns(sourceSel.value);

  document.getElementById('crGenerateBtn').addEventListener('click', generateCustomReport);
}

function populateCustomColumns(sourceKey) {
  const src = CUSTOM_SOURCES_CACHE.find(s => s.key === sourceKey);
  if (!src) return;
  CUSTOM_STATE.source = sourceKey;

  document.getElementById('crColumns').innerHTML = src.columns.map(c => `
    <label><input type="checkbox" value="${c.key}" checked> ${esc(c.label)}</label>`).join('');

  const groupSel = document.getElementById('crGroupBy');
  groupSel.innerHTML = '<option value="">No grouping — show raw rows</option>' +
    src.columns.map(c => `<option value="${c.key}">${esc(c.label)}</option>`).join('');

  const orderSel = document.getElementById('crOrderBy');
  orderSel.innerHTML = '<option value="">Default</option>' +
    src.columns.map(c => `<option value="${c.key}">${esc(c.label)}</option>`).join('');
}

async function generateCustomReport() {
  const source = document.getElementById('crSource').value;
  const cols = Array.from(document.querySelectorAll('#crColumns input:checked')).map(i => i.value);
  const dateFrom = document.getElementById('crDateFrom').value;
  const dateTo = document.getElementById('crDateTo').value;
  const q = document.getElementById('crSearch').value;
  const groupBy = document.getElementById('crGroupBy').value;
  const orderBy = document.getElementById('crOrderBy').value;
  const orderDir = document.getElementById('crOrderDir').value;

  const params = new URLSearchParams({ type: 'custom', source });
  cols.forEach(c => params.append('columns[]', c));
  if (dateFrom) params.set('date_from', dateFrom);
  if (dateTo) params.set('date_to', dateTo);
  if (q) params.set('q', q);
  if (groupBy) params.set('group_by', groupBy);
  if (orderBy) params.set('order_by', orderBy);
  if (orderDir) params.set('order_dir', orderDir);

  const wrap = document.getElementById('crResultsWrap');
  wrap.innerHTML = `<div class="stat-card"><div class="stat-label">Generating…</div></div>`;

  let data;
  try {
    const res = await fetch(`api/reports.php?${params.toString()}`);
    const json = await res.json();
    if (!json.success) throw new Error(json.message || 'Failed to generate');
    data = json.data;
  } catch (err) {
    wrap.innerHTML = `<div class="stat-card"><div class="stat-label">Could not generate report: ${esc(err.message)}</div></div>`;
    return;
  }

  destroyCharts();

  let chartHtml = '';
  if (data.grouped) {
    chartHtml = `<div class="panel" style="margin-bottom:18px;">
      <div class="panel-head"><div class="panel-title">Grouped Chart</div></div>
      <div class="chart-canvas-wrap donut"><canvas id="crChart"></canvas></div>
      <div id="crChartLegend"></div>
    </div>`;
  }

  wrap.innerHTML = `
    ${chartHtml}
    <div class="table-panel">
      <div class="panel-head"><div><div class="panel-title">Report Results</div><div class="panel-sub">${data.rows.length} row(s)</div></div></div>
      <div class="rpt-toolbar">
        <div class="rpt-search"><i class="fas fa-search"></i><input type="text" id="crTableSearch" placeholder="Search results…"></div>
        <div class="rpt-actions">
          <button class="rpt-btn" id="crExcelBtn"><i class="fas fa-file-excel"></i> Export Excel</button>
          <button class="rpt-btn" id="crPdfBtn"><i class="fas fa-file-pdf"></i> Export PDF</button>
          <button class="rpt-btn" id="crPrintBtn"><i class="fas fa-print"></i> Print</button>
          <div class="rpt-col-menu-wrap">
            <button class="rpt-btn" id="crColBtn"><i class="fas fa-table-columns"></i> Columns</button>
            <div class="rpt-col-menu" id="crColMenu"></div>
          </div>
        </div>
      </div>
      <div class="table-scroll"><table class="data-table" id="crDataTable">
        <thead><tr id="crTableHead"></tr></thead>
        <tbody id="crTableBody"></tbody>
      </table></div>
      <div class="rpt-pagination" id="crPagination"></div>
    </div>
  `;

  if (data.grouped && data.rows.length) {
    renderPlainPieChart('crChart', data.rows.map(r => r.label), data.rows.map(r => +r.cnt));
    document.getElementById('crChartLegend').innerHTML = legendHTML(data.rows.map(r => r.label));
  }

  CUSTOM_STATE.table = buildDataTable('crDataTable', 'crTableHead', 'crTableBody', 'crPagination',
    'crTableSearch', 'crColBtn', 'crColMenu', data.columns, data.rows);

  document.getElementById('crExcelBtn').addEventListener('click', () => {
    if (!window.XLSX || !CUSTOM_STATE.table) { alert('Excel library failed to load.'); return; }
    const { columns, rows } = CUSTOM_STATE.table.getExportData();
    const ws = window.XLSX.utils.aoa_to_sheet([columns, ...rows]);
    const wb = window.XLSX.utils.book_new();
    window.XLSX.utils.book_append_sheet(wb, ws, 'Custom Report');
    window.XLSX.writeFile(wb, `Custom_Report_${dateStamp()}.xlsx`);
  });
  document.getElementById('crPdfBtn').addEventListener('click', () => {
    if (!window.jspdf || !CUSTOM_STATE.table) { alert('PDF library failed to load.'); return; }
    const { jsPDF } = window.jspdf;
    const { columns, rows } = CUSTOM_STATE.table.getExportData();
    const doc = new jsPDF('l');
    doc.setFontSize(15); doc.text('Custom Report', 14, 16);
    doc.autoTable({ startY: 24, head: [columns], body: rows, headStyles: { fillColor: [26, 36, 56] }, bodyStyles: { fontSize: 7.5 } });
    doc.save(`Custom_Report_${dateStamp()}.pdf`);
  });
  document.getElementById('crPrintBtn').addEventListener('click', () => window.print());
}
