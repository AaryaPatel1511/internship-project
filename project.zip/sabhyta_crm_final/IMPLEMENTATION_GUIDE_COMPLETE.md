# SABHYTA CRM - Complete Implementation Guide

## Overview
This comprehensive guide covers all features added to the CRM system based on the CRM Development Requirements document.

---

## 1. COMPLIANCE RECORDS SYSTEM

### 1.1 GST Records
**Location:** `api/compliance.php?type=gst`

**Features:**
- Create and manage GST return periods (GSTR-1, GSTR-2B, GSTR-3B)
- Track taxable values, CGST, SGST, IGST, CESS amounts
- Reconcile purchase and sales records
- Separate tracking of preparation, payment, and filing status
- ITC eligibility management
- Supporting document attachments

**Database Tables:**
- `gst_records` - Main GST transaction records
- `compliance_attachments` - Supporting documents
- `compliance_approvals` - Review and approval chain

**Usage:**
```javascript
// Create GST record
fetch('api/compliance.php?type=gst&action=create', {
    method: 'POST',
    body: JSON.stringify({
        company_id: 1,
        gstin: '27AAPCS1234H1Z0',
        return_period: '2024-09',
        taxable_value: 100000,
        cgst_amount: 9000,
        sgst_amount: 9000,
        payable_amount: 18000
    })
});
```

### 1.2 TDS Records
**Location:** `api/compliance.php?type=tds`

**Features:**
- Track TDS deductions from salaries and payments
- Separate salary and non-salary deductions
- Threshold accumulation tracking
- Challan and statement management
- Certificate tracking

### 1.3 PF Records
**Location:** `api/compliance.php?type=pf`

**Features:**
- Employee and employer contribution tracking
- Wage calculation with non-contributory days
- ECR submission management
- Pension fund allocation
- Wage month closure protection

### 1.4 ESIC Records
**Location:** `api/compliance.php?type=esic`

**Features:**
- Coverage eligibility management
- Employee and employer contributions
- Zero contribution tracking with reasons
- Payable days calculation
- Coverage decision preservation

### 1.5 Professional Tax
**Location:** `api/compliance.php?type=prof_tax`

**Features:**
- State-wise configuration support
- Employee category and salary band mapping
- Exemption management with evidence
- Monthly deduction tracking
- Multi-jurisdiction support

### 1.6 ROC Filings
**Location:** `api/compliance.php?type=roc`

**Features:**
- Annual and event-based obligations
- Form-based tracking (MCA portal)
- Director and signatory management
- Financial statement attachment
- Multi-state company support

### 1.7 Company Licenses
**Location:** `api/compliance.php?type=license`

**Features:**
- License register with validity tracking
- Renewal condition management
- Certificate version history
- Expiry date monitoring
- Active, Renewal Due, Applied, Expired, Suspended status tracking

### 1.8 ISO Documents
**Location:** `api/compliance.php?type=iso`

**Features:**
- Controlled document repository
- Certification scope management
- Surveillance and audit tracking
- Corrective action workflow
- Version control with superseded marking

### 1.9 Compliance Reminders
**Location:** `api/compliance.php?type=reminder`

**Features:**
- Automated daily scheduler
- Configurable offset reminders (90/60/30/7 days)
- Multi-channel notification support
- Escalation management
- Delivery status tracking

---

## 2. ENHANCED REPORTING SYSTEM

All reports available at: `api/reports.php`

### 2.1 CRM Reports
- Lead funnel analysis with conversion metrics
- Source performance tracking
- Overdue follow-up identification
- Loss reason analysis
- Cohort-based conversion measurement

### 2.2 Sales Reports
- Target achievement tracking
- Quotation to order conversion rates
- Pipeline forecasting
- Salesperson performance
- Separate booked, invoiced, and revenue tracking

### 2.3 Customer Reports
- Purchase history analysis
- Outstanding balance tracking
- Repeat business identification
- Inactivity list generation
- Retention/Churn analysis with activity windows

### 2.4 Employee Reports
- Headcount analytics
- Joiners/exits tracking
- Skill availability assessment
- Historical headcount reconstruction
- Restricted column masking

### 2.5 Attendance Reports
- Present/Absent day tracking
- Lateness identification
- Overtime calculation
- Exception reporting
- Multi-timezone and overnight shift support

### 2.6 Payroll Reports
- Salary register generation
- Payslip distribution
- Deduction summaries
- Payroll cost analysis
- Draft vs finalized run distinction

### 2.7 Project Reports
- Project milestone tracking
- Progress vs planned comparison
- Resource utilization
- Budget variance analysis
- Cost tracking by transaction ID

### 2.8 Inventory Reports
- Stock ledger generation
- Availability tracking
- Reorder identification
- Valuation method support
- Warehouse transfer reconciliation

### 2.9 Financial Reports
- Trial balance generation
- Profit and loss statements
- Balance sheet creation
- Receivables/Payables aging
- Cash movement analysis

### 2.10 Support Reports
- Open ticket tracking
- SLA breach identification
- Response time analysis
- Satisfaction metrics
- Reopened ticket tracking

### 2.11 Productivity Reports
- Task throughput measurement
- Billable utilization calculation
- Workload balance identification
- Blocker analysis
- Effort vs completed work comparison

### 2.12 Custom Reports
- Approved query builder interface
- Row limits and query timeout
- Sensitive column masking
- Export audit logging

---

## 3. AI TOOLS SYSTEM

### 3.1 AI Chat Assistant
**Location:** `api/ai_tools.php?tool=chat_assistant`

**Features:**
- Context-aware responses
- Permission-based content access
- Document and record linking
- Conversation history preservation
- Action proposal with confirmation

**Usage:**
```javascript
fetch('api/ai_tools.php?tool=chat_assistant&action=start_session', {
    method: 'POST'
});

fetch('api/ai_tools.php?tool=chat_assistant&action=send_message', {
    method: 'POST',
    body: JSON.stringify({
        session_id: 'sessionId',
        message: 'User question',
        permitted_records: []
    })
});
```

### 3.2 Email Generator
**Features:**
- Recipient, purpose, language, and tone selection
- Draft generation with editing
- Explicit send confirmation
- Communication log tracking
- Duplicate send prevention

### 3.3 Proposal Generator
**Features:**
- Customer-linked proposals
- Scope and deliverable management
- Technical and sales review workflow
- Manager approval with commercial terms
- Versioned proposal storage

### 3.4 Code Generator
**Features:**
- Snippet and module generation
- Framework and language selection
- Isolated testing environment
- Dependency and security checking
- Production deployment safeguards

### 3.5 Meeting Summary
**Features:**
- Recording and transcript management
- Participant-based minutes correction
- Decision and action item extraction
- Uncertain speaker flagging
- Task auto-linking

### 3.6 OCR Scanner
**Features:**
- Document type classification
- Field extraction with confidence scores
- Duplicate detection
- Reviewer correction tracking
- Original document preservation

### 3.7 Voice Notes
**Features:**
- Audio recording with timestamp
- Multi-language transcription
- Uncertain word highlighting
- Follow-up task creation
- Retention policy enforcement

### 3.8 Analytics
**Features:**
- Trend explanation generation
- Anomaly detection
- Forecasting with confidence levels
- Forecast accuracy tracking
- Limitation disclosure

---

## 4. USER PROFILE & SELF-SERVICE

### 4.1 My Profile Management
**Location:** `api/user_profile_extended.php?module=profile`

**Features:**
- Self-editable personal fields
- Protected field change requests (HR approval)
- Profile change history
- Photo management
- Restricted field masking (bank, tax, identity)

### 4.2 Password Management
**Location:** `api/user_profile_extended.php?module=password`

**Features:**
- Secure password hashing (BCRYPT)
- Password policy enforcement
- History tracking
- Reset token management
- Session revocation on change

### 4.3 Attendance Management
**Location:** `api/user_profile_extended.php?module=attendance`

**Features:**
- Check-in/Check-out recording
- Shift and work duration calculation
- Missing punch detection
- Regularization workflow
- Original data preservation
- Holiday calendar integration
- Multi-timezone support
- Overnight shift handling

**Usage:**
```javascript
// Check in
fetch('api/user_profile_extended.php?module=attendance&action=check_in', {
    method: 'POST',
    body: JSON.stringify({ shift_id: 1 })
});

// Check out
fetch('api/user_profile_extended.php?module=attendance&action=check_out', {
    method: 'POST'
});

// Request regularization
fetch('api/user_profile_extended.php?module=attendance&action=request_regularization', {
    method: 'POST',
    body: JSON.stringify({
        attendance_id: 123,
        reason: 'Missed check-out'
    })
});
```

### 4.4 Leave Management
**Location:** `api/user_profile_extended.php?module=leave`

**Features:**
- Leave type and balance management
- Full and partial day support
- Policy validation
- Overlap checking
- Approval workflow
- Balance ledger tracking
- Carryforward configuration

**Database Tables:**
- `leave_types` - Leave type configuration
- `leave_requests` - Leave request workflow
- `leave_balance_ledger` - Ledger tracking

### 4.5 My Projects & Tasks
**Location:** `api/user_profile_extended.php?module=tasks`

**Features:**
- Task assignment and tracking
- Effort estimation
- Time entry logging
- Billable hours tracking
- Task dependency management
- Review and acceptance workflow
- Overdue task identification

### 4.6 Notifications
**Location:** `api/user_profile_extended.php?module=notifications`

**Features:**
- Multi-channel delivery (email, SMS, in-app)
- Event-based triggering
- Permission re-checking on open
- Sensitive information masking
- Read status tracking
- Delivery retry logic

---

## 5. DATABASE SETUP

### 5.1 Import Schemas

Execute in this order:

```bash
# 1. Compliance schema
mysql -u root -p sabhyta_crm < database/schema_compliance.sql

# 2. Extended user profile schema
mysql -u root -p sabhyta_crm < database/schema_user_profile_extended.sql

# 3. AI tools schema
mysql -u root -p sabhyta_crm < database/schema_ai_tools.sql
```

### 5.2 Verify Tables

```sql
SHOW TABLES LIKE '%gst%';
SHOW TABLES LIKE '%compliance%';
SHOW TABLES LIKE '%employee_profiles%';
SHOW TABLES LIKE '%ai_%';
```

---

## 6. FRONTEND INTEGRATION

### 6.1 Include Modules in index.html

```html
<!-- Compliance Module -->
<script src="modules/compliance.js"></script>

<!-- Employee Self-Service Module -->
<script src="modules/employee_self_service.js"></script>

<!-- AI Tools Module -->
<script src="modules/ai_tools.js"></script>
```

### 6.2 Add Menu Items

Update navigation to include:
- Compliance Dashboard
- Employee Self-Service
- AI Tools
- Reports (Enhanced)

### 6.3 Create Module HTML Pages

**compliance.html**
```html
<div id="complianceDashboard"></div>
<div class="compliance-tabs">
    <button class="compliance-tab" data-tab="gst">GST</button>
    <button class="compliance-tab" data-tab="tds">TDS</button>
    <!-- More tabs -->
</div>
```

**employee_self_service.html**
```html
<div class="self-service-tabs">
    <button class="self-service-tab" data-tab="profile">My Profile</button>
    <button class="self-service-tab" data-tab="attendance">Attendance</button>
    <button class="self-service-tab" data-tab="leave">Leave</button>
    <button class="self-service-tab" data-tab="tasks">My Tasks</button>
    <button class="self-service-tab" data-tab="notifications">Notifications</button>
</div>
```

---

## 7. SECURITY & COMPLIANCE

### 7.1 Permission Matrix

| Module | Admin | HR | Finance | Manager | Employee |
|--------|-------|----|---------|---------| ---------|
| Compliance (View) | ✓ | ✓ | ✓ | ✗ | ✗ |
| Compliance (Edit) | ✓ | ✓ | ✓ | ✗ | ✗ |
| My Profile | ✓ | ✓ | ✗ | ✗ | ✓ |
| Attendance | ✓ | ✓ | ✗ | ✓ | ✓ |
| Leave Approval | ✓ | ✓ | ✗ | ✓ | ✗ |
| Task Management | ✓ | ✗ | ✗ | ✓ | ✓ |
| AI Tools | ✓ | ✓ | ✓ | ✓ | ✓ |

### 7.2 Audit Logging

All compliance and AI actions logged to:
- `compliance_approvals` table
- `ai_audit_log` table
- `password_history` table
- `profile_change_requests` table

### 7.3 Data Retention

- Compliance records: Permanent (with legal hold)
- AI logs: 90 days (configurable)
- Password history: 24 months
- Deleted records: Soft delete with timestamp

---

## 8. CONFIGURATION

### 8.1 Company-Specific Settings

Update in admin panel:
- GST registration details per company
- TDS threshold amounts
- PF establishment codes
- Payroll rules by effective date
- Leave policies per employee type
- Holiday calendar per company/branch

### 8.2 AI Provider Configuration

In `config.php`:
```php
define('AI_PROVIDER', 'anthropic'); // or 'openai'
define('AI_MODEL', 'claude-opus');
define('AI_API_KEY', getenv('AI_API_KEY'));
define('AI_DATA_RETENTION', 90); // days
```

### 8.3 Notification Settings

Per-user configuration in `notification_preferences`:
- Email/SMS/In-app channels
- Daily/Weekly digests
- Quiet hours
- Escalation rules

---

## 9. DEPLOYMENT CHECKLIST

- [ ] Database schemas imported
- [ ] API endpoints tested
- [ ] Frontend modules loaded
- [ ] Permission matrix configured
- [ ] Compliance rules validated with legal team
- [ ] AI provider credentials configured
- [ ] Email templates created
- [ ] Notification channels enabled
- [ ] Audit logging verified
- [ ] Backup strategy documented
- [ ] User training completed

---

## 10. SUPPORT & TROUBLESHOOTING

### Common Issues:

**1. Database Connection Errors**
```php
// Check connection in api/db.php
// Verify credentials in config.php
```

**2. Permission Denied on Files**
```bash
chmod 755 uploads/
chmod 755 database/
```

**3. Session Expired**
- Extend session timeout in `config.php`
- Clear browser cache
- Re-login

**4. AI Response Timeout**
- Increase `max_execution_time` in php.ini
- Add queue processing for long jobs

---

## 11. API DOCUMENTATION

All endpoints return JSON:
```json
{
    "success": true/false,
    "data": {},
    "error": "error message if applicable"
}
```

**Base URL:** `api/compliance.php` or `api/user_profile_extended.php` or `api/ai_tools.php`

**Authentication:** Session-based (via `session_guard.php`)

---

## 12. FUTURE ENHANCEMENTS

- [ ] Mobile app integration
- [ ] Third-party GST portal integration
- [ ] PF Unified Portal direct submission
- [ ] Blockchain audit trail
- [ ] Machine learning compliance predictions
- [ ] Voice-based AI interactions
- [ ] Real-time collaboration features
- [ ] Advanced analytics dashboard

---

**Document Version:** 1.0
**Last Updated:** September 19, 2026
**Prepared for:** Basil Infotech Limited
