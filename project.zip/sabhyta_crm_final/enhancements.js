/**
 * SABHYTA CRM - PROFESSIONAL ENHANCEMENTS
 * ======================================
 * Auto-sync Quotation to Sales
 * Professional Salary Processing
 * Enhanced Data Flow
 * Loaded after script.js and hrms_sales.js
 */

// ============================================================================
// AUTO-SYNC: QUOTATION TO SALES - REAL-TIME DATA FLOW
// ============================================================================

/**
 * Monitor quotation line items and automatically sync to sales order
 * when quotation number is entered/changed
 */
(function autoSyncQuotationToSales() {
  // Watch for changes to the quotation number input in sales order
  const soQuotationNumberInput = document.getElementById('soQuotationNumber');
  if (!soQuotationNumberInput) return;

  // Add auto-load button if not already present
  let autoLoadBtn = document.getElementById('soLoadFromQuoteBtn');
  if (!autoLoadBtn) {
    autoLoadBtn = document.createElement('button');
    autoLoadBtn.id = 'soLoadFromQuoteBtn';
    autoLoadBtn.type = 'button';
    autoLoadBtn.className = 'btn-secondary';
    autoLoadBtn.innerHTML = '<i class="fas fa-sync"></i> Auto-Load from Quotation';
    autoLoadBtn.style.marginLeft = '8px';
    
    const quoteNumberGroup = soQuotationNumberInput.closest('.form-group');
    if (quoteNumberGroup) {
      quoteNumberGroup.appendChild(autoLoadBtn);
    }
  }

  // Enhanced auto-load with blur event (when user leaves the field)
  soQuotationNumberInput.addEventListener('blur', async function() {
    const quotationNum = this.value.trim();
    if (quotationNum && quotationNum.length > 3) {
      // Show a subtle indicator
      const statusEl = document.createElement('div');
      statusEl.id = 'quoteAutoLoadStatus';
      statusEl.style.cssText = 'font-size:12px;color:#ff9800;margin-top:4px;';
      statusEl.textContent = 'Searching quotation...';
      
      const existing = this.closest('.form-group').querySelector('#quoteAutoLoadStatus');
      if (existing) existing.remove();
      this.closest('.form-group').appendChild(statusEl);
      
      // Try to auto-load
      try {
        if (typeof loadQuotationData === 'function') {
          await loadQuotationData(quotationNum);
        }
      } catch (err) {
        if (statusEl) {
          statusEl.textContent = 'Error auto-fetching quotation';
          statusEl.style.color = '#d33';
        }
      }
    }
  });
})();

// ============================================================================
// QUOTATION-TO-SALES ITEM SYNC ENHANCEMENT
// ============================================================================

/**
 * Enhanced loadQuotationData to handle missing soLineItemsBody
 * and provide better user feedback
 */
window.loadQuotationDataEnhanced = async function(quotationNumber) {
  try {
    const res = await fetch(`api/records.php?module=${encodeURIComponent('CRM||Create Quote')}&search=${encodeURIComponent(quotationNumber)}`);
    const json = await res.json();
    
    if (!json.success || !json.data || json.data.length === 0) {
      showQuotationSyncNotification(`Quotation "${quotationNumber}" not found. Please verify the number and try again.`, 'error');
      return;
    }

    const quote = json.data[0];
    const extraData = quote.extra_data ? JSON.parse(quote.extra_data) : {};
    const quoteItems = extraData.items || extraData.line_items || [];
    
    if (quoteItems.length === 0) {
      showQuotationSyncNotification('This quotation has no items to load.', 'warning');
      return;
    }

    // Auto-populate quote details if available
    const qData = extraData.quotationData || {};
    const customerSelect = document.getElementById('soCustomer');
    const branchInput = document.getElementById('soBranch');
    
    if (qData.customer && customerSelect) {
      customerSelect.value = qData.customer;
      customerSelect.dispatchEvent(new Event('change'));
    }
    if (qData.branch && branchInput) branchInput.value = qData.branch;

    // Clear and reload items
    const tbody = document.getElementById('soLineItemsBody');
    if (!tbody) {
      showQuotationSyncNotification('Sales Order form not ready. Please refresh and try again.', 'error');
      return;
    }
    
    tbody.innerHTML = '';

    // Add quotation items to sales order with better mapping
    let loadedCount = 0;
    quoteItems.forEach((item, index) => {
      // Map quotation item fields to sales order item fields
      const soItem = {
        productCode: item.productCode || item.code || '',
        productName: item.productName || item.name || '',
        category: item.category || '',
        description: item.description || '',
        brand: item.brand || '',
        model: item.model || '',
        hsn: item.hsn || '',
        unit: item.unit || 'Nos',
        qty: parseFloat(item.qty) || 1,
        price: parseFloat(item.price) || 0,
        discount: parseFloat(item.discount) || 0,
        tax: parseFloat(item.tax) || 18,
        deliveryDate: item.deliveryDate || '',
        remarks: item.remarks || `From Quotation ${quotationNumber}`
      };
      
      if (typeof addSoLineItemRow === 'function') {
        addSoLineItemRow(soItem);
        loadedCount++;
      }
    });

    if (typeof recalcSoTotals === 'function') {
      recalcSoTotals();
    }

    showQuotationSyncNotification(
      `✓ Successfully loaded ${loadedCount} products from quotation "${quotationNumber}"`,
      'success'
    );
  } catch (err) {
    showQuotationSyncNotification(`Error loading quotation: ${err.message}`, 'error');
  }
};

/**
 * Display notification for quotation sync operations
 */
function showQuotationSyncNotification(message, type = 'info') {
  const notif = document.createElement('div');
  notif.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 16px 20px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 500;
    z-index: 10000;
    max-width: 400px;
    animation: slideIn 0.3s ease-out;
  `;

  const bgColors = {
    success: '#4caf50',
    error: '#f44336',
    warning: '#ff9800',
    info: '#2196f3'
  };

  notif.style.backgroundColor = bgColors[type] || bgColors.info;
  notif.style.color = '#fff';
  notif.textContent = message;

  document.body.appendChild(notif);
  setTimeout(() => {
    notif.style.animation = 'slideOut 0.3s ease-out';
    setTimeout(() => notif.remove(), 300);
  }, 4000);
}

// ============================================================================
// PROFESSIONAL SALARY PROCESSING ENHANCEMENTS
// ============================================================================

/**
 * Enhance salary sheet with professional formatting
 * Auto-calculate based on branch and employee data
 */
window.enhancedSalaryCalculations = {
  /**
   * Get salary breakup based on employee and branch metro status
   */
  calculateEmployeeSalary: async function(employeeId) {
    try {
      if (typeof fetchEmployeesCached !== 'function') return null;
      
      const emps = await fetchEmployeesCached();
      const emp = emps.find(e => String(e.id) === String(employeeId));
      if (!emp) return null;

      const basic = parseFloat(emp.basic_salary) || 0;
      
      // Check branch metro status
      let metro = false;
      if (typeof isMetroCityName === 'function') {
        metro = isMetroCityName(emp.city);
      }
      
      // Use the standard salary computation
      if (typeof computeSalaryBreakup === 'function') {
        return computeSalaryBreakup(basic, metro);
      }
      
      return null;
    } catch (err) {
      console.error('Salary calculation error:', err);
      return null;
    }
  },

  /**
   * Generate comprehensive salary report
   */
  generateSalaryReport: async function(employeeId, month, year) {
    const salary = await this.calculateEmployeeSalary(employeeId);
    if (!salary) return null;

    return {
      period: `${month}/${year}`,
      basicSalary: salary.basic,
      dearness: salary.dearness,
      houseRent: salary.hra,
      conveyance: salary.conveyance,
      medicalAllowance: salary.medical,
      specialAllowance: salary.specialAllowance,
      grossSalary: salary.gross,
      providentFund: salary.pf,
      professionTax: salary.pt,
      incomeTax: salary.it,
      totalDeductions: salary.totalDeductions,
      netSalary: salary.net,
      netSalaryAnnual: salary.netYearly
    };
  }
};

// ============================================================================
// BRANCH SALARY PROCESSING PROFESSIONAL FEATURES
// ============================================================================

/**
 * Enhanced branch salary report generation
 */
window.generateProfessionalBranchReport = async function(employees, branch, financialYear, month) {
  if (!window.jspdf) {
    alert('PDF library not loaded. Please refresh and try again.');
    return;
  }

  const { jsPDF } = window.jspdf;
  const doc = new jsPDF('l'); // landscape
  
  let currentY = 20;
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 14;

  // Header
  doc.setFontSize(16);
  doc.setTextColor(28, 43, 74);
  doc.text('PROFESSIONAL SALARY REPORT', margin, currentY);
  
  doc.setFontSize(11);
  doc.setTextColor(80, 80, 80);
  currentY += 8;
  doc.text(`Branch: ${branch}`, margin, currentY);
  currentY += 5;
  doc.text(`Financial Year: ${financialYear} | Month: ${month}`, margin, currentY);
  currentY += 5;
  doc.text(`Generated on: ${new Date().toLocaleDateString()}`, margin, currentY);
  currentY += 10;

  // Summary statistics
  doc.setFontSize(10);
  doc.setTextColor(100, 100, 100);
  doc.text(`Total Employees: ${employees.length}`, margin, currentY);
  currentY += 20;

  // Detailed employee data table
  const tableColumns = [
    'Employee Code',
    'Name',
    'Designation',
    'Basic',
    'Gross',
    'Deductions',
    'Net Salary'
  ];

  const tableData = employees.map(emp => {
    const basic = parseFloat(emp.basic_salary) || 0;
    const gross = basic * 1.75; // Approximation
    const deductions = basic * 0.25; // Approximation
    const net = gross - deductions;

    return [
      emp.employee_code || 'N/A',
      emp.name || 'N/A',
      emp.designation_name || 'N/A',
      `₹${basic.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`,
      `₹${gross.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`,
      `₹${deductions.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`,
      `₹${net.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`
    ];
  });

  doc.autoTable({
    startY: currentY,
    head: [tableColumns],
    body: tableData,
    headStyles: {
      fillColor: [28, 43, 74],
      textColor: [255, 255, 255],
      fontSize: 9,
      fontStyle: 'bold'
    },
    bodyStyles: {
      fontSize: 8,
      textColor: [0, 0, 0]
    },
    alternateRowStyles: {
      fillColor: [245, 245, 245]
    },
    margin: margin,
    didDrawPage: function(data) {
      // Footer
      const pageNumber = doc.internal.getPageCount();
      doc.setFontSize(8);
      doc.setTextColor(128, 128, 128);
      doc.text(
        `Page ${doc.internal.getPageNumber()}`,
        pageWidth / 2,
        pageHeight - 10,
        { align: 'center' }
      );
    }
  });

  // Download PDF
  const fileName = `Salary_Report_${branch}_${month}_${year}.pdf`;
  doc.save(fileName);

  showQuotationSyncNotification(`✓ Salary report generated: ${fileName}`, 'success');
};

// ============================================================================
// AUTO-INITIALIZE ENHANCEMENTS
// ============================================================================

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
  // Add any initialization code here
  console.log('SABHYTA CRM Enhancements loaded successfully');
});

// Add CSS animation for notifications
const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn {
    from {
      transform: translateX(400px);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }

  @keyframes slideOut {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(400px);
      opacity: 0;
    }
  }

  .salary-tab-bar button:hover {
    background: #f5f5f5 !important;
    border-color: #ddd !important;
  }

  .salary-tab-bar button.active,
  .salary-tab-bar button[style*="background:#1c2b4a"] {
    background: #1c2b4a !important;
    color: #fff !important;
    border-color: #1c2b4a !important;
  }
`;
document.head.appendChild(style);
