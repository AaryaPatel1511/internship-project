<?php
/**
 * EMERGENCY PASSWORD RESET  (command line only)
 * --------------------------------------------------------
 * Use this if you are locked out and cannot use the "Forgot password?"
 * screen on login.html.
 *
 *   List the accounts:
 *       php reset_password.php --list
 *
 *   Reset one account's password:
 *       php reset_password.php you@company.com NewPassword123
 *
 *   (If you leave the password off, you are asked for it.)
 *
 * XAMPP on Windows:  open  XAMPP Control Panel > Shell  and run
 *       cd C:\xampp\htdocs\sabhytacrm
 *       php reset_password.php --list
 *
 * This file refuses to run from a web browser, so it cannot be used remotely.
 * It also re-activates the account if it was suspended.
 * --------------------------------------------------------
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/api/db.php';   // gives us $pdo

function out(string $m): void { fwrite(STDOUT, $m . PHP_EOL); }
function fail(string $m): void { fwrite(STDERR, "ERROR: $m" . PHP_EOL); exit(1); }

$args = array_slice($argv, 1);

if (!$args || in_array($args[0], ['-h', '--help'], true)) {
    out("Usage:");
    out("  php reset_password.php --list");
    out("  php reset_password.php <email> [new-password]");
    exit(0);
}

if ($args[0] === '--list') {
    $rows = $pdo->query("SELECT id, name, email, role FROM users ORDER BY id")->fetchAll();
    if (!$rows) {
        out("No accounts yet. Open login.html in the browser to create the first admin.");
        exit(0);
    }
    out(sprintf("%-4s %-24s %-34s %s", 'ID', 'NAME', 'EMAIL', 'ROLE'));
    foreach ($rows as $r) out(sprintf("%-4s %-24s %-34s %s", $r['id'], mb_substr($r['name'], 0, 24), $r['email'], $r['role']));
    exit(0);
}

$email = trim($args[0]);
$st = $pdo->prepare("SELECT id, name, role FROM users WHERE email = ?");
$st->execute([$email]);
$user = $st->fetch();
if (!$user) fail("No account with the email '$email'. Run:  php reset_password.php --list");

$password = $args[1] ?? '';
if ($password === '') {
    fwrite(STDOUT, "New password for {$user['name']} <$email>: ");
    $password = trim((string)fgets(STDIN));
}
if (strlen($password) < 6) fail("The password must be at least 6 characters.");

$pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?")
    ->execute([password_hash($password, PASSWORD_BCRYPT), $user['id']]);
try { $pdo->prepare("UPDATE users SET status = 'Active' WHERE id = ?")->execute([$user['id']]); } catch (Throwable $e) { /* column not created yet */ }

out("Done. {$user['name']} ({$user['role']}) can now sign in at login.html with the new password.");
