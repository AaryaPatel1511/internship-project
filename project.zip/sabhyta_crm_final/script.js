
const sidebar        = document.getElementById('sidebar');
const hamburgerBtn    = document.getElementById('hamburgerBtn');
const sidebarOverlay  = document.getElementById('sidebarOverlay');
const mainContent     = document.getElementById('mainContent');
const searchInput     = document.getElementById('searchInput');
const searchResults   = document.getElementById('searchResults');

let activeCharts = [];


const money = n => '₹' + Math.round(n).toLocaleString('en-IN');
const CHART_COLORS = ['#ff6b4a','#7c5cff','#14b8a6','#e08c1c','#2563eb'];

function classify(label, section) {
  const s = (label + ' ' + section).toLowerCase();
  if (/lead|customer|contact|crm|quotation|marketing|campaign/.test(s)) return 'crm';
  if (/employee|payroll|hrms|attendance|salary|leave|recruit|appraisal|bonus|department|hr\b/.test(s)) return 'hr';
  if (/invoice|payment|sales order|proforma|receipt|accounts|finance|gst|tds|ledger|balance|profit/.test(s)) return 'finance';
  if (/ticket|helpdesk|support|complaint|amc|sla/.test(s)) return 'ticket';
  if (/project|task|milestone|module|gantt|sprint/.test(s)) return 'project';
  if (/stock|inventory|product|warehouse|barcode|purchase order/.test(s)) return 'inventory';
  if (/asset|laptop|desktop|printer|server|license/.test(s)) return 'asset';
  return 'generic';
}

const CATEGORY_META = {
  crm:       { icon:'fa-user-plus',    accent:'--accent-orange', kpis:['Total Leads','Converted','Follow-ups Due','Pipeline Value'] },
  hr:        { icon:'fa-user-tie',     accent:'--accent-purple', kpis:['Total Employees','Present Today','Open Positions','Monthly Payroll'] },
  finance:   { icon:'fa-wallet',       accent:'--accent-teal',   kpis:['Total Amount','Paid','Pending','Overdue'] },
  ticket:    { icon:'fa-headset',      accent:'--accent-red',    kpis:['Open Tickets','Resolved','Avg Response','SLA Breaches'] },
  project:   { icon:'fa-project-diagram', accent:'--accent-blue',kpis:['Active Items','Completed','At Risk','Team Members'] },
  inventory: { icon:'fa-box-open',     accent:'--accent-amber',  kpis:['Total SKUs','In Stock','Low Stock','Stock Value'] },
  asset:     { icon:'fa-cogs',         accent:'--accent-blue',   kpis:['Total Assets','Allocated','Under Maintenance','Book Value'] },
  generic:   { icon:'fa-layer-group',  accent:'--accent-orange', kpis:['Total Records','Active','Pending','This Month'] }
};

function statusClass(st) {
  return 'status-' + st.toLowerCase().replace(/\s+/g,'');
}


function destroyCharts() {
  activeCharts.forEach(c => { try { c.destroy(); } catch (e) {} });
  activeCharts = [];
}

function legendHTML(labels) {
  return `<div class="legend-pill">${labels.map((l, i) =>
    `<span><i style="background:${CHART_COLORS[i % CHART_COLORS.length]}"></i>${l}</span>`).join('')}</div>`;
}

function timeAgo(dateStr) {
  const diffMs = Date.now() - new Date(dateStr.replace(' ', 'T')).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hr ago`;
  const days = Math.floor(hrs / 24);
  return `${days} day${days > 1 ? 's' : ''} ago`;
}

function renderBarChartData(canvasId, labels, data, accentHex) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  const chart = new Chart(ctx, {
    type: 'bar',
    data: { labels, datasets: [{ data, backgroundColor: accentHex, borderRadius: 6, maxBarThickness: 34 }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { grid: { color: '#eef0f5' }, ticks: { font: { size: 11 }, color: '#8f97a8' } },
        x: { grid: { display: false }, ticks: { font: { size: 11 }, color: '#8f97a8' } }
      }
    }
  });
  activeCharts.push(chart);
}

function renderDonutChartData(canvasId, labels, data) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  const chart = new Chart(ctx, {
    type: 'doughnut',
    data: { labels, datasets: [{ data, backgroundColor: CHART_COLORS, borderWidth: 0, hoverOffset: 4 }] },
    options: { responsive: true, maintainAspectRatio: false, cutout: '68%', plugins: { legend: { display: false } } }
  });
  activeCharts.push(chart);
}

async function renderDashboardHome() {
  destroyCharts();
  mainContent.innerHTML = `<div class="stat-grid" id="dashLoading"><div class="stat-card"><div class="stat-label">Loading your dashboard…</div></div></div>`;

  let stats;
  try {
    const res = await fetch('api/dashboard.php');
    const json = await res.json();
    if (!json.success) throw new Error(json.message);
    stats = json.data;
  } catch (err) {
    mainContent.innerHTML = `<div class="stat-grid"><div class="stat-card"><div class="stat-label">Could not load dashboard: ${err.message}</div></div></div>`;
    return;
  }

  const revenueMonths = stats.monthly_revenue.map(m => m.label);
  const revenueValues = stats.monthly_revenue.map(m => m.total);
  const thisMonth = revenueValues[revenueValues.length - 1] || 0;
  const lastMonth = revenueValues[revenueValues.length - 2] || 0;
  const revChangePct = lastMonth > 0 ? Math.round(((thisMonth - lastMonth) / lastMonth) * 100) : (thisMonth > 0 ? 100 : 0);
  const revUp = revChangePct >= 0;

  const typeLabels = stats.customer_types.map(t => t.label);
  const typeCounts = stats.customer_types.map(t => +t.count);

  mainContent.innerHTML = `
    <div class="stat-grid">
      <div class="stat-card" style="--stat-accent:#ff6b4a">
        <div class="stat-label"><i class="fas fa-indian-rupee-sign"></i> Total Revenue</div>
        <div class="stat-value">${money(stats.total_revenue)}</div>
        <div class="stat-change ${revUp ? 'up' : 'down'}"><i class="fas fa-arrow-${revUp ? 'up' : 'down'}"></i> ${Math.abs(revChangePct)}% <span class="muted">MoM</span></div>
      </div>
      <div class="stat-card" style="--stat-accent:#16a34a">
        <div class="stat-label"><i class="fas fa-user-plus"></i> New Leads</div>
        <div class="stat-value">${stats.new_leads}</div>
        <div class="stat-change"><span class="muted">from Lead records</span></div>
      </div>
      <div class="stat-card" style="--stat-accent:#e0384c">
        <div class="stat-label"><i class="fas fa-headset"></i> Open Tickets</div>
        <div class="stat-value">${stats.open_tickets}</div>
        <div class="stat-change"><span class="muted">Active / Pending</span></div>
      </div>
      <div class="stat-card" style="--stat-accent:#14b8a6">
        <div class="stat-label"><i class="fas fa-diagram-project"></i> Active Projects</div>
        <div class="stat-value">${stats.active_projects}</div>
        <div class="stat-change"><span class="muted">from Project records</span></div>
      </div>
    </div>

    <div class="chart-grid">
      <div class="panel">
        <div class="panel-head">
          <div><div class="panel-title">Revenue</div><div class="panel-sub">Last 6 months</div></div>
        </div>
        <div class="chart-canvas-wrap"><canvas id="chartRevenue"></canvas></div>
      </div>
      <div class="panel">
        <div class="panel-head">
          <div><div class="panel-title">Customers by Type</div><div class="panel-sub">All time</div></div>
        </div>
        <div class="chart-canvas-wrap donut"><canvas id="chartCustTypes"></canvas></div>
        ${typeLabels.length ? legendHTML(typeLabels) : '<div class="muted" style="text-align:center;padding:20px;">No customers yet</div>'}
      </div>
    </div>

    <div class="list-grid">
      <div class="panel">
        <div class="panel-head"><div class="panel-title">Recent Activity</div></div>
        <div id="activityList"></div>
      </div>
      <div class="panel">
        <div class="panel-head"><div class="panel-title">Tasks for You</div></div>
        <div id="taskList"></div>
      </div>
    </div>
  `;

  renderBarChartData('chartRevenue', revenueMonths, revenueValues, '#ff6b4a');
  if (typeLabels.length) renderDonutChartData('chartCustTypes', typeLabels, typeCounts);

  const activityList = document.getElementById('activityList');
  if (!stats.recent_activity.length) {
    activityList.innerHTML = `<div class="activity-row"><div class="row-body"><div class="row-title">No activity yet</div><div class="row-sub">Add a customer or record to see it here</div></div></div>`;
  } else {
    activityList.innerHTML = stats.recent_activity.map(a => `
      <div class="activity-row">
        <div class="row-icon" style="background:${a.kind === 'customer' ? '#2563eb' : '#7c5cff'}">
          <i class="fas ${a.kind === 'customer' ? 'fa-user-plus' : 'fa-file-lines'}"></i>
        </div>
        <div class="row-body"><div class="row-title">${a.title || '(untitled)'}</div><div class="row-sub">${a.sub || ''}</div></div>
        <div class="row-time">${timeAgo(a.created_at)}</div>
      </div>`).join('');
  }

  const taskList = document.getElementById('taskList');
  if (!stats.tasks.length) {
    taskList.innerHTML = `<div class="task-row"><div class="row-body"><div class="row-title">No pending tasks</div><div class="row-sub">Records marked "Pending" will show up here</div></div></div>`;
  } else {
    taskList.innerHTML = stats.tasks.map(t => `
      <div class="task-row">
        <div class="row-icon" style="background:#e0384c"><i class="fas fa-clock"></i></div>
        <div class="row-body"><div class="row-title">${t.title}</div><div class="row-sub">${t.module_label}</div></div>
        <div class="row-time">${t.record_date || ''}</div>
      </div>`).join('');
  }
}


// ---------------------------------------------------------
// Overview pages (clicking a main-heading like "CRM" or a
// sub-heading like "Lead Management"). Card counts and the
// KPI strip are now pulled live from api/records.php's
// aggregate ?stats=1&keys=... endpoint instead of random
// numbers, scoped to exactly the leaf modules shown on screen.
// ---------------------------------------------------------
async function renderOverviewPage(sectionLabel, iconClass, items, onItemClick, backAction, backLabel, keySectionLabel) {
  destroyCharts();
  const category = classify(sectionLabel, sectionLabel);
  const meta = CATEGORY_META[category];
  // moduleKeyFor() always builds keys off the top-level main-heading label
  // (see the sidebar leaf click handler below), regardless of how deep a
  // sub-heading this overview is showing — so use that for lookups, while
  // still displaying sectionLabel (which may be a sub-heading) in the UI.
  const keyLabel = keySectionLabel || sectionLabel;

  mainContent.innerHTML = `
    ${backAction ? `<button class="back-btn" id="backBtn"><i class="fas fa-arrow-left"></i> Back to ${backLabel}</button>` : ''}
    <div class="eyebrow"><span class="crumb-current">${sectionLabel}</span></div>
    <div class="page-title"><span><i class="fas ${iconClass}" style="color:var(${meta.accent}); margin-right:10px;"></i>${sectionLabel}</span></div>

    <div class="stat-grid" id="overviewStats">
      <div class="stat-card"><div class="stat-label">Loading…</div></div>
    </div>

    <div class="panel" style="margin-bottom:24px;">
      <div class="panel-head"><div><div class="panel-title">Explore ${sectionLabel}</div><div class="panel-sub">Select a module to view detailed analytics</div></div></div>
      <div class="card-grid" id="overviewCards"><div class="muted" style="padding:12px;">Loading…</div></div>
    </div>
  `;

  if (backAction) document.getElementById('backBtn').addEventListener('click', backAction);

  // Every item shown here is either a leaf sidebar entry itself, or a
  // sub-heading standing in for a group of leaves. Resolve each one down
  // to its real module_key(s) so we can ask the database for real counts.
  const allLeafKeys = [];
  items.forEach(item => {
    item.leaves.forEach(leaf => allLeafKeys.push(moduleKeyFor(keyLabel, leaf)));
  });

  let statsData = { total: 0, active: 0, pending: 0, amount_sum: 0, by_module: {} };
  let customerCount = null;

  try {
    const keysParam = encodeURIComponent(allLeafKeys.join(','));
    const res = await fetch(`api/records.php?stats=1&keys=${keysParam}`);
    const json = await res.json();
    if (json.success) statsData = json.data;
  } catch (err) {
    // leave statsData at zeroed defaults if the request fails
  }

  // "Customers" is backed by its own dedicated table (api/customers.php),
  // not generic_records, so fetch its real count separately if it's
  // one of the cards on this page.
  if (items.some(item => item.leaves.includes('Customers'))) {
    try {
      const res = await fetch('api/customers.php');
      const json = await res.json();
      if (json.success) customerCount = json.data.length;
    } catch (err) { /* ignore, card just falls back to 0 */ }
  }

  // Lead Management leaves are backed by the dedicated leads table
  // (api/leads.php), not generic_records — pull their real counts too.
  let leadCounts = null;
  let leadTotal = 0;
  if (typeof LEAD_ITEM_NAMES !== 'undefined' && items.some(item => item.leaves.some(l => LEAD_ITEM_NAMES.has(l)))) {
    try {
      const res = await fetch('api/leads.php?action=stats');
      const json = await res.json();
      if (json.success) {
        const d = json.data;
        leadTotal = d.total_leads || 0;
        leadCounts = {
          'Add Lead': leadTotal,
          'Import Leads': leadTotal,
          'Website Leads': (d.by_source && d.by_source['Website']) || 0,
          'Facebook Leads': (d.by_source && d.by_source['Facebook']) || 0,
          'Google Ads Leads': (d.by_source && d.by_source['Google Ads']) || 0,
          'WhatsApp Leads': (d.by_source && d.by_source['WhatsApp']) || 0,
          'Assigned Leads': leadTotal,
          'Follow-up': d.pending_followups || 0,
          'Lead Status': leadTotal,
          'Lost Leads': d.lost_leads || 0,
          'Converted Leads': (d.by_status && d.by_status['Converted']) || 0,
        };
      }
    } catch (err) { /* card just falls back to 0 */ }
  }

  // Marketing / Project / Asset / Document / Administration leaves live in dedicated tables
  // (api/erp.php) - merge their real counts in.
  let erpCounts = null;
  if (typeof erpOverviewCounts === 'function') {
    try { erpCounts = await erpOverviewCounts(sectionLabel, keyLabel); } catch (err) { erpCounts = null; }
  }
  const erpHas = leaf => !!erpCounts && leaf !== '_total' && Object.prototype.hasOwnProperty.call(erpCounts, leaf);
  const erpTotal = erpCounts && erpCounts._total ? erpCounts._total : 0;
  const grandTotal = statsData.total + (customerCount || 0) + leadTotal + erpTotal;

  document.getElementById('overviewStats').innerHTML = `
    <div class="stat-card" style="--stat-accent:var(${meta.accent})">
      <div class="stat-label"><i class="fas ${meta.icon}"></i> Total Records</div>
      <div class="stat-value">${grandTotal.toLocaleString('en-IN')}</div>
      <div class="stat-change"><span class="muted">across ${items.length} module${items.length === 1 ? '' : 's'}</span></div>
    </div>
    <div class="stat-card" style="--stat-accent:var(${meta.accent})">
      <div class="stat-label"><i class="fas fa-check-circle"></i> Active</div>
      <div class="stat-value">${statsData.active.toLocaleString('en-IN')}</div>
      <div class="stat-change"><span class="muted">status = Active</span></div>
    </div>
    <div class="stat-card" style="--stat-accent:var(${meta.accent})">
      <div class="stat-label"><i class="fas fa-clock"></i> Pending</div>
      <div class="stat-value">${statsData.pending.toLocaleString('en-IN')}</div>
      <div class="stat-change"><span class="muted">status = Pending</span></div>
    </div>
    <div class="stat-card" style="--stat-accent:var(${meta.accent})">
      <div class="stat-label"><i class="fas fa-indian-rupee-sign"></i> Total Value</div>
      <div class="stat-value">${money(statsData.amount_sum)}</div>
      <div class="stat-change"><span class="muted">sum of Amount field</span></div>
    </div>
  `;

  const cardColors = ['#2563eb,#7c5cff', '#14b8a6,#2563eb', '#ff6b4a,#e08c1c', '#7c5cff,#e0384c', '#16a34a,#14b8a6'];
  document.getElementById('overviewCards').innerHTML = items.map((item, i) => {
    const count = item.leaves.includes('Customers')
      ? (customerCount || 0)
      : leadCounts && item.leaves.some(l => leadCounts.hasOwnProperty(l))
        ? item.leaves.reduce((sum, leaf) => sum + (leadCounts.hasOwnProperty(leaf) ? leadCounts[leaf] : (statsData.by_module[moduleKeyFor(keyLabel, leaf)] || 0)), 0)
        : item.leaves.reduce((sum, leaf) => sum + (statsData.by_module[moduleKeyFor(keyLabel, leaf)] || 0), 0);
    const erpAdjust = item.leaves.reduce((sum, leaf) => erpHas(leaf) ? sum + erpCounts[leaf] - (statsData.by_module[moduleKeyFor(keyLabel, leaf)] || 0) : sum, 0);
    const finalCount = count + erpAdjust;
    return `
    <div class="content-card" data-idx="${i}">
      <div class="cc-icon" style="background:linear-gradient(135deg, ${cardColors[i % cardColors.length].split(',')[0]}, ${cardColors[i % cardColors.length].split(',')[1]})">
        <i class="fas ${meta.icon}"></i>
      </div>
      <div class="cc-label">${item.label}</div>
      <div class="cc-meta">${finalCount.toLocaleString('en-IN')} record${finalCount === 1 ? '' : 's'}</div>
    </div>`;
  }).join('');

  mainContent.querySelectorAll('#overviewCards .content-card').forEach(card => {
    card.addEventListener('click', () => onItemClick(items[+card.dataset.idx].label));
  });
}

// Resolve a direct child <li> of a heading down to the list of real leaf
// labels it represents: a plain leaf li is just itself; a sub-heading
// stands in for every leaf nested inside it.
function leafLabelsUnder(li) {
  if (li.classList.contains('sub-heading')) {
    return Array.from(li.querySelectorAll(':scope > ul > li')).map(x => x.textContent.trim());
  }
  return [li.textContent.trim()];
}


document.querySelectorAll('.main-heading, .sub-heading').forEach(li => {
  const header = li.querySelector(':scope > .menu-header');
  header.addEventListener('click', (e) => {
    e.stopPropagation();
    li.classList.toggle('active');
  });
});

document.querySelectorAll('.main-heading > .menu-header').forEach(header => {
  header.addEventListener('click', () => {
    const mainLi = header.closest('.main-heading');
    const sectionLabel = header.querySelector('span').textContent.trim();
    const iconClass = header.querySelector('i').className.split(' ').find(c => c.startsWith('fa-') && c !== 'fa-solid');
    openSectionOverview(mainLi, sectionLabel, iconClass);
    if (window.innerWidth <= 900) closeSidebar();
  });
});

function showSubOverview(subLi, mainLi, sectionLabel, subLabel, iconClass, items) {
  setActiveLeaf(null);
  // Under a sub-heading, every direct child is already a real leaf item.
  const itemsWithLeaves = items.map(label => ({ label, leaves: [label] }));
  renderOverviewPage(subLabel, iconClass, itemsWithLeaves,
    (leaf) => openLeaf(leaf, subLabel, () => showSubOverview(subLi, mainLi, sectionLabel, subLabel, iconClass, items), subLabel),
    () => openSectionOverview(mainLi, sectionLabel),
    sectionLabel,
    sectionLabel
  );
}

document.querySelectorAll('.sub-heading > .menu-header').forEach(header => {
  header.addEventListener('click', (e) => {
    e.stopPropagation();
    const subLi = header.closest('.sub-heading');
    const mainLi = subLi.closest('.main-heading');
    const sectionLabel = mainLi.querySelector(':scope > .menu-header span').textContent.trim();
    const subLabel = header.querySelector('span').textContent.trim();
    const iconClass = header.querySelector('i').className.split(' ').find(c => c.startsWith('fa-') && c !== 'fa-solid');
    const items = Array.from(subLi.querySelectorAll(':scope > ul > li')).map(li => li.textContent.trim());

    showSubOverview(subLi, mainLi, sectionLabel, subLabel, iconClass, items);
    if (window.innerWidth <= 900) closeSidebar();
  });
});

function openSectionOverview(mainLi, sectionLabel, iconClassArg) {
  const iconClass = iconClassArg || mainLi.querySelector(':scope > .menu-header i').className.split(' ').find(c => c.startsWith('fa-') && c !== 'fa-solid');
  // Direct children are either a leaf <li> or a sub-heading standing in
  // for a whole group of leaves — resolve both down to real leaf labels
  // so record counts can be looked up per card.
  const directItems = Array.from(mainLi.querySelectorAll(':scope > ul > li')).filter(li => li.dataset.aclHidden !== '1').map(li => {
    const sub = li.querySelector(':scope > .menu-header > span');
    const label = sub ? sub.textContent.trim() : li.textContent.trim();
    return { label, leaves: leafLabelsUnder(li) };
  });
  setActiveLeaf(null);
  renderOverviewPage(sectionLabel, iconClass, directItems, (label) => {
    
    const matchSub = Array.from(mainLi.querySelectorAll(':scope > ul > .sub-heading')).find(sh =>
      sh.querySelector(':scope > .menu-header span').textContent.trim() === label);
    if (matchSub) {
      matchSub.querySelector(':scope > .menu-header').click();
    } else {
      openLeaf(label, sectionLabel, () => openSectionOverview(mainLi, sectionLabel), sectionLabel);
    }
  }, null, null);
}


document.querySelectorAll('.single-item').forEach(li => {
  li.addEventListener('click', () => {
    document.querySelectorAll('.single-item, .main-heading').forEach(x => x.classList.remove('active'));
    li.classList.add('active');
    setActiveLeaf(null);
    renderDashboardHome();
    if (window.innerWidth <= 900) closeSidebar();
  });
});


document.querySelectorAll('.sidebar li').forEach(li => {
  const isContainer = li.classList.contains('main-heading') || li.classList.contains('sub-heading') || li.classList.contains('single-item');
  if (isContainer) return;
  if (li.querySelector(':scope > ul')) return;

  li.addEventListener('click', (e) => {
    e.stopPropagation();
    const mainLi = li.closest('.main-heading');
    const subLi = li.closest('.sub-heading');
    const sectionLabel = mainLi.querySelector(':scope > .menu-header span').textContent.trim();
    const backLabel = subLi ? subLi.querySelector(':scope > .menu-header span').textContent.trim() : sectionLabel;
    const itemLabel = li.textContent.trim();

    setActiveLeaf(li);
    const backAction = subLi
      ? () => {
          const subLabel = subLi.querySelector(':scope > .menu-header span').textContent.trim();
          const iconClass = subLi.querySelector(':scope > .menu-header i').className.split(' ').find(c => c.startsWith('fa-') && c !== 'fa-solid');
          const items = Array.from(subLi.querySelectorAll(':scope > ul > li')).map(x => x.textContent.trim());
          showSubOverview(subLi, mainLi, sectionLabel, subLabel, iconClass, items);
        }
      : () => openSectionOverview(mainLi, sectionLabel);

      dispatchLeaf(itemLabel, sectionLabel, backAction, backLabel);

    if (window.innerWidth <= 900) closeSidebar();
  });
});

// Single place that decides which page renderer owns a given sidebar
// leaf label, used by the direct sidebar click handler above, by
// openLeaf() (overview cards), and by the global search results —
// so Lead Management / HRMS / Sales rich pages open the same way
// no matter how the person navigated there.
function dispatchLeaf(itemLabel, sectionLabel, backAction, backLabel) {
  if (sectionLabel === 'User Profile' && itemLabel === 'Change Password') {
    renderChangePasswordPage();
  } else if (itemLabel === "Customers") {
    renderCustomerListPage();
  } else if (itemLabel === "Create Quote") {
    renderCreateQuotePage(backAction, backLabel);
  } else if (typeof routeErpLeaf === 'function' && routeErpLeaf(itemLabel, sectionLabel, backAction, backLabel)) {
    // handled by modules/erp_pages_*.js (Marketing, Project Management, Asset Management,
    // Document Management and Administration)
  } else if (typeof routeLeadLeaf === 'function' && routeLeadLeaf(itemLabel, sectionLabel, backAction, backLabel)) {
    // handled by modules/lead_management.js (Add Lead, Import Leads, Website/
    // Facebook/Google Ads/WhatsApp Leads, Assigned Leads, Follow-up, Lead
    // Status, Lost Leads, Converted Leads)
  } else if (typeof routeHrmsSalesLeaf === 'function' && routeHrmsSalesLeaf(itemLabel, sectionLabel, backAction, backLabel)) {
    // handled by hrms_sales.js (Employee, Department, Designation, Sales Order,
    // and every other HRMS/Sales rich detail form)
  } else if (typeof routeHelpdeskLeaf === 'function' && routeHelpdeskLeaf(itemLabel, sectionLabel, backAction, backLabel)) {
    // handled by modules/helpdesk.js (Tickets, Complaints, Support, AMC,
    // Remote Support, Priority, SLA, Resolution)
  } else if (typeof routeReportsLeaf === 'function' && routeReportsLeaf(itemLabel, sectionLabel, backAction, backLabel)) {
    // handled by modules/reports.js (CRM/Sales/Customer/Employee/Attendance/
    // Payroll/Project/Inventory/Financial/Support/Productivity/Custom Reports)
  } else if (typeof routeUserMgmt === 'function' && routeUserMgmt(itemLabel, sectionLabel, backAction, backLabel)) {
    // handled by modules/user_management.js (Users, Roles, Permissions, Departments, Designations)
  } else {
    renderModuleListPage(itemLabel, sectionLabel, backAction, backLabel);
  }
}

// User Management Router
function routeUserMgmt(itemLabel, sectionLabel, backAction, backLabel) {
  if (sectionLabel !== 'User Management') return false;
  
  switch (itemLabel) {
    case 'Users':
      renderUsersPage();
      break;
    case 'Roles':
      renderRolesPage();
      break;
    case 'Permissions':
      if (typeof renderPermissionsPage === 'function') renderPermissionsPage();
      else renderRolesPage();
      break;
    case 'Departments':
      renderDepartmentsPage();
      break;
    case 'Designations':
      if (typeof renderDesignationsPage === 'function') renderDesignationsPage();
      else renderDepartmentsPage();
      break;
    default:
      return false;
  }
  
  return true;
}

function setActiveLeaf(li) {
  document.querySelectorAll('.active-leaf').forEach(x => x.classList.remove('active-leaf'));
  if (li) li.classList.add('active-leaf');
}

function openLeaf(itemLabel, sectionLabel, backAction, backLabel) {
  dispatchLeaf(itemLabel, sectionLabel, backAction || (() => renderDashboardHome()), backLabel || 'Dashboard');
}


function openSidebar() { sidebar.classList.add('open'); sidebarOverlay.classList.add('active'); }
function closeSidebar() { sidebar.classList.remove('open'); sidebarOverlay.classList.remove('active'); }
function toggleSidebar() { sidebar.classList.contains('open') ? closeSidebar() : openSidebar(); }

if (hamburgerBtn) hamburgerBtn.addEventListener('click', toggleSidebar);
if (sidebarOverlay) sidebarOverlay.addEventListener('click', closeSidebar);
window.addEventListener('resize', () => { if (window.innerWidth > 900) closeSidebar(); });


const searchIndex = [];
document.querySelectorAll('.sidebar li').forEach(li => {
  const isContainer = li.classList.contains('main-heading') || li.classList.contains('sub-heading') || li.classList.contains('single-item');
  if (isContainer || li.querySelector(':scope > ul')) return;
  const mainLi = li.closest('.main-heading');
  if (!mainLi) return;
  const section = mainLi.querySelector(':scope > .menu-header span').textContent.trim();
  searchIndex.push({ label: li.textContent.trim(), section, el: li });
});

function renderSearchResults(query) {
  const q = query.toLowerCase();
  const matches = searchIndex.filter(item => item.label.toLowerCase().includes(q)).slice(0, 30);

  searchResults.innerHTML = matches.length === 0
    ? `<div class="no-results">No results for "${query}"</div>`
    : matches.map(item => `<div class="result-item" data-label="${item.label}" data-section="${item.section}">${item.label}<small>${item.section}</small></div>`).join('');

  searchResults.classList.add('active');
  searchResults.querySelectorAll('.result-item').forEach(el => {
    el.addEventListener('click', () => {
      searchResults.classList.remove('active');
      searchInput.value = '';
      const match = searchIndex.find(i => i.label === el.dataset.label && i.section === el.dataset.section);
      setActiveLeaf(match ? match.el : null);
      dispatchLeaf(el.dataset.label, el.dataset.section, () => renderDashboardHome(), 'Dashboard');
      if (window.innerWidth <= 900) closeSidebar();
    });
  });
}

if (searchInput) {
  searchInput.addEventListener('input', (e) => {
    const q = e.target.value.trim();
    if (!q) { searchResults.classList.remove('active'); return; }
    renderSearchResults(q);
  });
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const q = searchInput.value.trim();
      if (!q) return;
      const first = searchIndex.find(i => i.label.toLowerCase().includes(q.toLowerCase()));
      if (first) {
        searchResults.classList.remove('active');
        searchInput.value = '';
        setActiveLeaf(first.el);
        openLeaf(first.label, first.section, () => renderDashboardHome(), 'Dashboard');
      }
    }
    if (e.key === 'Escape') { searchResults.classList.remove('active'); searchInput.blur(); }
  });
}

document.addEventListener('click', (e) => {
  if (searchResults && !e.target.closest('.search-box')) searchResults.classList.remove('active');
});

document.addEventListener('keydown', (e) => {
  if (e.key === '/' && document.activeElement !== searchInput) {
    e.preventDefault();
    searchInput.focus();
  }
});


document.querySelector('.single-item').classList.add('active');
initApp();

async function initApp() {
  const nameEl = document.querySelector('.user-profile .user-name');
  const roleEl = document.querySelector('.user-profile .user-role');
  const avatarEl = document.querySelector('.user-profile .avatar');

  let user;
  try {
    const res = await fetch('api/auth.php?action=check');
    const json = await res.json();
    if (!json.success) throw new Error('not authenticated');
    user = json.user;
  } catch (err) {
    // No valid session — send the person to sign in instead of
    // showing the dashboard with fake data.
    window.location.href = 'login.html';
    return;
  }

  window.currentUser = user;
  if (typeof erpApplyRoleMenu === 'function') erpApplyRoleMenu(user);
  if (nameEl) nameEl.textContent = user.name || 'User';
  if (roleEl) roleEl.textContent = user.role || 'User';
  if (avatarEl) {
    if (user.avatar) {
      avatarEl.innerHTML = `<img src="${user.avatar}" alt="${user.name || ''}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`;
    } else {
      avatarEl.textContent = (user.name || 'U').trim().charAt(0).toUpperCase();
    }
  }
  wireProfileMenu();

  renderDashboardHome();
}

// Clicking the avatar/name opens a tiny profile menu with a photo-upload
// option, wired to api/auth.php action=update_profile. Built once, lazily.
function wireProfileMenu() {
  const profile = document.querySelector('.user-profile');
  if (!profile || document.getElementById('profileMenuPopover')) return;

  const popover = document.createElement('div');
  popover.id = 'profileMenuPopover';
  popover.className = 'profile-menu-popover';
  popover.innerHTML = `
    <div class="pm-row"><strong id="pmName"></strong></div>
    <div class="pm-row muted" id="pmRole" style="font-size:.78rem;"></div>
    <hr style="margin:8px 0;border:none;border-top:1px solid #e7e9f0;">
    <label class="pm-upload-btn">
      <i class="fas fa-camera"></i> Change photo
      <input type="file" id="pmAvatarInput" accept="image/*" style="display:none;">
    </label>
    <button type="button" class="pm-upload-btn" id="pmChangePw" style="display:block;margin-top:8px;border:none;background:none;padding:0;font:inherit;cursor:pointer;text-align:left;">
      <i class="fas fa-key"></i> Change password
    </button>
    <div id="pmMsg" style="font-size:.76rem;margin-top:6px;"></div>
  `;
  popover.style.cssText = `position:absolute;top:56px;right:16px;background:#fff;border:1px solid #e2e6ee;
    border-radius:10px;box-shadow:0 12px 30px rgba(15,23,42,.14);padding:14px 16px;min-width:200px;
    z-index:200;display:none;`;
  document.body.appendChild(popover);

  const nameHolder = document.querySelector('.user-profile .user-name');
  const avatarEl = document.querySelector('.user-profile .avatar');

  profile.style.cursor = 'pointer';
  profile.addEventListener('click', (e) => {
    if (e.target.closest('.logout-btn')) return;
    document.getElementById('pmName').textContent = window.currentUser?.name || '';
    document.getElementById('pmRole').textContent = window.currentUser?.role || '';
    const rect = profile.getBoundingClientRect();
    popover.style.top = (rect.bottom + 8) + 'px';
    popover.style.right = (window.innerWidth - rect.right) + 'px';
    popover.style.display = popover.style.display === 'block' ? 'none' : 'block';
  });

  document.addEventListener('click', (e) => {
    if (!popover.contains(e.target) && !profile.contains(e.target)) popover.style.display = 'none';
  });

  document.getElementById('pmChangePw').addEventListener('click', () => {
    popover.style.display = 'none';
    renderChangePasswordPage();
  });

  document.getElementById('pmAvatarInput').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const msg = document.getElementById('pmMsg');
    msg.textContent = 'Uploading…'; msg.style.color = '#64748b';
    const fd = new FormData();
    fd.append('action', 'update_profile');
    fd.append('avatar', file);
    try {
      const res = await fetch('api/auth.php', { method: 'POST', body: fd });
      const json = await res.json();
      if (!json.success) throw new Error(json.message || 'Upload failed');
      const path = json.user.avatar_path;
      window.currentUser.avatar = path;
      if (avatarEl && path) {
        avatarEl.innerHTML = `<img src="${path}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`;
      }
      msg.textContent = 'Photo updated.'; msg.style.color = '#16a34a';
    } catch (err) {
      msg.textContent = err.message; msg.style.color = '#d3312f';
    }
  });
}

// ---------------------------------------------------------
// Change my password (signed-in user). api/auth.php action=change_password
// ---------------------------------------------------------
function renderChangePasswordPage() {
  if (typeof destroyCharts === 'function') destroyCharts();
  if (typeof setActiveLeaf === 'function') setActiveLeaf(null);
  mainContent.innerHTML = `
    <div class="eyebrow"><span class="crumb-current">User Profile</span></div>
    <div class="page-title"><span><i class="fas fa-key" style="color:var(--accent-orange);margin-right:10px;"></i>Change Password</span></div>
    <div class="panel" style="max-width:480px;">
      <form id="cpForm" autocomplete="off">
        <div class="form-group"><label for="cpCurrent">Current password</label>
          <input type="password" id="cpCurrent" required autocomplete="current-password"></div>
        <div class="form-group"><label for="cpNew">New password</label>
          <input type="password" id="cpNew" required minlength="6" autocomplete="new-password"></div>
        <div class="form-group"><label for="cpConfirm">Confirm new password</label>
          <input type="password" id="cpConfirm" required autocomplete="new-password"></div>
        <button type="submit" class="btn-primary" id="cpBtn" style="margin-top:6px;"><i class="fas fa-check"></i> Update password</button>
        <div id="cpMsg" style="margin-top:12px;font-size:.88rem;"></div>
      </form>
    </div>`;
  document.getElementById('cpForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const msg = document.getElementById('cpMsg'), btn = document.getElementById('cpBtn');
    const nw = document.getElementById('cpNew').value, cf = document.getElementById('cpConfirm').value;
    msg.style.color = '#d3312f';
    if (nw !== cf) { msg.textContent = 'New password and confirmation do not match.'; return; }
    btn.disabled = true;
    try {
      const res = await fetch('api/auth.php', { method: 'POST', body: new URLSearchParams({
        action: 'change_password', current_password: document.getElementById('cpCurrent').value, new_password: nw, confirm: cf }) });
      const json = await res.json();
      if (!json.success) throw new Error(json.message || 'Could not change the password.');
      msg.style.color = '#16a34a'; msg.textContent = json.message;
      e.target.reset();
    } catch (err) { msg.textContent = err.message; }
    btn.disabled = false;
  });
}

const logoutBtn = document.querySelector('.logout-btn');
if (logoutBtn) {
  logoutBtn.addEventListener('click', async () => {
    if (!confirm('Log out of SABHYTACRM?')) return;
    try {
      await fetch('api/auth.php', { method: 'POST', body: new URLSearchParams({ action: 'logout' }) });
    } finally {
      window.location.href = 'login.html';
    }
  });
}

const API_BASE = 'api/customers.php';

function renderCustomerForm(editId = null) {

  destroyCharts();

  mainContent.innerHTML = `

      <!-- ================= CUSTOMER INFORMATION FORM ================= -->

<div id="customerFormPage" class="page-content">

    <div class="page-header">
        <h2>${editId ? 'Edit Customer' : 'Customer Management'}</h2>
        <p>${editId ? 'Update customer information' : 'Create and Manage Customer Information'}</p>
        <button type="button" class="btn-secondary" id="backToListBtn" style="margin-top:10px;">
            <i class="fas fa-arrow-left"></i> Back to List
        </button>
    </div>

    <form id="customerForm">

        <!-- ================= CUSTOMER DETAILS ================= -->

        <div class="form-card">

            <div class="card-title">
                <h3>Customer Information</h3>
            </div>

            <div class="form-grid">

                <div class="form-group">
                    <label>Customer ID</label>
                    <input type="text" id="customerId" readonly>
                </div>

                <div class="form-group">
                    <label>Customer Code *</label>
                    <input type="text" id="customerCode" required>
                </div>

                <div class="form-group">
                    <label>Customer Type *</label>
                    <select id="customerType" required>
                        <option value="">Select</option>
                        <option>Individual</option>
                        <option>Company</option>
                        <option>Government</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Customer Category *</label>
                    <select id="customerCategory">
                        <option>Retail</option>
                        <option>Wholesale</option>
                        <option>Distributor</option>
                        <option>Dealer</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Customer Name *</label>
                    <input type="text" id="customerName">
                </div>

                <div class="form-group">
                    <label>Company Name</label>
                    <input type="text" id="companyName">
                </div>

                <div class="form-group">
                    <label>Display Name</label>
                    <input type="text" id="displayName">
                </div>

                <div class="form-group">
                    <label>GST Number</label>
                    <input type="text" id="gst">
                </div>

                <div class="form-group">
                    <label>PAN Number</label>
                    <input type="text" id="pan">
                </div>

                <div class="form-group">
                    <label>TAN Number</label>
                    <input type="text" id="tan">
                </div>

                <div class="form-group">
                    <label>CIN Number</label>
                    <input type="text" id="cin">
                </div>

                <div class="form-group">
                    <label>MSME Number</label>
                    <input type="text" id="msme">
                </div>

                <div class="form-group">
                    <label>Industry Type *</label>
                    <select id="industry">
                        <option>Manufacturing</option>
                        <option>IT</option>
                        <option>Education</option>
                        <option>Healthcare</option>
                        <option>Retail</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Business Nature *</label>
                    <select id="businessNature">
                        <option>Service</option>
                        <option>Trading</option>
                        <option>Manufacturing</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Annual Turnover</label>
                    <input type="number" id="turnover">
                </div>

                <div class="form-group">
                    <label>Employees</label>
                    <input type="number" id="employees">
                </div>

                <div class="form-group">
                    <label>Website</label>
                    <input type="url" id="website">
                </div>

                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" id="email">
                </div>

                <div class="form-group">
                    <label>Mobile *</label>
                    <input type="tel" id="mobile">
                </div>

                <div class="form-group">
                    <label>Alternate Mobile</label>
                    <input type="tel" id="altMobile">
                </div>

                <div class="form-group">
                    <label>Landline</label>
                    <input type="text" id="landline">
                </div>

                <div class="form-group">
                    <label>Fax</label>
                    <input type="text" id="fax">
                </div>

                <div class="form-group">
                    <label>Status</label>
                    <select id="status">
                        <option>Active</option>
                        <option>Inactive</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Lead Source</label>
                    <select id="leadSource">
                        <option>Website</option>
                        <option>Reference</option>
                        <option>Walk In</option>
                        <option>Advertisement</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Customer Since</label>
                    <input type="date" id="customerSince">
                </div>

                <div class="form-group">
                    <label>Customer Rating</label>
                    <select id="rating">
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option selected>4</option>
                        <option>5</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Sales Executive</label>
                    <select id="salesExecutive">
                        <option value="">Loading employees…</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Branch</label>
                    <select id="branch">
                        <option>Head Office</option>
                        <option>Mumbai</option>
                        <option>Delhi</option>
                        <option>Pune</option>
                    </select>
                </div>

                <div class="form-group full-width">
                    <label>Remarks</label>
                    <textarea rows="4" id="remarks"></textarea>
                </div>

            </div>

        </div>

        <!-- ================= COMPANY DETAILS ================= -->

        <div class="form-card">

            <div class="card-title">
                <h3>Company Details</h3>
            </div>

            <div class="form-grid">

                <div class="form-group">
                    <label>Legal Company Name</label>
                    <input type="text" id="legalCompanyName">
                </div>

                <div class="form-group">
                    <label>Trade Name</label>
                    <input type="text" id="tradeName">
                </div>

                <div class="form-group">
                    <label>Registration Number</label>
                    <input type="text" id="registrationNumber">
                </div>

                <div class="form-group">
                    <label>GST Registration Date</label>
                    <input type="date" id="gstRegistrationDate">
                </div>

                <div class="form-group">
                    <label>PAN Card</label>
                    <input type="file" id="panCardFile">
                </div>

                <div class="form-group">
                    <label>GST Certificate</label>
                    <input type="file" id="gstCertificateFile">
                </div>

                <div class="form-group">
                    <label>Incorporation Certificate</label>
                    <input type="file" id="incorporationCertificateFile">
                </div>

                <div class="form-group">
                    <label>Business License</label>
                    <input type="file" id="businessLicenseFile">
                </div>

                <div class="form-group">
                    <label>ISO Certificate</label>
                    <input type="file" id="isoCertificateFile">
                </div>

                <div class="form-group">
                    <label>UDYAM Certificate</label>
                    <input type="file" id="udyamCertificateFile">
                </div>

                <div class="form-group">
                    <label>Company Logo</label>
                    <input type="file" id="companyLogoFile">
                </div>

                <div class="form-group">
                    <label>Company Profile PDF</label>
                    <input type="file" id="companyProfileFile">
                </div>

            </div>

        </div>

        <!-- ================= REGISTERED ADDRESS ================= -->

        <div class="form-card">

            <div class="card-title">
                <h3>Registered Address</h3>
            </div>

            <div class="form-grid">

                <div class="form-group">
                    <label>Address Line 1</label>
                    <input type="text" id="addressLine1">
                </div>

                <div class="form-group">
                    <label>Address Line 2</label>
                    <input type="text" id="addressLine2">
                </div>

                <div class="form-group">
                    <label>Area</label>
                    <input type="text" id="area">
                </div>

                <div class="form-group">
                    <label>City</label>
                    <input type="text" id="city">
                </div>

                <div class="form-group">
                    <label>District</label>
                    <input type="text" id="district">
                </div>

                <div class="form-group">
                    <label>State</label>
                    <input type="text" id="state">
                </div>

                <div class="form-group">
                    <label>Country</label>
                    <input type="text" id="country" value="India">
                </div>

                <div class="form-group">
                    <label>PIN Code</label>
                    <input type="number" id="pincode">
                </div>

            </div>

        </div>

        <!-- Buttons -->

        <div class="form-actions">

            <button type="submit" class="btn-primary" id="saveCustomerBtn">
                ${editId ? 'Update Customer' : 'Save Customer'}
            </button>

            <button type="reset" class="btn-secondary">
                Clear
            </button>

            <span id="formStatusMsg" style="margin-left:14px;font-size:14px;"></span>

        </div>

    </form>

</div>

  `;

  wireCustomerForm(editId);
}

// ---------------------------------------------------------
// Wires up the Customer form: edit-mode prefill + save via API
// ---------------------------------------------------------
async function wireCustomerForm(editId) {
  const form = document.getElementById('customerForm');
  const statusMsg = document.getElementById('formStatusMsg');
  const saveBtn = document.getElementById('saveCustomerBtn');

  document.getElementById('backToListBtn').addEventListener('click', () => renderCustomerListPage());

  // Map of DB column -> form field id, mirrors api/customers.php $FIELDS
  const FIELD_MAP = {
    customer_code: 'customerCode', customer_type: 'customerType', customer_category: 'customerCategory',
    customer_name: 'customerName', company_name: 'companyName', display_name: 'displayName',
    gst_number: 'gst', pan_number: 'pan', tan_number: 'tan', cin_number: 'cin', msme_number: 'msme',
    industry: 'industry', business_nature: 'businessNature', turnover: 'turnover', employees: 'employees',
    website: 'website', email: 'email', mobile: 'mobile', alt_mobile: 'altMobile', landline: 'landline',
    fax: 'fax', status: 'status', lead_source: 'leadSource', customer_since: 'customerSince',
    rating: 'rating', sales_executive: 'salesExecutive', branch: 'branch', remarks: 'remarks',
    legal_company_name: 'legalCompanyName', trade_name: 'tradeName', registration_number: 'registrationNumber',
    gst_registration_date: 'gstRegistrationDate', address_line1: 'addressLine1', address_line2: 'addressLine2',
    area: 'area', city: 'city', district: 'district', state: 'state', country: 'country', pincode: 'pincode'
  };

  if (editId) {
    try {
      const res = await fetch(`${API_BASE}?id=${editId}`);
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      const c = json.data;
      document.getElementById('customerId').value = c.id;
      Object.entries(FIELD_MAP).forEach(([col, fieldId]) => {
        const el = document.getElementById(fieldId);
        if (el && c[col] !== null && c[col] !== undefined && fieldId !== 'salesExecutive') el.value = c[col];
      });
      if (typeof populateEmployeeNameSelect === 'function') {
        await populateEmployeeNameSelect('salesExecutive', c.sales_executive);
      }
    } catch (err) {
      statusMsg.textContent = 'Could not load customer: ' + err.message;
      statusMsg.style.color = '#d33';
    }
  } else if (typeof populateEmployeeNameSelect === 'function') {
    await populateEmployeeNameSelect('salesExecutive');
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    statusMsg.textContent = '';
    saveBtn.disabled = true;
    saveBtn.textContent = editId ? 'Updating…' : 'Saving…';

    const fd = new FormData();
    Object.entries(FIELD_MAP).forEach(([col, fieldId]) => {
      const el = document.getElementById(fieldId);
      if (el) fd.append(fieldId, el.value);
    });

    // File inputs
    ['panCardFile','gstCertificateFile','incorporationCertificateFile','businessLicenseFile',
     'isoCertificateFile','udyamCertificateFile','companyLogoFile','companyProfileFile'].forEach(id => {
      const el = document.getElementById(id);
      if (el && el.files[0]) fd.append(id, el.files[0]);
    });

    let url = API_BASE;
    if (editId) {
      fd.append('id', editId);
      fd.append('_method', 'PUT');
    }

    try {
      const res = await fetch(url, { method: 'POST', body: fd });
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      statusMsg.style.color = 'green';
      statusMsg.textContent = editId ? 'Customer updated successfully.' : 'Customer saved successfully.';
      setTimeout(() => renderCustomerListPage(), 700);
    } catch (err) {
      statusMsg.style.color = '#d33';
      statusMsg.textContent = 'Error: ' + err.message;
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = editId ? 'Update Customer' : 'Save Customer';
    }
  });
}

// ---------------------------------------------------------
// Customer list page: fetches from API, shows table with
// Edit / Delete actions and an "Add Customer" button.
// ---------------------------------------------------------
async function renderCustomerListPage() {
  destroyCharts();

  mainContent.innerHTML = `
    <div class="page-header">
      <h2>Customers</h2>
      <p>All saved customer records</p>
      <button type="button" class="btn-primary" id="addCustomerBtn" style="margin-top:10px;">
        <i class="fas fa-plus"></i> Add Customer
      </button>
    </div>

    <div class="table-panel">
      <div class="panel-head"><h3>Customer List</h3></div>
      <div class="table-scroll">
        <table class="data-table">
          <thead>
            <tr>
              <th>ID</th><th>Code</th><th>Name</th><th>Company</th><th>Mobile</th><th>Email</th><th>Status</th><th>Actions</th>
            </tr>
          </thead>
          <tbody id="customerTableBody">
            <tr><td colspan="8">Loading…</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  `;

  document.getElementById('addCustomerBtn').addEventListener('click', () => renderCustomerForm());

  const tbody = document.getElementById('customerTableBody');
  try {
    const res = await fetch(API_BASE);
    const json = await res.json();
    if (!json.success) throw new Error(json.message);
    const rows = json.data;

    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="8">No customers yet. Click "Add Customer" to create one.</td></tr>`;
      return;
    }

    tbody.innerHTML = rows.map(c => `
      <tr>
        <td>${c.id}</td>
        <td class="cell-strong">${c.customer_code ?? ''}</td>
        <td>${c.customer_name ?? ''}</td>
        <td>${c.company_name ?? ''}</td>
        <td>${c.mobile ?? ''}</td>
        <td>${c.email ?? ''}</td>
        <td><span class="status-chip ${statusClass(c.status || 'Active')}">${c.status ?? ''}</span></td>
        <td>
          <button type="button" class="btn-secondary edit-customer-btn" data-id="${c.id}">Edit</button>
          <button type="button" class="btn-secondary delete-customer-btn" data-id="${c.id}">Delete</button>
        </td>
      </tr>
    `).join('');

    tbody.querySelectorAll('.edit-customer-btn').forEach(btn => {
      btn.addEventListener('click', () => renderCustomerForm(btn.dataset.id));
    });
    tbody.querySelectorAll('.delete-customer-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        if (!confirm('Delete this customer? This cannot be undone.')) return;
        try {
          const res = await fetch(`${API_BASE}?id=${btn.dataset.id}`, { method: 'DELETE' });
          const json = await res.json();
          if (!json.success) throw new Error(json.message);
          renderCustomerListPage();
        } catch (err) {
          alert('Delete failed: ' + err.message);
        }
      });
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8">Failed to load customers: ${err.message}</td></tr>`;
  }
}
// ===========================================================
// CREATE QUOTE — split-view page
// 1st half: searchable table of customers already created
// (live from api/customers.php), with a search box on top.
// 2nd half: the full Quote form. Saving posts to
// api/records.php (module_key "crm__create-quote") with the
// detailed quote fields (line items, financial summary, terms)
// packed into extra_data as JSON.
// ===========================================================

const QUOTE_MODULE_KEY   = 'crm__create-quote';
const QUOTE_MODULE_LABEL = 'Create Quote';

let quoteCustomersCache  = [];
let quoteSelectedCustomer = null;
let quoteLineItemSeq     = 0;

function generateQuoteNumber() {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  return `QT-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

function fmtCurrency(n) {
  const v = isFinite(n) ? n : 0;
  return '₹' + v.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

async function renderCreateQuotePage(backAction, backLabel) {
  destroyCharts();
  quoteSelectedCustomer = null;
  quoteLineItemSeq = 0;

  const quoteNumber = generateQuoteNumber();
  const today = new Date().toISOString().slice(0, 10);

  mainContent.innerHTML = `
    <button class="back-btn" id="backBtn"><i class="fas fa-arrow-left"></i> Back to ${backLabel}</button>
    <div class="eyebrow">CRM <span class="crumb-sep">/</span> Quotation <span class="crumb-sep">/</span> <span class="crumb-current">Create Quote</span></div>
    <div class="page-title">
      <span>Create Quote</span>
      <div class="actions">
        <button type="button" class="btn-secondary" id="viewSavedQuotesBtn"><i class="fas fa-list"></i> Saved Quotations</button>
      </div>
    </div>

    <div class="quote-split-wrap">

      <!-- ================= 1st HALF — CUSTOMER DETAILS ================= -->
      <div class="table-panel quote-half" id="quoteCustomerHalf">
        <div class="panel-head" style="padding:20px 22px 0;">
          <div>
            <div class="quote-half-label"><span class="half-num">1</span> Customer Details</div>
            <div class="panel-title" style="margin-top:6px;">Customers already created</div>
            <div class="panel-sub">Search below, then pick who this quote is for</div>
          </div>
        </div>
        <div style="padding: 14px 22px 0;">
          <div class="customer-search-bar">
            <i class="fas fa-search"></i>
            <input type="text" id="quoteCustomerSearch" placeholder="Search by name, company, code, email or mobile…" autocomplete="off">
            <button type="button" class="clear-search-btn" id="quoteCustomerSearchClear"><i class="fas fa-times"></i></button>
          </div>
        </div>
        <div class="table-scroll" style="padding-bottom:6px;">
          <table class="data-table">
            <thead>
              <tr><th>Code</th><th>Customer / Company</th><th>Contact</th><th>Branch</th><th>Status</th><th></th></tr>
            </thead>
            <tbody id="quoteCustomerTableBody"><tr><td colspan="6">Loading customers…</td></tr></tbody>
          </table>
        </div>
      </div>

      <!-- ================= 2nd HALF — QUOTE FORM ================= -->
      <div class="quote-half" id="quoteFormHalf">
        <div class="quote-half-label" style="margin-bottom:12px;"><span class="half-num">2</span> Quote Form</div>

        <div id="quoteSelectedBanner"></div>

        <form id="createQuoteForm">
          <div class="form-card">
            <h3>Quote Information</h3>
            <div class="form-grid">
              <div class="form-group"><label>Quotation Number</label><input type="text" id="qQuoteNumber" value="${quoteNumber}" readonly></div>
              <div class="form-group"><label>Revision No.</label><input type="text" id="qRevisionNo" value="0" readonly></div>
              <div class="form-group"><label>Quote Date <span class="required">*</span></label><input type="date" id="qQuoteDate" value="${today}" required></div>
              <div class="form-group"><label>Valid Till <span class="required">*</span></label><input type="date" id="qValidTill" required></div>
              <div class="form-group"><label>RFQ Number</label><input type="text" id="qRfqNumber"></div>
              <div class="form-group"><label>Inquiry Number</label><input type="text" id="qInquiryNumber"></div>
              <div class="form-group"><label>Inquiry Date</label><input type="date" id="qInquiryDate"></div>

              <div class="form-group">
                <label>Customer <span class="required">*</span></label>
                <select id="qCustomer" required><option value="">Select from Customer Details above…</option></select>
              </div>
              <div class="form-group"><label>Contact Person <span class="required">*</span></label><input type="text" id="qContactPerson" required></div>
              <div class="form-group"><label>Sales Executive <span class="required">*</span></label><select id="qSalesExecutive" required><option value="">Loading employees…</option></select></div>
              <div class="form-group"><label>Sales Team</label><input type="text" id="qSalesTeam"></div>
              <div class="form-group"><label>Branch <span class="required">*</span></label><input type="text" id="qBranch" required></div>
              <div class="form-group"><label>Project Name</label><input type="text" id="qProjectName"></div>
              <div class="form-group"><label>Project Location</label><input type="text" id="qProjectLocation"></div>
              <div class="form-group"><label>Department</label><input type="text" id="qDepartment"></div>

              <div class="form-group">
                <label>Currency <span class="required">*</span></label>
                <select id="qCurrency" required>
                  <option value="INR" selected>INR — Indian Rupee</option>
                  <option value="USD">USD — US Dollar</option>
                  <option value="EUR">EUR — Euro</option>
                  <option value="GBP">GBP — British Pound</option>
                  <option value="AED">AED — UAE Dirham</option>
                </select>
              </div>
              <div class="form-group"><label>Exchange Rate</label><input type="number" step="0.0001" id="qExchangeRate" value="1"></div>

              <div class="form-group">
                <label>Price Basis <span class="required">*</span></label>
                <select id="qPriceBasis" required>
                  <option value="Ex-Works">Ex-Works</option>
                  <option value="FOB">FOB</option>
                  <option value="CIF">CIF</option>
                  <option value="DDP">DDP</option>
                </select>
              </div>
              <div class="form-group">
                <label>Payment Terms <span class="required">*</span></label>
                <select id="qPaymentTerms" required>
                  <option value="100% Advance">100% Advance</option>
                  <option value="50% Advance, 50% on Delivery">50% Advance, 50% on Delivery</option>
                  <option value="30% Advance, 70% on Delivery">30% Advance, 70% on Delivery</option>
                  <option value="Net 15">Net 15</option>
                  <option value="Net 30">Net 30</option>
                  <option value="Net 45">Net 45</option>
                  <option value="Against Delivery">Against Delivery</option>
                </select>
              </div>
              <div class="form-group">
                <label>Delivery Terms <span class="required">*</span></label>
                <select id="qDeliveryTerms" required>
                  <option value="Ex-Works">Ex-Works</option>
                  <option value="Door Delivery">Door Delivery</option>
                  <option value="Site Delivery">Site Delivery</option>
                  <option value="Freight on Board">Freight on Board</option>
                </select>
              </div>
              <div class="form-group"><label>Delivery Time <span class="required">*</span></label><input type="text" id="qDeliveryTime" placeholder="e.g. 4-6 weeks" required></div>
              <div class="form-group"><label>Warranty</label><input type="text" id="qWarranty" placeholder="e.g. 12 months"></div>
              <div class="form-group">
                <label>AMC Applicable <span class="required">*</span></label>
                <select id="qAmcApplicable" required><option value="No">No</option><option value="Yes">Yes</option></select>
              </div>
              <div class="form-group">
                <label>Tax Type <span class="required">*</span></label>
                <select id="qTaxType" required><option value="GST">GST</option><option value="IGST">IGST</option></select>
              </div>

              <div class="form-group"><label>Freight Charges</label><input type="number" step="0.01" id="qFreight" value="0"></div>
              <div class="form-group"><label>Packing Charges</label><input type="number" step="0.01" id="qPacking" value="0"></div>
              <div class="form-group"><label>Installation Charges</label><input type="number" step="0.01" id="qInstallation" value="0"></div>
              <div class="form-group"><label>Insurance Charges</label><input type="number" step="0.01" id="qInsurance" value="0"></div>
              <div class="form-group"><label>Other Charges</label><input type="number" step="0.01" id="qOtherCharges" value="0"></div>

              <div class="form-group">
                <label>Status <span class="required">*</span></label>
                <select id="qStatus" required>
                  <option value="Draft" selected>Draft</option>
                  <option value="Submitted">Submitted</option>
                  <option value="Sent">Sent</option>
                  <option value="Approved">Approved</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>
            </div>
          </div>

          <div class="form-card">
            <h3>Product / Service Details</h3>
            <div class="line-items-wrap">
              <table class="line-items-table">
                <thead>
                  <tr>
                    <th style="min-width:160px;">Product / Service</th>
                    <th style="min-width:180px;">Description</th>
                    <th style="min-width:90px;">HSN/SAC</th>
                    <th style="min-width:80px;">Unit</th>
                    <th style="min-width:70px;">Qty</th>
                    <th style="min-width:100px;">Unit Price</th>
                    <th style="min-width:80px;">Disc %</th>
                    <th style="min-width:70px;">Tax %</th>
                    <th style="min-width:110px;">Total</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody id="quoteLineItemsBody"></tbody>
              </table>
            </div>
            <button type="button" class="btn-secondary add-line-btn" id="addLineItemBtn"><i class="fas fa-plus"></i> Add Line Item</button>
          </div>

          <div class="form-card">
            <h3>Financial Summary</h3>
            <div class="financial-summary-grid">
              <div class="fin-item"><label>Sub Total</label><div class="fin-value" id="finSubTotal">₹0.00</div></div>
              <div class="fin-item"><label>Total Discount</label><div class="fin-value" id="finDiscount">₹0.00</div></div>
              <div class="fin-item"><label>Total Tax</label><div class="fin-value" id="finTax">₹0.00</div></div>
              <div class="fin-item"><label>Freight + Packing + Install + Ins. + Other</label><div class="fin-value" id="finOtherCharges">₹0.00</div></div>
              <div class="fin-item grand-total"><label>Grand Total</label><div class="fin-value" id="finGrandTotal">₹0.00</div></div>
              <div class="fin-item"><label>Round Off</label><div class="fin-value" id="finRoundOff">₹0.00</div></div>
              <div class="fin-item net-amount"><label>Net Amount</label><div class="fin-value" id="finNetAmount">₹0.00</div></div>
            </div>
          </div>

          <div class="form-card">
            <h3>Terms &amp; Notes</h3>
            <div class="form-grid">
              <div class="form-group full-width"><label>Terms &amp; Conditions <span class="required">*</span></label><textarea id="qTerms" required placeholder="Standard terms & conditions for this quotation…"></textarea></div>
              <div class="form-group full-width"><label>Internal Notes</label><textarea id="qInternalNotes" placeholder="Visible only inside the CRM"></textarea></div>
              <div class="form-group full-width"><label>Customer Notes</label><textarea id="qCustomerNotes" placeholder="Shown on the quotation sent to the customer"></textarea></div>
            </div>
          </div>

          <div class="form-card">
            <h3>Attachments</h3>
            <div class="form-grid">
              <div class="form-group"><label>BOQ</label><input type="file" id="qFileBoq"></div>
              <div class="form-group"><label>Drawings</label><input type="file" id="qFileDrawings"></div>
              <div class="form-group"><label>Technical Specification</label><input type="file" id="qFileTechSpec"></div>
              <div class="form-group"><label>Customer RFQ</label><input type="file" id="qFileRfq"></div>
              <div class="form-group"><label>Images</label><input type="file" id="qFileImages"></div>
              <div class="form-group"><label>Supporting Documents</label><input type="file" id="qFileSupporting" multiple></div>
            </div>
          </div>

          <div class="form-actions">
            <button type="submit" class="btn-save" id="saveQuoteBtn">Save Quote</button>
            <button type="reset" class="btn-reset" id="resetQuoteBtn">Clear</button>
            <span id="quoteFormStatusMsg" style="margin-left:14px;font-size:14px;"></span>
          </div>
        </form>
      </div>
    </div>
  `;

  document.getElementById('backBtn').addEventListener('click', backAction);
  document.getElementById('viewSavedQuotesBtn').addEventListener('click', () =>
    renderModuleListPage(QUOTE_MODULE_LABEL, 'CRM', backAction, backLabel));

  addQuoteLineItemRow();      // start with one blank line item
  wireQuoteCustomerPanel();   // top half: load + search customers
  wireQuoteForm();            // bottom half: totals + save
  if (typeof populateEmployeeNameSelect === 'function') populateEmployeeNameSelect('qSalesExecutive');
}

// ---------- 1st half: customer list + live search ----------
async function wireQuoteCustomerPanel() {
  const tbody = document.getElementById('quoteCustomerTableBody');
  const searchInput = document.getElementById('quoteCustomerSearch');
  const clearBtn = document.getElementById('quoteCustomerSearchClear');

  async function loadCustomers(q = '') {
    tbody.innerHTML = `<tr><td colspan="6">Loading customers…</td></tr>`;
    try {
      const url = q ? `${API_BASE}?q=${encodeURIComponent(q)}` : API_BASE;
      const res = await fetch(url);
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      quoteCustomersCache = json.data;
      renderQuoteCustomerTable(quoteCustomersCache);
      populateQuoteCustomerDropdown(quoteCustomersCache);
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="6">Failed to load customers: ${err.message}</td></tr>`;
    }
  }

  let searchTimer = null;
  searchInput.addEventListener('input', (e) => {
    const q = e.target.value.trim();
    clearBtn.style.display = q ? 'block' : 'none';
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => loadCustomers(q), 300);
  });
  clearBtn.addEventListener('click', () => {
    searchInput.value = '';
    clearBtn.style.display = 'none';
    loadCustomers('');
  });

  await loadCustomers('');
}

function renderQuoteCustomerTable(rows) {
  const tbody = document.getElementById('quoteCustomerTableBody');
  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="6">No customers found. Add one from Customer Management → Customers first.</td></tr>`;
    return;
  }
  tbody.innerHTML = rows.map(c => {
    const isSel = quoteSelectedCustomer && String(quoteSelectedCustomer.id) === String(c.id);
    return `
    <tr class="customer-mini-row${isSel ? ' selected-customer-row' : ''}" data-id="${c.id}">
      <td class="cell-strong">${c.customer_code ?? ''}</td>
      <td>${c.customer_name ?? ''}${c.company_name ? ` <span style="color:var(--text-faint);">(${c.company_name})</span>` : ''}</td>
      <td>${c.mobile ?? ''}<br><span style="color:var(--text-faint);">${c.email ?? ''}</span></td>
      <td>${c.branch ?? ''}</td>
      <td><span class="status-chip ${statusClass(c.status || 'Active')}">${c.status ?? ''}</span></td>
      <td><button type="button" class="use-customer-btn${isSel ? ' is-selected' : ''}" data-id="${c.id}">${isSel ? '<i class="fas fa-check"></i> Selected' : 'Use for Quote'}</button></td>
    </tr>`;
  }).join('');

  tbody.querySelectorAll('.customer-mini-row').forEach(row => {
    row.addEventListener('click', () => {
      const c = quoteCustomersCache.find(x => String(x.id) === String(row.dataset.id));
      if (c) selectQuoteCustomer(c);
    });
  });
}

function populateQuoteCustomerDropdown(rows) {
  const sel = document.getElementById('qCustomer');
  if (!sel) return;
  const current = sel.value;
  sel.innerHTML = '<option value="">Select from Customer Details above…</option>' +
    rows.map(c => `<option value="${c.id}">${c.customer_name ?? ''}${c.company_name ? ' — ' + c.company_name : ''}</option>`).join('');
  if (current) sel.value = current;
}

function selectQuoteCustomer(c) {
  quoteSelectedCustomer = c;
  renderQuoteCustomerTable(quoteCustomersCache);

  const sel = document.getElementById('qCustomer');
  if (sel) sel.value = c.id;

  const contactEl = document.getElementById('qContactPerson');
  if (contactEl && !contactEl.value) contactEl.value = c.customer_name || '';
  const salesExecEl = document.getElementById('qSalesExecutive');
  if (salesExecEl && !salesExecEl.value && c.sales_executive) salesExecEl.value = c.sales_executive;
  const branchEl = document.getElementById('qBranch');
  if (branchEl && !branchEl.value && c.branch) branchEl.value = c.branch;

  const banner = document.getElementById('quoteSelectedBanner');
  if (banner) {
    banner.innerHTML = `
      <div class="selected-customer-banner">
        <i class="fas fa-circle-check"></i>
        Quoting for <b>${c.customer_name ?? ''}</b>${c.company_name ? ' · ' + c.company_name : ''}${c.mobile ? ' — ' + c.mobile : ''}
      </div>`;
  }
}

// ---------- 2nd half: line items, totals, save ----------
function addQuoteLineItemRow(item = {}) {
  const tbody = document.getElementById('quoteLineItemsBody');
  quoteLineItemSeq++;
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td><input type="text" class="li-name" value="${item.name ?? ''}" placeholder="Product / service name"></td>
    <td><input type="text" class="li-desc" value="${item.description ?? ''}" placeholder="Description"></td>
    <td><input type="text" class="li-hsn" value="${item.hsn ?? ''}"></td>
    <td><input type="text" class="li-unit" value="${item.unit ?? 'Nos'}"></td>
    <td><input type="number" class="li-qty" min="0" step="0.01" value="${item.qty ?? 1}"></td>
    <td><input type="number" class="li-price" min="0" step="0.01" value="${item.price ?? 0}"></td>
    <td><input type="number" class="li-discount" min="0" step="0.01" value="${item.discount ?? 0}"></td>
    <td><input type="number" class="li-tax" min="0" step="0.01" value="${item.tax ?? 18}"></td>
    <td class="line-total-cell" data-total>₹0.00</td>
    <td><button type="button" class="remove-line-btn" title="Remove row"><i class="fas fa-trash"></i></button></td>
  `;
  tbody.appendChild(tr);

  tr.querySelectorAll('input').forEach(inp => inp.addEventListener('input', recalcQuoteTotals));
  tr.querySelector('.remove-line-btn').addEventListener('click', () => {
    if (tbody.querySelectorAll('tr').length <= 1) {
      tr.querySelector('.li-name').value = '';
      tr.querySelector('.li-desc').value = '';
      tr.querySelector('.li-hsn').value = '';
      tr.querySelector('.li-unit').value = 'Nos';
      tr.querySelector('.li-qty').value = 1;
      tr.querySelector('.li-price').value = 0;
      tr.querySelector('.li-discount').value = 0;
      tr.querySelector('.li-tax').value = 18;
    } else {
      tr.remove();
    }
    recalcQuoteTotals();
  });

  recalcQuoteTotals();
}

function recalcQuoteTotals() {
  const rows = document.querySelectorAll('#quoteLineItemsBody tr');
  let subTotal = 0, totalDiscount = 0, totalTax = 0;

  rows.forEach(tr => {
    const qty = parseFloat(tr.querySelector('.li-qty').value) || 0;
    const price = parseFloat(tr.querySelector('.li-price').value) || 0;
    const discPct = parseFloat(tr.querySelector('.li-discount').value) || 0;
    const taxPct = parseFloat(tr.querySelector('.li-tax').value) || 0;

    const gross = qty * price;
    const discAmt = gross * discPct / 100;
    const taxable = gross - discAmt;
    const taxAmt = taxable * taxPct / 100;
    const lineTotal = taxable + taxAmt;

    subTotal += gross;
    totalDiscount += discAmt;
    totalTax += taxAmt;

    tr.querySelector('[data-total]').textContent = fmtCurrency(lineTotal);
  });

  const num = id => parseFloat(document.getElementById(id)?.value) || 0;
  const chargesTotal = num('qFreight') + num('qPacking') + num('qInstallation') + num('qInsurance') + num('qOtherCharges');

  const grandTotal = subTotal - totalDiscount + totalTax + chargesTotal;
  const netAmount = Math.round(grandTotal);
  const roundOff = netAmount - grandTotal;

  const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = fmtCurrency(val); };
  set('finSubTotal', subTotal);
  set('finDiscount', totalDiscount);
  set('finTax', totalTax);
  set('finOtherCharges', chargesTotal);
  set('finGrandTotal', grandTotal);
  set('finRoundOff', roundOff);
  set('finNetAmount', netAmount);

  return { subTotal, totalDiscount, totalTax, chargesTotal, grandTotal, roundOff, netAmount };
}

function wireQuoteForm() {
  ['qFreight', 'qPacking', 'qInstallation', 'qInsurance', 'qOtherCharges'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', recalcQuoteTotals);
  });

  document.getElementById('addLineItemBtn').addEventListener('click', () => addQuoteLineItemRow());

  document.getElementById('qCustomer').addEventListener('change', (e) => {
    const c = quoteCustomersCache.find(x => String(x.id) === String(e.target.value));
    if (c) selectQuoteCustomer(c);
  });

  const form = document.getElementById('createQuoteForm');
  const statusMsg = document.getElementById('quoteFormStatusMsg');
  const saveBtn = document.getElementById('saveQuoteBtn');

  document.getElementById('resetQuoteBtn').addEventListener('click', () => {
    setTimeout(() => {
      document.getElementById('quoteLineItemsBody').innerHTML = '';
      addQuoteLineItemRow();
      quoteSelectedCustomer = null;
      document.getElementById('quoteSelectedBanner').innerHTML = '';
      document.getElementById('qQuoteNumber').value = generateQuoteNumber();
      statusMsg.textContent = '';
      recalcQuoteTotals();
    }, 0);
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    statusMsg.textContent = '';

    if (!quoteSelectedCustomer) {
      statusMsg.style.color = '#d33';
      statusMsg.textContent = 'Please pick a customer from the Customer Details list above (or the Customer dropdown) first.';
      return;
    }

    const rows = Array.from(document.querySelectorAll('#quoteLineItemsBody tr')).map(tr => ({
      productName: tr.querySelector('.li-name').value.trim(),
      description: tr.querySelector('.li-desc').value.trim(),
      hsn: tr.querySelector('.li-hsn').value.trim(),
      unit: tr.querySelector('.li-unit').value.trim(),
      qty: parseFloat(tr.querySelector('.li-qty').value) || 0,
      price: parseFloat(tr.querySelector('.li-price').value) || 0,
      discount: parseFloat(tr.querySelector('.li-discount').value) || 0,
      tax: parseFloat(tr.querySelector('.li-tax').value) || 0,
      productCode: '',
      category: '',
      brand: '',
      model: '',
      deliveryDate: '',
      remarks: ''
    })).filter(r => r.productName !== '');

    if (!rows.length) {
      statusMsg.style.color = '#d33';
      statusMsg.textContent = 'Add at least one product / service line item.';
      return;
    }

    const totals = recalcQuoteTotals();
    const val = id => document.getElementById(id)?.value ?? '';

    const extraData = {
      quote_number: val('qQuoteNumber'),
      revision_no: val('qRevisionNo'),
      rfq_number: val('qRfqNumber'),
      inquiry_number: val('qInquiryNumber'),
      inquiry_date: val('qInquiryDate'),
      customer_id: quoteSelectedCustomer.id,
      customer_name: quoteSelectedCustomer.customer_name,
      company_name: quoteSelectedCustomer.company_name,
      sales_team: val('qSalesTeam'),
      project_name: val('qProjectName'),
      project_location: val('qProjectLocation'),
      department: val('qDepartment'),
      currency: val('qCurrency'),
      exchange_rate: val('qExchangeRate'),
      price_basis: val('qPriceBasis'),
      payment_terms: val('qPaymentTerms'),
      delivery_terms: val('qDeliveryTerms'),
      delivery_time: val('qDeliveryTime'),
      warranty: val('qWarranty'),
      amc_applicable: val('qAmcApplicable'),
      tax_type: val('qTaxType'),
      charges: {
        freight: parseFloat(val('qFreight')) || 0,
        packing: parseFloat(val('qPacking')) || 0,
        installation: parseFloat(val('qInstallation')) || 0,
        insurance: parseFloat(val('qInsurance')) || 0,
        other: parseFloat(val('qOtherCharges')) || 0,
      },
      items: rows,
      line_items: rows,
      financial_summary: totals,
      terms_conditions: val('qTerms'),
      customer_notes: val('qCustomerNotes'),
      valid_till: val('qValidTill'),
      quote_date: val('qQuoteDate'),
      quotationData: {
        customer: quoteSelectedCustomer.id,
        branch: val('qBranch'),
        salesExecutive: val('qSalesExecutive'),
      }
    };

    const fd = new FormData();
    fd.append('module_key', QUOTE_MODULE_KEY);
    fd.append('module_label', QUOTE_MODULE_LABEL);
    fd.append('title', val('qQuoteNumber'));
    fd.append('party_name', quoteSelectedCustomer.company_name || quoteSelectedCustomer.customer_name || '');
    fd.append('assigned_to', val('qSalesExecutive'));
    fd.append('record_date', val('qQuoteDate'));
    fd.append('amount', totals.netAmount);
    fd.append('status', val('qStatus'));
    fd.append('notes', val('qInternalNotes'));
    fd.append('extra_data', JSON.stringify(extraData));

    saveBtn.disabled = true;
    saveBtn.textContent = 'Saving…';

    try {
      const res = await fetch('api/records.php', { method: 'POST', body: fd });
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      statusMsg.style.color = 'green';
      statusMsg.textContent = 'Quote saved successfully.';

      document.getElementById('quoteLineItemsBody').innerHTML = '';
      addQuoteLineItemRow();
      quoteSelectedCustomer = null;
      document.getElementById('quoteSelectedBanner').innerHTML = '';
      document.getElementById('qQuoteNumber').value = generateQuoteNumber();
      recalcQuoteTotals();
    } catch (err) {
      statusMsg.style.color = '#d33';
      statusMsg.textContent = 'Error: ' + err.message;
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = 'Save Quote';
    }
  });
}

// ===========================================================
// GENERIC MODULE SYSTEM
// Powers every sidebar leaf item that isn't Customers, with
// real Add / Edit / Delete backed by api/records.php +
// the generic_records MySQL table.
// ===========================================================

function slugify(str) {
  return str.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
}
function moduleKeyFor(sectionLabel, itemLabel) {
  return slugify(sectionLabel) + '__' + slugify(itemLabel);
}

async function renderModuleListPage(itemLabel, sectionLabel, backAction, backLabel) {
  destroyCharts();
  const moduleKey = moduleKeyFor(sectionLabel, itemLabel);

  mainContent.innerHTML = `
    <button class="back-btn" id="backBtn"><i class="fas fa-arrow-left"></i> Back to ${backLabel}</button>
    <div class="eyebrow">${sectionLabel} <span class="crumb-sep">/</span> <span class="crumb-current">${itemLabel}</span></div>
    <div class="page-title">
      <span>${itemLabel}</span>
      <div class="actions">
        <button class="btn btn-primary" id="addRecordBtn"><i class="fas fa-plus"></i> Add New</button>
      </div>
    </div>

    <div class="table-panel">
      <div class="panel-head"><div><div class="panel-title">${itemLabel}</div><div class="panel-sub">Live records from the database</div></div></div>
      <div class="table-scroll">
        <table class="data-table">
          <thead>
            <tr><th>ID</th><th>Title</th><th>Party / Company</th><th>Assigned To</th><th>Date</th><th>Amount</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody id="genericTableBody"><tr><td colspan="8">Loading…</td></tr></tbody>
        </table>
      </div>
    </div>
  `;

  document.getElementById('backBtn').addEventListener('click', backAction);
  document.getElementById('addRecordBtn').addEventListener('click', () =>
    renderModuleForm(itemLabel, sectionLabel, () => renderModuleListPage(itemLabel, sectionLabel, backAction, backLabel)));

  const tbody = document.getElementById('genericTableBody');
  try {
    const res = await fetch(`api/records.php?module=${encodeURIComponent(moduleKey)}`);
    const json = await res.json();
    if (!json.success) throw new Error(json.message);
    const rows = json.data;

    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="8">No records yet. Click "Add New" to create one.</td></tr>`;
      return;
    }

    tbody.innerHTML = rows.map(r => `
      <tr>
        <td>${r.id}</td>
        <td class="cell-strong">${r.title ?? ''}</td>
        <td>${r.party_name ?? ''}</td>
        <td>${r.assigned_to ?? ''}</td>
        <td>${r.record_date ?? ''}</td>
        <td>${r.amount ? money(r.amount) : ''}</td>
        <td><span class="status-chip ${statusClass(r.status || 'Active')}">${r.status ?? ''}</span></td>
        <td>
          <button type="button" class="btn-secondary edit-record-btn" data-id="${r.id}">Edit</button>
          <button type="button" class="btn-secondary delete-record-btn" data-id="${r.id}">Delete</button>
        </td>
      </tr>
    `).join('');

    tbody.querySelectorAll('.edit-record-btn').forEach(btn => {
      btn.addEventListener('click', () =>
        renderModuleForm(itemLabel, sectionLabel, () => renderModuleListPage(itemLabel, sectionLabel, backAction, backLabel), btn.dataset.id));
    });
    tbody.querySelectorAll('.delete-record-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        if (!confirm('Delete this record?')) return;
        try {
          const res = await fetch(`api/records.php?id=${btn.dataset.id}`, { method: 'DELETE' });
          const json = await res.json();
          if (!json.success) throw new Error(json.message);
          renderModuleListPage(itemLabel, sectionLabel, backAction, backLabel);
        } catch (err) {
          alert('Delete failed: ' + err.message);
        }
      });
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8">Failed to load: ${err.message}</td></tr>`;
  }
}

async function renderModuleForm(itemLabel, sectionLabel, backToList, editId = null) {
  destroyCharts();
  const moduleKey = moduleKeyFor(sectionLabel, itemLabel);

  mainContent.innerHTML = `
    <div class="page-header">
      <h2>${editId ? 'Edit' : 'Add New'} — ${itemLabel}</h2>
      <p>${sectionLabel}</p>
      <button type="button" class="btn-secondary" id="backToModuleListBtn" style="margin-top:10px;">
        <i class="fas fa-arrow-left"></i> Back to List
      </button>
    </div>

    <form id="genericRecordForm">
      <div class="form-card">
        <div class="card-title"><h3>Details</h3></div>
        <div class="form-grid">
          <div class="form-group">
            <label>Title *</label>
            <input type="text" id="grTitle" required>
          </div>
          <div class="form-group">
            <label>Party / Company Name</label>
            <input type="text" id="grParty">
          </div>
          <div class="form-group">
            <label>Assigned To</label>
            <input type="text" id="grAssigned">
          </div>
          <div class="form-group">
            <label>Date</label>
            <input type="date" id="grDate">
          </div>
          <div class="form-group">
            <label>Amount</label>
            <input type="number" step="0.01" id="grAmount">
          </div>
          <div class="form-group">
            <label>Status</label>
            <select id="grStatus">
              <option>Active</option>
              <option>Pending</option>
              <option>Completed</option>
              <option>On Hold</option>
              <option>Cancelled</option>
            </select>
          </div>
          <div class="form-group full-width">
            <label>Notes</label>
            <textarea rows="4" id="grNotes"></textarea>
          </div>
        </div>
      </div>

      <div class="form-actions">
        <button type="submit" class="btn-primary" id="grSaveBtn">${editId ? 'Update' : 'Save'}</button>
        <button type="reset" class="btn-secondary">Clear</button>
        <span id="grStatusMsg" style="margin-left:14px;font-size:14px;"></span>
      </div>
    </form>
  `;

  document.getElementById('backToModuleListBtn').addEventListener('click', backToList);

  if (editId) {
    try {
      const res = await fetch(`api/records.php?id=${editId}`);
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      const r = json.data;
      document.getElementById('grTitle').value = r.title ?? '';
      document.getElementById('grParty').value = r.party_name ?? '';
      document.getElementById('grAssigned').value = r.assigned_to ?? '';
      document.getElementById('grDate').value = r.record_date ?? '';
      document.getElementById('grAmount').value = r.amount ?? '';
      document.getElementById('grStatus').value = r.status ?? 'Active';
      document.getElementById('grNotes').value = r.notes ?? '';
    } catch (err) {
      document.getElementById('grStatusMsg').textContent = 'Could not load record: ' + err.message;
      document.getElementById('grStatusMsg').style.color = '#d33';
    }
  }

  document.getElementById('genericRecordForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const statusMsg = document.getElementById('grStatusMsg');
    const saveBtn = document.getElementById('grSaveBtn');
    statusMsg.textContent = '';
    saveBtn.disabled = true;
    saveBtn.textContent = editId ? 'Updating…' : 'Saving…';

    const fd = new FormData();
    fd.append('module_key', moduleKey);
    fd.append('module_label', itemLabel);
    fd.append('title', document.getElementById('grTitle').value);
    fd.append('party_name', document.getElementById('grParty').value);
    fd.append('assigned_to', document.getElementById('grAssigned').value);
    fd.append('record_date', document.getElementById('grDate').value);
    fd.append('amount', document.getElementById('grAmount').value);
    fd.append('status', document.getElementById('grStatus').value);
    fd.append('notes', document.getElementById('grNotes').value);
    if (editId) { fd.append('id', editId); fd.append('_method', 'PUT'); }

    try {
      const res = await fetch('api/records.php', { method: 'POST', body: fd });
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      statusMsg.style.color = 'green';
      statusMsg.textContent = editId ? 'Updated successfully.' : 'Saved successfully.';
      setTimeout(() => backToList(), 600);
    } catch (err) {
      statusMsg.style.color = '#d33';
      statusMsg.textContent = 'Error: ' + err.message;
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = editId ? 'Update' : 'Save';
    }
  });
}
