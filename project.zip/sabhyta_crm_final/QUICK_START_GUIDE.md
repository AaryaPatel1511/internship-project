# SABHYTA CRM - Quick Start Guide for New Features

---

## 🎯 New Feature 1: Load Quotation into Sales Order

### Location:
**Sales → Sales Order → Create Order Form**

### Step-by-Step Guide:

#### Step 1: Create Sales Order
1. Go to **Sales Module**
2. Click on **Sales Order**
3. Click **New Sales Order** button
4. Select a Customer from the Customer Details panel

#### Step 2: Load Quotation Data
1. In the Sales Order Form, find the **"Quotation Number"** field
2. Enter the quotation number (e.g., "QT-2026-001")
3. Click the **"Load Quote"** button next to it
4. The system will:
   - Search for the quotation
   - Extract all products/services from the quote
   - Automatically populate the **Sales Order Items** table
   - Recalculate totals automatically

#### Step 3: Review & Save
1. Review the populated items (quantities, prices, taxes)
2. Make any adjustments if needed
3. Fill in remaining sales order details (delivery date, terms, etc.)
4. Click **"Save Sales Order"**

### Example:
```
Customer: Acme Corporation
Quotation Number: QT-2026-005
└─ Product 1: Laptop (Qty: 2, Price: ₹50,000, Tax: 18%)
└─ Product 2: Monitor (Qty: 2, Price: ₹15,000, Tax: 18%)
└─ Product 3: Keyboard & Mouse (Qty: 2, Price: ₹3,000, Tax: 18%)
→ All products auto-loaded into Sales Order Items
```

### Benefits:
✅ No re-entry of product details  
✅ Accurate pricing and quantities  
✅ Fast order creation  
✅ Maintains quote-order link  

---

## 💰 New Feature 2: Process Salary by Employee

### Location:
**HRMS → Salary → Process Salary by Employee**

### Step-by-Step Guide:

#### Step 1: Access Salary Processing
1. Go to **HRMS Module**
2. Click on **Salary**
3. Click on **"Process Salary by Employee"** tab (first tab)

#### Step 2: Configure Salary Parameters
In the "Salary Processing Configuration" section:

**Select Employee:**
- Choose employee from dropdown (searchable)
- Shows employee code and designation

**Choose Financial Year:**
- Select from dropdown:
  - FY 2027-28 (Next year)
  - FY 2026-27 (Current year - pre-selected)
  - FY 2025-26 (Previous year)

**Select Period Type:**
- **Monthly Salary** (default) → Choose specific month
- **Annual Salary** → Shows year input

**Month Selection (if Monthly is selected):**
- Dropdown showing all 12 months
- Pre-selects current month

#### Step 3: Review Salary Structure
System displays:
- Employee Details (code, department, designation)
- Metro/Non-Metro Classification
- CTC (Cost to Company)
- **Earnings Table:**
  - Basic Salary (Monthly & Yearly)
  - HRA (House Rent Allowance)
  - DA (Dearness Allowance)
  - Conveyance Allowance
  - Medical Allowance
  - Special Allowance
  - Gross Salary
- **Deductions Table:**
  - Provident Fund (PF)
  - ESIC
  - Professional Tax
  - Total Deductions
- **Net Salary (Take Home)** - Bold & Highlighted

#### Step 4: Complete Professional Checklist
Before processing, verify all items:
```
☐ Attendance verified for [Month/Year]
☐ Leave deductions verified
☐ Allowances and benefits reviewed
☐ All deductions calculated correctly
☐ Tax compliance verified
☐ Approved by HR Manager
```

✓ Check each box after verifying
✓ Progress bar shows completion percentage
✓ Button becomes active when all 6 items checked
✓ Success message appears

#### Step 5: Download & Send
Once checklist is complete:
- **Download PDF:** Click "Download PDF" button
  - Saves as: Salary-Slip-[EmployeeCode]-[Period].pdf
  - Professional format ready for employee

- **Send Email:** Click "Send Email Report to Employee"
  - Sends salary slip via email
  - Professional formatting
  - Shows confirmation message

### Example Workflow:
```
Step 1: Select Employee → Rahul Reddy
Step 2: Select FY → 2026-27 (Current)
Step 3: Select Period → Monthly
Step 4: Select Month → July 2026
Step 5: View Salary → ₹1,45,000 Gross | ₹1,10,500 Net
Step 6: Verify Checklist → All 6 items ✓
Step 7: Download PDF → Salary slip ready
Step 8: Send Email → Sent to employee
```

---

## 🏢 New Feature 3: Process Salary by Branch

### Location:
**HRMS → Salary → Process Salary by Branch**

### Step-by-Step Guide:

#### Step 1: Access Branch Salary Processing
1. Go to **HRMS Module**
2. Click on **Salary**
3. Click on **"Process Salary by Branch"** tab

#### Step 2: Configure Branch Parameters
- **Select Branch:** Dropdown with all branch options
- **Financial Year:** FY 2026-27, 2025-26, etc.
- **Period Type:** Monthly or Annual
- **Month (if Monthly):** Select from dropdown

#### Step 3: View Branch Employees
System displays:
- All employees in selected branch (e.g., "Mumbai Branch - 5 employees")
- Employee details: Name, Code, Designation

#### Step 4: Select Employees
Multiple selection options:
- **Individual Selection:** Check boxes next to each employee
- **Select All:** Click "Select All" button
- **Deselect All:** Click "Deselect All" button

#### Step 5: Download Salary Report
- Click **"Download Salary Records for Selected Employees"**
- Generates professional PDF containing:
  - Branch name
  - All selected employees
  - Net Salary (Monthly & Yearly)
  - Gross Salary
  - Salary components table
  - Properly formatted for record-keeping

### Example Workflow:
```
Step 1: Select Branch → Mumbai Branch
Step 2: Select FY → 2026-27
Step 3: Select Period → Monthly
Step 4: Select Month → July 2026
Step 5: Select Employees → Rahul (✓) + Priya (✓) + Sneha (✓)
Step 6: Download → Branch-Salary-Report-Mumbai-Branch-2026-07-27.pdf
```

### Use Cases:
- HR Manager needs all July salaries for a branch
- Finance department requires branch salary details
- Prepare payroll report
- Employee verification
- Compliance documentation

---

## 📊 Tips & Best Practices

### Salary Processing:
1. **Always verify attendance first** - Check leave records
2. **Complete checklist before processing** - Ensures compliance
3. **Download PDF for record** - Keep salary slips archived
4. **Send email to employee** - Professional communication
5. **Monthly review** - Process at month-end

### Branch Processing:
1. **Process in bulk** - More efficient than individual processing
2. **Review before download** - Verify correct branch selected
3. **Keep records organized** - Date-stamp your downloads
4. **Monthly routine** - Schedule as month-end task

### Quotation to Sales Order:
1. **Always verify quotation number** - Check spelling
2. **Review loaded items** - Ensure all products correct
3. **Update delivery dates** - If different from quote
4. **Save immediately** - Don't lose data
5. **Link to quotation** - For audit trail

---

## ⚙️ Troubleshooting

### Quotation Loading Issues

**Problem:** "Quotation not found"
- **Solution:** 
  - Verify quotation number (spelling & case-sensitive)
  - Check quotation exists and is saved in CRM
  - Use quotation number format exactly as displayed in CRM

**Problem:** No items loaded from quotation
- **Solution:**
  - Check quotation has line items in CRM
  - Add items to quotation first, then retry
  - Refresh browser if needed

### Salary Processing Issues

**Problem:** Checklist items won't check
- **Solution:**
  - Ensure checkbox element is visible
  - Refresh page and try again
  - Use latest browser version

**Problem:** Financial Year not showing correctly
- **Solution:**
  - Check system date is correct
  - FY calculated as: April 1 = New FY starts
  - Manual override by selecting desired FY

**Problem:** Employees not showing in branch list
- **Solution:**
  - Verify employee records have branch assigned
  - Check branch name matches exactly
  - Refresh page and try again

**Problem:** PDF won't download
- **Solution:**
  - Check browser download settings
  - Ensure popup blocker allows PDFs
  - Try different browser if needed

---

## 🔐 Important Notes

- ✅ No existing data is modified or deleted
- ✅ All features are additions only
- ✅ Backward compatible with existing system
- ✅ All previous functionality preserved
- ✅ Employee records remain unchanged
- ✅ Salary calculations using existing formulas

---

## 📞 Need Help?

### Quick Reference:
- **Sales Order → Load Quote:** Sales Module → Sales Order → Enter Quote# → Click Load Quote
- **Salary by Employee:** HRMS → Salary → Process Salary by Employee → Select Employee → Complete Checklist
- **Salary by Branch:** HRMS → Salary → Process Salary by Branch → Select Branch → Select Employees → Download

### Common Errors:
- Check spelling of quotation numbers
- Verify all checklist items before processing
- Ensure employees have branch assigned
- Use correct financial year format (e.g., FY 2026-27)

---

*Last Updated: July 27, 2026*
*Version: 3.1*
