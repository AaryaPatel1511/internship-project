# SABHYTA CRM — Submission and Run Guide

## What is included

This is a PHP/MySQL web application. The customer, lead, employee, quotation,
sales order, helpdesk, dashboard and report flows use server-side data. Some ERP
areas have dedicated entities; other sidebar items use a shared record form and
store common fields. Those generic screens are useful for record tracking, but
do not implement the full business rules of specialized systems such as a
general ledger, stock valuation or statutory payroll.

AI tools include simulated/demo behavior in places and need external provider or
service integration before they can be described as production AI. Do not enter
real employee, tax, financial or customer data in a classroom demo installation.

## Requirements

- PHP 8.0+ with PDO MySQL and MySQLi extensions enabled.
- MySQL 8.0+ or a compatible MariaDB server.
- Apache with PHP enabled (XAMPP is suitable for a local presentation).
- Browser access to the internet for the externally hosted fonts, icons and
  chart/export libraries currently referenced by the pages.

## First-time setup with XAMPP

1. Start Apache and MySQL from the XAMPP control panel.
2. In phpMyAdmin, create a database named `sabhytacrm` using
   `utf8mb4_unicode_ci`. The configured MySQL account needs permission to create
   and alter tables in this database.
3. Copy the `sabhyta_crm_final` folder into `C:\xampp\htdocs\`.
4. If your MySQL credentials differ from XAMPP's local `root` account with an
   empty password, set `SABHYTA_DB_HOST`, `SABHYTA_DB_PORT`, `SABHYTA_DB_NAME`,
   `SABHYTA_DB_USER` and `SABHYTA_DB_PASS` in the PHP/Apache environment before
   starting Apache. The defaults target local XAMPP only.
5. Open `http://localhost/sabhyta_crm_final/setup.html` and select **Start
   Initialization**. The installer creates the module tables and sample data.
   It is safe to revisit after successful initialization; it will not reseed.
6. Open `http://localhost/sabhyta_crm_final/login.html` and create the first
   administrator account with your own name, email and password.
7. Sign in and try creating, editing and deleting a customer and a lead, then
   create a quotation and convert it to a sales order.

The web-server process needs write access to `storage/` and `uploads/` for
recovery-key throttling and profile/document uploads. Keep this installation on
localhost for a class demonstration; production deployment needs a dedicated
database account, HTTPS, backups, and a security review.

## Useful submission checks

- Confirm that the dashboard and list pages show the seeded sample records.
- Confirm that login is required before application pages and protected APIs.
- Create and edit a customer, lead, quotation and sales order; check that each
  change remains after reloading the page.
- Test search and report date filters with the sample records.
- Remove sample records before presenting if the assignment requires a clean
  database. Keep a database export so the demo can be restored.

## Environment verification note

The supplied source was statically reviewed and JavaScript files were checked
with Node.js. A PHP runtime and MySQL server were not available in the review
environment, so PHP linting and live database/browser flows still need to be
run on the XAMPP/MySQL setup above.
