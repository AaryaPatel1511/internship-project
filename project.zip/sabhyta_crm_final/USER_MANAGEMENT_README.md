# User Management — Working Guide

## What changed
Only the **User Management** section was updated. Dashboard and all other modules are unchanged.

### Design (aligned with your PDF)
1. **Users = HRMS Employees** — list comes from `employees` table (not a separate users list).
2. **Roles** (5 levels): Super Admin (1) → Admin (2) → Manager (3) → Supervisor (4) → Executive (5).
3. **Assign role to a particular user** — open any employee → **Assign Role**.
4. **Permissions** with **data scope**: own / team / department / company / all.
5. **Departments & Designations** read from existing HRMS masters.

### Database tables used
| Table | Purpose |
|-------|---------|
| `employees` | Source of users (HRMS) |
| `departments` | HRMS departments |
| `designations` | HRMS designations |
| `roles` | Super Admin … Executive |
| `modules` | CRM, HRMS, … |
| `permissions` | View/Add/Edit actions |
| `role_permissions` | Role → permission + data_scope |
| `user_roles` | Employee → role assignment |

Login still uses the system `users` table (admin account). Operational access is controlled by roles on **employees**.

### Setup order
1. Import `database/schema.sql`
2. Import `database/schema_hrms_sales.sql`
3. Import `database/schema_user_management.sql` (optional — APIs auto-create tables)
4. Run `database/seed_demo_data.php` (or add employees via HRMS → Employee)
5. Log in → **User Management → Users** → assign roles

### APIs
- `api/users.php` — list/detail employees, assign/remove role
- `api/user_roles.php` — roles list + detail
- `api/user_permissions.php` — permissions by module
- `api/user_masters.php` — departments & designations

Tables and default roles/permissions are **auto-created** on first API call if missing.
