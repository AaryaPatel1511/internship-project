# 🚀 SABHYTA CRM v2.0 - INTEGRATION & DEPLOYMENT GUIDE

## 📋 PRE-DEPLOYMENT CHECKLIST

### System Requirements
- [x] PHP 7.4 or higher
- [x] MySQL 5.7 or higher (MariaDB 10.2+)
- [x] Apache 2.4 with mod_rewrite enabled
- [x] 100MB disk space minimum
- [x] 256MB PHP memory limit minimum

### Local Development Environment
- XAMPP 8.0+ OR
- WAMP 3.2+ OR
- LAMP Stack OR
- Docker Container

---

## 🔧 INSTALLATION STEPS

### Step 1: Extract Project
```bash
# Extract the zip file
unzip sabhyta_crm_professional.zip

# Navigate to project
cd sabhyta_crm_professional

# Set proper permissions
chmod -R 755 .
chmod -R 777 uploads/
chmod -R 777 api/
```

### Step 2: Database Setup
**Option A: Using phpMyAdmin (GUI)**
1. Open http://localhost/phpmyadmin
2. No need to create database manually - it will auto-create!
3. Just ensure MySQL is running

**Option B: Using Command Line**
```bash
mysql -u root -p < database/schema.sql
mysql -u root -p < database/schema_hrms_sales.sql
mysql -u root -p < database/schema_masters.sql
```

### Step 3: Configure Database Connection
Edit `api/db.php` if your setup differs from default:
```php
$DB_HOST = "localhost";      // Your MySQL host
$DB_NAME = "sabhytacrm";     // Database name
$DB_USER = "root";           // MySQL username
$DB_PASS = "";               // MySQL password (empty by default)
```

### Step 4: Access Application
**First Time Setup:**
1. Open browser: `http://localhost/sabhytacrm/`
2. You will be automatically redirected to `setup.html`
3. Click "Start Initialization"
4. Wait for confirmation of all 4 steps
5. Note down your admin credentials

**After Setup:**
1. Open: `http://localhost/sabhytacrm/login.html`
2. Use provided credentials
3. Change password immediately!

---

## 📁 FOLDER STRUCTURE

```
sabhyta_crm_professional/
├── api/                          # Backend APIs
│   ├── auto_init.php            # ✨ Auto-initialization (NEW)
│   ├── salary_processing.php    # 💰 Salary processing (NEW)
│   ├── salary_report_generator.php  # 📊 Reports (NEW)
│   ├── quotation_to_order.php   # 📋 Auto-population (NEW)
│   ├── db.php                   # Database connection
│   ├── auth.php                 # Authentication
│   ├── session_guard.php        # Session management
│   ├── employees.php            # Employee API
│   ├── customers.php            # Customer API
│   ├── departments.php          # Department API
│   ├── designations.php         # Designation API
│   ├── records.php              # Generic records API
│   ├── sales_orders.php         # Sales order API
│   └── send_salary_email.php    # Email integration
│
├── database/                     # Database schemas
│   ├── schema.sql               # Main schema
│   ├── schema_hrms_sales.sql    # HRMS & Sales schema
│   ├── schema_masters.sql       # Master data schema
│   ├── seed_test_data.php       # ✨ Test data (NEW)
│   ├── seed_admin.php           # Admin seeding
│   ├── seed_module_map.php      # Module configuration
│   ├── seed_demo_data.php       # Demo data
│   └── *.sql                    # Migrations
│
├── modules/                      # Feature modules
│   └── salary_enhanced.js       # 💰 Enhanced salary UI (NEW)
│
├── uploads/                      # File storage (writable)
│
├── setup.html                   # ✨ Setup wizard (NEW)
├── login.html                   # Login page
├── index.html                   # Main dashboard
├── script.js                    # Main app logic
├── hrms_sales.js                # HRMS & Sales logic
├── style.css                    # Styling
├── .htaccess                    # Apache config
├── SETUP_PROFESSIONAL.md        # Setup guide
├── IMPLEMENTATION_CHECKLIST.md  # Feature checklist
├── INTEGRATION_GUIDE.md         # This file
└── README.md                    # Original readme
```

---

## 🔐 SECURITY CONFIGURATION

### 1. Change Default Credentials
**CRITICAL - Do This First!**
```sql
-- Change admin password in MySQL:
UPDATE users SET password_hash = PASSWORD('new_secure_password') 
WHERE email = 'admin@sabhytacrm.com';
```

OR via Admin Panel:
1. Login as admin
2. Go to Settings > User Management
3. Change password

### 2. Enable HTTPS
For production, force HTTPS:
```php
// Add to top of index.html or via .htaccess:
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
</IfModule>
```

### 3. Database Backup
Set up automated backups:
```bash
# Daily backup at 2 AM
0 2 * * * mysqldump -u root -p sabhytacrm > /backup/sabhytacrm_$(date +\%Y\%m\%d).sql
```

### 4. File Permissions
```bash
# Recommended permissions
chmod 644 api/*.php
chmod 755 api/
chmod 777 uploads/
chmod 755 database/
chmod 644 *.html *.js *.css
```

---

## 🚀 PRODUCTION DEPLOYMENT

### Option 1: Shared Hosting (cPanel/Plesk)
1. Upload files via FTP to public_html or subdirectory
2. Import SQL files via phpMyAdmin
3. Update `api/db.php` with hosting credentials
4. Access via your domain

### Option 2: VPS/Dedicated Server
```bash
# 1. SSH into server
ssh user@your-server.com

# 2. Navigate to web root
cd /var/www/html

# 3. Clone or extract project
git clone <repo-url> sabhytacrm
# OR
unzip sabhytacrm.zip

# 4. Set permissions
sudo chown -R www-data:www-data sabhytacrm
chmod -R 755 sabhytacrm
chmod -R 777 sabhytacrm/uploads

# 5. Configure Apache/Nginx
# Copy .htaccess rules to vhost config

# 6. Install SSL (Let's Encrypt)
sudo certbot certonly -d yourdomain.com

# 7. Restart web server
sudo systemctl restart apache2
```

### Option 3: Docker Container
```dockerfile
FROM php:7.4-apache

RUN docker-php-ext-install mysqli pdo pdo_mysql

COPY . /var/www/html/sabhytacrm/

RUN chown -R www-data:www-data /var/www/html/sabhytacrm/
RUN chmod -R 755 /var/www/html/sabhytacrm/
RUN chmod -R 777 /var/www/html/sabhytacrm/uploads

EXPOSE 80

CMD ["apache2-foreground"]
```

```bash
# Build and run
docker build -t sabhyta-crm .
docker run -d -p 80:80 --name sabhyta sabhyta-crm
```

---

## 📊 CONFIGURATION OPTIONS

### Salary Module Configuration
File: `hrms_sales.js` (lines 158-220)

```javascript
// Metro cities (50% HRA)
const metroCities = ['Delhi', 'Mumbai', 'Kolkata', 'Chennai'];

// Modify as needed for your country/state
const salaryConfig = {
    hra_metro: 0.50,
    hra_non_metro: 0.40,
    da: 0.10,
    conveyance_metro: 1600,
    conveyance_non_metro: 1000,
    medical_allowance: 1250,
    special_allowance_metro: 0.05,
    special_allowance_non_metro: 0.03,
    pf_rate: 0.12,
    pf_ceiling: 15000,
    esic_rate: 0.0075,
    esic_limit: 21000,
    professional_tax: 200
};
```

### Email Configuration
To enable salary slip emails, configure SMTP in PHP:

```php
// In api/send_salary_email.php
$mail_config = [
    'smtp_host' => 'smtp.gmail.com',      // Your SMTP server
    'smtp_port' => 587,
    'smtp_user' => 'your-email@gmail.com',
    'smtp_pass' => 'app-password',        // Use app password for Gmail
    'from_email' => 'noreply@company.com',
    'from_name' => 'SABHYTA CRM'
];
```

---

## 🧪 TESTING CHECKLIST

Before going live, test:

- [ ] Database connection from API
- [ ] Auto-initialization on fresh install
- [ ] Login/logout functionality
- [ ] Employee creation and management
- [ ] Salary calculation accuracy
- [ ] PDF salary slip generation
- [ ] Quotation creation
- [ ] Auto-population to sales order
- [ ] Report generation (Excel/PDF)
- [ ] Email sending (if configured)
- [ ] File uploads in uploads/ folder
- [ ] User roles and permissions
- [ ] Dashboard statistics
- [ ] Search functionality
- [ ] Date filtering
- [ ] Export functionality

---

## 📱 MOBILE ACCESS

The application is responsive and works on mobile devices:
- iOS Safari: Full support
- Android Chrome: Full support
- Tablets: Optimized layout

For mobile app integration (future):
1. All APIs are JSON-based
2. Session tokens supported
3. CORS configured if needed

---

## 🔄 MIGRATION FROM OLDER VERSION

If migrating from v1.0:

```bash
# 1. Backup old database
mysqldump -u root -p sabhytacrm > backup_v1.sql

# 2. Run new schemas
mysql -u root -p sabhytacrm < database/schema_hrms_sales.sql

# 3. Preserve old data (if needed)
# Run manual migration queries for critical tables

# 4. Test thoroughly
# Verify all data integrity

# 5. Update bookmarks/links to new URLs
```

---

## 🐛 TROUBLESHOOTING

### "Database Connection Failed"
```
Solution:
1. Check MySQL is running: sudo service mysql status
2. Verify credentials in api/db.php
3. Ensure database exists: mysql -u root -p sabhytacrm -e "SELECT 1"
4. Check user permissions: GRANT ALL ON sabhytacrm.* TO 'root'@'localhost'
```

### "Auto-initialization not working"
```
Solution:
1. Check PHP error logs: tail -f /var/log/php_errors.log
2. Verify database connection: test with phpMyAdmin
3. Check file permissions: chmod -R 777 api/ database/
4. Manually run: php api/auto_init.php from command line
```

### "PDF generation fails"
```
Solution:
1. Ensure imagick or similar is installed
2. Check uploads folder exists and is writable
3. Increase PHP memory limit to 256MB
4. Check for missing fonts in system
```

### "Email not sending"
```
Solution:
1. Verify SMTP configuration in api/send_salary_email.php
2. Check firewall allows port 587/465
3. Test with: telnet smtp.gmail.com 587
4. Enable "Less secure apps" for Gmail or use app password
```

### "Session expires too quickly"
```
Solution:
Edit php.ini:
session.gc_maxlifetime = 86400  ; 24 hours
session.cookie_lifetime = 86400  ; 24 hours

Or in api/session_guard.php
```

---

## 📞 SUPPORT & MAINTENANCE

### Regular Maintenance Tasks
```bash
# Daily
- Monitor error logs
- Check database backup completion

# Weekly
- Verify all features working
- Review user activity
- Check disk space

# Monthly
- Update passwords
- Review access logs
- Test disaster recovery
- Database optimization: ANALYZE TABLE

# Quarterly
- PHP/MySQL updates
- Security patches
- Performance tuning
```

### Performance Optimization
```php
// Enable caching in index.html
header('Cache-Control: max-age=3600');

// Database optimization
ALTER TABLE employees ADD INDEX idx_status (status);
ALTER TABLE generic_records ADD INDEX idx_module (module_key);
ALTER TABLE salary_slips ADD INDEX idx_date (year, month);
```

---

## 📈 SCALING CONSIDERATIONS

For large deployments (1000+ users):

1. **Database Optimization**
   - Add indexes on frequently searched fields
   - Archive old salary slips
   - Implement query caching

2. **Performance**
   - Use CDN for static files
   - Implement Redis caching
   - Load balance web servers

3. **Security**
   - Use firewalls and WAF
   - Implement rate limiting
   - Regular security audits

4. **Infrastructure**
   - Separate database server
   - Implement replication
   - Use auto-scaling

---

## 📞 GETTING HELP

1. **Documentation**
   - Read SETUP_PROFESSIONAL.md
   - Check IMPLEMENTATION_CHECKLIST.md
   - Review API endpoints in code comments

2. **Debugging**
   - Check browser console (F12)
   - Review PHP error logs
   - Enable debug mode in code

3. **Community**
   - Check FAQs
   - Review documentation examples
   - Test with sample data

---

## 🎉 DEPLOYMENT COMPLETE!

Your SABHYTA CRM v2.0 is ready for production.

**Next Steps:**
1. ✓ Database initialized
2. ✓ Admin user created
3. ✓ Test data loaded
4. ✓ Employees ready to manage
5. ✓ Quotations ready to create
6. ✓ Salary processing ready
7. ✓ Reports ready to generate

**Time to Success:** 5-10 minutes

**Go Live:** `http://your-domain.com/sabhytacrm/`

---

**Version:** 2.0 Professional  
**Last Updated:** July 2026  
**Status:** Production Ready ✓
