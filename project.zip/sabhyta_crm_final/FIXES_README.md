# Fixes in this build

## 1. Forgot / reset password
- login.html > "Forgot password?" now has a working form (email + recovery key + new password).
- Recovery key: open `storage/recovery_key.php` in Notepad and copy the `RECOVERY-KEY:` line.
  The file is created automatically the first time the Forgot screen is opened.
  Delete the file to generate a new key.
- Command line fallback (XAMPP > Shell):
    cd C:\xampp\htdocs\sabhytacrm
    php reset_password.php --list
    php reset_password.php you@email.com NewPassword
- Signed-in users: profile menu (top right) > Change password, or sidebar User Profile > Change Password.

## 2. User Management in the sidebar
Shown for Admin / Super Admin, or any role holding Manage Users / Manage Roles / Manage Permissions.
Manage Users -> Users, Departments, Designations. Manage Roles -> Roles. Manage Permissions -> Permissions.
Grant a permission to a role (example: Manager role id 3, Manage Users id 27):
    INSERT IGNORE INTO role_permissions (role_id, permission_id, data_scope, status)
    VALUES (3, 27, 'company', 'Active');
(28 = Manage Roles, 29 = Manage Permissions.) Or simply give the user the Admin role.

## 3. Security
User Management APIs now check permissions on the server (api/access.php).
Only Admin / Super Admin can create or assign Admin-level roles.

Files changed: api/auth.php, api/users.php, api/user_roles.php, api/user_roles_fixed.php,
api/user_permissions.php, api/user_masters.php, api/user_management_dashboard.php,
login.html, script.js, modules/erp_pages_b.js
New files: api/access.php, reset_password.php, FIXES_README.md
