# Start Here

Use `FINAL_SUBMISSION_GUIDE.md` as the current and authoritative setup guide.

1. Run PHP with PDO MySQL and MySQLi extensions plus MySQL/MariaDB.
2. Create the `sabhytacrm` database in phpMyAdmin.
3. Copy this folder under XAMPP `htdocs` and open `setup.html`.
4. Initialize the schema and sample data.
5. Open `login.html` and create your own first administrator account.

There are no default login credentials. Older guides from earlier project
revisions have been removed from this start page because their SQLite and
sample-login steps no longer apply.