<?php
/**
 * SCHEDULED DATABASE BACKUP  (command line only)
 * ------------------------------------------------------------
 * Run daily, e.g.
 *   Linux cron      0 2 * * *  php /path/to/sabhyta_crm_final/cron/backup.php
 *   XAMPP / Windows Task Scheduler (daily 2:00 AM), Program:
 *                   C:\xampp\php\php.exe
 *                   Arguments: C:\xampp\htdocs\sabhyta_crm_final\cron\backup.php
 *
 * Writes a compressed dump to /storage/backups, records it in
 * Administration > Backup as "Scheduled", and removes backups older
 * than the retention period set on that page.
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit("This script can only be run from the command line.\n"); }

chdir(__DIR__ . '/../api');
require_once __DIR__ . '/../api/db.php';
require_once __DIR__ . '/../api/erp_core.php';
require_once __DIR__ . '/../api/erp_admin.php';

try {
    erp_ensure_schema($pdo);
    $r = adm_backup_make($pdo, 'Scheduled');
    echo date('Y-m-d H:i:s') . " Backup OK: {$r['file']} ({$r['size_mb']} MB, {$r['tables']} tables)\n";
    exit(0);
} catch (Throwable $e) {
    fwrite(STDERR, date('Y-m-d H:i:s') . ' Backup FAILED: ' . $e->getMessage() . "\n");
    exit(1);
}
