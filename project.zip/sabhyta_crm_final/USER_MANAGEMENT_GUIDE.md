# User Management System Implementation Guide

## Overview

The User Management system is a comprehensive role-based access control (RBAC) module integrated with your HRMS employees system. It provides:

- **Centralized User Management** - Auto-fetches employees from HRMS
- **Role-Based Access Control** - 5-level hierarchy (Super Admin, Admin, Manager, Supervisor, Executive)
- **Permission Management** - Module-level permissions with data scopes
- **Department & Designation Management** - Organizational structure
- **Team Hierarchy** - Visual reporting relationships

## Architecture

### Database Layer
The system uses a relational database schema with these core tables:

```
employees (existing HRMS)
    ↓
user_roles → roles ← role_permissions → permissions
    ↓
user_permissions (for exceptions/overrides)

departments → designations → reporting_hierarchy
teams → team_members
```

### File Structure

```
/database
  - schema_user_management.sql      (Core tables & views)
  - seed_user_management.sql         (Initial data)

/api
  - users.php                        (User management API)
  - user_roles.php                   (Role management API)
  - user_permissions.php             (Permission management API)
  - user_masters.php                 (Departments & Designations API)

/modules
  - user_management.js               (Frontend UI module)

/css
  - user_management.css              (Styling)

index.html                           (Menu items added)
script.js                            (Routing updated)
```

## Installation Steps

### 1. Database Setup

Run the schema file to create all necessary tables:

```sql
source database/schema_user_management.sql;
```

This creates:
- `departments` - Department master data
- `designations` - Job positions/designations
- `roles` - User roles (5 levels)
- `modules` - System modules for permissions
- `permissions` - Module-level actions
- `role_permissions` - Role to permission mapping
- `user_roles` - User to role assignment
- `user_permissions` - User-specific permission overrides
- `reporting_hierarchy` - Manager-employee relationships
- `teams` and `team_members` - Team structure
- `user_login_audit` - Login tracking

### 2. Seed Initial Data

Load the seed data to populate roles, departments, and designations:

```sql
source database/seed_user_management.sql;
```

This inserts:
- 5 default roles with hierarchy levels
- 8 departments
- 20 designations (job positions)
- 30+ permissions across modules
- Default permission mappings for each role

### 3. Sync Existing Employees

After setup, sync your existing HRMS employees with the user system:

```sql
CALL SyncEmployeesWithUsers();
```

Or use the UI: Navigate to **User Management → Users → Sync Employees** button.

### 4. Assign Roles to Users

Users are automatically pulled from your HRMS employees table. To assign roles:

1. Go to **User Management → Users**
2. Click on any user to open their profile
3. Click **"Assign Role"** button
4. Select from available roles (Super Admin, Admin, Manager, Supervisor, Executive)
5. Save

## Data Scope Levels

Each permission can be scoped to different data visibility levels:

| Scope | Access Level | Use Case |
|-------|--------------|----------|
| `own` | Only own records | Employees see their own tasks |
| `team` | Own + team members' records | Supervisors manage their team |
| `department` | Entire department data | Managers see all dept employees |
| `branch` | Entire branch data | Branch head views branch operations |
| `company` | All company data | Admin/CFO sees everything |
| `all` | Unrestricted | Super Admin (system level) |

## API Endpoints

### Users Management
```
GET    /api/users.php                    List all active users
GET    /api/users.php?id=5               Get user detail with roles & permissions
GET    /api/users.php?q=john             Search users by name/email/code
POST   /api/users.php?action=assign_role Assign role to user
POST   /api/users.php?action=remove_role Remove role from user
POST   /api/users.php?action=sync_employees Sync HRMS employees to user system
```

### Roles Management
```
GET    /api/user_roles.php               List all roles with stats
GET    /api/user_roles.php?id=3          Get role detail with permissions & users
POST   /api/user_roles.php               Create new role
POST   /api/user_roles.php?action=assign_permission Assign permission to role
```

### Permissions Management
```
GET    /api/user_permissions.php         List all permissions by module
GET    /api/user_permissions.php?user_id=5 Get user's effective permissions
POST   /api/user_permissions.php?action=override Create user-specific permission override
```

### Masters Management
```
GET    /api/user_masters.php?type=departments              List departments
GET    /api/user_masters.php?type=departments&id=1         Get department detail
GET    /api/user_masters.php?type=designations             List designations
GET    /api/user_masters.php?type=designations&id=5        Get designation detail
POST   /api/user_masters.php?type=departments              Create department
POST   /api/user_masters.php?type=designations             Create designation
```

## Frontend Features

### Users Page
- **List View** - Searchable table of all users with department/designation/roles
- **Hierarchy View** - Visual organization hierarchy tree
- **User Detail Modal** - Full user info, assigned roles, and permissions
- **Role Assignment** - Assign/remove roles with single-click actions
- **Sync Button** - Sync latest HRMS employees to user system

### Roles Page
- **Roles List** - Card view of all roles with user count
- **Role Details** - Complete role info with permissions and assigned users
- **Permissions by Module** - Grouped view of what each role can do

### Permissions Page
- **Module Organization** - Permissions grouped by module
- **Action Types** - View, Add, Edit, Delete, Approve, Assign, Export, Import
- **Data Scope** - See access level for each permission

### Departments & Designations Page
- **Department Cards** - Overview with employee count and designations
- **Designation Cards** - Job positions with employee count
- **Detail Views** - Click any card to see employees in that dept/designation

## Permission Structure

Permissions follow a 4-level hierarchy:

```
MODULE (e.g., CRM, HRMS, Accounts)
  ├─ SUB-MODULE (e.g., Lead Management)
  │   └─ ACTION (view, add, edit, delete, approve, assign, export, import)
  │       └─ DATA SCOPE (own, team, department, branch, company, all)
```

Example: A Sales Manager might have:
- `CRM → Lead Management → view: department`
- `CRM → Lead Management → add: team`
- `CRM → Lead Management → edit: team`

## User Workflow

### 1. Employee Creation (HRMS)
```
HR → Add Employee
  ├─ Name, Email, Mobile
  ├─ Department
  ├─ Designation
  ├─ Reporting Manager
  └─ Employment Status
```

### 2. Sync to User System
```
User Management → Sync Employees
  → Pulls active employees
  → Creates reporting hierarchy
  → Ready for role assignment
```

### 3. Role Assignment
```
User Management → Users → Select Employee
  → Click "Assign Role"
  → Select from 5 roles
  → Automatic permissions applied
```

### 4. Permission Overrides (Optional)
```
If exceptions needed:
  → User Management → Permissions
  → Create user-specific override
  → Temporarily enable/disable specific action
  → Set valid date range
```

## Role Definitions

### 1. Super Admin (Level 1)
- **Access**: Full system authority
- **Capabilities**:
  - Manage all users and roles
  - Modify permissions
  - View all data across company
  - System configuration
- **Data Scope**: `all`

### 2. Admin (Level 2)
- **Access**: Company-level operations
- **Capabilities**:
  - Create employees
  - Manage departments
  - Assign roles (except Super Admin role)
  - View company reports
  - Manage integrations
- **Data Scope**: `company`

### 3. Manager (Level 3)
- **Access**: Department-level control
- **Capabilities**:
  - View all department employees
  - Review team performance
  - Approve leaves/expenses
  - Manage department resources
  - Access department reports
- **Data Scope**: `department`

### 4. Supervisor (Level 4)
- **Access**: Team management
- **Capabilities**:
  - View team members
  - Assign tasks
  - Review work progress
  - Attendance tracking
  - Recommend approvals
- **Data Scope**: `team`

### 5. Executive (Level 5)
- **Access**: Operational work
- **Capabilities**:
  - Own records only
  - Submit work/reports
  - Access assigned resources
  - View team communications
- **Data Scope**: `own`

## Query Examples

### Get User with All Permissions
```php
$userId = 5;
$query = "SELECT * FROM v_user_with_roles WHERE id = $userId";
$result = mysqli_query($conn, $query);
```

### Check User Can Edit Leads (Department Scope)
```php
$userId = 10;
$query = "
  SELECT * FROM v_user_permissions_effective 
  WHERE employee_id = $userId 
  AND permission_id = (SELECT id FROM permissions WHERE permission_name = 'Edit Lead')
  AND effective_scope IN ('department', 'all')
";
```

### Get All Managers in Sales Department
```php
$query = "
  SELECT e.*, r.role_name FROM employees e
  JOIN user_roles ur ON e.id = ur.employee_id
  JOIN roles r ON ur.role_id = r.id
  WHERE e.department_id = (SELECT id FROM departments WHERE dept_code = 'SALES')
  AND r.role_level = 3
";
```

## Security Considerations

1. **Session Guard** - All APIs check `session_guard.php` for authentication
2. **SQL Injection Prevention** - Prepared statements used throughout
3. **Authorization Checks** - Role-level validation on sensitive operations
4. **Audit Logging** - Login attempts tracked in `user_login_audit`
5. **Permission Cache** - Redis/memory caching for performance (optional)

## Performance Optimization

### Caching Strategy
- Cache role-permission mappings on login
- Cache user hierarchy structure
- Invalidate cache on role changes

### Database Indexes
```sql
CREATE INDEX idx_user_roles_employee ON user_roles(employee_id);
CREATE INDEX idx_role_permissions_role ON role_permissions(role_id);
CREATE INDEX idx_user_perms_employee ON user_permissions(employee_id);
```

### View Usage
- Use `v_user_with_roles` for user listings
- Use `v_user_permissions_effective` for permission checks

## Troubleshooting

### Issue: Employees not appearing in Users list
**Solution**: Run sync employees:
```sql
CALL SyncEmployeesWithUsers();
```

### Issue: Role not showing permissions
**Solution**: Verify role_permissions table entries:
```sql
SELECT * FROM role_permissions WHERE role_id = 3;
```

### Issue: User can't access module after role assignment
**Solution**: Check if permissions are assigned to role:
```sql
SELECT * FROM role_permissions 
WHERE role_id = (SELECT id FROM roles WHERE role_name = 'Manager')
AND permission_id IN (SELECT id FROM permissions WHERE module_id = 1);
```

## Extending the System

### Add New Module
```sql
INSERT INTO modules (module_name, module_icon, description, status)
VALUES ('New Module', 'fa-icon', 'Description', 'Active');
```

### Add New Permission
```sql
INSERT INTO permissions (module_id, permission_name, action_type, description, status)
VALUES (1, 'New Action', 'view', 'Description', 'Active');
```

### Add New Role
```sql
INSERT INTO roles (role_name, role_level, description, status)
VALUES ('Custom Role', 6, 'Description', 'Active');
```

### Assign Permission to Role
```sql
INSERT INTO role_permissions (role_id, permission_id, data_scope, status)
VALUES (6, 1, 'department', 'Active');
```

## Support & Documentation

For questions or issues:
1. Check the API response status and messages
2. Review browser console for JavaScript errors
3. Check database logs for SQL errors
4. Verify session and authentication
5. Ensure proper role-permission assignments

## Version Information

- **System**: SABHYTA CRM v2.0+
- **Database**: MySQL 5.7+
- **PHP**: 7.4+
- **Frontend**: Vanilla JavaScript, no framework required
- **CSS**: Modern CSS3 with variables

## Future Enhancements

Potential improvements:
- [ ] API-based permission checking in frontend
- [ ] Real-time permission updates via WebSocket
- [ ] Bulk role assignment
- [ ] Permission analytics dashboard
- [ ] Time-based permission expiry
- [ ] IP-based access restrictions
- [ ] Device-based access control
- [ ] Two-factor authentication integration
