# PROFESSIONAL CRM SETUP GUIDE

> Current setup instructions are in [FINAL_SUBMISSION_GUIDE.md](FINAL_SUBMISSION_GUIDE.md). This legacy guide describes an older revision; its default credentials and SQLite references do not apply.

## 🚀 QUICK START (2 Steps)

### Step 1: Database Setup
1. Open phpMyAdmin
2. Navigate to your localhost (typically http://localhost/phpmyadmin)
3. Locate the SQL tab or create new database option
4. The database will auto-initialize on first app load!

### Step 2: Access Application
1. Open browser: `http://localhost/sabhytacrm/`
2. The app will auto-detect if it's the first run
3. Database will be created automatically
4. Admin user will be seeded automatically
5. Test data will be loaded automatically

---

## 📋 Default Credentials (After First Load)

**Email:** `admin@sabhytacrm.com`  
**Password:** `admin123`

> **⚠️ SECURITY NOTE:** Change these credentials immediately after first login in production!

---

## 🎯 KEY FEATURES

### 1. ✅ AUTO-INITIALIZATION
- **No manual seed_admin.php required**
- Database schema auto-created on first load
- Admin user auto-seeded
- Test data automatically loaded
- Module mappings auto-configured

### 2. 💰 PROFESSIONAL SALARY MODULE

#### Three Processing Options:

**Option A: Individual Employee Monthly Salary**
- Process single employee for specific month
- View detailed salary breakdown:
  - Basic Salary
  - HRA, DA, Conveyance
  - Medical & Special Allowances
  - PF, ESIC, Professional Tax
- Download salary slip as PDF
- Email salary slip to employee

**Option B: Bulk Department/Branch Processing**
- Process entire department in one action
- Specify month and year
- Auto-calculates for all active employees
- Export summary with net payables
- Bulk email option to all employees

**Option C: Financial Year Report**
- Generate comprehensive FY summary
- Annual salary analysis per employee
- Total earnings & deductions report
- Download as Excel/CSV
- Department-wise breakdown

#### Features:
✓ Automatic salary component calculation  
✓ Statutory deduction handling (PF, ESIC, PT)  
✓ Professional salary slip generation  
✓ PDF & Excel reports  
✓ Financial year based reporting  
✓ Email integration  

---

### 3. 📊 QUOTATION TO SALES ORDER

#### Auto-Population Features:

When you select "Use for Orders" on a quotation:

**Automatically Populated:**
- ✓ Customer information (name, address, GST)
- ✓ Contact person and email
- ✓ All quotation line items
- ✓ Product/Service details
- ✓ Quantities and rates
- ✓ Discounts and taxes
- ✓ Commercial terms
- ✓ Payment & Delivery terms
- ✓ Warranty information

**No Manual Data Entry Required!**

#### Workflow:
1. Create Quotation with items
2. Open Quotation
3. Click "Convert to Sales Order"
4. All details auto-populate
5. Review and confirm
6. Sales Order created automatically

---

### 4. 📝 TEST DATA

Pre-loaded test data includes:

- **5 Departments** (HR, IT, Sales, Finance, Operations)
- **8 Employees** (with complete salary structures)
- **5 Customers** (ready for quotations)
- **10 Quotations** (with multiple line items)
- **10 Sample Leads** (for pipeline management)

Use this data to explore all features without creating from scratch!

---

## 📂 PROJECT STRUCTURE

```
sabhyta_crm_professional/
├── api/
│   ├── auto_init.php              ← AUTO-INITIALIZATION
│   ├── salary_processing.php      ← SALARY PROCESSING API
│   ├── salary_report_generator.php ← SALARY REPORTS & PDFs
│   ├── quotation_to_order.php     ← AUTO-POPULATION
│   ├── db.php                     ← Database connection
│   ├── auth.php                   ← Authentication
│   └── ... (other APIs)
├── database/
│   ├── schema.sql                 ← Main schema
│   ├── schema_hrms_sales.sql      ← HRMS schema
│   ├── schema_masters.sql         ← Master data schema
│   ├── seed_test_data.php         ← TEST DATA
│   └── ... (migrations)
├── index.html                     ← Main app
├── login.html                     ← Login page
├── script.js                      ← Main app logic
├── hrms_sales.js                  ← HRMS & Sales logic
└── style.css                      ← Styling
```

---

## 🔧 CONFIGURATION

### Database Settings
File: `api/db.php`

```php
$DB_HOST = "localhost";     // Database host
$DB_NAME = "sabhytacrm";    // Database name
$DB_USER = "root";          // MySQL user
$DB_PASS = "";              // MySQL password
```

Edit these if your database setup is different.

### Admin Credentials
File: `database/seed_admin.php` OR auto-set in auto_init.php

```php
$adminEmail = "admin@sabhytacrm.com";
$adminPassword = "admin123";
```

Change these before first run if needed.

---

## 🎓 MODULE GUIDE

### HRMS Module

**Employee Management**
- Create employee master records
- Assign designations and departments
- Set salary components automatically
- Track employment history

**Salary Processing**
- Monthly individual processing
- Bulk department/branch processing
- Financial year reporting
- Salary slip generation

### CRM Module

**Lead Management**
- Add new leads from various sources
- Track lead status and pipeline
- Convert leads to customers

**Customer Management**
- Maintain customer master data
- Track customer information
- Manage customer relationships

**Quotation Management**
- Create detailed quotations
- Add multiple line items
- Calculate taxes and discounts
- Convert to sales orders

**Sales Order Management**
- Create sales orders
- Auto-populate from quotations
- Manage order fulfillment
- Track order status

### Accounting Module

**Chart of Accounts**
- Maintain account master
- Categorize accounts
- Track account hierarchies

---

## 🔐 Security Notes

1. **Change Default Password**
   - Login immediately after setup
   - Change admin password
   - Create role-based users

2. **Database Access**
   - Restrict database user permissions
   - Use strong MySQL passwords
   - Backup regularly

3. **File Permissions**
   - Set proper folder permissions
   - Protect `.env` or config files
   - Use HTTPS in production

---

## ⚙️ TROUBLESHOOTING

### Database Connection Error
**Solution:**
1. Verify MySQL is running
2. Check credentials in `api/db.php`
3. Ensure database has proper permissions

### Auto-init not working
**Solution:**
1. Manually run: `database/seed_admin.php`
2. Then navigate to app

### Missing Test Data
**Solution:**
1. Login as admin
2. Navigate to HRMS > Employees
3. Run `database/seed_test_data.php` in command line:
   ```bash
   php database/seed_test_data.php
   ```

### PDF Download Not Working
**Solution:**
1. Ensure `uploads/` folder exists and is writable
2. Check PHP `mbstring` extension is enabled
3. Verify `allow_url_fopen` is enabled in php.ini

---

## 📚 API ENDPOINTS

### Salary Processing
- `GET api/salary_processing.php?action=get_employees`
- `POST api/salary_processing.php?action=process_individual`
- `POST api/salary_processing.php?action=process_bulk`
- `POST api/salary_processing.php?action=financial_year_report`

### Salary Reports
- `POST api/salary_report_generator.php?action=generate_salary_slip_pdf`
- `POST api/salary_report_generator.php?action=generate_department_report_pdf`
- `POST api/salary_report_generator.php?action=generate_fy_summary_excel`

### Quotation to Order
- `GET api/quotation_to_order.php?action=get&quotation_number=QT-202407-001`
- `POST api/quotation_to_order.php?action=auto_populate`
- `POST api/quotation_to_order.php?action=convert_and_create`

---

## 📞 SUPPORT

For issues or questions:
1. Check this documentation first
2. Review error messages in browser console (F12)
3. Check PHP error logs
4. Verify database connections

---

## 🎉 You're All Set!

1. ✓ Database auto-initialized
2. ✓ Admin user created
3. ✓ Test data loaded
4. ✓ Ready to use!

**Next Steps:**
1. Login with provided credentials
2. Explore HRMS module (Employee & Salary)
3. Create quotations and convert to orders
4. Generate salary reports
5. Manage your business efficiently!

---

**Version:** 2.0 Professional  
**Last Updated:** July 2026  
**Status:** Production Ready ✓
