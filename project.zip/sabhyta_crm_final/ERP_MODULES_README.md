# Marketing · Project · Asset · Document · Administration

This release completes the five sections described in `PENDING.pdf` and fixes the
Department-name problem in User Management. Login, the existing modules and their screens are unchanged.

---------------------------------------------------------------------------

## 1. Installing / upgrading

**Existing install (XAMPP):** copy the project over the old folder. That's all — the first time any new screen is
opened the 40 new tables are created automatically (and three additive columns are added to `users`).
You can also import `database/schema_erp_modules.sql` by hand in phpMyAdmin; it is safe to run twice.

**New install:** follow the existing README (import the SQL files in the same order as before), then log in. The ERP
schema needs no extra step.

**Re-import `database/schema_user_management.sql`** (or just open the Users page — see §6): the old file contained a view
that could not be created.

**Requirements:** PHP 8.0+ with `pdo_mysql`, `openssl`, `mbstring`; MySQL/MariaDB. `zlib` is optional (compresses backups).
For large uploads raise `upload_max_filesize` / `post_max_size` in `php.ini` (XAMPP defaults to 40 MB).

**Folders created at run time:** `storage/` (documents, project files, marketing media, backups, the encryption key).
It is *not* web-served (`.htaccess` denies it and files are only streamed through the API after a permission check).
**Back this folder up** — `storage/keys/.erp_key` decrypts saved gateway passwords/tokens; without it they must be re-entered.

**Scheduled backup:** run `cron/backup.php` daily (Windows Task Scheduler: `C:\xampp\php\php.exe C:\xampp\htdocs\sabhyta_crm_final\cron\backup.php`).

---------------------------------------------------------------------------

## 2. Table names

The PDF uses short names (`modules`, `permissions`, `roles`, `users`, `audit_logs`, `maintenance`, `files`…). Several of
those already exist in this project for User Management and login, so every new table has a prefix:

| Prefix | Section | Tables |
|---|---|---|
| `pm_` | Project Management | projects, milestones, modules, tasks, sub_tasks, team_assignments, time_tracking, files, testing_bugs, client_approvals, deployments, maintenance |
| `am_` | Asset Management | assets, software_licenses, asset_allocations, maintenance_logs, asset_history, asset_depreciation, gl_postings |
| `dms_` | Document Management | documents, document_versions, document_permissions, document_signatures, audit_logs |
| `adm_` | Administration | system_settings, audit_logs, security_rules, backup_history |
| `mk_` | Marketing | audience_lists, audience_contacts, suppression, email/sms/whatsapp/social_campaigns, wa_flows, social_audiences, utm_links, performance, ab_tests |

Columns, types, enums and foreign keys follow the PDF. References to customers, employees, users, departments and roles
are real foreign keys (`ON DELETE SET NULL`, so deleting an employee never destroys project or asset history).
`Branch` in Administration is the existing **Master › Branch** list (one source of truth). Users / Roles / Permissions use
the existing User Management pages.

---------------------------------------------------------------------------

## 3. What each section does

### Project Management (15 screens)
Projects → Milestones → Modules → Tasks (with dependencies) → Sub Tasks → Assign Team (several people at once) → Time Tracking
(clock in/out or manual) → Files (briefs, contracts…) → Testing/bugs → Client Approval → Deployment → Maintenance.
* **Gantt Chart** is drawn from the data: task bars with progress, dependency arrows, milestones, today line, and an
  "on track / ahead / behind" verdict (planned % vs actual %).
* **Project Reports**: estimated vs actual hours, efficiency, estimated labour cost (from employee CTC ÷ 2112 h), billing
  (milestones reached), bugs, overdue tasks; export to Excel / PDF.
* Workflow rules from the PDF flow: rejected approval needs feedback and creates a High-priority rework task and returns the
  project to Active; an approved approval marks its milestone **Reached**; **Production deployment is blocked** until a
  *Final* approval is Approved and no Critical bug is open; production deployment marks the project Completed.

### Asset Management (9 screens)
Company Assets, Laptop / Desktop / Printer / Server (same data, filtered), Software License (seats), Allocation (issue / return,
overdue), Maintenance, History (automatic timeline).
* Status is workflow-driven: allocate → *In Use*, return → *In Stock*, service in progress → *In Repair*, **Retire** closes
  allocations and writes the asset off.
* **Finance integration** posts Journal vouchers into the existing **Accounts › Journal**, so the Ledger, Trial Balance,
  P&L and Balance Sheet pick them up: purchase (CapEx), monthly depreciation (straight-line or declining-balance,
  idempotent — a month is never booked twice), repairs and renewals (OpEx), disposal (accumulated depreciation, proceeds,
  loss/gain). Choose the accounts once in **Administration › Company Settings › Accounting Mapping**. If an account isn't
  mapped yet, entries wait as "pending" and can be posted later with one click.

### Document Management (8 screens)
Contracts, NDA, Agreements, Proposal, Company / Employee / Client documents, Version Control.
* Real file upload; every upload is a **new version** (v1.0 → v1.1 → v2.0) — nothing is ever overwritten; old versions can be
  downloaded or restored.
* **Access control**: administrators, the owner and the uploader have full access; everyone else needs a rule (per
  employee, or per **role** — which applies to everyone holding that role in User Management). Company documents are
  readable by all unless rules are added.
* Digital signature (name, time, IP) → document becomes Active; a new version after signing returns it to Pending Review.
* Audit trail of every view / download / change; renewal alerts for expiring contracts and NDAs.

### Marketing (5 screens)
Email, SMS, WhatsApp, Social Media, Campaign Analytics — each with the data the PDF lists (audience, content assets,
configuration, compliance).
* Audience lists from the CRM (customers / leads) or CSV/Excel upload with a consent confirmation; phone numbers are
  normalised; unsubscribes and bounces go to a **suppression list** automatically.
* Email: UTM tracking link builder and a spam-check score; SMS: segment counter, Sender ID and DLT fields; WhatsApp:
  template approval status, opt-in + verified-number rules, auto-reply flows; Social: personas, budget, bidding, encrypted token.
* **Launch** validates the channel's requirements and resolves the eligible recipient list; **Export recipients** gives you
  the clean CSV to upload to your email provider / SMS gateway / WhatsApp API.
* Campaign Analytics: import the results exported from your platforms (CSV/Excel) or enter them; dashboard with open rate,
  CTR, CPC, ROAS, conversion rate, monthly trend, channel benchmarks, UTM master list and A/B tests with significance.

> This CRM manages campaign **data and lifecycle**; it does not itself transmit email/SMS/WhatsApp messages. That matches the
> PDF's process (upload approved assets to your marketing platforms, then bring the metrics back).

### Administration (12 screens)
* **Users / Roles / Permissions / Branch** – existing pages. The Users page gains a **Login Accounts** shortcut: create sign-in
  accounts, choose a role, suspend / re-activate, reset passwords (password policy enforced; the last Super Admin is protected).
  Only Super Admin / Admin see Administration and User Management in the menu.
* **Company / Email / SMS / WhatsApp / Payment settings** – key/value store; secrets are AES-256-GCM encrypted and never
  sent back to the browser. **Email has a real "Send test email"** over SMTP. The SMS default country code is used by Marketing.
* **Backup** – one-click or scheduled dump (pure PHP, no `mysqldump` needed), download, retention, and restore
  (Super Admin only, type RESTORE, automatic safety copy first).
* **Audit Logs** – every POST/PUT/DELETE in the **whole application** (not just the new modules) is recorded with user,
  action, module, IP and outcome. Passwords and request bodies are never stored. Filter by date, module, outcome, method; CSV export.
* **Security** – IP whitelist / blacklist (single IP, CIDR or wildcard; the system refuses a rule that would lock you out and
  never blocks the server itself; lead webhooks are exempt from the whitelist), password policy, and optional
  brute-force lock-out (off until you set a limit).

---------------------------------------------------------------------------

## 4. Mapping of "users" in the PDF to this project
* `users` (login accounts) = who signs in; used for *uploaded by*, *reported by*, *performed by*, *signer*.
* `employees` = people assigned to tasks, assets, documents (the PDF's "user_id (FK – Employee)").
* A login account is linked to its employee by `users.employee_id` or, failing that, by matching e-mail address.

---------------------------------------------------------------------------

## 5. How it was verified
Run against a real PHP 8.3 + MariaDB 10.11 stack, including a database rebuilt from scratch from the project's SQL files:
33 entity lists / 16 lookups; ~200 workflow assertions (project lifecycle & gates, asset allocation/maintenance/depreciation
with exact math, ledger posting, document permissions/versions/signatures, marketing import/suppression/launch rules,
encrypted settings, real SMTP conversation, firewall from a second source IP, brute-force lock, backup → restore); all 49 new
screens rendered in a DOM harness with form submission, cascading dropdowns, multi-select and row actions; 18 pre-existing screens
re-rendered to confirm nothing regressed.

---------------------------------------------------------------------------

## 6. The Department-name fix (User Management)
**Cause.** `users.php`, `user_masters.php`, `user_roles.php` and the dashboard query used
`COALESCE(d.department_name, d.dept_name)`. MySQL/MariaDB reject a query that merely *names* a column that doesn't exist,
and the real tables only have `department_name` / `designation_name`. So Users, Departments and Designations
failed, and creating a department failed with a raw SQL error. The SQL view `v_user_with_roles` had the same mistake.

**Fix.** New `api/schema_compat.php` looks at the real columns and only ever uses ones that exist (so both naming styles work).
`user_masters.php` was rewritten to create departments/designations safely with friendly messages for duplicates and automatic unique codes.
The view in `schema_user_management.sql` now uses the correct names.

---------------------------------------------------------------------------

## 7. Notes & known limits
* Other sidebar areas that the PDF doesn't describe (Website CMS, AI Tools, Compliance, User Profile) still use the app's
  generic record form. `database/schema_compliance.sql` has a pre-existing syntax error at line 72 (that module isn't wired in).
* Password *expiry* is stored in the policy but not enforced yet.
* Dashboard "Active Projects" and the existing *Reports › Project Reports* now include the new project tables.
* Files changed in existing code: `script.js` (3 small hooks), `index.html` (script/style tags), `api/db.php` (loads hooks),
  `api/auth.php` (suspended accounts can't sign in), `api/dashboard.php` and `api/reports.php` (add project counts),
  and the User Management files listed in §6.
