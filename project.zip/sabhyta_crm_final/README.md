# SABHYTA CRM

For the current setup sequence, first administrator flow and known feature
limits, read [FINAL_SUBMISSION_GUIDE.md](FINAL_SUBMISSION_GUIDE.md). Older
setup instructions below refer to earlier revisions and have been superseded.

This wires your existing frontend's **Customer Management** form to a real
PHP/MySQL backend: Save, list, edit and delete customers, including document
uploads (PAN card, GST certificate, logo, etc).

## 1. Folder placement

Copy the whole `sabhytacrm` folder into your XAMPP `htdocs` directory:

- Windows: `C:\xampp\htdocs\sabhytacrm`
- Mac: `/Applications/XAMPP/htdocs/sabhytacrm`
- Linux: `/opt/lampp/htdocs/sabhytacrm`

Final structure should look like:
```
htdocs/sabhytacrm/
├── index.html
├── login.html
├── style.css
├── script.js
├── api/
│   ├── db.php
│   ├── auth.php
│   ├── session_guard.php
│   └── customers.php
├── database/
│   ├── schema.sql
│   └── seed_admin.php
└── uploads/            (auto-created if missing, stores document files)
```

## 2. Start Apache + MySQL

Open the **XAMPP Control Panel** and click **Start** next to both `Apache`
and `MySQL`.

## 3. Create the database

Create a database named `sabhytacrm` in phpMyAdmin, then use the setup wizard
at `setup.html` to initialize the complete schema and sample data. Configure
non-default credentials with the `SABHYTA_DB_*` environment variables; see
`FINAL_SUBMISSION_GUIDE.md`.

## 3b. Create your first login (one-time)

Open `login.html` after setup and create your own administrator account. There
are no default login credentials; the old fixed-password seeder is disabled.

## 4. Run the app

Open your browser to:

```
http://localhost/sabhytacrm/
```

You'll be redirected to `login.html` if you're not signed in. Log in with
the credentials from step 3b. Once logged in:

- The navbar shows your real name/role (pulled from the `users` table via
  session), not the old hardcoded "Admin".
- Clicking the logout icon in the top-right ends your session and sends you
  back to the login page.
- Every request to `api/customers.php` now requires an active session —
  if it's missing/expired you'll get a 401 and should log in again.

Then click **CRM → Customer Management → Customers** in the sidebar to see
the real, database-backed Customer List page.

## 5. What now works

- **Add Customer**: fills the form → `Save Customer` → sends the data
  (including any uploaded files) to `api/customers.php` via `fetch()` →
  inserted into the `customers` MySQL table.
- **Customer List**: fetched live from the database, shows Code, Name,
  Company, Mobile, Email, Status.
- **Edit**: click **Edit** on a row → form is pre-filled from the database →
  `Update Customer` sends a PUT-style update.
- **Delete**: click **Delete** → confirms → removes the row from MySQL.
- **File uploads** (PAN card, GST certificate, incorporation certificate,
  business license, ISO certificate, UDYAM certificate, logo, company
  profile PDF) are stored in the `uploads/` folder, and their relative path
  is saved in the matching `..._file` database column.

## 6. How the pieces connect

- `script.js` → `renderCustomerListPage()` and `renderCustomerForm()` do all
  the `fetch()` calls to `api/customers.php`.
- `api/customers.php` is a single REST-style endpoint:
  - `GET  /api/customers.php` → list all
  - `GET  /api/customers.php?id=5` → get one
  - `POST /api/customers.php` → create (multipart form, handles files)
  - `POST /api/customers.php?id=5` with `_method=PUT` → update
  - `DELETE /api/customers.php?id=5` → delete
- `api/db.php` opens the PDO/MySQL connection every other API file
  `require`s.
- `api/auth.php` handles login/logout and session checks; `login.html` and
  `script.js`'s `initApp()` talk to it.
- `api/session_guard.php` is included at the top of `customers.php` (and
  should be included at the top of any future protected API file) to block
  requests from anyone who isn't logged in.

## 7. Current module coverage

Customers, leads, employees, quotations, sales orders, helpdesk, reports,
compliance, self-service and the ERP entities have dedicated data-backed
flows where implemented. Several other sidebar items use the shared
`generic_records` form and store only common fields (title, party, assignee,
date, amount, status, notes and optional JSON). They are usable for basic
record tracking, but are not full domain workflows such as accounting,
inventory valuation or payroll processing. Review `FINAL_SUBMISSION_GUIDE.md`
for the setup steps and feature limits before presenting the project.

To build a dedicated module, use this pattern:

1. **SQL**: add a table to `database/schema.sql` (e.g. `leads`, `invoices`).
2. **API**: copy `api/customers.php` → `api/leads.php`, change the table
   name and the `$FIELDS` map to match that module's fields.
3. **Frontend**: write a `renderLeadForm()` / `renderLeadListPage()` pair in
   `script.js`, following the same `fetch()` pattern used for customers, and
   route the relevant sidebar `<li>` click to it (like the `itemLabel ===
  "Customers"` check).

This keeps the whole project consistent while dedicated workflows are added.

## 7b. The home Dashboard is now live, not sample data

`api/dashboard.php` aggregates real numbers from your `customers` and
`generic_records` tables:

- **Total Revenue** — sum of `amount` across every record you've entered
  anywhere in the CRM.
- **New Leads / Open Tickets / Active Projects** — real counts filtered by
  module key (e.g. anything with "lead" in its module key).
- **Revenue chart** — actual `SUM(amount)` grouped by month, last 6 months
  (zero-filled if you haven't entered anything yet).
- **Customers by Type** donut — a real breakdown of your `customers` table
  by Individual / Company / Government (replaces the old fake "Leads by
  Source" chart, since `generic_records` doesn't track lead source — see
  section 8 if you want to add that field to a dedicated Leads table).
- **Recent Activity** — your 5 most recently created customers/records.
- **Tasks for You** — any record you've marked with status "Pending".

So now: add a customer, add a record under any sidebar item, go back to
**Dashboard**, and the numbers/charts/lists update to reflect it — nothing
on the dashboard is hardcoded or randomly generated anymore.

## 8. Every sidebar item now has a real backend

Rather than hand-building ~100+ bespoke tables/forms for every single leaf
item (Add Lead, Import Leads, Website Leads, Milestones, Payroll, GST,
Tickets, SLA, Backup, SEO... every menu item under CRM, Project Management,
HRMS, Accounts, Inventory, Asset Management, Helpdesk, Document Management,
Administration, Website CMS, Compliance, Reports, AI Tools), which isn't
realistic to do correctly in one pass, **every item except Customers now
shares one generic, real, database-backed module**:

- **Table:** `generic_records` (see `database/schema.sql`) — common fields:
  Title, Party/Company, Assigned To, Date, Amount, Status, Notes.
- **API:** `api/records.php` — same create/read/update/delete pattern as
  `api/customers.php`, scoped by a `module_key` (e.g. `crm__add-lead`,
  `hrms__payroll`) so every menu item's records stay separate.
- **Frontend:** `renderModuleListPage()` / `renderModuleForm()` in
  `script.js` — clicking **any** leaf item in the sidebar now shows a real
  list pulled from MySQL with working **Add New / Edit / Delete**, instead
  of the old randomly-generated demo data.

This means the whole CRM is now functionally wired end-to-end — every
click leads to real Add/Edit/Delete against your database — just with a
shared, general-purpose set of fields rather than each module's exact
real-world fields (e.g. a Lead doesn't yet have "Lead Score" or "Expected
Close Date" as dedicated columns; a Payroll entry doesn't yet have
"Basic Pay" / "Deductions" broken out).

**To give a specific module its own exact fields** (like we did for
Customers), follow the pattern in section 7 above: add a dedicated table,
copy `api/customers.php` as a starting point, and write a dedicated
`render<Module>Form()`/`render<Module>ListPage()` pair — then special-case
that `itemLabel` in the sidebar click handler the same way `"Customers"`
is special-cased today. Do this one module at a time, starting with
whichever ones your business actually uses day-to-day (Leads and
Invoices/Sales are usually the highest-value next two).

## 9. Common issues

| Problem | Fix |
|---|---|
| "Database connection failed" | Make sure MySQL is running in XAMPP and `api/db.php` credentials match. |
| Blank page / 500 error from `api/customers.php` | Check `htdocs/sabhytacrm/uploads/` folder exists and is writable. |
| "Customer Code already exists" | `customer_code` is set UNIQUE in the schema — use a different code. |
| Uploaded files not saving | Check PHP's `upload_max_filesize` / `post_max_size` in `php.ini` if files are large. |
| Stuck redirecting to login.html in a loop | Make sure cookies aren't blocked and you're accessing via `http://localhost/...` consistently (not mixing `localhost` and `127.0.0.1`, since PHP sessions are cookie-based per-host). |
| seed_admin.php says "already exists" but you forgot the password | Delete the row from the `users` table in phpMyAdmin, then re-run `seed_admin.php`. |

## 10. HRMS + Sales — now fully built out (Employee, Department, Designation, Sales Order + every sub-module)

**One extra step:** after importing `database/schema.sql`, also import
`database/schema_hrms_sales.sql` (phpMyAdmin → Import, same as before).
It adds four new real tables: `departments`, `designations`, `employees`,
`sales_orders`. Nothing else to configure — the new pages appear
automatically the moment you click **HRMS** or **Sales** in the sidebar.

### What's real now

- **HRMS → Employee**: full master record (`api/employees.php`) — Personal
  Info, Address, Employment Details, repeatable Educational Qualification
  rows, repeatable Work Experience rows, photograph upload. This is the
  single source of truth for every "employee" field in the whole CRM.
- **HRMS → Department** (`api/departments.php`) and **HRMS → Designation**
  (`api/designations.php`) — both real tables, with Department Head /
  Reporting Manager as live dropdowns sourced from Employees.
- **Sales → Sales Order** (`api/sales_orders.php`) — a split-panel page
  exactly like **Create Quote**: pick a real Customer on the left, fill in
  the full Sales Order (Sales Executive & Department are live dropdowns
  from Employees/Departments), add Sales Order Items line-by-line with
  auto-calculated totals, and a Financial Summary (Sub Total, Discount,
  Tax, Freight/Installation/Packing/Insurance/Other charges, Round Off,
  Grand Total). "Saved Sales Orders" lists everything back from the DB.
- **Sales → Sales Report**: a live mini-dashboard pulling real counts/totals
  from Sales Orders, Invoices, Receipts and Payments.
- **Every other HRMS/Sales leaf item** — Recruitment, Internship,
  Attendance, Leave, Holidays, Payroll, Salary, Bonus, Incentive,
  Performance, Appraisal, Exit Process, Experience Letter, ID Card,
  Documents, Proforma Invoice, Invoice, Receipt, Payment — now has its
  **own detailed form with every field from the HRMS/Sales spec**
  (not the old generic 6-field placeholder), built by a small config-driven
  engine (`RICH_MODULES` in `hrms_sales.js`) on top of the existing
  `generic_records` table/API — the same pattern **Create Quote** already
  used. Any field that should reference an Employee, Department, Customer,
  or a previously-saved Sales Order / Invoice / Receipt is a **live
  dropdown**, not free text.

### The employee link — "add once, use everywhere"

Add an employee under **HRMS → Employee** and they instantly become
selectable in:
- **Customer Management → Customers**: Sales Executive dropdown
- **Quotation → Create Quote**: Sales Executive dropdown
- **Sales → Sales Order**: Sales Executive dropdown
- Every HRMS sub-module that has an employee field (Attendance, Leave,
  Payroll, Salary, Bonus, Incentive, Performance, Appraisal, Exit Process,
  Experience Letter, ID Card, Documents, Recruitment's HR Assigned/Hiring
  Manager, Internship's Guide/Mentor)
- Every Sales sub-module's Prepared By / Approved By / Received By /
  Verified By / Receipt Issued By fields

No re-entering names by hand, and no risk of two different spellings of
the same person's name across modules.

### Files added in this pass

```
database/schema_hrms_sales.sql   -- departments, designations, employees, sales_orders
api/employees.php                -- Employee CRUD
api/departments.php              -- Department CRUD
api/designations.php             -- Designation CRUD
api/sales_orders.php             -- Sales Order CRUD (line items as JSON)
hrms_sales.js                    -- all HRMS/Sales frontend pages + the
                                     live Employee/Department/Customer/
                                     Sales-Order dropdown helpers
```

`index.html` now loads `hrms_sales.js` right after `script.js`, and
`script.js`'s sidebar click handler was given one extra `else if` branch
that hands off to `routeHrmsSalesLeaf()` (defined in `hrms_sales.js`)
before falling back to the old generic form — so Customers and Create
Quote behave exactly as before, and everything under HRMS/Sales is now
real.

### Extending further

Every remaining sidebar section (Project Management, Accounts, Inventory,
Asset Management, Helpdesk, Document Management, Administration, Website
CMS, Compliance, AI Tools) still uses the original generic form. Follow
the `RICH_MODULES` pattern in `hrms_sales.js` to give any of those the
same treatment — add a config entry keyed `"<Section>||<Item>"` with its
exact fields, and it will automatically get a full detail form the next
time you click that sidebar item.
