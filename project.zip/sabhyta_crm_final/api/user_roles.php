<?php
/**
 * User Roles Management API (PDO)
 * GET    /api/user_roles.php              -> list all roles
 * GET    /api/user_roles.php?id=2         -> get role with permissions
 * POST   /api/user_roles.php              -> create role
 * POST   /api/user_roles.php?action=assign_permission -> assign permission to role
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';
require_once 'schema_compat.php';
require_once 'access.php';

// Listing roles is needed by the Users, Roles and Permissions screens; changing them is not.
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    acc_require($pdo, ['Manage Users', 'Manage Roles', 'Manage Permissions'], 'view roles');
} elseif (($_GET['action'] ?? '') === 'assign_permission') {
    acc_require($pdo, ['Manage Permissions', 'Manage Roles'], 'assign permissions to roles');
} else {
    acc_require($pdo, ['Manage Roles'], 'create roles');
}

$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'GET') {
        if (isset($_GET['id'])) {
            getRoleDetail($_GET['id']);
        } else {
            listRoles();
        }
    } elseif ($method === 'POST') {
        $action = $_GET['action'] ?? '';
        if ($action === 'assign_permission') {
            assignPermissionToRole();
        } else {
            createRole();
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

function listRoles() {
    global $pdo;

    // Ensure roles table exists with seed data
    ensureRolesSeeded();

    $query = "
        SELECT
            r.id,
            r.role_name,
            r.role_level,
            r.description,
            r.status,
            r.created_at,
            r.updated_at,
            COUNT(DISTINCT ur.employee_id) as user_count,
            COUNT(DISTINCT rp.permission_id) as permission_count
        FROM roles r
        LEFT JOIN user_roles ur ON r.id = ur.role_id AND ur.status = 'Active'
        LEFT JOIN role_permissions rp ON r.id = rp.role_id AND rp.status = 'Active'
        GROUP BY r.id, r.role_name, r.role_level, r.description, r.status, r.created_at, r.updated_at
        ORDER BY r.role_level
    ";

    $roles = $pdo->query($query)->fetchAll();
    echo json_encode(['success' => true, 'data' => $roles, 'count' => count($roles)]);
}

function getRoleDetail($roleId) {
    global $pdo;

    $roleQuery = "
        SELECT
            r.id,
            r.role_name,
            r.role_level,
            r.description,
            r.status,
            r.created_at,
            r.updated_at
        FROM roles r
        WHERE r.id = ?
    ";
    $stmt = $pdo->prepare($roleQuery);
    $stmt->execute([$roleId]);
    $role = $stmt->fetch();

    if (!$role) {
        echo json_encode(['success' => false, 'message' => 'Role not found']);
        return;
    }

    $countStmt = $pdo->prepare("SELECT COUNT(DISTINCT employee_id) FROM user_roles WHERE role_id = ? AND status = 'Active'");
    $countStmt->execute([$roleId]);
    $role['assigned_users'] = (int)$countStmt->fetchColumn();

    $permQuery = "
        SELECT
            rp.id as role_perm_id,
            p.id as permission_id,
            p.permission_name,
            m.module_name,
            p.action_type,
            rp.data_scope,
            rp.status,
            rp.created_at
        FROM role_permissions rp
        JOIN permissions p ON rp.permission_id = p.id
        JOIN modules m ON p.module_id = m.id
        WHERE rp.role_id = ?
        ORDER BY m.module_name, p.permission_name
    ";
    $stmt = $pdo->prepare($permQuery);
    $stmt->execute([$roleId]);
    $perms = $stmt->fetchAll();

    $role['permissions'] = $perms;
    $moduleGroup = [];
    foreach ($perms as $perm) {
        $module = $perm['module_name'];
        if (!isset($moduleGroup[$module])) {
            $moduleGroup[$module] = [];
        }
        $moduleGroup[$module][] = $perm;
    }
    $role['permissions_by_module'] = $moduleGroup;

    $usersQuery = "
        SELECT
            e.id,
            e.employee_code,
            CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as full_name,
            " . scDeptName('d') . " as dept_name
        FROM user_roles ur
        JOIN employees e ON ur.employee_id = e.id
        LEFT JOIN departments d ON e.department_id = d.id
        WHERE ur.role_id = ? AND ur.status = 'Active'
        ORDER BY e.first_name
    ";
    $stmt = $pdo->prepare($usersQuery);
    $stmt->execute([$roleId]);
    $role['assigned_users_list'] = $stmt->fetchAll();
    // Keep array key expected by frontend
    $role['assigned_users'] = $role['assigned_users_list'];

    echo json_encode(['success' => true, 'data' => $role]);
}

function createRole() {
    global $pdo;

    $input = json_decode(file_get_contents('php://input'), true);
    $roleName = trim($input['role_name'] ?? '');
    $roleLevel = (int)($input['role_level'] ?? 0);
    $description = $input['description'] ?? '';

    if ($roleName === '' || $roleLevel < 1) {
        echo json_encode(['success' => false, 'message' => 'Role name and level are required']);
        return;
    }
    if ($roleLevel <= 2 && !acc_is_admin_role(acc_session_user()['role'])) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Only an Admin or Super Admin can create Admin-level roles (level 1-2).']);
        return;
    }

    $check = $pdo->prepare("SELECT id FROM roles WHERE role_name = ?");
    $check->execute([$roleName]);
    if ($check->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Role name already exists']);
        return;
    }

    $stmt = $pdo->prepare("
        INSERT INTO roles (role_name, role_level, description, status)
        VALUES (?, ?, ?, 'Active')
    ");
    $stmt->execute([$roleName, $roleLevel, $description]);
    echo json_encode([
        'success' => true,
        'message' => 'Role created successfully',
        'role_id' => (int)$pdo->lastInsertId()
    ]);
}

function assignPermissionToRole() {
    global $pdo;

    $input = json_decode(file_get_contents('php://input'), true);
    $roleId = $input['role_id'] ?? null;
    $permissionId = $input['permission_id'] ?? null;
    $dataScope = $input['data_scope'] ?? 'own';

    if (!$roleId || !$permissionId) {
        echo json_encode(['success' => false, 'message' => 'Role and Permission are required']);
        return;
    }
    acc_guard_privileged_role($pdo, (int)$roleId);

    $check = $pdo->prepare("SELECT id FROM role_permissions WHERE role_id = ? AND permission_id = ?");
    $check->execute([$roleId, $permissionId]);
    if ($check->fetch()) {
        // Update scope if already exists
        $upd = $pdo->prepare("UPDATE role_permissions SET data_scope = ?, status = 'Active' WHERE role_id = ? AND permission_id = ?");
        $upd->execute([$dataScope, $roleId, $permissionId]);
        echo json_encode(['success' => true, 'message' => 'Permission updated for role']);
        return;
    }

    $stmt = $pdo->prepare("
        INSERT INTO role_permissions (role_id, permission_id, data_scope, status)
        VALUES (?, ?, ?, 'Active')
    ");
    $stmt->execute([$roleId, $permissionId, $dataScope]);
    echo json_encode(['success' => true, 'message' => 'Permission assigned to role']);
}

/**
 * Auto-create roles table + default seed if missing (so UI never hangs empty)
 */
function ensureRolesSeeded() {
    global $pdo;

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS roles (
          id INT AUTO_INCREMENT PRIMARY KEY,
          role_name VARCHAR(100) UNIQUE NOT NULL,
          role_level INT NOT NULL,
          description TEXT,
          status VARCHAR(20) DEFAULT 'Active',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          INDEX idx_level (role_level),
          INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS modules (
          id INT AUTO_INCREMENT PRIMARY KEY,
          module_name VARCHAR(100) UNIQUE NOT NULL,
          module_icon VARCHAR(50),
          description TEXT,
          status VARCHAR(20) DEFAULT 'Active',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS permissions (
          id INT AUTO_INCREMENT PRIMARY KEY,
          module_id INT NOT NULL,
          permission_name VARCHAR(150) NOT NULL,
          action_type VARCHAR(50) NOT NULL,
          description TEXT,
          status VARCHAR(20) DEFAULT 'Active',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_module (module_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS role_permissions (
          id INT AUTO_INCREMENT PRIMARY KEY,
          role_id INT NOT NULL,
          permission_id INT NOT NULL,
          data_scope VARCHAR(50) DEFAULT 'own',
          status VARCHAR(20) DEFAULT 'Active',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          UNIQUE KEY unique_role_perm (role_id, permission_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS user_roles (
          id INT AUTO_INCREMENT PRIMARY KEY,
          employee_id INT NOT NULL,
          role_id INT NOT NULL,
          assigned_by INT,
          assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          status VARCHAR(20) DEFAULT 'Active',
          UNIQUE KEY unique_emp_role (employee_id, role_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $count = (int)$pdo->query("SELECT COUNT(*) FROM roles")->fetchColumn();
    if ($count === 0) {
        $pdo->exec("
            INSERT INTO roles (role_name, role_level, description, status) VALUES
            ('Super Admin', 1, 'Complete system authority - Full access to all modules and settings', 'Active'),
            ('Admin', 2, 'Company administration - Manage users, departments, and operational data', 'Active'),
            ('Manager', 3, 'Department control - Full access to department data and team management', 'Active'),
            ('Supervisor', 4, 'Team control - Manage team members and their work', 'Active'),
            ('Executive', 5, 'User level - Access only assigned data and own records', 'Active')
        ");
    }

    $modCount = (int)$pdo->query("SELECT COUNT(*) FROM modules")->fetchColumn();
    if ($modCount === 0) {
        $pdo->exec("
            INSERT INTO modules (module_name, module_icon, description, status) VALUES
            ('CRM', 'fa-users', 'Customer Relationship Management', 'Active'),
            ('HRMS', 'fa-user-tie', 'Human Resource Management', 'Active'),
            ('Accounts', 'fa-wallet', 'Financial and Accounting Management', 'Active'),
            ('Projects', 'fa-project-diagram', 'Project Management', 'Active'),
            ('Inventory', 'fa-box-open', 'Stock and Inventory Management', 'Active'),
            ('Helpdesk', 'fa-headset', 'Support and Ticket Management', 'Active'),
            ('Reports', 'fa-chart-pie', 'Reporting and Analytics', 'Active'),
            ('Administration', 'fa-user-shield', 'System Administration', 'Active')
        ");
    }
}
