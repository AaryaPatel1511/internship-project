<?php
/**
 * SALARY REPORT GENERATOR
 * Generates professional salary reports with PDF and Excel downloads
 * Supports:
 * - Individual Salary Slip (monthly)
 * - Department Salary Report
 * - Branch Salary Report
 * - Financial Year Summary
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/session_guard.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? 'list';

try {
    switch ($action) {
        case 'generate_salary_slip_pdf':
            generateSalarySlipPDF();
            break;

        case 'generate_department_report_pdf':
            generateDepartmentReportPDF();
            break;

        case 'generate_fy_summary_excel':
            generateFYSummaryExcel();
            break;

        case 'generate_department_summary_excel':
            generateDepartmentSummaryExcel();
            break;

        case 'generate_attendance_linked_report':
            generateAttendanceLinkedReport();
            break;

        default:
            http_response_code(400);
            echo json_encode(['error' => 'Invalid action']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

// ===== PDF & REPORT GENERATION FUNCTIONS =====

function generateSalarySlipPDF() {
    global $pdo;
    $data = json_decode(file_get_contents('php://input'), true);

    $employeeId = $data['employee_id'] ?? null;
    $month = $data['month'] ?? date('m');
    $year = $data['year'] ?? date('Y');

    $stmt = $pdo->prepare("
        SELECT e.*, ss.slip_number, ss.gross_salary, ss.net_salary, ss.pf, ss.esic, ss.professional_tax,
               d.designation_name, dept.department_name
        FROM employees e
        LEFT JOIN salary_slips ss ON e.id = ss.employee_id AND ss.month = ? AND ss.year = ?
        LEFT JOIN designations d ON e.designation_id = d.id
        LEFT JOIN departments dept ON e.department_id = dept.id
        WHERE e.id = ?
    ");

    $stmt->execute([$month, $year, $employeeId]);
    $employee = $stmt->fetch();

    if (!$employee) {
        throw new Exception('Employee not found');
    }

    // Generate HTML for PDF
    $html = generateSalarySlipHTML($employee, $month, $year);

    echo json_encode([
        'status' => 'success',
        'type' => 'salary_slip_pdf',
        'filename' => 'Salary_Slip_' . $employee['employee_code'] . '_' . $month . '_' . $year . '.pdf',
        'html' => $html,
        'employee' => $employee['first_name'] . ' ' . $employee['last_name'],
        'period' => monthToName($month) . ' ' . $year
    ]);
}

function generateSalarySlipHTML($employee, $month, $year) {
    $basicSalary = $employee['basic_salary'] ?? 0;
    $hra = $employee['hra'] ?? 0;
    $da = $employee['da'] ?? 0;
    $conveyance = $employee['conveyance'] ?? 0;
    $medicalAllowance = $employee['medical_allowance'] ?? 0;
    $specialAllowance = $employee['special_allowance'] ?? 0;

    $grossSalary = $basicSalary + $hra + $da + $conveyance + $medicalAllowance + $specialAllowance;

    $pf = $employee['pf'] ?? 0;
    $esic = $employee['esic'] ?? 0;
    $professionalTax = $employee['professional_tax'] ?? 0;

    $totalDeductions = $pf + $esic + $professionalTax;
    $netSalary = $grossSalary - $totalDeductions;

    $monthName = monthToName($month);
    $date = date('d-M-Y');
    $designationName = $employee['designation_name'] ?? 'N/A';
    $departmentName = $employee['department_name'] ?? 'N/A';
    $bankName = $employee['bank_name'] ?? 'N/A';
    $accountNumber = $employee['account_number'] ?? 'N/A';
    $ifscCode = $employee['ifsc_code'] ?? 'N/A';

    return <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Salary Slip</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { background: white; max-width: 800px; margin: 0 auto; padding: 40px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .header { text-align: center; border-bottom: 3px solid #2c3e50; padding-bottom: 20px; margin-bottom: 20px; }
        .header h1 { color: #2c3e50; font-size: 24px; margin-bottom: 5px; }
        .header p { color: #7f8c8d; font-size: 12px; }
        .title { text-align: center; font-size: 18px; font-weight: bold; margin: 20px 0; color: #2c3e50; }
        .employee-info { background: #ecf0f1; padding: 15px; margin-bottom: 20px; border-left: 4px solid #3498db; }
        .employee-info table { width: 100%; }
        .employee-info td { padding: 5px; font-size: 13px; }
        .employee-info td:first-child { font-weight: bold; width: 40%; color: #2c3e50; }
        .salary-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        .salary-table th { background: #34495e; color: white; padding: 10px; text-align: left; font-size: 12px; }
        .salary-table td { padding: 10px; border-bottom: 1px solid #bdc3c7; font-size: 12px; }
        .salary-table tr:nth-child(even) { background: #f9f9f9; }
        .section-header { background: #3498db; color: white; padding: 8px; font-weight: bold; }
        .amount { text-align: right; font-weight: bold; }
        .total-row { background: #ecf0f1; font-weight: bold; }
        .footer { margin-top: 30px; border-top: 1px solid #bdc3c7; padding-top: 20px; font-size: 11px; color: #7f8c8d; text-align: center; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>SALARY SLIP</h1>
            <p>Confidential</p>
        </div>

        <div class="employee-info">
            <table>
                <tr>
                    <td>Employee Name:</td>
                    <td>{$employee['first_name']} {$employee['last_name']}</td>
                    <td>Employee Code:</td>
                    <td>{$employee['employee_code']}</td>
                </tr>
                <tr>
                    <td>Designation:</td>
                    <td>{$designationName}</td>
                    <td>Department:</td>
                    <td>{$departmentName}</td>
                </tr>
                <tr>
                    <td>Pay Period:</td>
                    <td>{$monthName} {$year}</td>
                    <td>Date of Issue:</td>
                    <td>{$date}</td>
                </tr>
            </table>
        </div>

        <div class="title">EARNINGS</div>
        <table class="salary-table">
            <tr>
                <th>Description</th>
                <th class="amount">Amount (₹)</th>
            </tr>
            <tr>
                <td>Basic Salary</td>
                <td class="amount">{$basicSalary}</td>
            </tr>
            <tr>
                <td>House Rent Allowance (HRA)</td>
                <td class="amount">{$hra}</td>
            </tr>
            <tr>
                <td>Dearness Allowance (DA)</td>
                <td class="amount">{$da}</td>
            </tr>
            <tr>
                <td>Conveyance Allowance</td>
                <td class="amount">{$conveyance}</td>
            </tr>
            <tr>
                <td>Medical Allowance</td>
                <td class="amount">{$medicalAllowance}</td>
            </tr>
            <tr>
                <td>Special Allowance</td>
                <td class="amount">{$specialAllowance}</td>
            </tr>
            <tr class="total-row">
                <td>GROSS SALARY</td>
                <td class="amount">{$grossSalary}</td>
            </tr>
        </table>

        <div class="title">DEDUCTIONS</div>
        <table class="salary-table">
            <tr>
                <th>Description</th>
                <th class="amount">Amount (₹)</th>
            </tr>
            <tr>
                <td>Provident Fund (PF)</td>
                <td class="amount">{$pf}</td>
            </tr>
            <tr>
                <td>ESIC Contribution</td>
                <td class="amount">{$esic}</td>
            </tr>
            <tr>
                <td>Professional Tax</td>
                <td class="amount">{$professionalTax}</td>
            </tr>
            <tr class="total-row">
                <td>TOTAL DEDUCTIONS</td>
                <td class="amount">{$totalDeductions}</td>
            </tr>
        </table>

        <div style="background: #2ecc71; color: white; padding: 15px; text-align: center; margin: 20px 0; font-weight: bold;">
            NET SALARY PAYABLE: ₹ {$netSalary}
        </div>

        <div class="employee-info">
            <table>
                <tr>
                    <td>Bank Name:</td>
                    <td>{$bankName}</td>
                    <td>Account No:</td>
                    <td>{$accountNumber}</td>
                </tr>
                <tr>
                    <td>IFSC Code:</td>
                    <td>{$ifscCode}</td>
                    <td></td>
                    <td></td>
                </tr>
            </table>
        </div>

        <div class="footer">
            <p>This is a system-generated document and does not require any signature.</p>
            <p>For queries regarding this salary slip, please contact the HR Department.</p>
        </div>
    </div>
</body>
</html>
HTML;
}

function generateDepartmentReportPDF() {
    global $pdo;
    $data = json_decode(file_get_contents('php://input'), true);

    $department = $data['department_id'] ?? null;
    $month = $data['month'] ?? date('m');
    $year = $data['year'] ?? date('Y');

    $stmt = $pdo->prepare("
        SELECT e.id, e.first_name, e.last_name, e.employee_code, e.basic_salary,
               ss.gross_salary, ss.net_salary
        FROM employees e
        LEFT JOIN salary_slips ss ON e.id = ss.employee_id AND ss.month = ? AND ss.year = ?
        WHERE e.department_id = ? AND e.status = 'Active'
        ORDER BY e.first_name
    ");

    $stmt->execute([$month, $year, $department]);
    $employees = $stmt->fetchAll();

    $monthName = monthToName($month);
    $totalGross = 0;
    $totalNet = 0;
    $rows = '';

    foreach ($employees as $emp) {
        $gross = $emp['gross_salary'] ?? 0;
        $net = $emp['net_salary'] ?? 0;
        $totalGross += $gross;
        $totalNet += $net;

        $rows .= <<<ROW
        <tr>
            <td>{$emp['employee_code']}</td>
            <td>{$emp['first_name']} {$emp['last_name']}</td>
            <td class="amount">{$emp['basic_salary']}</td>
            <td class="amount">{$gross}</td>
            <td class="amount">{$net}</td>
        </tr>
ROW;
    }

    $html = <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Department Salary Report</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; padding: 20px; }
        .container { background: white; padding: 30px; }
        .header { text-align: center; border-bottom: 3px solid #2c3e50; padding-bottom: 15px; margin-bottom: 20px; }
        .title { font-size: 18px; font-weight: bold; margin: 15px 0; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th { background: #34495e; color: white; padding: 10px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #bdc3c7; }
        .amount { text-align: right; }
        .total-row { background: #ecf0f1; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>DEPARTMENT SALARY REPORT</h1>
            <p>{$monthName} {$year}</p>
        </div>
        <table>
            <tr>
                <th>Employee Code</th>
                <th>Employee Name</th>
                <th class="amount">Basic Salary</th>
                <th class="amount">Gross Salary</th>
                <th class="amount">Net Salary</th>
            </tr>
            {$rows}
            <tr class="total-row">
                <td colspan="3">TOTAL</td>
                <td class="amount">{$totalGross}</td>
                <td class="amount">{$totalNet}</td>
            </tr>
        </table>
    </div>
</body>
</html>
HTML;

    echo json_encode([
        'status' => 'success',
        'type' => 'department_report_pdf',
        'html' => $html,
        'filename' => 'Department_Salary_Report_' . $month . '_' . $year . '.pdf'
    ]);
}

function generateFYSummaryExcel() {
    global $pdo;
    $data = json_decode(file_get_contents('php://input'), true);

    $financialYear = $data['financial_year'] ?? date('Y');

    $stmt = $pdo->prepare("
        SELECT e.employee_code, e.first_name, e.last_name, e.designation_id, d.designation_name,
               SUM(ss.gross_salary) as total_gross, SUM(ss.net_salary) as total_net,
               COUNT(*) as months_paid
        FROM employees e
        LEFT JOIN salary_slips ss ON e.id = ss.employee_id AND ss.year >= ? AND ss.year < ?
        LEFT JOIN designations d ON e.designation_id = d.id
        WHERE e.status = 'Active'
        GROUP BY e.id
        ORDER BY e.first_name
    ");

    $stmt->execute([$financialYear, $financialYear + 1]);
    $data = $stmt->fetchAll();

    // Excel CSV format
    $csv = "Employee Code,Employee Name,Designation,Total Gross Salary,Total Net Salary,Months Paid\n";
    
    foreach ($data as $row) {
        $csv .= "\"{$row['employee_code']}\",\"{$row['first_name']} {$row['last_name']}\",\"{$row['designation_name']}\",{$row['total_gross']},{$row['total_net']},{$row['months_paid']}\n";
    }

    echo json_encode([
        'status' => 'success',
        'type' => 'fy_summary_excel',
        'filename' => 'FY_Salary_Summary_' . $financialYear . '.csv',
        'content' => $csv,
        'format' => 'csv'
    ]);
}

function generateDepartmentSummaryExcel() {
    global $pdo;
    $data = json_decode(file_get_contents('php://input'), true);

    $stmt = $pdo->query("
        SELECT dept.department_name, COUNT(e.id) as employee_count,
               SUM(e.basic_salary) as total_basic,
               SUM(e.gross_salary) as total_gross
        FROM departments dept
        LEFT JOIN employees e ON dept.id = e.department_id AND e.status = 'Active'
        GROUP BY dept.id
        ORDER BY dept.department_name
    ");

    $departments = $stmt->fetchAll();

    $csv = "Department,Employee Count,Total Basic,Total Gross\n";
    
    foreach ($departments as $dept) {
        $csv .= "\"{$dept['department_name']}\",{$dept['employee_count']},{$dept['total_basic']},{$dept['total_gross']}\n";
    }

    echo json_encode([
        'status' => 'success',
        'type' => 'dept_summary_excel',
        'filename' => 'Department_Salary_Summary.csv',
        'content' => $csv,
        'format' => 'csv'
    ]);
}

function generateAttendanceLinkedReport() {
    echo json_encode([
        'status' => 'success',
        'message' => 'Attendance-linked salary report (Future feature - requires attendance module)'
    ]);
}

function monthToName($month) {
    $months = [
        '01' => 'January', '02' => 'February', '03' => 'March', '04' => 'April',
        '05' => 'May', '06' => 'June', '07' => 'July', '08' => 'August',
        '09' => 'September', '10' => 'October', '11' => 'November', '12' => 'December'
    ];
    return $months[$month] ?? 'Unknown';
}
?>
