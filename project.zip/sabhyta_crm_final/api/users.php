<?php
/**
 * User Management API
 * Users = HRMS employees. Roles assigned via user_roles table.
 *
 * GET  /api/users.php                  -> list employees + roles
 * GET  /api/users.php?id=5             -> employee detail + roles + permissions
 * POST /api/users.php?action=assign_role
 * POST /api/users.php?action=remove_role
 * POST /api/users.php?action=sync_employees
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';
require_once 'schema_compat.php';
require_once 'access.php';

// Users screen = "Manage Users" permission (Admin / Super Admin always allowed).
acc_require($pdo, ['Manage Users'], 'manage users');

$method = $_SERVER['REQUEST_METHOD'];

try {
    ensureUserMgmtTables();

    if ($method === 'GET') {
        if (isset($_GET['id'])) {
            getUserDetail((int)$_GET['id']);
        } else {
            listUsers();
        }
    } elseif ($method === 'POST') {
        $action = $_GET['action'] ?? '';
        switch ($action) {
            case 'assign_role':
                assignRoleToUser();
                break;
            case 'remove_role':
                removeRoleFromUser();
                break;
            case 'sync_employees':
                syncEmployeesWithUsers();
                break;
            default:
                echo json_encode(['success' => false, 'message' => 'Invalid action']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

function ensureUserMgmtTables() {
    global $pdo;

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS roles (
          id INT AUTO_INCREMENT PRIMARY KEY,
          role_name VARCHAR(100) UNIQUE NOT NULL,
          role_level INT NOT NULL,
          description TEXT,
          status VARCHAR(20) DEFAULT 'Active',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS modules (
          id INT AUTO_INCREMENT PRIMARY KEY,
          module_name VARCHAR(100) UNIQUE NOT NULL,
          module_icon VARCHAR(50),
          description TEXT,
          status VARCHAR(20) DEFAULT 'Active',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS permissions (
          id INT AUTO_INCREMENT PRIMARY KEY,
          module_id INT NOT NULL,
          permission_name VARCHAR(150) NOT NULL,
          action_type VARCHAR(50) NOT NULL,
          description TEXT,
          status VARCHAR(20) DEFAULT 'Active',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS role_permissions (
          id INT AUTO_INCREMENT PRIMARY KEY,
          role_id INT NOT NULL,
          permission_id INT NOT NULL,
          data_scope VARCHAR(50) DEFAULT 'own',
          status VARCHAR(20) DEFAULT 'Active',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          UNIQUE KEY unique_role_perm (role_id, permission_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS user_roles (
          id INT AUTO_INCREMENT PRIMARY KEY,
          employee_id INT NOT NULL,
          role_id INT NOT NULL,
          assigned_by INT NULL,
          assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          status VARCHAR(20) DEFAULT 'Active',
          UNIQUE KEY unique_emp_role (employee_id, role_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $count = (int)$pdo->query("SELECT COUNT(*) FROM roles")->fetchColumn();
    if ($count === 0) {
        $pdo->exec("
            INSERT INTO roles (role_name, role_level, description, status) VALUES
            ('Super Admin', 1, 'Complete system authority', 'Active'),
            ('Admin', 2, 'Company / operational administration', 'Active'),
            ('Manager', 3, 'Complete department control', 'Active'),
            ('Supervisor', 4, 'Team control', 'Active'),
            ('Executive', 5, 'Assigned work only', 'Active')
        ");
    }

    $modCount = (int)$pdo->query("SELECT COUNT(*) FROM modules")->fetchColumn();
    if ($modCount === 0) {
        $pdo->exec("
            INSERT INTO modules (module_name, module_icon, description, status) VALUES
            ('CRM', 'fa-users', 'Customer Relationship Management', 'Active'),
            ('HRMS', 'fa-user-tie', 'Human Resource Management', 'Active'),
            ('Accounts', 'fa-wallet', 'Financial Management', 'Active'),
            ('Projects', 'fa-project-diagram', 'Project Management', 'Active'),
            ('Inventory', 'fa-box-open', 'Inventory Management', 'Active'),
            ('Helpdesk', 'fa-headset', 'Support Management', 'Active'),
            ('Reports', 'fa-chart-pie', 'Reporting', 'Active'),
            ('Administration', 'fa-user-shield', 'System Administration', 'Active')
        ");
    }

    $permCount = (int)$pdo->query("SELECT COUNT(*) FROM permissions")->fetchColumn();
    if ($permCount === 0) {
        $pdo->exec("
            INSERT INTO permissions (module_id, permission_name, action_type, description, status) VALUES
            (1, 'View Leads', 'view', 'View lead records', 'Active'),
            (1, 'Add Lead', 'add', 'Create new leads', 'Active'),
            (1, 'Edit Lead', 'edit', 'Modify leads', 'Active'),
            (1, 'Delete Lead', 'delete', 'Delete leads', 'Active'),
            (1, 'Assign Lead', 'assign', 'Assign leads', 'Active'),
            (1, 'Export Leads', 'export', 'Export leads', 'Active'),
            (1, 'View Customers', 'view', 'View customers', 'Active'),
            (1, 'Add Customer', 'add', 'Create customers', 'Active'),
            (1, 'Edit Customer', 'edit', 'Modify customers', 'Active'),
            (1, 'Approve Quotation', 'approve', 'Approve quotations', 'Active'),
            (2, 'View Employees', 'view', 'View employees', 'Active'),
            (2, 'Add Employee', 'add', 'Create employees', 'Active'),
            (2, 'Edit Employee', 'edit', 'Modify employees', 'Active'),
            (2, 'View Attendance', 'view', 'View attendance', 'Active'),
            (2, 'Manage Leave', 'edit', 'Manage leave', 'Active'),
            (2, 'View Payroll', 'view', 'View payroll', 'Active'),
            (8, 'Manage Users', 'edit', 'Manage users', 'Active'),
            (8, 'Manage Roles', 'edit', 'Manage roles', 'Active'),
            (8, 'Manage Permissions', 'edit', 'Manage permissions', 'Active'),
            (8, 'View Audit Logs', 'view', 'View audit logs', 'Active')
        ");
        $pdo->exec("INSERT IGNORE INTO role_permissions (role_id, permission_id, data_scope, status)
            SELECT 1, id, 'all', 'Active' FROM permissions");
        $pdo->exec("INSERT IGNORE INTO role_permissions (role_id, permission_id, data_scope, status)
            SELECT 2, id, 'company', 'Active' FROM permissions WHERE id IN (1,2,3,7,8,9,11,12,13,14,15,16,17)");
        $pdo->exec("INSERT IGNORE INTO role_permissions (role_id, permission_id, data_scope, status)
            SELECT 3, id, 'department', 'Active' FROM permissions WHERE id IN (1,2,3,5,7,9,11,13,14)");
        $pdo->exec("INSERT IGNORE INTO role_permissions (role_id, permission_id, data_scope, status)
            SELECT 4, id, 'team', 'Active' FROM permissions WHERE id IN (1,2,3,7,11,14)");
        $pdo->exec("INSERT IGNORE INTO role_permissions (role_id, permission_id, data_scope, status)
            SELECT 5, id, 'own', 'Active' FROM permissions WHERE id IN (1,2,3,7,11,14)");
    }
}

function listUsers() {
    global $pdo;

    $empCheck = $pdo->query("SHOW TABLES LIKE 'employees'")->fetch();
    if (!$empCheck) {
        echo json_encode([
            'success' => false,
            'message' => 'HRMS employees table not found. Run database/schema_hrms_sales.sql and seed employees first.'
        ]);
        return;
    }

    $search = $_GET['q'] ?? '';
    $status = $_GET['status'] ?? 'Active';
    $department = $_GET['department'] ?? '';
    $role = $_GET['role'] ?? '';

    $query = "
        SELECT
            e.id as user_id,
            e.employee_code,
            CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as full_name,
            e.official_email,
            e.mobile_number,
            e.employment_status,
            e.date_of_joining,
            " . scDeptName('d') . " as department,
            " . scDesigName('dg') . " as designation,
            GROUP_CONCAT(DISTINCT r.role_name ORDER BY r.role_level SEPARATOR ', ') as roles,
            GROUP_CONCAT(DISTINCT r.role_level ORDER BY r.role_level SEPARATOR ',') as role_levels,
            e.photograph_file,
            MAX(ur.assigned_at) as roles_assigned_at
        FROM employees e
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN designations dg ON e.designation_id = dg.id
        LEFT JOIN user_roles ur ON e.id = ur.employee_id AND ur.status = 'Active'
        LEFT JOIN roles r ON ur.role_id = r.id
        WHERE 1=1
    ";

    $params = [];

    if ($status !== '') {
        $query .= " AND e.employment_status = ?";
        $params[] = $status;
    }

    if ($search !== '') {
        $query .= " AND (e.first_name LIKE ? OR e.last_name LIKE ? OR e.employee_code LIKE ? OR e.official_email LIKE ? OR e.mobile_number LIKE ?)";
        $term = "%$search%";
        $params = array_merge($params, [$term, $term, $term, $term, $term]);
    }

    if ($department !== '') {
        $query .= " AND " . scDeptName('d') . " = ?";
        $params[] = $department;
    }

    if ($role !== '') {
        $query .= " AND r.role_name = ?";
        $params[] = $role;
    }

    $query .= " GROUP BY e.id ORDER BY e.first_name, e.last_name";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $users = $stmt->fetchAll();

    foreach ($users as &$row) {
        $levels = array_filter(explode(',', $row['role_levels'] ?? ''));
        $row['role_levels_parsed'] = array_values($levels);
        $row['authority_level'] = $levels ? min(array_map('intval', $levels)) : null;
    }
    unset($row);

    echo json_encode(['success' => true, 'data' => $users, 'count' => count($users)]);
}

function getUserDetail($userId) {
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT
            e.id as user_id,
            e.employee_code,
            CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as full_name,
            e.first_name,
            e.last_name,
            e.official_email,
            e.mobile_number,
            e.employment_status,
            e.date_of_joining,
            " . scDeptName('d') . " as department,
            d.id as department_id,
            " . scDesigName('dg') . " as designation,
            dg.id as designation_id,
            e.reporting_manager_id,
            CONCAT(rm.first_name, ' ', COALESCE(rm.last_name, '')) as reporting_manager_name,
            e.photograph_file
        FROM employees e
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN designations dg ON e.designation_id = dg.id
        LEFT JOIN employees rm ON e.reporting_manager_id = rm.id
        WHERE e.id = ?
    ");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        return;
    }

    $rolesStmt = $pdo->prepare("
        SELECT ur.id, r.id as role_id, r.role_name, r.role_level, ur.assigned_at, ur.status
        FROM user_roles ur
        JOIN roles r ON ur.role_id = r.id
        WHERE ur.employee_id = ? AND ur.status = 'Active'
        ORDER BY r.role_level
    ");
    $rolesStmt->execute([$userId]);
    $user['roles'] = $rolesStmt->fetchAll();

    $permStmt = $pdo->prepare("
        SELECT DISTINCT
            p.id, p.permission_name, p.action_type, p.description,
            m.module_name, m.module_icon,
            rp.data_scope
        FROM user_roles ur
        JOIN role_permissions rp ON ur.role_id = rp.role_id AND rp.status = 'Active'
        JOIN permissions p ON rp.permission_id = p.id AND p.status = 'Active'
        JOIN modules m ON p.module_id = m.id
        WHERE ur.employee_id = ? AND ur.status = 'Active'
        ORDER BY m.module_name, p.permission_name
    ");
    $permStmt->execute([$userId]);
    $perms = $permStmt->fetchAll();
    $user['permissions'] = $perms;

    $byModule = [];
    foreach ($perms as $p) {
        $mod = $p['module_name'];
        if (!isset($byModule[$mod])) $byModule[$mod] = [];
        $byModule[$mod][] = $p;
    }
    $user['permissions_by_module'] = $byModule;

    echo json_encode(['success' => true, 'data' => $user]);
}

function assignRoleToUser() {
    global $pdo;

    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $employeeId = isset($input['employee_id']) ? (int)$input['employee_id'] : 0;
    $roleId = isset($input['role_id']) ? (int)$input['role_id'] : 0;
    $assignedBy = $_SESSION['user_id'] ?? null;

    if (!$employeeId || !$roleId) {
        echo json_encode(['success' => false, 'message' => 'Employee and Role are required']);
        return;
    }

    $emp = $pdo->prepare("SELECT id FROM employees WHERE id = ?");
    $emp->execute([$employeeId]);
    if (!$emp->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Employee not found in HRMS']);
        return;
    }

    $role = $pdo->prepare("SELECT id FROM roles WHERE id = ? AND status = 'Active'");
    $role->execute([$roleId]);
    if (!$role->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Role not found']);
        return;
    }
    acc_guard_privileged_role($pdo, $roleId);   // only admins may hand out Admin-level roles

    $check = $pdo->prepare("SELECT id, status FROM user_roles WHERE employee_id = ? AND role_id = ?");
    $check->execute([$employeeId, $roleId]);
    $existing = $check->fetch();
    if ($existing) {
        $pdo->prepare("UPDATE user_roles SET status = 'Active', assigned_by = ?, assigned_at = NOW() WHERE employee_id = ? AND role_id = ?")
            ->execute([$assignedBy, $employeeId, $roleId]);
        echo json_encode(['success' => true, 'message' => 'Role assigned successfully']);
        return;
    }

    $stmt = $pdo->prepare("
        INSERT INTO user_roles (employee_id, role_id, assigned_by, status)
        VALUES (?, ?, ?, 'Active')
    ");
    $stmt->execute([$employeeId, $roleId, $assignedBy]);
    echo json_encode(['success' => true, 'message' => 'Role assigned successfully']);
}

function removeRoleFromUser() {
    global $pdo;

    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $userRoleId = isset($input['user_role_id']) ? (int)$input['user_role_id'] : 0;

    if (!$userRoleId) {
        echo json_encode(['success' => false, 'message' => 'User Role ID is required']);
        return;
    }

    $lookup = $pdo->prepare("SELECT role_id FROM user_roles WHERE id = ?");
    $lookup->execute([$userRoleId]);
    $existingRoleId = $lookup->fetchColumn();
    if ($existingRoleId) acc_guard_privileged_role($pdo, (int)$existingRoleId);

    $stmt = $pdo->prepare("DELETE FROM user_roles WHERE id = ?");
    $stmt->execute([$userRoleId]);
    echo json_encode(['success' => true, 'message' => 'Role removed successfully']);
}

function syncEmployeesWithUsers() {
    global $pdo;

    $empCheck = $pdo->query("SHOW TABLES LIKE 'employees'")->fetch();
    if (!$empCheck) {
        echo json_encode(['success' => false, 'error' => 'Employees table not found']);
        return;
    }

    $summary = $pdo->query("
        SELECT
            (SELECT COUNT(*) FROM employees WHERE employment_status = 'Active') as total_employees,
            (SELECT COUNT(DISTINCT employee_id) FROM user_roles WHERE status = 'Active') as users_with_roles,
            (SELECT COUNT(*) FROM roles WHERE status = 'Active') as total_roles
    ")->fetch();

    echo json_encode([
        'success' => true,
        'message' => 'Employees are the source of users. Assign roles from the Users page.',
        'summary' => $summary
    ]);
}
