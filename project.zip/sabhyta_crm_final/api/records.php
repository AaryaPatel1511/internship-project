<?php
/**
 * Generic Records API — powers every sidebar leaf item that
 * isn't Customers (which has its own dedicated api/customers.php).
 * --------------------------------------------------------
 * GET    /api/records.php?module=KEY            -> list records for that module
 * GET    /api/records.php?module=KEY&id=5        -> get one record
 * POST   /api/records.php                        -> create (module_key, module_label, ...)
 * POST   /api/records.php   (id + _method=PUT)   -> update
 * DELETE /api/records.php?id=5                   -> delete
 * --------------------------------------------------------
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

if ($method === 'GET') {
    // Aggregate stats for an overview page.
    //   GET /api/records.php?stats=1&prefix=crm       -> every module_key starting with "crm__"
    //   GET /api/records.php?stats=1&keys=crm__leads,crm__add-lead  -> just those exact module_keys
    // "keys" is what the sidebar overview pages use, since it can scope
    // the totals to exactly the cards shown on screen (a sub-heading's
    // leaves), not every module under the whole top-level section.
    if (!empty($_GET['stats'])) {
        if (!empty($_GET['keys'])) {
            $keys = array_filter(array_map('trim', explode(',', $_GET['keys'])));
            if (!$keys) $keys = ['__none__'];
            $placeholders = implode(', ', array_fill(0, count($keys), '?'));
            $where = "module_key IN ($placeholders)";
            $params = $keys;
        } else {
            $where = "module_key LIKE ?";
            $params = [isset($_GET['prefix']) ? $_GET['prefix'] . '__%' : '%'];
        }

        $stmt = $pdo->prepare("SELECT COUNT(*) AS total,
                                       SUM(status = 'Active') AS active,
                                       SUM(status = 'Pending') AS pending,
                                       SUM(status = 'Completed') AS completed,
                                       COALESCE(SUM(amount), 0) AS amount_sum,
                                       SUM(MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())) AS this_month
                                FROM generic_records WHERE $where");
        $stmt->execute($params);
        $totals = $stmt->fetch();

        $stmt2 = $pdo->prepare("SELECT module_key, COUNT(*) AS cnt
                                 FROM generic_records WHERE $where
                                 GROUP BY module_key");
        $stmt2->execute($params);
        $byModule = [];
        foreach ($stmt2->fetchAll() as $row) {
            $byModule[$row['module_key']] = (int) $row['cnt'];
        }

        respond(["success" => true, "data" => [
            "total"      => (int) ($totals['total'] ?? 0),
            "active"     => (int) ($totals['active'] ?? 0),
            "pending"    => (int) ($totals['pending'] ?? 0),
            "completed"  => (int) ($totals['completed'] ?? 0),
            "amount_sum" => (float) ($totals['amount_sum'] ?? 0),
            "this_month" => (int) ($totals['this_month'] ?? 0),
            "by_module"  => $byModule,
        ]]);
    }

    if (!empty($_GET['id'])) {
        $stmt = $pdo->prepare("SELECT * FROM generic_records WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        $row = $stmt->fetch();
        if (!$row) respond(["success" => false, "message" => "Record not found"], 404);
        respond(["success" => true, "data" => $row]);
    }

    if (empty($_GET['module'])) respond(["success" => false, "message" => "Missing module"], 422);

    $stmt = $pdo->prepare("SELECT * FROM generic_records WHERE module_key = ? ORDER BY created_at DESC");
    $stmt->execute([$_GET['module']]);
    respond(["success" => true, "data" => $stmt->fetchAll()]);
}

if ($method === 'POST') {
    $isUpdate = !empty($_POST['id']) && (($_POST['_method'] ?? '') === 'PUT');

    foreach (['module_key', 'module_label', 'title'] as $required) {
        if (empty($_POST[$required])) {
            respond(["success" => false, "message" => "Missing required field: $required"], 422);
        }
    }

    $data = [
        'module_key'   => $_POST['module_key'],
        'module_label' => $_POST['module_label'],
        'title'        => $_POST['title'],
        'party_name'   => $_POST['party_name'] ?: null,
        'assigned_to'  => $_POST['assigned_to'] ?: null,
        'record_date'  => $_POST['record_date'] ?: null,
        'amount'       => $_POST['amount'] !== '' ? $_POST['amount'] : null,
        'status'       => $_POST['status'] ?: 'Active',
        'notes'        => $_POST['notes'] ?: null,
        // Structured JSON blob for modules that need more than the
        // flat columns above (e.g. Create Quote's line items and
        // financial summary). Optional — only set when sent.
        'extra_data'   => isset($_POST['extra_data']) && $_POST['extra_data'] !== '' ? $_POST['extra_data'] : null,
    ];

    try {
        if ($isUpdate) {
            $id = $_POST['id'];
            $setSql = implode(', ', array_map(fn($c) => "$c = :$c", array_keys($data)));
            $stmt = $pdo->prepare("UPDATE generic_records SET $setSql WHERE id = :id");
            $data['id'] = $id;
            $stmt->execute($data);
            respond(["success" => true, "message" => "Record updated", "id" => $id]);
        } else {
            $cols = implode(', ', array_keys($data));
            $placeholders = implode(', ', array_map(fn($c) => ":$c", array_keys($data)));
            $stmt = $pdo->prepare("INSERT INTO generic_records ($cols) VALUES ($placeholders)");
            $stmt->execute($data);
            respond(["success" => true, "message" => "Record created", "id" => $pdo->lastInsertId()], 201);
        }
    } catch (PDOException $e) {
        respond(["success" => false, "message" => "Database error: " . $e->getMessage()], 400);
    }
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? null;
    if (!$id) respond(["success" => false, "message" => "Missing id"], 422);
    $stmt = $pdo->prepare("DELETE FROM generic_records WHERE id = ?");
    $stmt->execute([$id]);
    respond(["success" => true, "message" => "Record deleted"]);
}

respond(["success" => false, "message" => "Method not allowed"], 405);
