<?php
/**
 * Reports API — powers every leaf under the "Reports" sidebar section
 * (CRM / Sales / Customer / Employee / Attendance / Payroll / Project /
 * Inventory / Financial / Support / Productivity / Custom Reports).
 *
 * Every report is computed live from the SAME tables the rest of the
 * app already writes to (leads, customers, employees, sales_orders,
 * generic_records, account_groups) — nothing here is mock data. Modules
 * that don't have a dedicated table yet (Attendance, Projects,
 * Inventory, Financial extras, Support/Helpdesk) read from
 * generic_records, scoped by the exact module_key the rest of the app
 * already saves under (see moduleKeyFor() in script.js), so a report
 * only shows numbers once the matching module has real entries.
 *
 * --------------------------------------------------------
 * GET /api/reports.php?type=filters                          -> dropdown option lists for the filter bar
 * GET /api/reports.php?type=crm|sales|customer|employee|
 *                            attendance|payroll|project|
 *                            inventory|financial|support|
 *                            productivity
 *                      &date_from=&date_to=&department=&employee=
 *                      &customer=&status=&city=&state=&source=&branch=&q=
 *                                                              -> cards + charts + table for that report
 * GET /api/reports.php?type=custom&source=...&columns[]=...   -> ad-hoc report builder
 * --------------------------------------------------------
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

$type = $_GET['type'] ?? '';

/* =========================================================
   Small SQL helpers — every report builds its WHERE clause
   from these so filters behave identically everywhere.
   ========================================================= */
function w_date($col) {
    $w = []; $p = [];
    if (!empty($_GET['date_from'])) { $w[] = "$col >= ?"; $p[] = $_GET['date_from'] . ' 00:00:00'; }
    if (!empty($_GET['date_to']))   { $w[] = "$col <= ?"; $p[] = $_GET['date_to']   . ' 23:59:59'; }
    return [$w, $p];
}
function w_eq($col, $key) {
    if (empty($_GET[$key])) return [[], []];
    return [["$col = ?"], [$_GET[$key]]];
}
function w_like($col, $key) {
    if (empty($_GET[$key])) return [[], []];
    return [["$col LIKE ?"], ['%' . $_GET[$key] . '%']];
}
function w_add(&$where, &$params, $pair) {
    $where  = array_merge($where, $pair[0]);
    $params = array_merge($params, $pair[1]);
}
function w_sql($where) {
    return $where ? ('WHERE ' . implode(' AND ', $where)) : '';
}
function pct($cur, $prev) {
    $cur = (float) $cur; $prev = (float) $prev;
    if ($prev == 0) return $cur > 0 ? 100 : 0;
    return round((($cur - $prev) / $prev) * 100, 1);
}
function card($label, $value, $accent = '#2563eb', $icon = 'fa-chart-simple') {
    return ['label' => $label, 'value' => $value, 'accent' => $accent, 'icon' => $icon];
}

/* Generic "Total / Today / This Month / Last Month / Growth%" block,
   required on every report per spec — reused by every report type
   below against its own table + date column + (optional) WHERE. */
function generalCards($pdo, $table, $dateCol, $where, $params) {
    $baseWhere = $where ? implode(' AND ', $where) . ' AND ' : '';

    $total = (int) scalar($pdo, "SELECT COUNT(*) FROM $table " . w_sql($where), $params);

    $todayW = $where; $todayP = $params;
    $todayW[] = "DATE($dateCol) = CURDATE()";
    $today = (int) scalar($pdo, "SELECT COUNT(*) FROM $table " . w_sql($todayW), $todayP);

    $thisMonW = $where; $thisMonP = $params;
    $thisMonW[] = "MONTH($dateCol) = MONTH(CURDATE()) AND YEAR($dateCol) = YEAR(CURDATE())";
    $thisMonth = (int) scalar($pdo, "SELECT COUNT(*) FROM $table " . w_sql($thisMonW), $thisMonP);

    $lastMonW = $where; $lastMonP = $params;
    $lastMonW[] = "MONTH($dateCol) = MONTH(CURDATE() - INTERVAL 1 MONTH) AND YEAR($dateCol) = YEAR(CURDATE() - INTERVAL 1 MONTH)";
    $lastMonth = (int) scalar($pdo, "SELECT COUNT(*) FROM $table " . w_sql($lastMonW), $lastMonP);

    return [
        'total'      => $total,
        'today'      => $today,
        'this_month' => $thisMonth,
        'last_month' => $lastMonth,
        'growth_pct' => pct($thisMonth, $lastMonth),
    ];
}
function scalar($pdo, $sql, $params = []) {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchColumn();
}
function rows($pdo, $sql, $params = []) {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}
/* Monthly trend (last 6 months, zero-filled) for any table/date col/where */
function monthlyTrend($pdo, $table, $dateCol, $where, $params, $valueExpr = 'COUNT(*)') {
    $months = [];
    for ($i = 5; $i >= 0; $i--) {
        $ym = date('Y-m', strtotime("-$i months"));
        $months[$ym] = ['label' => date('M', strtotime("-$i months")), 'value' => 0];
    }
    $w = $where; $p = $params;
    $w[] = "$dateCol >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)";
    $sql = "SELECT DATE_FORMAT($dateCol,'%Y-%m') ym, $valueExpr val FROM $table " . w_sql($w) . " GROUP BY ym";
    foreach (rows($pdo, $sql, $p) as $r) {
        if (isset($months[$r['ym']])) $months[$r['ym']]['value'] = (float) $r['val'];
    }
    return array_values($months);
}
function groupBreakdown($pdo, $table, $groupCol, $where, $params, $limit = 8) {
    $w = $where;
    $w[] = "$groupCol IS NOT NULL AND $groupCol <> ''";
    $sql = "SELECT $groupCol AS label, COUNT(*) AS cnt FROM $table " . w_sql($w) .
           " GROUP BY $groupCol ORDER BY cnt DESC LIMIT $limit";
    return rows($pdo, $sql, $params);
}
function money($n) { return '₹' . number_format((float) $n, 0); }

/* =========================================================
   CUSTOM REPORT BUILDER — whitelisted sources/columns only,
   so the ad-hoc query stays SQL-injection safe.
   ========================================================= */
$CUSTOM_SOURCES = [
    'leads' => [
        'label' => 'Leads', 'table' => 'leads', 'date_col' => 'lead_date',
        'search_cols' => ['customer_name', 'mobile', 'lead_code'],
        'columns' => [
            'lead_code' => 'lead_code', 'customer_name' => 'customer_name', 'mobile' => 'mobile',
            'email' => 'email', 'city' => 'city', 'state' => 'state', 'lead_source' => 'lead_source',
            'sales_executive' => 'sales_executive', 'branch' => 'branch', 'status' => 'status',
            'priority' => 'priority', 'lead_date' => 'lead_date',
        ],
        'columns_labels' => [
            'lead_code' => 'Lead Code', 'customer_name' => 'Customer', 'mobile' => 'Mobile',
            'email' => 'Email', 'city' => 'City', 'state' => 'State', 'lead_source' => 'Source',
            'sales_executive' => 'Executive', 'branch' => 'Branch', 'status' => 'Status',
            'priority' => 'Priority', 'lead_date' => 'Date',
        ],
    ],
    'customers' => [
        'label' => 'Customers', 'table' => 'customers', 'date_col' => 'created_at',
        'search_cols' => ['customer_name', 'company_name', 'mobile'],
        'columns' => [
            'customer_code' => 'customer_code', 'customer_name' => 'customer_name', 'company_name' => 'company_name',
            'city' => 'city', 'state' => 'state', 'customer_type' => 'customer_type', 'industry' => 'industry',
            'email' => 'email', 'mobile' => 'mobile', 'status' => 'status', 'created_at' => 'created_at',
        ],
        'columns_labels' => [
            'customer_code' => 'Code', 'customer_name' => 'Name', 'company_name' => 'Company',
            'city' => 'City', 'state' => 'State', 'customer_type' => 'Type', 'industry' => 'Industry',
            'email' => 'Email', 'mobile' => 'Mobile', 'status' => 'Status', 'created_at' => 'Since',
        ],
    ],
    'employees' => [
        'label' => 'Employees', 'table' => 'employees e LEFT JOIN departments d ON d.id=e.department_id LEFT JOIN designations de ON de.id=e.designation_id',
        'date_col' => 'e.date_of_joining',
        'search_cols' => ['e.first_name', 'e.employee_code', 'e.mobile_number'],
        'columns' => [
            'employee_code' => 'e.employee_code', 'name' => "TRIM(CONCAT(e.first_name,' ',COALESCE(e.last_name,'')))",
            'department_name' => 'd.department_name', 'designation_name' => 'de.designation_name',
            'city' => 'e.city', 'state' => 'e.state', 'branch' => 'e.branch', 'mobile_number' => 'e.mobile_number',
            'date_of_joining' => 'e.date_of_joining', 'status' => 'e.employment_status',
            'gross_salary' => 'e.gross_salary', 'net_salary' => 'e.net_salary',
        ],
        'columns_labels' => [
            'employee_code' => 'Code', 'name' => 'Name', 'department_name' => 'Department',
            'designation_name' => 'Designation', 'city' => 'City', 'state' => 'State', 'branch' => 'Branch',
            'mobile_number' => 'Mobile', 'date_of_joining' => 'Joining Date', 'status' => 'Status',
            'gross_salary' => 'Gross Salary', 'net_salary' => 'Net Salary',
        ],
    ],
    'sales_orders' => [
        'label' => 'Sales Orders', 'table' => 'sales_orders so LEFT JOIN customers c ON c.id=so.customer_id',
        'date_col' => 'so.order_date',
        'search_cols' => ['so.sales_order_number', 'so.project_name'],
        'columns' => [
            'sales_order_number' => 'so.sales_order_number', 'order_date' => 'so.order_date',
            'customer_name' => 'c.customer_name', 'project_name' => 'so.project_name',
            'branch' => 'so.branch', 'order_status' => 'so.order_status', 'grand_total' => 'so.grand_total',
        ],
        'columns_labels' => [
            'sales_order_number' => 'Order #', 'order_date' => 'Date', 'customer_name' => 'Customer',
            'project_name' => 'Project', 'branch' => 'Branch', 'order_status' => 'Status', 'grand_total' => 'Amount',
        ],
    ],
    'generic' => [
        'label' => 'Any Module (generic records)', 'table' => 'generic_records', 'date_col' => 'created_at',
        'search_cols' => ['title', 'party_name', 'assigned_to'],
        'columns' => [
            'module_label' => 'module_label', 'title' => 'title', 'party_name' => 'party_name',
            'assigned_to' => 'assigned_to', 'record_date' => 'record_date', 'amount' => 'amount',
            'status' => 'status', 'created_at' => 'created_at',
        ],
        'columns_labels' => [
            'module_label' => 'Module', 'title' => 'Title', 'party_name' => 'Party', 'assigned_to' => 'Assigned To',
            'record_date' => 'Date', 'amount' => 'Amount', 'status' => 'Status', 'created_at' => 'Created',
        ],
    ],
];
// If a generic module_key is requested, scope the "generic" source to it.
if (($_GET['type'] ?? '') === 'custom' && ($_GET['source'] ?? '') === 'generic' && !empty($_GET['module_key'])) {
    $mk = $_GET['module_key'];
    $CUSTOM_SOURCES['generic']['fixed_where'] = "module_key = " . $pdo->quote($mk);
}
$CUSTOM_SOURCES_META = array_map(fn($k, $v) => [
    'key' => $k, 'label' => $v['label'],
    'columns' => array_map(fn($ck, $cl) => ['key' => $ck, 'label' => $cl], array_keys($v['columns_labels']), array_values($v['columns_labels'])),
], array_keys($CUSTOM_SOURCES), array_values($CUSTOM_SOURCES));

/* =========================================================
   FILTERS META — populates every dropdown in the filter bar
   ========================================================= */
if ($type === 'filters') {
    $departments = rows($pdo, "SELECT id, department_name AS name FROM departments WHERE status='Active' ORDER BY department_name");
    $designations = rows($pdo, "SELECT id, designation_name AS name FROM designations WHERE status='Active' ORDER BY designation_name");
    $employees = rows($pdo, "SELECT id, TRIM(CONCAT(first_name,' ',COALESCE(last_name,''))) AS name FROM employees ORDER BY first_name");
    $customers = rows($pdo, "SELECT id, customer_name AS name FROM customers ORDER BY customer_name LIMIT 500");
    $states = rows($pdo, "SELECT DISTINCT state FROM (
                             SELECT state FROM leads WHERE state IS NOT NULL AND state<>''
                             UNION SELECT state FROM customers WHERE state IS NOT NULL AND state<>''
                             UNION SELECT state FROM employees WHERE state IS NOT NULL AND state<>''
                           ) x ORDER BY state");
    $cities = rows($pdo, "SELECT DISTINCT city FROM (
                             SELECT city FROM leads WHERE city IS NOT NULL AND city<>''
                             UNION SELECT city FROM customers WHERE city IS NOT NULL AND city<>''
                             UNION SELECT city FROM employees WHERE city IS NOT NULL AND city<>''
                           ) x ORDER BY city");
    $sources = rows($pdo, "SELECT DISTINCT lead_source AS source FROM leads WHERE lead_source IS NOT NULL AND lead_source<>'' ORDER BY lead_source");
    $branches = rows($pdo, "SELECT DISTINCT branch FROM (
                             SELECT branch FROM leads WHERE branch IS NOT NULL AND branch<>''
                             UNION SELECT branch FROM employees WHERE branch IS NOT NULL AND branch<>''
                           ) x ORDER BY branch");
    $customerTypes = rows($pdo, "SELECT DISTINCT customer_type AS v FROM customers WHERE customer_type IS NOT NULL AND customer_type<>'' ORDER BY customer_type");
    $industries = rows($pdo, "SELECT DISTINCT industry AS v FROM customers WHERE industry IS NOT NULL AND industry<>'' ORDER BY industry");
    $leadStatuses = rows($pdo, "SELECT DISTINCT status AS v FROM leads WHERE status IS NOT NULL AND status<>'' ORDER BY status");
    $orderStatuses = rows($pdo, "SELECT DISTINCT order_status AS v FROM sales_orders WHERE order_status IS NOT NULL AND order_status<>'' ORDER BY order_status");

    respond(['success' => true, 'data' => [
        'departments'  => $departments,
        'designations' => $designations,
        'employees'    => $employees,
        'customers'    => $customers,
        'states'       => array_map(fn($r) => $r['state'], $states),
        'cities'       => array_map(fn($r) => $r['city'], $cities),
        'sources'      => array_map(fn($r) => $r['source'], $sources),
        'branches'     => array_map(fn($r) => $r['branch'], $branches),
        'customer_types' => array_map(fn($r) => $r['v'], $customerTypes),
        'industries'   => array_map(fn($r) => $r['v'], $industries),
        'lead_statuses'  => array_map(fn($r) => $r['v'], $leadStatuses),
        'order_statuses' => array_map(fn($r) => $r['v'], $orderStatuses),
    ]]);
}

/* =========================================================
   1. CRM REPORTS  — leads + lead_followups
   ========================================================= */
if ($type === 'crm') {
    $where = []; $params = [];
    w_add($where, $params, w_date('lead_date'));
    w_add($where, $params, w_eq('status', 'status'));
    w_add($where, $params, w_eq('lead_source', 'source'));
    w_add($where, $params, w_eq('city', 'city'));
    w_add($where, $params, w_eq('state', 'state'));
    w_add($where, $params, w_eq('branch', 'branch'));
    w_add($where, $params, w_like('sales_executive', 'employee'));
    if (!empty($_GET['q'])) { $where[] = "(customer_name LIKE ? OR mobile LIKE ? OR lead_code LIKE ?)"; $q = '%' . $_GET['q'] . '%'; array_push($params, $q, $q, $q); }

    $gc = generalCards($pdo, 'leads', 'lead_date', $where, $params);

    $converted = (int) scalar($pdo, "SELECT COUNT(*) FROM leads " . w_sql(array_merge($where, ["status = 'Converted'"])), $params);
    $lost      = (int) scalar($pdo, "SELECT COUNT(*) FROM leads " . w_sql(array_merge($where, ["status = 'Lost'"])), $params);
    $pendingFU = (int) scalar($pdo, "SELECT COUNT(*) FROM leads " . w_sql(array_merge($where, ["status NOT IN ('Converted','Lost') AND next_followup_date IS NOT NULL AND next_followup_date <= CURDATE()"])), $params);
    $qualified = (int) scalar($pdo, "SELECT COUNT(*) FROM leads " . w_sql(array_merge($where, ["status IN ('Interested','Test Drive','Quotation Sent','Finance','Booking')"])), $params);
    $conversionRate = $gc['total'] > 0 ? round(($converted / $gc['total']) * 100, 1) : 0;

    // Average response time = avg hours between lead_date and its first follow-up
    $avgResp = scalar($pdo, "SELECT AVG(TIMESTAMPDIFF(HOUR, l.lead_date, f.first_fu))
        FROM leads l JOIN (SELECT lead_id, MIN(created_at) first_fu FROM lead_followups GROUP BY lead_id) f ON f.lead_id = l.id");
    $avgResp = $avgResp !== null ? round((float) $avgResp, 1) : 0;

    $byStatus   = groupBreakdown($pdo, 'leads', 'status', $where, $params);
    $bySource   = groupBreakdown($pdo, 'leads', 'lead_source', $where, $params);
    $byExec     = groupBreakdown($pdo, 'leads', 'sales_executive', $where, $params);
    $byState    = groupBreakdown($pdo, 'leads', 'state', $where, $params);
    $byCity     = groupBreakdown($pdo, 'leads', 'city', $where, $params);

    $trend = monthlyTrend($pdo, 'leads', 'lead_date', $where, $params);

    $tableRows = rows($pdo, "SELECT lead_code, customer_name, mobile, lead_source, city, state, sales_executive, status, lead_date
                              FROM leads " . w_sql($where) . " ORDER BY lead_date DESC LIMIT 500", $params);

    respond(['success' => true, 'data' => [
        'cards' => [
            card('Total Leads', $gc['total'], '#ff6b4a', 'fa-user-plus'),
            card('Today Leads', $gc['today'], '#2563eb', 'fa-calendar-day'),
            card('This Month', $gc['this_month'], '#7c5cff', 'fa-calendar'),
            card('Last Month', $gc['last_month'], '#8f97a8', 'fa-calendar-minus'),
            card('Growth %', $gc['growth_pct'] . '%', $gc['growth_pct'] >= 0 ? '#16a34a' : '#e0384c', 'fa-arrow-trend-up'),
            card('Qualified Leads', $qualified, '#e08c1c', 'fa-star'),
            card('Converted', $converted, '#16a34a', 'fa-circle-check'),
            card('Lost', $lost, '#e0384c', 'fa-circle-xmark'),
            card('Follow-up Pending', $pendingFU, '#e08c1c', 'fa-clock'),
            card('Conversion Rate', $conversionRate . '%', '#14b8a6', 'fa-bullseye'),
            card('Avg Response Time (hrs)', $avgResp, '#2563eb', 'fa-stopwatch'),
        ],
        'charts' => [
            'pie'  => ['title' => 'Leads by Status', 'labels' => array_column($byStatus, 'label'), 'data' => array_map('intval', array_column($byStatus, 'cnt'))],
            'bar'  => ['title' => 'Lead Source Report', 'labels' => array_column($bySource, 'label'), 'data' => array_map('intval', array_column($bySource, 'cnt'))],
            'line' => ['title' => 'Leads Trend (6 months)', 'labels' => array_column($trend, 'label'), 'data' => array_column($trend, 'value')],
        ],
        'breakdowns' => [
            'employee_wise' => $byExec,
            'state_wise'    => $byState,
            'city_wise'     => $byCity,
        ],
        'table' => [
            'columns' => [
                ['key' => 'lead_code', 'label' => 'Lead Code'],
                ['key' => 'customer_name', 'label' => 'Customer'],
                ['key' => 'mobile', 'label' => 'Mobile'],
                ['key' => 'lead_source', 'label' => 'Source'],
                ['key' => 'city', 'label' => 'City'],
                ['key' => 'state', 'label' => 'State'],
                ['key' => 'sales_executive', 'label' => 'Executive'],
                ['key' => 'status', 'label' => 'Status'],
                ['key' => 'lead_date', 'label' => 'Date'],
            ],
            'rows' => $tableRows,
        ],
    ]]);
}

/* =========================================================
   2. SALES REPORTS — sales_orders + generic_records (sales__*)
   ========================================================= */
if ($type === 'sales') {
    $where = []; $params = [];
    w_add($where, $params, w_date('order_date'));
    w_add($where, $params, w_eq('order_status', 'status'));
    w_add($where, $params, w_eq('branch', 'branch'));
    w_add($where, $params, w_eq('sales_executive_id', 'employee'));
    w_add($where, $params, w_eq('customer_id', 'customer'));
    if (!empty($_GET['q'])) { $where[] = "(sales_order_number LIKE ? OR project_name LIKE ?)"; $q = '%' . $_GET['q'] . '%'; array_push($params, $q, $q); }

    $gc = generalCards($pdo, 'sales_orders', 'order_date', $where, $params);
    $totalAmount = (float) scalar($pdo, "SELECT COALESCE(SUM(grand_total),0) FROM sales_orders " . w_sql($where), $params);
    $confirmed = (int) scalar($pdo, "SELECT COUNT(*) FROM sales_orders " . w_sql(array_merge($where, ["order_status = 'Confirmed'"])), $params);
    $closed    = (int) scalar($pdo, "SELECT COUNT(*) FROM sales_orders " . w_sql(array_merge($where, ["order_status = 'Closed'"])), $params);
    $pending   = (int) scalar($pdo, "SELECT COUNT(*) FROM sales_orders " . w_sql(array_merge($where, ["order_status = 'Pending'"])), $params);

    $invCount = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records WHERE module_key IN ('sales__proforma-invoice','sales__invoice')");
    $recSum   = (float) scalar($pdo, "SELECT COALESCE(SUM(amount),0) FROM generic_records WHERE module_key = 'sales__receipt'");
    $payCount = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records WHERE module_key = 'sales__payment'");
    $outstanding = max($totalAmount - $recSum, 0);

    $byStatus = groupBreakdown($pdo, 'sales_orders', 'order_status', $where, $params);
    $trend = monthlyTrend($pdo, 'sales_orders', 'order_date', $where, $params, 'COALESCE(SUM(grand_total),0)');
    $byBranch = groupBreakdown($pdo, 'sales_orders', 'branch', $where, $params);

    $tableRows = rows($pdo, "SELECT so.sales_order_number, so.order_date, c.customer_name, so.project_name, so.order_status, so.grand_total
                              FROM sales_orders so LEFT JOIN customers c ON c.id = so.customer_id
                              " . w_sql($where) . " ORDER BY so.order_date DESC LIMIT 500", $params);

    respond(['success' => true, 'data' => [
        'cards' => [
            card('Total Sales Orders', $gc['total'], '#ff6b4a', 'fa-file-invoice'),
            card('Today\'s Sales', $gc['today'], '#2563eb', 'fa-calendar-day'),
            card('This Month', $gc['this_month'], '#7c5cff', 'fa-calendar'),
            card('Last Month', $gc['last_month'], '#8f97a8', 'fa-calendar-minus'),
            card('Growth %', $gc['growth_pct'] . '%', $gc['growth_pct'] >= 0 ? '#16a34a' : '#e0384c', 'fa-arrow-trend-up'),
            card('Total Sales Amount', money($totalAmount), '#16a34a', 'fa-indian-rupee-sign'),
            card('Confirmed Orders', $confirmed, '#14b8a6', 'fa-circle-check'),
            card('Pending Orders', $pending, '#e08c1c', 'fa-hourglass-half'),
            card('Closed Orders', $closed, '#7c5cff', 'fa-box-archive'),
            card('Collection (Receipts)', money($recSum), '#16a34a', 'fa-money-bill-wave'),
            card('Outstanding', money($outstanding), '#e0384c', 'fa-triangle-exclamation'),
            card('Invoices Raised', $invCount, '#2563eb', 'fa-file-invoice-dollar'),
            card('Payment Entries', $payCount, '#e08c1c', 'fa-credit-card'),
        ],
        'charts' => [
            'pie'  => ['title' => 'Orders by Status', 'labels' => array_column($byStatus, 'label'), 'data' => array_map('intval', array_column($byStatus, 'cnt'))],
            'bar'  => ['title' => 'Sales by Branch', 'labels' => array_column($byBranch, 'label'), 'data' => array_map('intval', array_column($byBranch, 'cnt'))],
            'line' => ['title' => 'Sales Amount Trend (6 months)', 'labels' => array_column($trend, 'label'), 'data' => array_column($trend, 'value')],
        ],
        'table' => [
            'columns' => [
                ['key' => 'sales_order_number', 'label' => 'Order #'],
                ['key' => 'order_date', 'label' => 'Date'],
                ['key' => 'customer_name', 'label' => 'Customer'],
                ['key' => 'project_name', 'label' => 'Project'],
                ['key' => 'order_status', 'label' => 'Status'],
                ['key' => 'grand_total', 'label' => 'Amount', 'money' => true],
            ],
            'rows' => $tableRows,
        ],
    ]]);
}

/* =========================================================
   3. CUSTOMER REPORTS — customers
   ========================================================= */
if ($type === 'customer') {
    $where = []; $params = [];
    w_add($where, $params, w_date('created_at'));
    w_add($where, $params, w_eq('status', 'status'));
    w_add($where, $params, w_eq('city', 'city'));
    w_add($where, $params, w_eq('state', 'state'));
    w_add($where, $params, w_eq('customer_type', 'customer_type'));
    w_add($where, $params, w_eq('industry', 'industry'));
    if (!empty($_GET['q'])) { $where[] = "(customer_name LIKE ? OR company_name LIKE ? OR mobile LIKE ?)"; $q = '%' . $_GET['q'] . '%'; array_push($params, $q, $q, $q); }

    $gc = generalCards($pdo, 'customers', 'created_at', $where, $params);
    $active   = (int) scalar($pdo, "SELECT COUNT(*) FROM customers " . w_sql(array_merge($where, ["status = 'Active'"])), $params);
    $inactive = (int) scalar($pdo, "SELECT COUNT(*) FROM customers " . w_sql(array_merge($where, ["status <> 'Active'"])), $params);
    $repeat   = (int) scalar($pdo, "SELECT COUNT(DISTINCT c.id) FROM customers c JOIN sales_orders so ON so.customer_id = c.id
                                     GROUP BY c.id HAVING COUNT(so.id) > 1") ?: 0;
    // Dormant: created > 90 days ago, no sales order at all
    $dormant  = (int) scalar($pdo, "SELECT COUNT(*) FROM customers c WHERE c.created_at <= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
                                     AND NOT EXISTS (SELECT 1 FROM sales_orders so WHERE so.customer_id = c.id)");
    $topCustomers = rows($pdo, "SELECT c.customer_name, c.company_name, COALESCE(SUM(so.grand_total),0) AS ltv
                                 FROM customers c LEFT JOIN sales_orders so ON so.customer_id = c.id
                                 GROUP BY c.id ORDER BY ltv DESC LIMIT 8");

    $byType  = groupBreakdown($pdo, 'customers', 'customer_type', $where, $params);
    $byState = groupBreakdown($pdo, 'customers', 'state', $where, $params);
    $trend = monthlyTrend($pdo, 'customers', 'created_at', $where, $params);

    $tableRows = rows($pdo, "SELECT customer_code, customer_name, company_name, city, state, customer_type, status, created_at
                              FROM customers " . w_sql($where) . " ORDER BY created_at DESC LIMIT 500", $params);

    respond(['success' => true, 'data' => [
        'cards' => [
            card('Total Customers', $gc['total'], '#ff6b4a', 'fa-user-friends'),
            card('New Today', $gc['today'], '#2563eb', 'fa-calendar-day'),
            card('This Month', $gc['this_month'], '#7c5cff', 'fa-calendar'),
            card('Last Month', $gc['last_month'], '#8f97a8', 'fa-calendar-minus'),
            card('Growth %', $gc['growth_pct'] . '%', $gc['growth_pct'] >= 0 ? '#16a34a' : '#e0384c', 'fa-arrow-trend-up'),
            card('Active Customers', $active, '#16a34a', 'fa-circle-check'),
            card('Inactive', $inactive, '#e0384c', 'fa-circle-xmark'),
            card('Repeat Customers', $repeat, '#14b8a6', 'fa-rotate'),
            card('Dormant (90+ days)', $dormant, '#e08c1c', 'fa-moon'),
        ],
        'charts' => [
            'pie'  => ['title' => 'Customers by Type', 'labels' => array_column($byType, 'label'), 'data' => array_map('intval', array_column($byType, 'cnt'))],
            'bar'  => ['title' => 'Customers by State', 'labels' => array_column($byState, 'label'), 'data' => array_map('intval', array_column($byState, 'cnt'))],
            'line' => ['title' => 'New Customers Trend (6 months)', 'labels' => array_column($trend, 'label'), 'data' => array_column($trend, 'value')],
        ],
        'top_customers' => $topCustomers,
        'table' => [
            'columns' => [
                ['key' => 'customer_code', 'label' => 'Code'],
                ['key' => 'customer_name', 'label' => 'Name'],
                ['key' => 'company_name', 'label' => 'Company'],
                ['key' => 'city', 'label' => 'City'],
                ['key' => 'state', 'label' => 'State'],
                ['key' => 'customer_type', 'label' => 'Type'],
                ['key' => 'status', 'label' => 'Status'],
                ['key' => 'created_at', 'label' => 'Since'],
            ],
            'rows' => $tableRows,
        ],
    ]]);
}

/* =========================================================
   4. EMPLOYEE REPORTS — employees + departments + designations
   ========================================================= */
if ($type === 'employee') {
    $where = []; $params = [];
    w_add($where, $params, w_date('e.date_of_joining'));
    w_add($where, $params, w_eq('e.employment_status', 'status'));
    w_add($where, $params, w_eq('e.department_id', 'department'));
    w_add($where, $params, w_eq('e.designation_id', 'designation'));
    w_add($where, $params, w_eq('e.branch', 'branch'));
    w_add($where, $params, w_eq('e.city', 'city'));
    w_add($where, $params, w_eq('e.state', 'state'));
    if (!empty($_GET['q'])) { $where[] = "(e.first_name LIKE ? OR e.employee_code LIKE ? OR e.mobile_number LIKE ?)"; $q = '%' . $_GET['q'] . '%'; array_push($params, $q, $q, $q); }

    $gc = generalCards($pdo, 'employees e', 'e.date_of_joining', $where, $params);
    $active   = (int) scalar($pdo, "SELECT COUNT(*) FROM employees e " . w_sql(array_merge($where, ["e.employment_status = 'Active'"])), $params);
    $inactive = (int) scalar($pdo, "SELECT COUNT(*) FROM employees e " . w_sql(array_merge($where, ["e.employment_status <> 'Active'"])), $params);

    $birthdays = rows($pdo, "SELECT TRIM(CONCAT(first_name,' ',COALESCE(last_name,''))) AS name, date_of_birth, employee_code
        FROM employees WHERE date_of_birth IS NOT NULL
        AND DATE_FORMAT(date_of_birth,'%m-%d') BETWEEN DATE_FORMAT(CURDATE(),'%m-%d') AND DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 30 DAY),'%m-%d')
        ORDER BY DATE_FORMAT(date_of_birth,'%m-%d') LIMIT 10");
    $anniversaries = rows($pdo, "SELECT TRIM(CONCAT(first_name,' ',COALESCE(last_name,''))) AS name, date_of_joining, employee_code
        FROM employees WHERE date_of_joining IS NOT NULL
        AND DATE_FORMAT(date_of_joining,'%m-%d') BETWEEN DATE_FORMAT(CURDATE(),'%m-%d') AND DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 30 DAY),'%m-%d')
        ORDER BY DATE_FORMAT(date_of_joining,'%m-%d') LIMIT 10");

    $avgExpYears = scalar($pdo, "SELECT AVG(TIMESTAMPDIFF(YEAR, date_of_joining, CURDATE())) FROM employees WHERE date_of_joining IS NOT NULL");
    $avgExpYears = $avgExpYears !== null ? round((float) $avgExpYears, 1) : 0;

    $byDept = rows($pdo, "SELECT COALESCE(d.department_name,'Unassigned') AS label, COUNT(*) AS cnt
        FROM employees e LEFT JOIN departments d ON d.id = e.department_id " . w_sql($where) . "
        GROUP BY label ORDER BY cnt DESC LIMIT 8", $params);
    $byDesig = rows($pdo, "SELECT COALESCE(de.designation_name,'Unassigned') AS label, COUNT(*) AS cnt
        FROM employees e LEFT JOIN designations de ON de.id = e.designation_id " . w_sql($where) . "
        GROUP BY label ORDER BY cnt DESC LIMIT 8", $params);
    $trend = monthlyTrend($pdo, 'employees e', 'e.date_of_joining', $where, $params);

    $tableRows = rows($pdo, "SELECT e.employee_code, TRIM(CONCAT(e.first_name,' ',COALESCE(e.last_name,''))) AS name,
                                     COALESCE(d.department_name,'') AS department_name, COALESCE(de.designation_name,'') AS designation_name,
                                     e.mobile_number, e.date_of_joining, e.employment_status
                              FROM employees e
                              LEFT JOIN departments d ON d.id = e.department_id
                              LEFT JOIN designations de ON de.id = e.designation_id
                              " . w_sql($where) . " ORDER BY e.date_of_joining DESC LIMIT 500", $params);

    respond(['success' => true, 'data' => [
        'cards' => [
            card('Total Employees', $gc['total'], '#ff6b4a', 'fa-users'),
            card('Joined Today', $gc['today'], '#2563eb', 'fa-calendar-day'),
            card('This Month', $gc['this_month'], '#7c5cff', 'fa-calendar'),
            card('Last Month', $gc['last_month'], '#8f97a8', 'fa-calendar-minus'),
            card('Growth %', $gc['growth_pct'] . '%', $gc['growth_pct'] >= 0 ? '#16a34a' : '#e0384c', 'fa-arrow-trend-up'),
            card('Active', $active, '#16a34a', 'fa-circle-check'),
            card('Inactive / Exited', $inactive, '#e0384c', 'fa-circle-xmark'),
            card('Avg Experience (yrs)', $avgExpYears, '#14b8a6', 'fa-briefcase'),
            card('Upcoming Birthdays', count($birthdays), '#e08c1c', 'fa-cake-candles'),
            card('Upcoming Anniversaries', count($anniversaries), '#7c5cff', 'fa-award'),
        ],
        'charts' => [
            'pie'  => ['title' => 'Department-wise Employees', 'labels' => array_column($byDept, 'label'), 'data' => array_map('intval', array_column($byDept, 'cnt'))],
            'bar'  => ['title' => 'Designation-wise Employees', 'labels' => array_column($byDesig, 'label'), 'data' => array_map('intval', array_column($byDesig, 'cnt'))],
            'line' => ['title' => 'Joinings Trend (6 months)', 'labels' => array_column($trend, 'label'), 'data' => array_column($trend, 'value')],
        ],
        'birthdays' => $birthdays,
        'anniversaries' => $anniversaries,
        'table' => [
            'columns' => [
                ['key' => 'employee_code', 'label' => 'Code'],
                ['key' => 'name', 'label' => 'Name'],
                ['key' => 'department_name', 'label' => 'Department'],
                ['key' => 'designation_name', 'label' => 'Designation'],
                ['key' => 'mobile_number', 'label' => 'Mobile'],
                ['key' => 'date_of_joining', 'label' => 'Joining Date'],
                ['key' => 'employment_status', 'label' => 'Status'],
            ],
            'rows' => $tableRows,
        ],
    ]]);
}

/* =========================================================
   5. ATTENDANCE REPORTS — generic_records (hrms__attendance)
   ========================================================= */
if ($type === 'attendance') {
    $moduleKey = 'hrms__attendance';
    $where = ["module_key = ?"]; $params = [$moduleKey];
    w_add($where, $params, w_date('record_date'));
    w_add($where, $params, w_eq('status', 'status'));
    w_add($where, $params, w_like('party_name', 'employee'));

    $gc = generalCards($pdo, 'generic_records', 'record_date', $where, $params);
    $present = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["status = 'Present'"])), $params);
    $absent  = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["status = 'Absent'"])), $params);
    $onLeave = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["status = 'On Leave'"])), $params);
    $halfDay = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["status = 'Half Day'"])), $params);
    $late    = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["JSON_EXTRACT(extra_data,'$.lateMinutes') > 0"])), $params);

    $byStatus = groupBreakdown($pdo, 'generic_records', 'status', $where, $params);
    $byEmployee = groupBreakdown($pdo, 'generic_records', 'party_name', array_merge($where, ["status = 'Present'"]), $params);
    $trend = monthlyTrend($pdo, 'generic_records', 'record_date', $where, $params);

    $tableRows = rows($pdo, "SELECT party_name, record_date, status, notes
                              FROM generic_records " . w_sql($where) . " ORDER BY record_date DESC LIMIT 500", $params);

    respond(['success' => true, 'data' => [
        'cards' => [
            card('Total Marked', $gc['total'], '#ff6b4a', 'fa-clipboard-check'),
            card('Today', $gc['today'], '#2563eb', 'fa-calendar-day'),
            card('This Month', $gc['this_month'], '#7c5cff', 'fa-calendar'),
            card('Last Month', $gc['last_month'], '#8f97a8', 'fa-calendar-minus'),
            card('Growth %', $gc['growth_pct'] . '%', $gc['growth_pct'] >= 0 ? '#16a34a' : '#e0384c', 'fa-arrow-trend-up'),
            card('Present', $present, '#16a34a', 'fa-user-check'),
            card('Absent', $absent, '#e0384c', 'fa-user-xmark'),
            card('On Leave', $onLeave, '#e08c1c', 'fa-plane'),
            card('Half Day', $halfDay, '#7c5cff', 'fa-clock'),
            card('Late Coming', $late, '#e08c1c', 'fa-hourglass-end'),
        ],
        'charts' => [
            'pie'  => ['title' => 'Attendance by Status', 'labels' => array_column($byStatus, 'label'), 'data' => array_map('intval', array_column($byStatus, 'cnt'))],
            'bar'  => ['title' => 'Present Days by Employee', 'labels' => array_column($byEmployee, 'label'), 'data' => array_map('intval', array_column($byEmployee, 'cnt'))],
            'line' => ['title' => 'Attendance Trend (6 months)', 'labels' => array_column($trend, 'label'), 'data' => array_column($trend, 'value')],
        ],
        'table' => [
            'columns' => [
                ['key' => 'party_name', 'label' => 'Employee'],
                ['key' => 'record_date', 'label' => 'Date'],
                ['key' => 'status', 'label' => 'Status'],
                ['key' => 'notes', 'label' => 'Remarks'],
            ],
            'rows' => $tableRows,
        ],
        'note' => $gc['total'] === 0 ? 'No attendance has been marked yet. Add records under HRMS > Attendance to see live data here.' : null,
    ]]);
}

/* =========================================================
   6. PAYROLL REPORTS — employees salary columns + hrms bonus/incentive
   ========================================================= */
if ($type === 'payroll') {
    $where = []; $params = [];
    w_add($where, $params, w_eq('e.employment_status', 'status'));
    w_add($where, $params, w_eq('e.department_id', 'department'));
    w_add($where, $params, w_eq('e.branch', 'branch'));

    $total = (int) scalar($pdo, "SELECT COUNT(*) FROM employees e " . w_sql($where), $params);
    $sums = rows($pdo, "SELECT COALESCE(SUM(basic_salary),0) basic, COALESCE(SUM(gross_salary),0) gross, COALESCE(SUM(net_salary),0) net,
                                COALESCE(SUM(pf),0) pf, COALESCE(SUM(esic),0) esic, COALESCE(SUM(professional_tax),0) pt
                         FROM employees e " . w_sql($where), $params);
    $s = $sums[0] ?? ['basic'=>0,'gross'=>0,'net'=>0,'pf'=>0,'esic'=>0,'pt'=>0];
    $avgNet = $total > 0 ? round($s['net'] / $total) : 0;

    $bonusCount = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records WHERE module_key = 'hrms__bonus'");
    $incentiveCount = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records WHERE module_key = 'hrms__incentive'");
    $bonusAmt = (float) scalar($pdo, "SELECT COALESCE(SUM(amount),0) FROM generic_records WHERE module_key = 'hrms__bonus'");
    $incentiveAmt = (float) scalar($pdo, "SELECT COALESCE(SUM(amount),0) FROM generic_records WHERE module_key = 'hrms__incentive'");

    $byDept = rows($pdo, "SELECT COALESCE(d.department_name,'Unassigned') AS label, COALESCE(SUM(e.gross_salary),0) AS cnt
        FROM employees e LEFT JOIN departments d ON d.id = e.department_id " . w_sql($where) . "
        GROUP BY label ORDER BY cnt DESC LIMIT 8", $params);
    $topEarners = rows($pdo, "SELECT TRIM(CONCAT(e.first_name,' ',COALESCE(e.last_name,''))) AS label, COALESCE(e.net_salary,0) AS cnt
        FROM employees e " . w_sql($where) . " ORDER BY e.net_salary DESC LIMIT 8", $params);

    $tableRows = rows($pdo, "SELECT e.employee_code, TRIM(CONCAT(e.first_name,' ',COALESCE(e.last_name,''))) AS name,
                                     COALESCE(d.department_name,'') AS department_name, e.basic_salary, e.gross_salary,
                                     e.pf, e.esic, e.professional_tax, e.net_salary
                              FROM employees e LEFT JOIN departments d ON d.id = e.department_id
                              " . w_sql($where) . " ORDER BY e.net_salary DESC LIMIT 500", $params);

    respond(['success' => true, 'data' => [
        'cards' => [
            card('Employees on Payroll', $total, '#ff6b4a', 'fa-users'),
            card('Gross Salary (Monthly)', money($s['gross']), '#2563eb', 'fa-sack-dollar'),
            card('Net Salary (Monthly)', money($s['net']), '#16a34a', 'fa-money-bill-wave'),
            card('Total PF', money($s['pf']), '#7c5cff', 'fa-piggy-bank'),
            card('Total ESIC', money($s['esic']), '#e08c1c', 'fa-shield-heart'),
            card('Total Professional Tax', money($s['pt']), '#e0384c', 'fa-file-invoice-dollar'),
            card('Avg Net Salary', money($avgNet), '#14b8a6', 'fa-chart-simple'),
            card('Bonus Entries', $bonusCount . ' (' . money($bonusAmt) . ')', '#e08c1c', 'fa-gift'),
            card('Incentive Entries', $incentiveCount . ' (' . money($incentiveAmt) . ')', '#7c5cff', 'fa-trophy'),
        ],
        'charts' => [
            'pie'  => ['title' => 'Gross Salary Share by Department', 'labels' => array_column($byDept, 'label'), 'data' => array_map('floatval', array_column($byDept, 'cnt'))],
            'bar'  => ['title' => 'Top Net Salaries', 'labels' => array_column($topEarners, 'label'), 'data' => array_map('floatval', array_column($topEarners, 'cnt'))],
            'line' => ['title' => '', 'labels' => [], 'data' => []],
        ],
        'table' => [
            'columns' => [
                ['key' => 'employee_code', 'label' => 'Code'],
                ['key' => 'name', 'label' => 'Name'],
                ['key' => 'department_name', 'label' => 'Department'],
                ['key' => 'basic_salary', 'label' => 'Basic', 'money' => true],
                ['key' => 'gross_salary', 'label' => 'Gross', 'money' => true],
                ['key' => 'pf', 'label' => 'PF', 'money' => true],
                ['key' => 'esic', 'label' => 'ESIC', 'money' => true],
                ['key' => 'professional_tax', 'label' => 'PT', 'money' => true],
                ['key' => 'net_salary', 'label' => 'Net Salary', 'money' => true],
            ],
            'rows' => $tableRows,
        ],
    ]]);
}

/* =========================================================
   7. PROJECT REPORTS — generic_records (project-management__*)
   ========================================================= */
if ($type === 'project') {
    $where = ["module_key LIKE 'project-management\\_\\_%' ESCAPE '\\\\'"]; $params = [];
    w_add($where, $params, w_date('created_at'));
    w_add($where, $params, w_eq('status', 'status'));
    w_add($where, $params, w_like('assigned_to', 'employee'));
    w_add($where, $params, w_like('party_name', 'customer'));

    $gc = generalCards($pdo, 'generic_records', 'created_at', $where, $params);
    $running   = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["module_key='project-management__projects' AND status='Active'"])), $params);
    $completed = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["module_key='project-management__projects' AND status='Completed'"])), $params);
    $delayed   = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["module_key='project-management__projects' AND status NOT IN ('Completed') AND record_date IS NOT NULL AND record_date < CURDATE()"])), $params);
    $pendingTasks = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["module_key IN ('project-management__tasks','project-management__sub-tasks') AND status <> 'Completed'"])), $params);
    $totalBudget = (float) scalar($pdo, "SELECT COALESCE(SUM(amount),0) FROM generic_records " . w_sql(array_merge($where, ["module_key='project-management__projects'"])), $params);

    $byModule = rows($pdo, "SELECT module_label AS label, COUNT(*) AS cnt FROM generic_records " . w_sql($where) . " GROUP BY module_label ORDER BY cnt DESC", $params);
    $byStatus = groupBreakdown($pdo, 'generic_records', 'status', $where, $params);
    $trend = monthlyTrend($pdo, 'generic_records', 'created_at', $where, $params);

    $tableRows = rows($pdo, "SELECT module_label, title, party_name, assigned_to, record_date, status
                              FROM generic_records " . w_sql($where) . " ORDER BY created_at DESC LIMIT 500", $params);

    // Project Management module (dedicated tables) - added on top of the generic records above.
    try {
        $pm = $pdo->query("SELECT COUNT(*) n, COALESCE(SUM(status='Active'),0) a, COALESCE(SUM(status='Completed'),0) c,
                COALESCE(SUM(status<>'Completed' AND end_date IS NOT NULL AND end_date < CURDATE()),0) d, COALESCE(SUM(budget),0) b FROM pm_projects")->fetch();
        if ($pm && (int)$pm['n'] > 0) {
            $running += (int)$pm['a']; $completed += (int)$pm['c']; $delayed += (int)$pm['d']; $totalBudget += (float)$pm['b'];
            $pendingTasks += (int)$pdo->query("SELECT COUNT(*) FROM pm_tasks WHERE status <> 'Done'")->fetchColumn();
            $gc['total'] += (int)$pm['n'];
            foreach ($pdo->query("SELECT status AS label, COUNT(*) AS cnt FROM pm_projects GROUP BY status") as $b) {
                $found = false;
                foreach ($byStatus as &$x) if ($x['label'] === $b['label']) { $x['cnt'] += $b['cnt']; $found = true; }
                unset($x);
                if (!$found) $byStatus[] = ['label' => $b['label'], 'cnt' => $b['cnt']];
            }
            $byModule[] = ['label' => 'Projects (Project Management)', 'cnt' => (int)$pm['n']];
            $pmRows = $pdo->query("SELECT 'Projects' AS module_label, p.project_name AS title, c.customer_name AS party_name,
                    TRIM(CONCAT(COALESCE(e.first_name,''),' ',COALESCE(e.last_name,''))) AS assigned_to, p.end_date AS record_date, p.status
                FROM pm_projects p LEFT JOIN customers c ON c.id = p.client_id LEFT JOIN employees e ON e.id = p.project_manager_id
                ORDER BY p.project_id DESC LIMIT 200")->fetchAll();
            $tableRows = array_merge($pmRows, $tableRows);
        }
    } catch (Throwable $e) { /* project tables not created yet */ }

    respond(['success' => true, 'data' => [
        'cards' => [
            card('Total Project Items', $gc['total'], '#ff6b4a', 'fa-diagram-project'),
            card('Added Today', $gc['today'], '#2563eb', 'fa-calendar-day'),
            card('This Month', $gc['this_month'], '#7c5cff', 'fa-calendar'),
            card('Last Month', $gc['last_month'], '#8f97a8', 'fa-calendar-minus'),
            card('Growth %', $gc['growth_pct'] . '%', $gc['growth_pct'] >= 0 ? '#16a34a' : '#e0384c', 'fa-arrow-trend-up'),
            card('Running Projects', $running, '#16a34a', 'fa-play'),
            card('Completed Projects', $completed, '#14b8a6', 'fa-circle-check'),
            card('Delayed Projects', $delayed, '#e0384c', 'fa-triangle-exclamation'),
            card('Pending Tasks', $pendingTasks, '#e08c1c', 'fa-list-check'),
            card('Total Budget', money($totalBudget), '#7c5cff', 'fa-sack-dollar'),
        ],
        'charts' => [
            'pie'  => ['title' => 'By Module', 'labels' => array_column($byModule, 'label'), 'data' => array_map('intval', array_column($byModule, 'cnt'))],
            'bar'  => ['title' => 'By Status', 'labels' => array_column($byStatus, 'label'), 'data' => array_map('intval', array_column($byStatus, 'cnt'))],
            'line' => ['title' => 'Items Trend (6 months)', 'labels' => array_column($trend, 'label'), 'data' => array_column($trend, 'value')],
        ],
        'table' => [
            'columns' => [
                ['key' => 'module_label', 'label' => 'Module'],
                ['key' => 'title', 'label' => 'Title'],
                ['key' => 'party_name', 'label' => 'Client'],
                ['key' => 'assigned_to', 'label' => 'Assigned To'],
                ['key' => 'record_date', 'label' => 'Date'],
                ['key' => 'status', 'label' => 'Status'],
            ],
            'rows' => $tableRows,
        ],
        'note' => $gc['total'] === 0 ? 'No project data yet. Add records under Project Management to see live reports here.' : null,
    ]]);
}

/* =========================================================
   8. INVENTORY REPORTS — generic_records (inventory__*)
   ========================================================= */
if ($type === 'inventory') {
    $where = ["module_key LIKE 'inventory\\_\\_%' ESCAPE '\\\\'"]; $params = [];
    w_add($where, $params, w_date('created_at'));
    w_add($where, $params, w_eq('status', 'status'));

    $gc = generalCards($pdo, 'generic_records', 'created_at', $where, $params);
    $products = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["module_key='inventory__products'"])), $params);
    $stockEntries = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["module_key='inventory__stock'"])), $params);
    $purchaseOrders = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["module_key='inventory__purchase-order'"])), $params);
    $lowStock = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["module_key='inventory__stock' AND status='Pending'"])), $params);
    $totalValue = (float) scalar($pdo, "SELECT COALESCE(SUM(amount),0) FROM generic_records " . w_sql($where), $params);

    $byModule = rows($pdo, "SELECT module_label AS label, COUNT(*) AS cnt FROM generic_records " . w_sql($where) . " GROUP BY module_label ORDER BY cnt DESC", $params);
    $byStatus = groupBreakdown($pdo, 'generic_records', 'status', $where, $params);
    $trend = monthlyTrend($pdo, 'generic_records', 'created_at', $where, $params);

    $tableRows = rows($pdo, "SELECT module_label, title, assigned_to, record_date, amount, status
                              FROM generic_records " . w_sql($where) . " ORDER BY created_at DESC LIMIT 500", $params);

    respond(['success' => true, 'data' => [
        'cards' => [
            card('Total Inventory Items', $gc['total'], '#ff6b4a', 'fa-box-open'),
            card('Added Today', $gc['today'], '#2563eb', 'fa-calendar-day'),
            card('This Month', $gc['this_month'], '#7c5cff', 'fa-calendar'),
            card('Last Month', $gc['last_month'], '#8f97a8', 'fa-calendar-minus'),
            card('Growth %', $gc['growth_pct'] . '%', $gc['growth_pct'] >= 0 ? '#16a34a' : '#e0384c', 'fa-arrow-trend-up'),
            card('Products', $products, '#16a34a', 'fa-cubes'),
            card('Stock Entries', $stockEntries, '#14b8a6', 'fa-warehouse'),
            card('Purchase Orders', $purchaseOrders, '#7c5cff', 'fa-cart-arrow-down'),
            card('Low Stock Alerts', $lowStock, '#e08c1c', 'fa-triangle-exclamation'),
            card('Total Stock Value', money($totalValue), '#2563eb', 'fa-sack-dollar'),
        ],
        'charts' => [
            'pie'  => ['title' => 'By Module', 'labels' => array_column($byModule, 'label'), 'data' => array_map('intval', array_column($byModule, 'cnt'))],
            'bar'  => ['title' => 'By Status', 'labels' => array_column($byStatus, 'label'), 'data' => array_map('intval', array_column($byStatus, 'cnt'))],
            'line' => ['title' => 'Items Trend (6 months)', 'labels' => array_column($trend, 'label'), 'data' => array_column($trend, 'value')],
        ],
        'table' => [
            'columns' => [
                ['key' => 'module_label', 'label' => 'Module'],
                ['key' => 'title', 'label' => 'Item'],
                ['key' => 'assigned_to', 'label' => 'Warehouse/Owner'],
                ['key' => 'record_date', 'label' => 'Date'],
                ['key' => 'amount', 'label' => 'Value', 'money' => true],
                ['key' => 'status', 'label' => 'Status'],
            ],
            'rows' => $tableRows,
        ],
        'note' => $gc['total'] === 0 ? 'No inventory data yet. Add records under Inventory to see live reports here.' : null,
    ]]);
}

/* =========================================================
   9. FINANCIAL REPORTS — generic_records (accounts__/sales__) + account_groups
   ========================================================= */
if ($type === 'financial') {
    $incomeWhere = ["module_key IN ('accounts__income','sales__receipt')"];
    $expenseWhere = ["module_key = 'accounts__expenses'"];
    $dateW = w_date('created_at');
    $incomeWhere = array_merge($incomeWhere, $dateW[0]); $incomeParams = $dateW[1];
    $expenseWhere = array_merge($expenseWhere, $dateW[0]); $expenseParams = $dateW[1];

    $totalIncome  = (float) scalar($pdo, "SELECT COALESCE(SUM(amount),0) FROM generic_records " . w_sql($incomeWhere), $incomeParams);
    $totalExpense = (float) scalar($pdo, "SELECT COALESCE(SUM(amount),0) FROM generic_records " . w_sql($expenseWhere), $expenseParams);
    $profit = $totalIncome - $totalExpense;

    $invoiceTotal = (float) scalar($pdo, "SELECT COALESCE(SUM(amount),0) FROM generic_records WHERE module_key IN ('sales__invoice','sales__proforma-invoice')");
    $receiptTotal = (float) scalar($pdo, "SELECT COALESCE(SUM(amount),0) FROM generic_records WHERE module_key='sales__receipt'");
    $receivable = max($invoiceTotal - $receiptTotal, 0);
    $payable = (float) scalar($pdo, "SELECT COALESCE(SUM(amount),0) FROM generic_records WHERE module_key='accounts__expenses' AND status='Pending'");

    $thisMonthIncome = (float) scalar($pdo, "SELECT COALESCE(SUM(amount),0) FROM generic_records WHERE module_key IN ('accounts__income','sales__receipt') AND MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE())");
    $lastMonthIncome = (float) scalar($pdo, "SELECT COALESCE(SUM(amount),0) FROM generic_records WHERE module_key IN ('accounts__income','sales__receipt') AND MONTH(created_at)=MONTH(CURDATE() - INTERVAL 1 MONTH) AND YEAR(created_at)=YEAR(CURDATE() - INTERVAL 1 MONTH)");

    $incomeTrend = monthlyTrend($pdo, 'generic_records', 'created_at', ["module_key IN ('accounts__income','sales__receipt')"], [], 'COALESCE(SUM(amount),0)');
    $expenseTrend = monthlyTrend($pdo, 'generic_records', 'created_at', ["module_key = 'accounts__expenses'"], [], 'COALESCE(SUM(amount),0)');

    $tableRows = rows($pdo, "SELECT
            CASE WHEN module_key IN ('accounts__income','sales__receipt') THEN 'Income' ELSE 'Expense' END AS kind,
            module_label, title, party_name, record_date, amount, status
        FROM generic_records
        WHERE module_key IN ('accounts__income','accounts__expenses','sales__receipt')
        ORDER BY created_at DESC LIMIT 500");

    respond(['success' => true, 'data' => [
        'cards' => [
            card('Total Income', money($totalIncome), '#16a34a', 'fa-arrow-trend-up'),
            card('Total Expense', money($totalExpense), '#e0384c', 'fa-arrow-trend-down'),
            card('Net Profit', money($profit), $profit >= 0 ? '#16a34a' : '#e0384c', 'fa-scale-balanced'),
            card('This Month Income', money($thisMonthIncome), '#2563eb', 'fa-calendar'),
            card('Growth %', pct($thisMonthIncome, $lastMonthIncome) . '%', pct($thisMonthIncome, $lastMonthIncome) >= 0 ? '#16a34a' : '#e0384c', 'fa-arrow-trend-up'),
            card('Receivable', money($receivable), '#e08c1c', 'fa-hand-holding-dollar'),
            card('Payable', money($payable), '#7c5cff', 'fa-file-invoice-dollar'),
        ],
        'charts' => [
            'pie'  => ['title' => 'Income vs Expense', 'labels' => ['Income', 'Expense'], 'data' => [$totalIncome, $totalExpense]],
            'bar'  => ['title' => 'Monthly Income', 'labels' => array_column($incomeTrend, 'label'), 'data' => array_column($incomeTrend, 'value')],
            'line' => ['title' => 'Monthly Expense', 'labels' => array_column($expenseTrend, 'label'), 'data' => array_column($expenseTrend, 'value')],
        ],
        'table' => [
            'columns' => [
                ['key' => 'kind', 'label' => 'Type'],
                ['key' => 'module_label', 'label' => 'Module'],
                ['key' => 'title', 'label' => 'Title'],
                ['key' => 'party_name', 'label' => 'Party'],
                ['key' => 'record_date', 'label' => 'Date'],
                ['key' => 'amount', 'label' => 'Amount', 'money' => true],
                ['key' => 'status', 'label' => 'Status'],
            ],
            'rows' => $tableRows,
        ],
        'note' => ($totalIncome + $totalExpense) === 0.0 ? 'No income/expense entries yet. Add records under Accounts > Income / Expenses to see live reports here.' : null,
    ]]);
}

/* =========================================================
   10. SUPPORT REPORTS — generic_records (helpdesk__*)
   ========================================================= */
if ($type === 'support') {
    $where = ["module_key LIKE 'helpdesk\\_\\_%' ESCAPE '\\\\'"]; $params = [];
    w_add($where, $params, w_date('created_at'));
    w_add($where, $params, w_eq('status', 'status'));
    w_add($where, $params, w_like('assigned_to', 'employee'));

    $gc = generalCards($pdo, 'generic_records', 'created_at', $where, $params);
    $open   = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["status IN ('Active','Pending')"])), $params);
    $closed = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["status = 'Completed'"])), $params);
    $pending = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($where, ["status = 'Pending'"])), $params);
    $avgResolutionDays = scalar($pdo, "SELECT AVG(TIMESTAMPDIFF(HOUR, created_at, updated_at)) FROM generic_records " . w_sql(array_merge($where, ["status = 'Completed'"])), $params);
    $avgResolutionDays = $avgResolutionDays !== null ? round((float) $avgResolutionDays, 1) : 0;

    $byModule = rows($pdo, "SELECT module_label AS label, COUNT(*) AS cnt FROM generic_records " . w_sql($where) . " GROUP BY module_label ORDER BY cnt DESC", $params);
    $byEmployee = groupBreakdown($pdo, 'generic_records', 'assigned_to', $where, $params);
    $trend = monthlyTrend($pdo, 'generic_records', 'created_at', $where, $params);

    $tableRows = rows($pdo, "SELECT module_label, title, party_name, assigned_to, record_date, status
                              FROM generic_records " . w_sql($where) . " ORDER BY created_at DESC LIMIT 500", $params);

    respond(['success' => true, 'data' => [
        'cards' => [
            card('Total Tickets', $gc['total'], '#ff6b4a', 'fa-headset'),
            card('Today', $gc['today'], '#2563eb', 'fa-calendar-day'),
            card('This Month', $gc['this_month'], '#7c5cff', 'fa-calendar'),
            card('Last Month', $gc['last_month'], '#8f97a8', 'fa-calendar-minus'),
            card('Growth %', $gc['growth_pct'] . '%', $gc['growth_pct'] >= 0 ? '#16a34a' : '#e0384c', 'fa-arrow-trend-up'),
            card('Open Tickets', $open, '#e08c1c', 'fa-envelope-open'),
            card('Pending', $pending, '#e0384c', 'fa-hourglass-half'),
            card('Resolved', $closed, '#16a34a', 'fa-circle-check'),
            card('Avg Resolution (hrs)', $avgResolutionDays, '#14b8a6', 'fa-stopwatch'),
        ],
        'charts' => [
            'pie'  => ['title' => 'By Module', 'labels' => array_column($byModule, 'label'), 'data' => array_map('intval', array_column($byModule, 'cnt'))],
            'bar'  => ['title' => 'Employee-wise Tickets', 'labels' => array_column($byEmployee, 'label'), 'data' => array_map('intval', array_column($byEmployee, 'cnt'))],
            'line' => ['title' => 'Tickets Trend (6 months)', 'labels' => array_column($trend, 'label'), 'data' => array_column($trend, 'value')],
        ],
        'table' => [
            'columns' => [
                ['key' => 'module_label', 'label' => 'Module'],
                ['key' => 'title', 'label' => 'Subject'],
                ['key' => 'party_name', 'label' => 'Customer'],
                ['key' => 'assigned_to', 'label' => 'Assigned To'],
                ['key' => 'record_date', 'label' => 'Date'],
                ['key' => 'status', 'label' => 'Status'],
            ],
            'rows' => $tableRows,
        ],
        'note' => $gc['total'] === 0 ? 'No support tickets yet. Add records under Helpdesk to see live reports here.' : null,
    ]]);
}

/* =========================================================
   11. PRODUCTIVITY REPORTS — tasks + attendance + follow-ups
   ========================================================= */
if ($type === 'productivity') {
    $taskWhere = ["module_key IN ('project-management__tasks','project-management__sub-tasks')"];
    $dateW = w_date('created_at');
    $taskWhere = array_merge($taskWhere, $dateW[0]); $taskParams = $dateW[1];
    if (!empty($_GET['employee'])) { $taskWhere[] = "assigned_to LIKE ?"; $taskParams[] = '%' . $_GET['employee'] . '%'; }

    $tasksCompleted = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($taskWhere, ["status = 'Completed'"])), $taskParams);
    $tasksPending   = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records " . w_sql(array_merge($taskWhere, ["status <> 'Completed'"])), $taskParams);
    $totalTasks = $tasksCompleted + $tasksPending;
    $completionRate = $totalTasks > 0 ? round(($tasksCompleted / $totalTasks) * 100, 1) : 0;

    $attendanceMarked = (int) scalar($pdo, "SELECT COUNT(*) FROM generic_records WHERE module_key='hrms__attendance' AND status='Present'");

    $fuCompleted = (int) scalar($pdo, "SELECT COUNT(*) FROM lead_followups WHERE status NOT IN ('Call Later','Pending')");
    $fuPending   = (int) scalar($pdo, "SELECT COUNT(*) FROM leads WHERE next_followup_date IS NOT NULL AND next_followup_date <= CURDATE() AND status NOT IN ('Converted','Lost')");

    $byEmployee = rows($pdo, "SELECT assigned_to AS label, SUM(status='Completed') AS cnt FROM generic_records " . w_sql($taskWhere) . "
                               AND assigned_to IS NOT NULL AND assigned_to <> '' GROUP BY assigned_to ORDER BY cnt DESC LIMIT 8", $taskParams);
    $byStatus = groupBreakdown($pdo, 'generic_records', 'status', $taskWhere, $taskParams);
    $trend = monthlyTrend($pdo, 'generic_records', 'created_at', array_merge($taskWhere, ["status='Completed'"]), $taskParams);

    $tableRows = rows($pdo, "SELECT assigned_to, module_label, title, record_date, status
                              FROM generic_records " . w_sql($taskWhere) . " ORDER BY created_at DESC LIMIT 500", $taskParams);

    respond(['success' => true, 'data' => [
        'cards' => [
            card('Completed Tasks', $tasksCompleted, '#16a34a', 'fa-circle-check'),
            card('Pending Tasks', $tasksPending, '#e08c1c', 'fa-list-check'),
            card('Task Completion Rate', $completionRate . '%', '#14b8a6', 'fa-bullseye'),
            card('Attendance Marked (Present)', $attendanceMarked, '#2563eb', 'fa-user-check'),
            card('Follow-ups Completed', $fuCompleted, '#7c5cff', 'fa-phone'),
            card('Follow-ups Pending', $fuPending, '#e0384c', 'fa-phone-slash'),
        ],
        'charts' => [
            'pie'  => ['title' => 'Tasks by Status', 'labels' => array_column($byStatus, 'label'), 'data' => array_map('intval', array_column($byStatus, 'cnt'))],
            'bar'  => ['title' => 'Employee-wise Completed Tasks', 'labels' => array_column($byEmployee, 'label'), 'data' => array_map('intval', array_column($byEmployee, 'cnt'))],
            'line' => ['title' => 'Completed Tasks Trend (6 months)', 'labels' => array_column($trend, 'label'), 'data' => array_column($trend, 'value')],
        ],
        'table' => [
            'columns' => [
                ['key' => 'assigned_to', 'label' => 'Employee'],
                ['key' => 'module_label', 'label' => 'Module'],
                ['key' => 'title', 'label' => 'Task'],
                ['key' => 'record_date', 'label' => 'Date'],
                ['key' => 'status', 'label' => 'Status'],
            ],
            'rows' => $tableRows,
        ],
        'note' => $totalTasks === 0 ? 'No tasks yet. Add records under Project Management > Tasks to see live productivity data here.' : null,
    ]]);
}

/* =========================================================
   12. CUSTOM REPORTS — ad-hoc report builder
   ========================================================= */
if ($type === 'custom_sources') {
    respond(['success' => true, 'data' => $CUSTOM_SOURCES_META]);
}

if ($type === 'custom') {
    $source = $_GET['source'] ?? '';
    if (!isset($CUSTOM_SOURCES[$source])) respond(['success' => false, 'message' => 'Unknown source'], 422);
    $meta = $CUSTOM_SOURCES[$source];

    $reqCols = $_GET['columns'] ?? [];
    if (!is_array($reqCols) || !count($reqCols)) $reqCols = array_keys($meta['columns']);
    $cols = array_values(array_intersect($reqCols, array_keys($meta['columns'])));
    if (!count($cols)) $cols = array_keys($meta['columns']);

    $where = []; $params = [];
    if (!empty($meta['date_col'])) w_add($where, $params, w_date($meta['date_col']));
    if (!empty($_GET['status']) && isset($meta['columns']['status'])) w_add($where, $params, w_eq('status', 'status'));
    if (!empty($_GET['q']) && !empty($meta['search_cols'])) {
        $qParts = []; $q = '%' . $_GET['q'] . '%';
        foreach ($meta['search_cols'] as $sc) { $qParts[] = "$sc LIKE ?"; $params[] = $q; }
        $where[] = '(' . implode(' OR ', $qParts) . ')';
    }
    if (!empty($meta['fixed_where'])) $where[] = $meta['fixed_where'];

    $groupBy = $_GET['group_by'] ?? '';
    $orderBy = $_GET['order_by'] ?? '';
    $orderDir = (strtoupper($_GET['order_dir'] ?? 'DESC') === 'ASC') ? 'ASC' : 'DESC';

    if ($groupBy && isset($meta['columns'][$groupBy])) {
        $gCol = $meta['columns'][$groupBy];
        $sql = "SELECT $gCol AS label, COUNT(*) AS cnt FROM {$meta['table']} " . w_sql($where) . " GROUP BY $gCol ORDER BY cnt DESC LIMIT 200";
        $data = rows($pdo, $sql, $params);
        respond(['success' => true, 'data' => ['grouped' => true, 'rows' => $data, 'columns' => [['key'=>'label','label'=>$meta['columns_labels'][$groupBy] ?? $groupBy], ['key'=>'cnt','label'=>'Count']]]]);
    }

    $selectSql = implode(', ', array_map(fn($c) => $meta['columns'][$c] . " AS $c", $cols));
    $orderSql = '';
    if ($orderBy && isset($meta['columns'][$orderBy])) {
        $orderSql = "ORDER BY {$meta['columns'][$orderBy]} $orderDir";
    } elseif (!empty($meta['date_col'])) {
        $orderSql = "ORDER BY {$meta['date_col']} DESC";
    }
    $sql = "SELECT $selectSql FROM {$meta['table']} " . w_sql($where) . " $orderSql LIMIT 1000";
    $data = rows($pdo, $sql, $params);

    respond(['success' => true, 'data' => [
        'grouped' => false,
        'columns' => array_map(fn($c) => ['key' => $c, 'label' => $meta['columns_labels'][$c] ?? $c], $cols),
        'rows' => $data,
    ]]);
}

respond(['success' => false, 'message' => 'Unknown report type'], 422);
