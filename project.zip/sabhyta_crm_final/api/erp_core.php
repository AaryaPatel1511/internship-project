<?php
/**
 * ERP CORE HELPERS
 * --------------------------------------------------------
 * Shared by api/erp.php and the module action files
 * (erp_marketing.php, erp_projects.php, erp_assets.php,
 *  erp_documents.php, erp_admin.php) and by erp_hooks.php.
 * --------------------------------------------------------
 */

if (!defined('ERP_ROOT'))    define('ERP_ROOT', dirname(__DIR__));
if (!defined('ERP_STORAGE')) define('ERP_STORAGE', ERP_ROOT . '/storage');
if (!defined('ERP_TABLE_COUNT')) define('ERP_TABLE_COUNT', 40);

/* ---------------------------------------------------------
   Responses
   --------------------------------------------------------- */
function erp_out($payload, int $code = 200): void {
    if (!headers_sent()) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
    exit;
}
function erp_fail(string $message, int $code = 422, array $extra = []): void {
    erp_out(array_merge(['success' => false, 'message' => $message], $extra), $code);
}
function erp_ok($data = null, array $extra = []): void {
    erp_out(array_merge(['success' => true, 'data' => $data], $extra));
}

/* ---------------------------------------------------------
   Current user / roles
   --------------------------------------------------------- */
function erp_user(): array {
    return [
        'id'   => isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null,
        'name' => $_SESSION['user_name'] ?? 'System',
        'role' => $_SESSION['user_role'] ?? '',
    ];
}
function erp_is_admin(): bool {
    $r = erp_user()['role'];
    return in_array($r, ['Super Admin', 'Admin'], true);
}
function erp_require_admin(): void {
    if (!erp_is_admin()) erp_fail('Only an Administrator can do this.', 403);
}
function erp_ip(): string {
    return $_SERVER['REMOTE_ADDR'] ?? '';
}

/** Map the logged-in login-account to its HRMS employee (matched by e-mail), if any. */
function erp_current_employee_id(PDO $pdo): ?int {
    static $cache = false;
    if ($cache !== false) return $cache;
    $uid = erp_user()['id'];
    $cache = null;
    if (!$uid) return null;
    try {
        $st = $pdo->prepare("SELECT employee_id, email FROM users WHERE id = ?");
        $st->execute([$uid]);
        $u = $st->fetch();
        if ($u && !empty($u['employee_id'])) { $cache = (int)$u['employee_id']; return $cache; }
        if ($u && !empty($u['email'])) {
            $e = $pdo->prepare("SELECT id FROM employees WHERE official_email = ? OR personal_email = ? LIMIT 1");
            $e->execute([$u['email'], $u['email']]);
            $id = $e->fetchColumn();
            if ($id) $cache = (int)$id;
        }
    } catch (Exception $e) { /* optional mapping */ }
    return $cache;
}

/* ---------------------------------------------------------
   Schema bootstrap
   --------------------------------------------------------- */
function erp_ensure_schema(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    $done = true;

    $n = (int)$pdo->query(
        "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND (
            table_name LIKE 'mk\\_%' OR table_name LIKE 'pm\\_%' OR table_name LIKE 'am\\_%' OR
            table_name LIKE 'dms\\_%' OR table_name LIKE 'adm\\_%')"
    )->fetchColumn();

    if ($n < ERP_TABLE_COUNT) {
        $file = ERP_ROOT . '/database/schema_erp_modules.sql';
        if (!is_file($file)) erp_fail('database/schema_erp_modules.sql is missing.', 500);
        $sql = preg_replace('/^\s*--.*$/m', '', file_get_contents($file));
        foreach (preg_split('/;\s*(?:\r?\n|$)/', $sql) as $stmt) {
            $stmt = trim($stmt);
            if ($stmt === '') continue;
            if (preg_match('/^(CREATE\s+DATABASE|USE|ALTER\s+TABLE\s+users)\b/i', $stmt)) continue;
            $pdo->exec($stmt);
        }
    }

    // Additive columns on the existing login table (idempotent, MySQL + MariaDB safe)
    $cols = $pdo->query("SELECT column_name FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'users'")->fetchAll(PDO::FETCH_COLUMN);
    $cols = array_map('strtolower', $cols);
    if (!in_array('status', $cols, true))        $pdo->exec("ALTER TABLE users ADD COLUMN status ENUM('Active','Suspended') NOT NULL DEFAULT 'Active'");
    if (!in_array('employee_id', $cols, true))   $pdo->exec("ALTER TABLE users ADD COLUMN employee_id INT NULL");
    if (!in_array('last_login_at', $cols, true)) $pdo->exec("ALTER TABLE users ADD COLUMN last_login_at DATETIME NULL");
}

/* ---------------------------------------------------------
   Storage (private - never served directly)
   --------------------------------------------------------- */
function erp_storage_dir(string $sub = ''): string {
    $dir = ERP_STORAGE . ($sub !== '' ? '/' . trim($sub, '/') : '');
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    foreach ([ERP_STORAGE] as $guard) {
        if (is_dir($guard)) {
            if (!is_file($guard . '/.htaccess')) @file_put_contents($guard . '/.htaccess', "Require all denied\nDeny from all\n");
            if (!is_file($guard . '/index.html')) @file_put_contents($guard . '/index.html', '');
        }
    }
    return $dir;
}

const ERP_BLOCKED_EXT = ['php','php3','php4','php5','php7','phtml','phar','exe','bat','cmd','sh','js','jar','msi','com','scr','vbs','htaccess'];
const ERP_DOC_EXT     = ['pdf','doc','docx','xls','xlsx','ppt','pptx','txt','csv','rtf','odt','ods','jpg','jpeg','png','gif','webp','zip'];
const ERP_MEDIA_EXT   = ['jpg','jpeg','png','gif','webp','mp4','mov','pdf'];

function erp_upload_error_text(int $code): string {
    switch ($code) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE: return 'The file is larger than the server upload limit (' . ini_get('upload_max_filesize') . '). Increase upload_max_filesize / post_max_size in php.ini or upload a smaller file.';
        case UPLOAD_ERR_PARTIAL:   return 'The file was only partly uploaded. Please try again.';
        case UPLOAD_ERR_NO_TMP_DIR:return 'The server has no temporary folder for uploads.';
        case UPLOAD_ERR_CANT_WRITE:return 'The server could not write the uploaded file.';
        default: return 'Upload failed (code ' . $code . ').';
    }
}

/**
 * Save an uploaded file from $_FILES[$field] into storage/$sub.
 * Returns null when nothing was uploaded.
 */
function erp_save_upload(string $field, string $sub, array $allowedExt = ERP_DOC_EXT, int $maxBytes = 15728640): ?array {
    if (empty($_FILES[$field]) || ($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    $f = $_FILES[$field];
    if (is_array($f['error'])) erp_fail('Please upload one file at a time.');
    if ($f['error'] !== UPLOAD_ERR_OK) erp_fail(erp_upload_error_text((int)$f['error']));
    if ($f['size'] > $maxBytes) erp_fail('File is too large. Maximum allowed size is ' . round($maxBytes / 1048576) . ' MB.');

    $orig = preg_replace('/[^\w\-. ()\[\]]+/u', '_', basename($f['name']));
    $ext  = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    if ($ext === '' || in_array($ext, ERP_BLOCKED_EXT, true) || !in_array($ext, $allowedExt, true)) {
        erp_fail('This file type is not allowed. Allowed: ' . implode(', ', $allowedExt) . '.');
    }
    // A file called "report.pdf.php" is rejected via the blocked-extension check on every dot segment
    foreach (explode('.', $orig) as $seg) {
        if (in_array(strtolower($seg), ERP_BLOCKED_EXT, true)) erp_fail('This file name is not allowed.');
    }

    $dir = erp_storage_dir($sub);
    $stored = bin2hex(random_bytes(12)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $stored)) {
        // php -S / CLI tests: fall back to rename for non-uploaded files is intentionally NOT done.
        erp_fail('Could not save the uploaded file on the server (check folder permissions on /storage).', 500);
    }
    return ['path' => 'storage/' . trim($sub, '/') . '/' . $stored, 'name' => $orig, 'size' => (int)$f['size'], 'ext' => $ext];
}

function erp_abs_path(string $rel): ?string {
    $rel = str_replace('\\', '/', $rel);
    if (strpos($rel, 'storage/') !== 0 || strpos($rel, '..') !== false) return null;
    $abs = ERP_ROOT . '/' . $rel;
    return is_file($abs) ? $abs : null;
}
function erp_delete_file(?string $rel): void {
    if (!$rel) return;
    $abs = erp_abs_path($rel);
    if ($abs) @unlink($abs);
}

function erp_send_file(string $abs, string $downloadName, bool $inline = false): void {
    $ext = strtolower(pathinfo($abs, PATHINFO_EXTENSION));
    $mime = [
        'pdf'=>'application/pdf','png'=>'image/png','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','gif'=>'image/gif','webp'=>'image/webp',
        'txt'=>'text/plain','csv'=>'text/csv','mp4'=>'video/mp4','mov'=>'video/quicktime','zip'=>'application/zip',
        'doc'=>'application/msword','docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls'=>'application/vnd.ms-excel','xlsx'=>'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'ppt'=>'application/vnd.ms-powerpoint','pptx'=>'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    ][$ext] ?? 'application/octet-stream';
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($abs));
    header('X-Content-Type-Options: nosniff');
    $safe = str_replace(['"', "\r", "\n"], '', $downloadName);
    header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . $safe . '"');
    readfile($abs);
    exit;
}

/* ---------------------------------------------------------
   Encryption for stored secrets (AES-256-GCM)
   --------------------------------------------------------- */
function erp_key(): string {
    static $key = null;
    if ($key !== null) return $key;
    $dir = erp_storage_dir('keys');
    $file = $dir . '/.erp_key';
    if (!is_file($file)) {
        @file_put_contents($file, bin2hex(random_bytes(32)));
        @chmod($file, 0600);
    }
    $hex = trim((string)@file_get_contents($file));
    $key = strlen($hex) === 64 ? hex2bin($hex) : hash('sha256', 'sabhyta-fallback-key', true);
    return $key;
}
function erp_encrypt(string $plain): string {
    if ($plain === '') return '';
    if (function_exists('openssl_encrypt') && in_array('aes-256-gcm', openssl_get_cipher_methods(), true)) {
        $iv = random_bytes(12);
        $tag = '';
        $c = openssl_encrypt($plain, 'aes-256-gcm', erp_key(), OPENSSL_RAW_DATA, $iv, $tag);
        if ($c !== false) return 'gcm1:' . base64_encode($iv . $tag . $c);
    }
    return 'b64:' . base64_encode($plain);
}
function erp_decrypt(?string $stored): string {
    if ($stored === null || $stored === '') return '';
    if (strncmp($stored, 'gcm1:', 5) === 0) {
        $raw = base64_decode(substr($stored, 5), true);
        if ($raw === false || strlen($raw) < 28) return '';
        $iv = substr($raw, 0, 12); $tag = substr($raw, 12, 16); $c = substr($raw, 28);
        $p = openssl_decrypt($c, 'aes-256-gcm', erp_key(), OPENSSL_RAW_DATA, $iv, $tag);
        return $p === false ? '' : $p;
    }
    if (strncmp($stored, 'b64:', 4) === 0) return (string)base64_decode(substr($stored, 4));
    return $stored;
}
function erp_mask(string $plain): string {
    if ($plain === '') return '';
    $n = strlen($plain);
    return $n <= 4 ? str_repeat('•', $n) : str_repeat('•', 8) . substr($plain, -4);
}

/* ---------------------------------------------------------
   System settings (adm_system_settings key/value store)
   --------------------------------------------------------- */
function erp_setting_get(PDO $pdo, string $key, $default = null) {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            foreach ($pdo->query("SELECT setting_key, setting_value, is_encrypted FROM adm_system_settings") as $r) {
                $cache[$r['setting_key']] = $r['is_encrypted'] ? erp_decrypt($r['setting_value']) : $r['setting_value'];
            }
        } catch (Exception $e) { $cache = []; }
    }
    return array_key_exists($key, $cache) && $cache[$key] !== null && $cache[$key] !== '' ? $cache[$key] : $default;
}
function erp_setting_set(PDO $pdo, string $group, string $key, string $value, bool $secret = false): void {
    $stored = $secret ? erp_encrypt($value) : $value;
    $st = $pdo->prepare(
        "INSERT INTO adm_system_settings (setting_group, setting_key, setting_value, is_encrypted, updated_by)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE setting_group = VALUES(setting_group), setting_value = VALUES(setting_value),
                                 is_encrypted = VALUES(is_encrypted), updated_by = VALUES(updated_by)"
    );
    $st->execute([$group, $key, $stored, $secret ? 1 : 0, erp_user()['id']]);
}

/* ---------------------------------------------------------
   Password policy (adm_security_rules, rule_type = Password_Policy)
   Each row is "key=value".
   --------------------------------------------------------- */
function erp_policy(PDO $pdo): array {
    $p = ['min_length' => 6, 'require_upper' => 0, 'require_lower' => 0, 'require_number' => 0,
          'require_special' => 0, 'expiry_days' => 0, 'max_login_attempts' => 0, 'lock_minutes' => 15];
    try {
        foreach ($pdo->query("SELECT rule_value FROM adm_security_rules WHERE rule_type = 'Password_Policy' AND is_active = 1") as $r) {
            if (strpos($r['rule_value'], '=') === false) continue;
            [$k, $v] = array_map('trim', explode('=', $r['rule_value'], 2));
            if (array_key_exists($k, $p)) $p[$k] = (int)$v;
        }
    } catch (Exception $e) { /* defaults */ }
    return $p;
}
/** Returns a list of human readable problems (empty = password is acceptable). */
function erp_check_password(PDO $pdo, string $pw): array {
    $p = erp_policy($pdo);
    $bad = [];
    if (strlen($pw) < $p['min_length'])                     $bad[] = 'at least ' . $p['min_length'] . ' characters';
    if ($p['require_upper']   && !preg_match('/[A-Z]/', $pw)) $bad[] = 'an uppercase letter';
    if ($p['require_lower']   && !preg_match('/[a-z]/', $pw)) $bad[] = 'a lowercase letter';
    if ($p['require_number']  && !preg_match('/\d/', $pw))    $bad[] = 'a number';
    if ($p['require_special'] && !preg_match('/[^A-Za-z0-9]/', $pw)) $bad[] = 'a special character';
    return $bad;
}

/* ---------------------------------------------------------
   Chart of Accounts / Journal bridge (Finance integration)
   The existing Accounts module stores Journal vouchers as rows in
   generic_records (module_key accounts__journal) and its Ledger,
   Trial Balance, P&L and Balance Sheet read them from there - so
   posting a row here makes Asset Management flow straight into
   those reports.
   --------------------------------------------------------- */
function erp_coa_account(PDO $pdo, $id): ?array {
    if (!$id) return null;
    $st = $pdo->prepare("SELECT id, title FROM generic_records WHERE id = ? AND module_key = 'accounts__chart-of-accounts'");
    $st->execute([(int)$id]);
    $r = $st->fetch();
    return $r ?: null;
}
function erp_fin_map(PDO $pdo): array {
    $keys = ['fin_fixed_asset_acct','fin_accum_dep_acct','fin_dep_expense_acct','fin_maint_expense_acct',
             'fin_loss_disposal_acct','fin_gain_disposal_acct','fin_default_credit_acct','fin_cash_acct'];
    $m = [];
    foreach ($keys as $k) { $v = erp_setting_get($pdo, $k); $m[$k] = $v ? (int)$v : null; }
    return $m;
}
/** Post a double-entry Journal voucher. Returns generic_records.id or null when accounts are missing. */
function erp_post_journal(PDO $pdo, string $date, ?int $debitId, ?int $creditId, float $amount, string $narration, string $ref = ''): ?int {
    if ($amount <= 0) return null;
    $dr = erp_coa_account($pdo, $debitId);
    $cr = erp_coa_account($pdo, $creditId);
    if (!$dr || !$cr) return null;
    $extra = [
        'date' => $date,
        'debitAccount' => (string)$dr['id'],  'debitAccount_label'  => $dr['title'],
        'creditAccount' => (string)$cr['id'], 'creditAccount_label' => $cr['title'],
        'amount' => (string)round($amount, 2), 'costCenter' => '', 'project' => '',
        'narration' => $narration, 'approvedBy' => '',
        'source' => 'Asset Management', 'reference' => $ref,
    ];
    $st = $pdo->prepare(
        "INSERT INTO generic_records (module_key, module_label, title, party_name, assigned_to, record_date, amount, status, notes, extra_data)
         VALUES ('accounts__journal', 'Journal', ?, ?, '', ?, ?, 'Active', ?, ?)"
    );
    $st->execute([$dr['title'], $cr['title'], $date, round($amount, 2), $narration, json_encode($extra, JSON_UNESCAPED_UNICODE)]);
    return (int)$pdo->lastInsertId();
}

/* ---------------------------------------------------------
   Misc
   --------------------------------------------------------- */
function erp_now(): string { return date('Y-m-d H:i:s'); }
function erp_today(): string { return date('Y-m-d'); }
function erp_csv_out(string $filename, array $headers, array $rows): void {
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . str_replace('"', '', $filename) . '"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, $headers);
    foreach ($rows as $r) fputcsv($out, $r);
    fclose($out);
    exit;
}
function erp_json_body(): array {
    static $b = null;
    if ($b === null) {
        $raw = file_get_contents('php://input');
        $b = $raw !== '' ? (json_decode($raw, true) ?: []) : [];
    }
    return $b;
}
/** Merge multipart/urlencoded fields with a JSON body (JSON wins if both). */
function erp_input(): array { return array_merge($_POST, erp_json_body()); }
