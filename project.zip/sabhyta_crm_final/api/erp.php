<?php
/**
 * ERP API - one endpoint for Marketing, Project Management, Asset Management,
 * Document Management and Administration.
 * --------------------------------------------------------
 * GET  erp.php?action=meta
 * GET  erp.php?action=list&entity=KEY[&q=][&f_<field>=][&page=][&per=]
 * GET  erp.php?action=get&entity=KEY&id=N
 * POST erp.php?action=save&entity=KEY[&id=N]      (multipart/form-data or JSON)
 * POST erp.php?action=delete&entity=KEY&id=N
 * GET  erp.php?action=lookup&src=NAME[&q=][&a_<attr>=]
 * GET  erp.php?action=export&entity=KEY           (CSV)
 * GET  erp.php?action=file&entity=KEY&id=N&field=F
 * ...plus module actions (act_<name>) defined in erp_*.php
 * --------------------------------------------------------
 */

require_once 'session_guard.php';
require_once 'db.php';
require_once 'schema_compat.php';
require_once 'erp_core.php';
require_once 'erp_registry.php';
require_once 'erp_marketing.php';
require_once 'erp_projects.php';
require_once 'erp_assets.php';
require_once 'erp_documents.php';
require_once 'erp_admin.php';

header('Content-Type: application/json; charset=utf-8');

try {
    erp_ensure_schema($pdo);
    $st = $pdo->prepare("SELECT status FROM users WHERE id = ?");
    $st->execute([erp_user()['id']]);
    if ($st->fetchColumn() === 'Suspended') erp_fail('Your account has been suspended. Contact an administrator.', 403);
    erp_dispatch($pdo);
} catch (PDOException $e) {
    $no = (int)($e->errorInfo[1] ?? 0);
    if ($no === 1451) erp_fail('This record is still used by other records, so it cannot be deleted.', 409);
    if ($no === 1452) erp_fail('A related record you selected no longer exists. Please refresh and try again.', 409);
    if ($no === 1062) erp_fail('A record with the same unique value (such as a code, tag or name) already exists.', 409);
    if ($no === 1265 || $no === 1366 || $no === 1292) erp_fail('One of the values has an invalid format: ' . $e->getMessage(), 422);
    erp_fail('Database error: ' . $e->getMessage(), 500);
} catch (Throwable $e) {
    erp_fail('Server error: ' . $e->getMessage(), 500);
}

/* ========================================================= */

function erp_dispatch(PDO $pdo): void {
    $action = $_GET['action'] ?? $_POST['action'] ?? '';
    switch ($action) {
        case 'meta':      erp_ok(erp_meta());
        case 'list':      erp_action_list($pdo);
        case 'get':       erp_action_get($pdo);
        case 'save':      erp_action_save($pdo);
        case 'delete':    erp_action_delete($pdo);
        case 'lookup':    erp_action_lookup($pdo);
        case 'export':    erp_action_export($pdo);
        case 'file':      erp_action_file($pdo);
        case 'overview':  erp_action_overview($pdo);
    }
    $fn = 'act_' . preg_replace('/[^a-z0-9_]/i', '', $action);
    if ($action !== '' && function_exists($fn)) { $fn($pdo); exit; }
    erp_fail('Unknown action.', 400);
}

function erp_entity(string $key): array {
    $all = erp_entities();
    if (!isset($all[$key])) erp_fail('Unknown entity.', 400);
    if (!empty($all[$key]['adminOnly'])) erp_require_admin();
    return $all[$key];
}
function erp_field(array $E, string $k): ?array {
    foreach ($E['fields'] as $f) if ($f['k'] === $k) return $f;
    return null;
}
function erp_table_cols(PDO $pdo, string $table): array { return sc_columns($pdo, $table); }

/* ---------------------------------------------------------
   LIST
   --------------------------------------------------------- */
function erp_list_query(PDO $pdo, array $E, array $q, bool $paged = true): array {
    $pk = $E['pk'];
    $sel = ["t.*", "t.$pk AS id"];
    foreach ($E['select'] ?? [] as $s) $sel[] = $s;

    $where = []; $params = [];
    if (!empty($E['where'])) $where[] = '(' . $E['where'] . ')';

    $term = trim((string)($q['q'] ?? ''));
    if ($term !== '' && !empty($E['search'])) {
        $parts = [];
        foreach ($E['search'] as $col) { $parts[] = "$col LIKE ?"; $params[] = '%' . $term . '%'; }
        $where[] = '(' . implode(' OR ', $parts) . ')';
    }
    $cols = erp_table_cols($pdo, $E['table']);
    foreach ($q as $name => $val) {
        if (strncmp($name, 'f_', 2) !== 0 || $val === '' || $val === null) continue;
        $k = substr($name, 2);
        $f = erp_field($E, $k);
        $col = null;
        if ($f && !empty($f['col'])) $col = $f['col'];
        elseif (in_array($k, $cols, true)) $col = "t.`$k`";
        if (!$col) continue;
        $where[] = "$col = ?"; $params[] = $val;
    }
    if (!empty($E['dateField'])) {
        if (!empty($q['from'])) { $where[] = "DATE({$E['dateField']}) >= ?"; $params[] = $q['from']; }
        if (!empty($q['to']))   { $where[] = "DATE({$E['dateField']}) <= ?"; $params[] = $q['to']; }
    }
    $w = $where ? ' WHERE ' . implode(' AND ', $where) : '';
    $from = $E['from'];

    $total = null;
    if ($paged) {
        $c = $pdo->prepare("SELECT COUNT(*) FROM $from$w"); $c->execute($params);
        $total = (int)$c->fetchColumn();
    }
    $sql = 'SELECT ' . implode(', ', $sel) . " FROM $from$w ORDER BY " . ($E['order'] ?? "t.$pk DESC");
    if ($paged) {
        $per  = max(1, min(200, (int)($q['per'] ?? 25)));
        $page = max(1, (int)($q['page'] ?? 1));
        $sql .= ' LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per);
    }
    return [$sql, $params, $total];
}

function erp_clean_rows(array $E, array $rows, bool $forList): array {
    $secret = $E['secret'] ?? [];
    $maskCols = [];
    if ($forList) foreach ($E['list'] as $c) if (($c[2] ?? '') === 'masked') $maskCols[] = $c[0];
    foreach ($rows as &$r) {
        foreach ($secret as $s) if (array_key_exists($s, $r)) $r[$s] = '';
        foreach ($maskCols as $m) if (!empty($r[$m])) $r[$m] = erp_mask((string)$r[$m]);
    }
    unset($r);
    return $rows;
}

function erp_action_list(PDO $pdo): void {
    $E = erp_entity($_GET['entity'] ?? '');
    if (!empty($E['prepareList']) && function_exists($E['prepareList'])) ($E['prepareList'])($pdo);
    if (!empty($E['handlers']['list'])) {
        [$rows, $total] = ($E['handlers']['list'])($pdo, $E, $_GET);
    } else {
        [$sql, $params, $total] = erp_list_query($pdo, $E, $_GET);
        $st = $pdo->prepare($sql); $st->execute($params);
        $rows = $st->fetchAll();
        if (!empty($E['decorate']) && function_exists($E['decorate'])) $rows = ($E['decorate'])($pdo, $rows);
    }
    $rows = erp_clean_rows($E, $rows, true);
    $per = max(1, min(200, (int)($_GET['per'] ?? 25)));
    erp_ok($rows, ['total' => $total, 'page' => max(1, (int)($_GET['page'] ?? 1)), 'per' => $per]);
}

/* ---------------------------------------------------------
   GET ONE
   --------------------------------------------------------- */
function erp_fetch_row(PDO $pdo, array $E, int $id): ?array {
    $pk = $E['pk'];
    $sel = ["t.*", "t.$pk AS id"];
    foreach ($E['select'] ?? [] as $s) $sel[] = $s;
    $sql = 'SELECT ' . implode(', ', $sel) . ' FROM ' . $E['from'] . " WHERE t.$pk = ?";
    $st = $pdo->prepare($sql); $st->execute([$id]);
    $row = $st->fetch();
    if (!$row) return null;
    if (!empty($E['decorate']) && function_exists($E['decorate'])) $row = ($E['decorate'])($pdo, [$row])[0];
    return $row;
}
function erp_action_get(PDO $pdo): void {
    $E = erp_entity($_GET['entity'] ?? '');
    $id = (int)($_GET['id'] ?? 0);
    $row = !empty($E['handlers']['get']) ? ($E['handlers']['get'])($pdo, $E, $id) : erp_fetch_row($pdo, $E, $id);
    if (!$row) erp_fail('Record not found.', 404);
    $row = erp_clean_rows($E, [$row], false)[0];
    erp_ok($row);
}

/* ---------------------------------------------------------
   COERCION / VALIDATION
   --------------------------------------------------------- */
function erp_lookup_exists(PDO $pdo, string $src, int $id): bool {
    $L = erp_lookups();
    if (!isset($L[$src])) return true;
    $l = $L[$src];
    $sql = 'SELECT 1 FROM ' . $l['from'] . ' WHERE ' . $l['id'] . ' = ?' . (!empty($l['where']) ? ' AND ' . $l['where'] : '') . ' LIMIT 1';
    $st = $pdo->prepare($sql); $st->execute([$id]);
    return (bool)$st->fetchColumn();
}

/** Returns [value, error|null] */
function erp_coerce(PDO $pdo, array $f, $raw): array {
    $t = $f['t']; $label = $f['l'];
    if (is_array($raw) && empty($f['multi'])) $raw = reset($raw);
    if ($t === 'bool') {
        $v = is_string($raw) ? strtolower(trim($raw)) : $raw;
        return [in_array($v, [1, '1', true, 'true', 'on', 'yes', 'y'], true) ? 1 : 0, null];
    }
    if (is_string($raw)) $raw = trim($raw);
    if ($raw === '' || $raw === null) return [null, null];

    switch ($t) {
        case 'text': case 'textarea': case 'combo': case 'password': case 'file':
            $s = (string)$raw;
            if (!empty($f['max']) && mb_strlen($s) > $f['max']) return [null, "$label must be at most {$f['max']} characters."];
            return [$s, null];
        case 'email':
            if (!filter_var($raw, FILTER_VALIDATE_EMAIL)) return [null, "$label must be a valid email address."];
            return [(string)$raw, null];
        case 'url':
            if (!preg_match('~^https?://[^\s]+$~i', (string)$raw)) return [null, "$label must be a full URL starting with http:// or https://"];
            return [(string)$raw, null];
        case 'tel':
            if (!preg_match('/^[+0-9()\-.\s]{5,30}$/', (string)$raw)) return [null, "$label must be a valid phone number."];
            return [(string)$raw, null];
        case 'number':
            if (!preg_match('/^-?\d+$/', (string)$raw)) return [null, "$label must be a whole number."];
            $n = (int)$raw;
            if (isset($f['min']) && $n < $f['min']) return [null, "$label must be at least {$f['min']}."];
            if (isset($f['max']) && $n > $f['max']) return [null, "$label must be at most {$f['max']}."];
            return [$n, null];
        case 'decimal':
            if (!is_numeric($raw)) return [null, "$label must be a number."];
            $n = (float)$raw;
            if (isset($f['min']) && $n < $f['min']) return [null, "$label must be at least {$f['min']}."];
            if (isset($f['max']) && $n > $f['max']) return [null, "$label must be at most {$f['max']}."];
            return [$n, null];
        case 'date':
            $d = DateTime::createFromFormat('Y-m-d', substr((string)$raw, 0, 10));
            if (!$d || $d->format('Y-m-d') !== substr((string)$raw, 0, 10)) return [null, "$label must be a valid date."];
            return [$d->format('Y-m-d'), null];
        case 'datetime':
            $s = str_replace('T', ' ', (string)$raw);
            foreach (['Y-m-d H:i:s', 'Y-m-d H:i'] as $fmt) {
                $d = DateTime::createFromFormat($fmt, $s);
                if ($d && $d->format($fmt) === $s) return [$d->format('Y-m-d H:i:s'), null];
            }
            return [null, "$label must be a valid date and time."];
        case 'select':
            if (!in_array((string)$raw, array_map('strval', $f['opts'] ?? []), true)) return [null, "$label has an invalid value."];
            return [(string)$raw, null];
        case 'lookup':
            if (!empty($f['multi'])) {
                $ids = array_values(array_unique(array_filter(array_map('intval', (array)$raw))));
                foreach ($ids as $i) if (!erp_lookup_exists($pdo, $f['src'], $i)) return [null, "$label contains a record that no longer exists."];
                return [$ids, null];
            }
            if (!preg_match('/^\d+$/', (string)$raw) || (int)$raw < 1) return [null, "$label is invalid."];
            if (!erp_lookup_exists($pdo, $f['src'], (int)$raw)) return [null, "The selected $label no longer exists."];
            return [(int)$raw, null];
    }
    return [$raw, null];
}

/* ---------------------------------------------------------
   SAVE
   --------------------------------------------------------- */
function erp_action_save(PDO $pdo): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') erp_fail('POST required.', 405);
    $E = erp_entity($_GET['entity'] ?? $_POST['entity'] ?? '');
    if (!empty($E['readOnly'])) erp_fail('This list is read-only.', 403);
    $id = isset($_GET['id']) ? (int)$_GET['id'] : (isset($_POST['id']) ? (int)$_POST['id'] : 0);
    $in = erp_input();

    if (!empty($E['handlers']['save'])) {
        $res = ($E['handlers']['save'])($pdo, $E, $id ?: null, $in);
    } elseif (!empty($E['saveOverride'])) {
        $res = ($E['saveOverride'])($pdo, $E, $id ?: null, $in);
    } else {
        $res = erp_save_entity($pdo, $E, $id ?: null, $in);
    }
    erp_ok($res['row'] ?? null, ['id' => $res['id'] ?? null, 'notices' => $res['notices'] ?? [], 'message' => $res['message'] ?? 'Saved.']);
}

function erp_save_entity(PDO $pdo, array $E, ?int $id, array $in): array {
    $pk = $E['pk'];
    $old = null;
    if ($id) {
        $old = erp_fetch_row($pdo, $E, $id);
        if (!$old) erp_fail('Record not found.', 404);
    }
    $data = []; $errors = []; $newFiles = []; $oldFiles = [];

    foreach ($E['fields'] as $f) {
        $k = $f['k'];
        if (!empty($f['virtual']) || !empty($f['ro'])) continue;

        if ($f['t'] === 'file') {
            $info = erp_save_upload($k, $f['sub'] ?? 'uploads', $f['ext'] ?? ERP_DOC_EXT);
            if ($info) {
                $data[$k] = $info['path']; $newFiles[] = $info['path'];
                if (!empty($f['fileMeta']['name'])) $data[$f['fileMeta']['name']] = $info['name'];
                if (!empty($f['fileMeta']['size'])) $data[$f['fileMeta']['size']] = $info['size'];
                if ($old && !empty($old[$k])) $oldFiles[] = $old[$k];
            } elseif (!empty($in['remove_' . $k]) && $old && !empty($old[$k])) {
                $data[$k] = null; $oldFiles[] = $old[$k];
            }
            continue;
        }
        if (!array_key_exists($k, $in)) {
            if (!$id && array_key_exists('def', $f)) $data[$k] = $f['def'];
            continue;
        }
        [$val, $err] = erp_coerce($pdo, $f, $in[$k]);
        if ($err) { $errors[] = $err; continue; }
        if ($f['t'] === 'password') {           // secret: blank = keep the saved value
            if ($val === null) continue;
            $val = erp_encrypt($val);
        }
        $data[$k] = $val;
    }

    // required fields
    foreach ($E['fields'] as $f) {
        if (empty($f['req']) || !empty($f['virtual']) || !empty($f['ro'])) continue;
        $k = $f['k'];
        $has = array_key_exists($k, $data) ? ($data[$k] !== null && $data[$k] !== '')
                                           : ($old && isset($old[$k]) && $old[$k] !== '');
        if (!$has) $errors[] = $f['l'] . ' is required.';
    }
    // unique fields
    foreach ($E['fields'] as $f) {
        if (empty($f['unique']) || empty($data[$f['k']])) continue;
        $st = $pdo->prepare("SELECT 1 FROM {$E['table']} WHERE `{$f['k']}` = ? AND `$pk` <> ? LIMIT 1");
        $st->execute([$data[$f['k']], $id ?: 0]);
        if ($st->fetchColumn()) $errors[] = $f['l'] . ' "' . $data[$f['k']] . '" is already in use.';
    }
    if ($errors) { foreach ($newFiles as $p) erp_delete_file($p); erp_fail(implode(' ', array_unique($errors)), 422, ['errors' => $errors]); }

    $notices = [];
    try {
        $pdo->beginTransaction();
        if (!empty($E['before']) && function_exists($E['before'])) ($E['before'])($pdo, $data, $old, $in);

        $cols = erp_table_cols($pdo, $E['table']);
        if (!$id && in_array('created_by', $cols, true) && !isset($data['created_by'])) $data['created_by'] = erp_user()['id'];
        $data = array_filter($data, fn($k) => in_array($k, $cols, true) && $k !== $pk, ARRAY_FILTER_USE_KEY);

        if ($id) {
            if ($data) {
                $set = implode(', ', array_map(fn($c) => "`$c` = ?", array_keys($data)));
                $pdo->prepare("UPDATE {$E['table']} SET $set WHERE `$pk` = ?")->execute(array_merge(array_values($data), [$id]));
            }
        } else {
            if (!$data) erp_fail('Nothing to save.');
            $cs = implode(', ', array_map(fn($c) => "`$c`", array_keys($data)));
            $ph = implode(', ', array_fill(0, count($data), '?'));
            $pdo->prepare("INSERT INTO {$E['table']} ($cs) VALUES ($ph)")->execute(array_values($data));
            $id = (int)$pdo->lastInsertId();
        }
        if (!empty($E['after']) && function_exists($E['after'])) {
            $r = ($E['after'])($pdo, $id, $data, $old, $in);
            if (is_array($r)) $notices = $r;
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        foreach ($newFiles as $p) erp_delete_file($p);
        throw $e;
    }
    foreach ($oldFiles as $p) erp_delete_file($p);

    return ['id' => $id, 'row' => erp_clean_rows($E, [erp_fetch_row($pdo, $E, $id)], false)[0], 'notices' => $notices];
}

/* ---------------------------------------------------------
   DELETE
   --------------------------------------------------------- */
function erp_action_delete(PDO $pdo): void {
    if (!in_array($_SERVER['REQUEST_METHOD'], ['POST', 'DELETE'], true)) erp_fail('POST required.', 405);
    $E = erp_entity($_GET['entity'] ?? '');
    if (!empty($E['readOnly'])) erp_fail('This list is read-only.', 403);
    $id = (int)($_GET['id'] ?? 0);
    if (!empty($E['handlers']['delete'])) { ($E['handlers']['delete'])($pdo, $E, $id); erp_ok(null, ['message' => 'Deleted.']); }

    $old = erp_fetch_row($pdo, $E, $id);
    if (!$old) erp_fail('Record not found.', 404);
    try {
        $pdo->beginTransaction();
        if (!empty($E['beforeDelete']) && function_exists($E['beforeDelete'])) ($E['beforeDelete'])($pdo, $id, $old);
        $pdo->prepare("DELETE FROM {$E['table']} WHERE `{$E['pk']}` = ?")->execute([$id]);
        if (!empty($E['afterDelete']) && function_exists($E['afterDelete'])) ($E['afterDelete'])($pdo, $id, $old);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    foreach ($E['fields'] as $f) if ($f['t'] === 'file' && !empty($old[$f['k']])) erp_delete_file($old[$f['k']]);
    erp_ok(null, ['message' => 'Deleted.']);
}

/* ---------------------------------------------------------
   LOOKUP (dropdown data)
   --------------------------------------------------------- */
function erp_action_lookup(PDO $pdo): void {
    $L = erp_lookups();
    $src = $_GET['src'] ?? '';
    if (!isset($L[$src])) erp_fail('Unknown lookup.', 400);
    $l = $L[$src];
    $sel = [$l['id'] . ' AS id', $l['label'] . ' AS label'];
    foreach ($l['attrs'] ?? [] as $name => $expr) $sel[] = "$expr AS `$name`";
    $where = []; $params = [];
    if (!empty($l['where'])) $where[] = $l['where'];
    foreach ($_GET as $k => $v) {
        if (strncmp($k, 'a_', 2) !== 0 || $v === '') continue;
        $attr = substr($k, 2);
        if (isset($l['attrs'][$attr])) { $where[] = $l['attrs'][$attr] . ' = ?'; $params[] = $v; }
    }
    if ($src === 'assets' && !empty($_GET['avail'])) {
        $where[] = "(t.status = 'In Stock' OR (t.asset_type = 'Software' AND t.status <> 'Retired'))";
    }
    if ($src === 'assets' && !empty($_GET['not_retired'])) $where[] = "t.status <> 'Retired'";
    if (!empty($_GET['q'])) { $where[] = '(' . $l['label'] . ') LIKE ?'; $params[] = '%' . $_GET['q'] . '%'; }
    $sql = 'SELECT ' . implode(', ', $sel) . ' FROM ' . $l['from'] . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
         . ' ORDER BY ' . ($l['order'] ?? '2') . ' LIMIT 2000';
    $st = $pdo->prepare($sql); $st->execute($params);
    erp_ok($st->fetchAll());
}

/* ---------------------------------------------------------
   EXPORT (CSV of the current filter)
   --------------------------------------------------------- */
function erp_action_export(PDO $pdo): void {
    $E = erp_entity($_GET['entity'] ?? '');
    if (!empty($E['handlers']['list'])) {
        $q = $_GET; $q['per'] = 200; $q['page'] = 1;
        [$rows] = ($E['handlers']['list'])($pdo, $E, $q);
    } else {
        [$sql, $params] = erp_list_query($pdo, $E, $_GET, false);
        $st = $pdo->prepare($sql . ' LIMIT 20000'); $st->execute($params);
        $rows = $st->fetchAll();
        if (!empty($E['decorate']) && function_exists($E['decorate'])) $rows = ($E['decorate'])($pdo, $rows);
    }
    $rows = erp_clean_rows($E, $rows, true);
    $head = array_map(fn($c) => $c[1], $E['list']);
    $out = [];
    foreach ($rows as $r) $out[] = array_map(fn($c) => $r[$c[0]] ?? '', $E['list']);
    erp_csv_out(strtolower(preg_replace('/\W+/', '_', $E['plural'])) . '_' . date('Ymd') . '.csv', $head, $out);
}

/* ---------------------------------------------------------
   FILE (stream a stored file field - authenticated)
   --------------------------------------------------------- */
function erp_action_file(PDO $pdo): void {
    $E = erp_entity($_GET['entity'] ?? '');
    $id = (int)($_GET['id'] ?? 0);
    $fk = $_GET['field'] ?? ($E['download'] ?? '');
    $f = erp_field($E, $fk);
    if (!$f || $f['t'] !== 'file') erp_fail('No such file field.', 400);
    $row = erp_fetch_row($pdo, $E, $id);
    if (!$row || empty($row[$fk])) erp_fail('File not found.', 404);
    $abs = erp_abs_path($row[$fk]);
    if (!$abs) erp_fail('The file is missing on the server.', 404);
    $name = !empty($E['downloadName']) && !empty($row[$E['downloadName']]) ? $row[$E['downloadName']] : basename($abs);
    erp_send_file($abs, $name, !empty($_GET['inline']));
}

/* ---------------------------------------------------------
   OVERVIEW COUNTS (for the section overview cards)
   --------------------------------------------------------- */
function erp_action_overview(PDO $pdo): void {
    $c = function (string $sql) use ($pdo) { try { return (int)$pdo->query($sql)->fetchColumn(); } catch (Throwable $e) { return 0; } };
    $g = function (string $key) use ($c) { return $c("SELECT COUNT(*) FROM generic_records WHERE module_key = '$key'"); };
    $assetType = fn($t) => $c("SELECT COUNT(*) FROM am_assets WHERE asset_type = '$t'");
    $doc = fn($cat) => $c("SELECT COUNT(*) FROM dms_documents WHERE category = '$cat'");
    $data = [
        'CRM' => [
            'Email Campaign' => $c('SELECT COUNT(*) FROM mk_email_campaigns'), 'SMS Campaign' => $c('SELECT COUNT(*) FROM mk_sms_campaigns'),
            'WhatsApp Campaign' => $c('SELECT COUNT(*) FROM mk_whatsapp_campaigns'), 'Social Media' => $c('SELECT COUNT(*) FROM mk_social_campaigns'),
            'Campaign Analytics' => $c('SELECT COUNT(*) FROM mk_performance'),
        ],
        'Project Management' => [
            'Projects' => $c('SELECT COUNT(*) FROM pm_projects'), 'Create Project' => $c('SELECT COUNT(*) FROM pm_projects'),
            'Milestones' => $c('SELECT COUNT(*) FROM pm_milestones'), 'Modules' => $c('SELECT COUNT(*) FROM pm_modules'),
            'Tasks' => $c('SELECT COUNT(*) FROM pm_tasks'), 'Sub Tasks' => $c('SELECT COUNT(*) FROM pm_sub_tasks'),
            'Assign Team' => $c('SELECT COUNT(*) FROM pm_team_assignments'), 'Time Tracking' => $c('SELECT COUNT(*) FROM pm_time_tracking'),
            'Gantt Chart' => $c('SELECT COUNT(*) FROM pm_projects'), 'Files' => $c('SELECT COUNT(*) FROM pm_files'),
            'Client Approval' => $c('SELECT COUNT(*) FROM pm_client_approvals'), 'Testing' => $c('SELECT COUNT(*) FROM pm_testing_bugs'),
            'Deployment' => $c('SELECT COUNT(*) FROM pm_deployments'), 'Maintenance' => $c('SELECT COUNT(*) FROM pm_maintenance'),
            'Project Reports' => $c('SELECT COUNT(*) FROM pm_projects'),
        ],
        'Asset Management' => [
            'Company Assets' => $c('SELECT COUNT(*) FROM am_assets'), 'Laptop' => $assetType('Laptop'), 'Desktop' => $assetType('Desktop'),
            'Printer' => $assetType('Printer'), 'Server' => $assetType('Server'), 'Software License' => $c('SELECT COUNT(*) FROM am_software_licenses'),
            'Asset Allocation' => $c('SELECT COUNT(*) FROM am_asset_allocations'), 'Maintenance' => $c('SELECT COUNT(*) FROM am_maintenance_logs'),
            'Asset History' => $c('SELECT COUNT(*) FROM am_asset_history'),
        ],
        'Document Management' => [
            'Contracts' => $doc('Contract'), 'NDA' => $doc('NDA'), 'Agreements' => $doc('Agreement'), 'Proposal' => $doc('Proposal'),
            'Company Documents' => $doc('Company'), 'Employee Documents' => $doc('Employee'), 'Client Documents' => $doc('Client'),
            'Version Control' => $c('SELECT COUNT(*) FROM dms_document_versions'),
        ],
        'Administration' => [
            'Users' => $c('SELECT COUNT(*) FROM users'), 'Roles' => $c('SELECT COUNT(*) FROM roles'), 'Permissions' => $c('SELECT COUNT(*) FROM permissions'),
            'Branch' => $g('master__branch'),
            'Company Settings' => $c("SELECT COUNT(*) FROM adm_system_settings WHERE setting_group IN ('Company','Finance')"),
            'Email Settings' => $c("SELECT COUNT(*) FROM adm_system_settings WHERE setting_group = 'Email'"),
            'SMS Gateway' => $c("SELECT COUNT(*) FROM adm_system_settings WHERE setting_group = 'SMS'"),
            'WhatsApp API' => $c("SELECT COUNT(*) FROM adm_system_settings WHERE setting_group = 'WhatsApp'"),
            'Payment Gateway' => $c("SELECT COUNT(*) FROM adm_system_settings WHERE setting_group = 'Payment'"),
            'Backup' => $c('SELECT COUNT(*) FROM adm_backup_history'), 'Audit Logs' => $c('SELECT COUNT(*) FROM adm_audit_logs'),
            'Security' => $c('SELECT COUNT(*) FROM adm_security_rules'),
        ],
    ];
    // de-duplicated record totals per section (several leaves show the same table)
    $data['CRM']['_total'] = $c('SELECT (SELECT COUNT(*) FROM mk_email_campaigns)+(SELECT COUNT(*) FROM mk_sms_campaigns)+(SELECT COUNT(*) FROM mk_whatsapp_campaigns)+(SELECT COUNT(*) FROM mk_social_campaigns)+(SELECT COUNT(*) FROM mk_performance)');
    $data['Project Management']['_total'] = $c('SELECT (SELECT COUNT(*) FROM pm_projects)+(SELECT COUNT(*) FROM pm_milestones)+(SELECT COUNT(*) FROM pm_modules)+(SELECT COUNT(*) FROM pm_tasks)+(SELECT COUNT(*) FROM pm_sub_tasks)+(SELECT COUNT(*) FROM pm_team_assignments)+(SELECT COUNT(*) FROM pm_time_tracking)+(SELECT COUNT(*) FROM pm_files)+(SELECT COUNT(*) FROM pm_client_approvals)+(SELECT COUNT(*) FROM pm_testing_bugs)+(SELECT COUNT(*) FROM pm_deployments)+(SELECT COUNT(*) FROM pm_maintenance)');
    $data['Asset Management']['_total'] = $c('SELECT (SELECT COUNT(*) FROM am_assets)+(SELECT COUNT(*) FROM am_software_licenses)+(SELECT COUNT(*) FROM am_asset_allocations)+(SELECT COUNT(*) FROM am_maintenance_logs)');
    $data['Document Management']['_total'] = $c('SELECT COUNT(*) FROM dms_documents');
    $data['Administration']['_total'] = $c('SELECT (SELECT COUNT(*) FROM users)+(SELECT COUNT(*) FROM adm_backup_history)+(SELECT COUNT(*) FROM adm_security_rules)') + $g('master__branch');
    $data['Marketing'] = $data['CRM'];
    erp_ok($data);
}
