<?php
/**
 * Departments REST API (HRMS > Department)
 * --------------------------------------------------------
 * GET    /api/departments.php             -> list all
 * GET    /api/departments.php?id=5        -> get one
 * POST   /api/departments.php             -> create
 * POST   /api/departments.php (id + _method=PUT) -> update
 * DELETE /api/departments.php?id=5        -> delete
 * --------------------------------------------------------
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

$FIELDS = [
    'department_code'      => 'departmentCode',
    'department_name'      => 'departmentName',
    'department_head_id'   => 'departmentHeadId',
    'parent_department_id' => 'parentDepartmentId',
    'description'           => 'description',
    'status'                => 'status',
];

if ($method === 'GET') {
    if (!empty($_GET['id'])) {
        $stmt = $pdo->prepare("SELECT * FROM departments WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        $row = $stmt->fetch();
        if (!$row) respond(["success" => false, "message" => "Department not found"], 404);
        respond(["success" => true, "data" => $row]);
    }
    $stmt = $pdo->query("SELECT d.*,
                                 CONCAT(e.first_name, ' ', COALESCE(e.last_name,'')) AS department_head_name,
                                 (SELECT COUNT(*) FROM employees WHERE department_id = d.id) AS employee_count
                          FROM departments d
                          LEFT JOIN employees e ON e.id = d.department_head_id
                          ORDER BY d.created_at DESC");
    respond(["success" => true, "data" => $stmt->fetchAll()]);
}

if ($method === 'POST') {
    $isUpdate = !empty($_POST['id']) && (($_POST['_method'] ?? '') === 'PUT');

    foreach (['departmentCode', 'departmentName'] as $required) {
        if (empty($_POST[$required])) {
            respond(["success" => false, "message" => "Missing required field: $required"], 422);
        }
    }

    $data = [];
    foreach ($FIELDS as $col => $formName) {
        $data[$col] = $_POST[$formName] ?? null;
        if ($data[$col] === '') $data[$col] = null;
    }

    try {
        if ($isUpdate) {
            $id = $_POST['id'];
            $setSql = implode(', ', array_map(fn($c) => "$c = :$c", array_keys($data)));
            $stmt = $pdo->prepare("UPDATE departments SET $setSql WHERE id = :id");
            $data['id'] = $id;
            $stmt->execute($data);
            respond(["success" => true, "message" => "Department updated", "id" => $id]);
        } else {
            $cols = implode(', ', array_keys($data));
            $placeholders = implode(', ', array_map(fn($c) => ":$c", array_keys($data)));
            $stmt = $pdo->prepare("INSERT INTO departments ($cols) VALUES ($placeholders)");
            $stmt->execute($data);
            respond(["success" => true, "message" => "Department created", "id" => $pdo->lastInsertId()], 201);
        }
    } catch (PDOException $e) {
        $msg = $e->getCode() === '23000'
            ? "Department Code already exists. Please use a unique code."
            : "Database error: " . $e->getMessage();
        respond(["success" => false, "message" => $msg], 400);
    }
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? null;
    if (!$id) respond(["success" => false, "message" => "Missing id"], 422);
    $stmt = $pdo->prepare("DELETE FROM departments WHERE id = ?");
    $stmt->execute([$id]);
    respond(["success" => true, "message" => "Department deleted"]);
}

respond(["success" => false, "message" => "Method not allowed"], 405);
