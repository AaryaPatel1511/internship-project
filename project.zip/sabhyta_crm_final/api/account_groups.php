<?php
/**
 * Account Groups REST API (Master > Account Group)
 * --------------------------------------------------------
 * This is the master behind the Account Group / Sub Group cascading
 * dropdown used across every Accounts form (Chart of Accounts, Income,
 * Expenses, Purchase, Journal, Vendor, Bank, Cash, GST, TDS...).
 *
 * GET /api/account_groups.php                    -> full list
 * GET /api/account_groups.php?distinct=groups     -> unique group names (+ account_type)
 * GET /api/account_groups.php?group=Bank          -> sub groups for that group
 * GET /api/account_groups.php?id=5                -> get one
 * POST /api/account_groups.php                    -> create custom group/subgroup
 * POST /api/account_groups.php (id + _method=PUT) -> update
 * DELETE /api/account_groups.php?id=5             -> delete (blocked for is_system rows)
 * --------------------------------------------------------
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

if ($method === 'GET') {
    if (!empty($_GET['id'])) {
        $stmt = $pdo->prepare("SELECT * FROM account_groups WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        $row = $stmt->fetch();
        if (!$row) respond(["success" => false, "message" => "Account Group not found"], 404);
        respond(["success" => true, "data" => $row]);
    }

    if (!empty($_GET['distinct']) && $_GET['distinct'] === 'groups') {
        $stmt = $pdo->query("SELECT group_name, account_type, MIN(category) AS category
                              FROM account_groups WHERE status = 'Active'
                              GROUP BY group_name, account_type
                              ORDER BY account_type, group_name");
        respond(["success" => true, "data" => $stmt->fetchAll()]);
    }

    if (!empty($_GET['group'])) {
        $stmt = $pdo->prepare("SELECT * FROM account_groups WHERE group_name = ? AND status = 'Active' ORDER BY sub_group_name");
        $stmt->execute([$_GET['group']]);
        respond(["success" => true, "data" => $stmt->fetchAll()]);
    }

    $stmt = $pdo->query("SELECT * FROM account_groups ORDER BY account_type, category, group_name, sub_group_name");
    respond(["success" => true, "data" => $stmt->fetchAll()]);
}

if ($method === 'POST') {
    $isUpdate = !empty($_POST['id']) && (($_POST['_method'] ?? '') === 'PUT');

    foreach (['accountType', 'groupName', 'subGroupName'] as $required) {
        if (empty($_POST[$required])) {
            respond(["success" => false, "message" => "Missing required field: $required"], 422);
        }
    }

    $data = [
        'account_type'   => $_POST['accountType'],
        'category'       => $_POST['category'] ?? 'Custom',
        'group_name'     => $_POST['groupName'],
        'sub_group_name' => $_POST['subGroupName'],
        'status'         => $_POST['status'] ?? 'Active',
    ];

    try {
        if ($isUpdate) {
            $id = $_POST['id'];
            $chk = $pdo->prepare("SELECT is_system FROM account_groups WHERE id = ?");
            $chk->execute([$id]);
            $existing = $chk->fetch();
            if ($existing && (int)$existing['is_system'] === 1) {
                respond(["success" => false, "message" => "Standard account groups cannot be edited, only custom ones you add."], 403);
            }
            $setSql = implode(', ', array_map(fn($c) => "$c = :$c", array_keys($data)));
            $stmt = $pdo->prepare("UPDATE account_groups SET $setSql WHERE id = :id");
            $data['id'] = $id;
            $stmt->execute($data);
            respond(["success" => true, "message" => "Account Group updated", "id" => $id]);
        } else {
            $data['is_system'] = 0;
            $cols = implode(', ', array_keys($data));
            $placeholders = implode(', ', array_map(fn($c) => ":$c", array_keys($data)));
            $stmt = $pdo->prepare("INSERT INTO account_groups ($cols) VALUES ($placeholders)");
            $stmt->execute($data);
            respond(["success" => true, "message" => "Account Group created", "id" => $pdo->lastInsertId()], 201);
        }
    } catch (PDOException $e) {
        $msg = $e->getCode() === '23000'
            ? "This Group / Sub Group combination already exists."
            : "Database error: " . $e->getMessage();
        respond(["success" => false, "message" => $msg], 400);
    }
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? null;
    if (!$id) respond(["success" => false, "message" => "Missing id"], 422);
    $chk = $pdo->prepare("SELECT is_system FROM account_groups WHERE id = ?");
    $chk->execute([$id]);
    $existing = $chk->fetch();
    if (!$existing) respond(["success" => false, "message" => "Not found"], 404);
    if ((int)$existing['is_system'] === 1) {
        respond(["success" => false, "message" => "Standard account groups cannot be deleted, only deactivated custom ones."], 403);
    }
    $stmt = $pdo->prepare("DELETE FROM account_groups WHERE id = ?");
    $stmt->execute([$id]);
    respond(["success" => true, "message" => "Account Group deleted"]);
}

respond(["success" => false, "message" => "Method not allowed"], 405);
