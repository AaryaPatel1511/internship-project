<?php
/**
 * Public Lead Capture Webhook
 * --------------------------------------------------------
 * This is the single inbound endpoint every source posts to. It is
 * intentionally NOT behind session_guard.php — Facebook, Google and
 * a WhatsApp Business API bridge (or Zapier/Make/Pabbly acting as a
 * relay for platforms that don't support custom webhooks directly)
 * call this over the internet, not from inside a logged-in browser.
 * Security is instead handled by the per-source ?token= secret
 * (see api/lead_settings.php, table lead_source_settings).
 *
 *   GET  api/lead_webhooks.php?source=facebook&hub.mode=subscribe
 *        &hub.verify_token=...&hub.challenge=...
 *        -> Facebook/WhatsApp webhook verification handshake
 *
 *   POST api/lead_webhooks.php?source=website&token=XXXX
 *   POST api/lead_webhooks.php?source=facebook&token=XXXX
 *   POST api/lead_webhooks.php?source=google_ads&token=XXXX
 *   POST api/lead_webhooks.php?source=whatsapp&token=XXXX
 *        body: JSON payload from that platform (or the website's own
 *        enquiry form, posted directly as JSON — see below for the
 *        simple flat shape the Website Leads form uses).
 * --------------------------------------------------------
 */

header('Content-Type: application/json');
require_once 'db.php';

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

$source = $_REQUEST['source'] ?? '';
$validSources = ['website', 'facebook', 'google_ads', 'whatsapp'];
if (!in_array($source, $validSources, true)) {
    respond(["success" => false, "message" => "Unknown source."], 400);
}

// --- Facebook / WhatsApp (Meta) webhook verification handshake ---
// PHP automatically turns dots in query-string keys into underscores, so
// "hub.challenge" arrives here as $_GET['hub_challenge'].
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['hub_mode'], $_GET['hub_challenge'])) {
    echo $_GET['hub_challenge'];
    exit;
}

function logWebhook($pdo, $source, $status, $message, $payload, $leadId = null) {
    $pdo->prepare("INSERT INTO lead_webhook_logs (source_key, status, message, payload, lead_id) VALUES (?, ?, ?, ?, ?)")
        ->execute([$source, $status, $message, is_string($payload) ? $payload : json_encode($payload), $leadId]);
}

$rawBody = file_get_contents('php://input');
$payload = json_decode($rawBody, true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(["success" => false, "message" => "This endpoint accepts POST requests from your integration."], 405);
}

// --- Validate the shared-secret token ---
$token = $_GET['token'] ?? $_POST['token'] ?? '';
$stmt = $pdo->prepare("SELECT * FROM lead_source_settings WHERE source_key = ?");
$stmt->execute([$source]);
$settings = $stmt->fetch();

if (!$settings || !$settings['is_active'] || !hash_equals($settings['webhook_token'], (string) $token)) {
    logWebhook($pdo, $source, 'rejected', 'Invalid or missing webhook token', $rawBody);
    respond(["success" => false, "message" => "Invalid or missing token."], 401);
}

if ($payload === null) {
    logWebhook($pdo, $source, 'rejected', 'Body was not valid JSON', $rawBody);
    respond(["success" => false, "message" => "Request body must be JSON."], 422);
}

// --- Normalise each platform's payload shape down to a common set of fields ---
$lead = [
    'customer_name' => null, 'mobile' => null, 'email' => null, 'city' => null,
    'vehicle_model' => null, 'notes' => null, 'source_ref_id' => null,
    'source_campaign' => null, 'source_adset' => null, 'source_ad_name' => null,
    'source_keyword' => null, 'source_landing_page' => null, 'source_campaign_cost' => null,
    'page_url' => null, 'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
    'browser' => $_SERVER['HTTP_USER_AGENT'] ?? null,
];

if ($source === 'website') {
    // Simple flat JSON straight from the dealership's own website enquiry form.
    $lead['customer_name'] = $payload['name'] ?? $payload['customerName'] ?? null;
    $lead['mobile']        = $payload['mobile'] ?? $payload['phone'] ?? null;
    $lead['email']         = $payload['email'] ?? null;
    $lead['city']          = $payload['city'] ?? null;
    $lead['vehicle_model'] = $payload['vehicle'] ?? $payload['vehicleInterested'] ?? null;
    $lead['notes']         = $payload['message'] ?? null;
    $lead['page_url']      = $payload['pageUrl'] ?? null;

} elseif ($source === 'facebook') {
    // Facebook Lead Ads "leadgen" webhook shape (a leadgen_id is normally
    // resolved via a follow-up Graph API call using field_data — here we
    // also accept a pre-flattened field_data array for simpler bridges).
    $entry = $payload['entry'][0]['changes'][0]['value'] ?? $payload;
    $lead['source_ref_id'] = $entry['leadgen_id'] ?? $payload['leadId'] ?? null;
    $lead['source_campaign'] = $entry['campaign_name'] ?? $payload['campaignName'] ?? null;
    $lead['source_adset']    = $entry['adset_name'] ?? $payload['adsetName'] ?? null;
    $lead['source_ad_name']  = $entry['ad_name'] ?? $payload['adName'] ?? null;
    $fields = $entry['field_data'] ?? $payload['fieldData'] ?? [];
    foreach ($fields as $f) {
        $name = strtolower($f['name'] ?? '');
        $val = $f['values'][0] ?? $f['value'] ?? null;
        if (str_contains($name, 'name')) $lead['customer_name'] = $val;
        if (str_contains($name, 'phone') || str_contains($name, 'mobile')) $lead['mobile'] = $val;
        if (str_contains($name, 'email')) $lead['email'] = $val;
        if (str_contains($name, 'city')) $lead['city'] = $val;
        if (str_contains($name, 'vehicle') || str_contains($name, 'model')) $lead['vehicle_model'] = $val;
    }
    // Allow a simpler already-flattened payload too.
    $lead['customer_name'] = $lead['customer_name'] ?? $payload['customerName'] ?? null;
    $lead['mobile'] = $lead['mobile'] ?? $payload['mobile'] ?? null;

} elseif ($source === 'google_ads') {
    $lead['source_ref_id']       = $payload['google_key'] ?? $payload['leadId'] ?? null;
    $lead['source_campaign']     = $payload['campaign_name'] ?? $payload['campaignName'] ?? null;
    $lead['source_keyword']      = $payload['keyword'] ?? null;
    $lead['source_landing_page'] = $payload['landing_page'] ?? $payload['landingPage'] ?? null;
    $lead['customer_name']       = $payload['user_column_data']['FULL_NAME'] ?? $payload['customerName'] ?? null;
    $lead['mobile']              = $payload['user_column_data']['PHONE_NUMBER'] ?? $payload['mobile'] ?? null;
    $lead['email']               = $payload['user_column_data']['EMAIL'] ?? $payload['email'] ?? null;
    $lead['city']                = $payload['city'] ?? null;
    $lead['vehicle_model']       = $payload['vehicle'] ?? $payload['vehicleInterested'] ?? null;

} elseif ($source === 'whatsapp') {
    // Meta WhatsApp Business API "messages" webhook shape.
    $entry = $payload['entry'][0]['changes'][0]['value'] ?? $payload;
    $contact = $entry['contacts'][0] ?? [];
    $message = $entry['messages'][0] ?? [];
    $lead['customer_name'] = $contact['profile']['name'] ?? $payload['customerName'] ?? null;
    $lead['mobile']        = $contact['wa_id'] ?? $payload['mobile'] ?? null;
    $lead['notes']         = $message['text']['body'] ?? $payload['message'] ?? null;
}

if (empty($lead['customer_name']) || empty($lead['mobile'])) {
    logWebhook($pdo, $source, 'rejected', 'Payload missing customer name or mobile number', $payload);
    respond(["success" => false, "message" => "Could not find a customer name and mobile number in this payload."], 422);
}

// De-duplicate: same source + same platform lead id already captured.
if (!empty($lead['source_ref_id'])) {
    $dupStmt = $pdo->prepare("SELECT id FROM leads WHERE lead_source = ? AND source_ref_id = ?");
    $dupStmt->execute([ucfirst(str_replace('_', ' ', $source)), $lead['source_ref_id']]);
    if ($dupStmt->fetch()) {
        logWebhook($pdo, $source, 'duplicate', 'source_ref_id already captured', $payload);
        respond(["success" => true, "message" => "Already received (duplicate)."]);
    }
}

$sourceLabelMap = ['website' => 'Website', 'facebook' => 'Facebook', 'google_ads' => 'Google Ads', 'whatsapp' => 'WhatsApp'];

$codeN = (int) $pdo->query("SELECT COALESCE(MAX(id),0) FROM leads")->fetchColumn() + 1;
$leadCode = 'LD-' . str_pad($codeN, 6, '0', STR_PAD_LEFT);

$stmt = $pdo->prepare("INSERT INTO leads
    (lead_code, lead_date, customer_name, mobile, email, city, vehicle_model, notes,
     lead_source, source_ref_id, source_campaign, source_adset, source_ad_name,
     source_keyword, source_landing_page, page_url, ip_address, browser, status, created_by)
    VALUES (?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'New Lead', ?)");
$stmt->execute([
    $leadCode, $lead['customer_name'], $lead['mobile'], $lead['email'], $lead['city'],
    $lead['vehicle_model'], $lead['notes'], $sourceLabelMap[$source],
    $lead['source_ref_id'], $lead['source_campaign'], $lead['source_adset'], $lead['source_ad_name'],
    $lead['source_keyword'], $lead['source_landing_page'], $lead['page_url'], $lead['ip_address'],
    $lead['browser'], "$source integration",
]);
$leadId = $pdo->lastInsertId();

logWebhook($pdo, $source, 'created', "Lead $leadCode created", $payload, $leadId);

respond(["success" => true, "message" => "Lead captured.", "leadCode" => $leadCode]);
