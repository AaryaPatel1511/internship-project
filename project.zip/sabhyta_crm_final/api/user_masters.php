<?php
/**
 * User Management Masters API (PDO)
 * Works with both HRMS schema (department_name) and the older user-mgmt schema (dept_name).
 * Column names are detected from the real tables (see schema_compat.php) so a missing
 * alias column can never make the whole query fail.
 *
 * GET    /api/user_masters.php?type=departments
 * GET    /api/user_masters.php?type=designations
 * POST   /api/user_masters.php?type=departments|designations
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';
require_once 'schema_compat.php';
require_once 'access.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    acc_require($pdo, ['Manage Users', 'Manage Roles', 'Manage Permissions'], 'view departments and designations');
} else {
    acc_require($pdo, ['Manage Users'], 'change departments and designations');
}

$method = $_SERVER['REQUEST_METHOD'];
$type = $_GET['type'] ?? 'departments';

try {
    if ($method === 'GET') {
        if (isset($_GET['id'])) {
            getMasterDetail($type, $_GET['id']);
        } else {
            listMasters($type);
        }
    } elseif ($method === 'POST') {
        createMaster($type);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

function deptNameExpr()  { return scDeptName('d'); }
function deptCodeExpr()  { return scDeptCode('d', "CAST(d.id AS CHAR)"); }
function desigNameExpr() { return scDesigName('dg'); }
function desigCodeExpr() { return scDesigCode('dg'); }

function listMasters($type) {
    global $pdo;

    if ($type === 'departments') {
        $query = "
            SELECT
                d.id,
                " . deptCodeExpr() . " as dept_code,
                " . deptNameExpr() . " as dept_name,
                " . deptNameExpr() . " as department_name,
                " . deptCodeExpr() . " as department_code,
                d.description,
                d.status,
                COUNT(DISTINCT e.id) as employee_count,
                COUNT(DISTINCT dg.id) as designation_count
            FROM departments d
            LEFT JOIN employees e ON d.id = e.department_id AND e.employment_status = 'Active'
            LEFT JOIN designations dg ON d.id = dg.department_id
            GROUP BY d.id
            ORDER BY " . deptNameExpr() . "
        ";
        $rows = $pdo->query($query)->fetchAll();
        echo json_encode(['success' => true, 'data' => $rows, 'count' => count($rows)]);
    } elseif ($type === 'designations') {
        $departmentId = $_GET['department_id'] ?? null;
        $query = "
            SELECT
                dg.id,
                " . desigCodeExpr() . " as desig_code,
                " . desigNameExpr() . " as desig_name,
                " . desigNameExpr() . " as designation_name,
                dg.department_id,
                " . deptNameExpr() . " as dept_name,
                " . deptNameExpr() . " as department_name,
                dg.status,
                COUNT(DISTINCT e.id) as employee_count
            FROM designations dg
            LEFT JOIN departments d ON dg.department_id = d.id
            LEFT JOIN employees e ON e.designation_id = dg.id AND e.employment_status = 'Active'
        ";
        $params = [];
        if ($departmentId) {
            $query .= " WHERE dg.department_id = ?";
            $params[] = $departmentId;
        }
        $query .= " GROUP BY dg.id ORDER BY " . desigNameExpr();
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        echo json_encode(['success' => true, 'data' => $rows, 'count' => count($rows)]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid type']);
    }
}

function getMasterDetail($type, $id) {
    global $pdo;

    if ($type === 'departments') {
        $stmt = $pdo->prepare("
            SELECT d.*,
                " . deptCodeExpr() . " as dept_code,
                " . deptNameExpr() . " as dept_name
            FROM departments d WHERE d.id = ?
        ");
        $stmt->execute([$id]);
        $dept = $stmt->fetch();
        if (!$dept) {
            echo json_encode(['success' => false, 'message' => 'Department not found']);
            return;
        }

        $empStmt = $pdo->prepare("
            SELECT e.id, e.employee_code,
                CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as full_name,
                " . desigNameExpr() . " as desig_name,
                e.employment_status
            FROM employees e
            LEFT JOIN designations dg ON e.designation_id = dg.id
            WHERE e.department_id = ?
            ORDER BY e.first_name
        ");
        $empStmt->execute([$id]);
        $dept['employees'] = $empStmt->fetchAll();

        $desigStmt = $pdo->prepare("
            SELECT dg.id,
                " . desigNameExpr() . " as desig_name,
                " . desigCodeExpr() . " as desig_code,
                dg.status
            FROM designations dg WHERE dg.department_id = ?
            ORDER BY " . desigNameExpr());
        $desigStmt->execute([$id]);
        $dept['designations'] = $desigStmt->fetchAll();

        echo json_encode(['success' => true, 'data' => $dept]);
    } elseif ($type === 'designations') {
        $stmt = $pdo->prepare("
            SELECT dg.*,
                " . desigNameExpr() . " as desig_name,
                " . deptNameExpr() . " as dept_name
            FROM designations dg
            LEFT JOIN departments d ON dg.department_id = d.id
            WHERE dg.id = ?
        ");
        $stmt->execute([$id]);
        $desig = $stmt->fetch();
        if (!$desig) {
            echo json_encode(['success' => false, 'message' => 'Designation not found']);
            return;
        }

        $empStmt = $pdo->prepare("
            SELECT e.id, e.employee_code,
                CONCAT(e.first_name, ' ', COALESCE(e.last_name, '')) as full_name,
                " . deptNameExpr() . " as dept_name,
                e.employment_status
            FROM employees e
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE e.designation_id = ?
        ");
        $empStmt->execute([$id]);
        $desig['employees'] = $empStmt->fetchAll();

        echo json_encode(['success' => true, 'data' => $desig]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid type']);
    }
}

function uniqueCode(string $table, string $codeCol, string $base): string {
    global $pdo;
    $code = $base !== '' ? $base : 'DEPT';
    $n = 1;
    $try = $code;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM `$table` WHERE `$codeCol` = ?");
    while (true) {
        $stmt->execute([$try]);
        if ((int)$stmt->fetchColumn() === 0) return $try;
        $n++;
        $try = substr($code, 0, 45) . $n;
    }
}

function createMaster($type) {
    global $pdo;

    $input = json_decode(file_get_contents('php://input'), true) ?: [];

    if ($type === 'departments') {
        $code = trim($input['dept_code'] ?? $input['department_code'] ?? '');
        $name = trim($input['dept_name'] ?? $input['department_name'] ?? '');
        $description = $input['description'] ?? '';

        if ($name === '') {
            echo json_encode(['success' => false, 'message' => 'Department name is required']);
            return;
        }

        $cols = sc_columns($pdo, 'departments');
        $nameCol = in_array('department_name', $cols, true) ? 'department_name' : (in_array('dept_name', $cols, true) ? 'dept_name' : null);
        $codeCol = in_array('department_code', $cols, true) ? 'department_code' : (in_array('dept_code', $cols, true) ? 'dept_code' : null);
        if (!$nameCol) {
            echo json_encode(['success' => false, 'message' => 'Departments table schema unknown']);
            return;
        }

        // Same department name twice is almost always a mistake.
        $dup = $pdo->prepare("SELECT id FROM departments WHERE LOWER(`$nameCol`) = LOWER(?) LIMIT 1");
        $dup->execute([$name]);
        if ($dup->fetch()) {
            echo json_encode(['success' => false, 'message' => "A department named \"$name\" already exists."]);
            return;
        }

        $fields = [$nameCol => $name];
        if ($codeCol) {
            if ($code === '') $code = strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', $name), 0, 8));
            $fields[$codeCol] = uniqueCode('departments', $codeCol, $code);
        }
        if (in_array('description', $cols, true)) $fields['description'] = $description;
        if (in_array('status', $cols, true))      $fields['status'] = 'Active';

        $colSql = implode(', ', array_map(fn($c) => "`$c`", array_keys($fields)));
        $ph = implode(', ', array_fill(0, count($fields), '?'));
        $pdo->prepare("INSERT INTO departments ($colSql) VALUES ($ph)")->execute(array_values($fields));

        echo json_encode([
            'success' => true,
            'message' => 'Department created',
            'department_id' => (int)$pdo->lastInsertId()
        ]);
    } elseif ($type === 'designations') {
        $code = trim($input['desig_code'] ?? $input['designation_code'] ?? '');
        $name = trim($input['desig_name'] ?? $input['designation_name'] ?? '');
        $departmentId = !empty($input['department_id']) ? (int)$input['department_id'] : null;
        $description = $input['description'] ?? $input['job_description'] ?? '';

        if ($name === '') {
            echo json_encode(['success' => false, 'message' => 'Designation name is required']);
            return;
        }

        $cols = sc_columns($pdo, 'designations');
        $nameCol = in_array('designation_name', $cols, true) ? 'designation_name' : (in_array('desig_name', $cols, true) ? 'desig_name' : null);
        $codeCol = in_array('designation_code', $cols, true) ? 'designation_code' : (in_array('desig_code', $cols, true) ? 'desig_code' : null);
        $descCol = in_array('job_description', $cols, true) ? 'job_description' : (in_array('description', $cols, true) ? 'description' : null);
        if (!$nameCol) {
            echo json_encode(['success' => false, 'message' => 'Designations table schema unknown']);
            return;
        }

        $dup = $pdo->prepare("SELECT id FROM designations WHERE LOWER(`$nameCol`) = LOWER(?) AND (department_id <=> ?) LIMIT 1");
        $dup->execute([$name, $departmentId]);
        if ($dup->fetch()) {
            echo json_encode(['success' => false, 'message' => "Designation \"$name\" already exists in that department."]);
            return;
        }

        $fields = [$nameCol => $name, 'department_id' => $departmentId];
        if ($codeCol) {
            if ($code === '') $code = strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', $name), 0, 8));
            $fields[$codeCol] = uniqueCode('designations', $codeCol, $code);
        }
        if ($descCol) $fields[$descCol] = $description;
        if (in_array('status', $cols, true)) $fields['status'] = 'Active';

        $colSql = implode(', ', array_map(fn($c) => "`$c`", array_keys($fields)));
        $ph = implode(', ', array_fill(0, count($fields), '?'));
        $pdo->prepare("INSERT INTO designations ($colSql) VALUES ($ph)")->execute(array_values($fields));

        echo json_encode([
            'success' => true,
            'message' => 'Designation created',
            'designation_id' => (int)$pdo->lastInsertId()
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid type']);
    }
}
