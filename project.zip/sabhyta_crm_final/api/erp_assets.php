<?php
/**
 * ASSET MANAGEMENT - hooks & actions
 * Procurement -> Inventory -> Deployment -> Lifecycle -> Decommissioning
 * Finance integration posts Journal vouchers into Accounts (generic_records).
 */

const AM_TAG_PREFIX = ['Laptop' => 'LAP', 'Desktop' => 'DSK', 'Printer' => 'PRN', 'Server' => 'SRV', 'Software' => 'SW'];

function am_history(PDO $pdo, int $assetId, string $action, string $remarks = ''): void {
    $pdo->prepare("INSERT INTO am_asset_history (asset_id, action_type, performed_by, remarks) VALUES (?, ?, ?, ?)")
        ->execute([$assetId, $action, erp_user()['id'], $remarks !== '' ? $remarks : null]);
}
function am_asset(PDO $pdo, int $id): array {
    $st = $pdo->prepare("SELECT * FROM am_assets WHERE asset_id = ?"); $st->execute([$id]);
    $a = $st->fetch();
    if (!$a) erp_fail('Asset not found.', 404);
    return $a;
}
function am_emp_name(PDO $pdo, ?int $id): string {
    if (!$id) return '';
    $st = $pdo->prepare("SELECT TRIM(CONCAT(first_name,' ',COALESCE(last_name,''))) FROM employees WHERE id = ?"); $st->execute([$id]);
    return (string)$st->fetchColumn();
}
/** Put an asset back to the right resting status after allocation/repair ends. */
function am_settle_status(PDO $pdo, int $assetId): void {
    $a = am_asset($pdo, $assetId);
    if (in_array($a['status'], ['Retired'], true)) return;
    $rep = $pdo->prepare("SELECT COUNT(*) FROM am_maintenance_logs WHERE asset_id = ? AND status = 'In Progress'");
    $rep->execute([$assetId]);
    if ((int)$rep->fetchColumn() > 0) { $new = 'In Repair'; }
    else {
        $al = $pdo->prepare("SELECT COUNT(*) FROM am_asset_allocations WHERE asset_id = ? AND actual_return_date IS NULL");
        $al->execute([$assetId]);
        $new = ((int)$al->fetchColumn() > 0) ? 'In Use' : 'In Stock';
    }
    if ($new !== $a['status']) $pdo->prepare("UPDATE am_assets SET status = ? WHERE asset_id = ?")->execute([$new, $assetId]);
}

/* ---------------------------------------------------------
   General-ledger postings
   --------------------------------------------------------- */
function am_gl_record(PDO $pdo, int $assetId, string $event, string $period, float $amount, string $date, string $narration): ?int {
    if ($amount <= 0) return null;
    $st = $pdo->prepare("INSERT IGNORE INTO am_gl_postings (asset_id, event_type, period_key, amount, entry_date, narration) VALUES (?, ?, ?, ?, ?, ?)");
    $st->execute([$assetId, $event, $period, round($amount, 2), $date, mb_substr($narration, 0, 255)]);
    if (!$st->rowCount()) return null;
    return (int)$pdo->lastInsertId();
}
/** Try to turn a pending posting into a Journal voucher. Returns journal id or null if accounts are not mapped. */
function am_gl_try_post(PDO $pdo, int $postingId): ?int {
    $st = $pdo->prepare("SELECT * FROM am_gl_postings WHERE posting_id = ?"); $st->execute([$postingId]);
    $p = $st->fetch();
    if (!$p || $p['journal_record_id']) return $p['journal_record_id'] ?? null;
    $map = erp_fin_map($pdo);
    $dep = $pdo->prepare("SELECT ledger_account_id FROM am_asset_depreciation WHERE asset_id = ?"); $dep->execute([$p['asset_id']]);
    $assetLedger = $dep->fetchColumn();
    $fixed = $assetLedger ? (int)$assetLedger : $map['fin_fixed_asset_acct'];
    $credit = $map['fin_default_credit_acct'];
    $cash = $map['fin_cash_acct'] ?: $credit;

    $dr = $cr = null;
    switch ($p['event_type']) {
        case 'Purchase':     $dr = $fixed;                        $cr = $credit; break;
        case 'Depreciation': $dr = $map['fin_dep_expense_acct'];  $cr = $map['fin_accum_dep_acct']; break;
        case 'Maintenance':  $dr = $map['fin_maint_expense_acct'];$cr = $credit; break;
        case 'Disposal':
            switch ($p['period_key']) {
                case 'accum':    $dr = $map['fin_accum_dep_acct'];     $cr = $fixed; break;
                case 'proceeds': $dr = $cash;                          $cr = $fixed; break;
                case 'loss':     $dr = $map['fin_loss_disposal_acct']; $cr = $fixed; break;
                case 'gain':     $dr = $cash;                          $cr = $map['fin_gain_disposal_acct']; break;
            }
    }
    $asset = $pdo->prepare("SELECT asset_tag FROM am_assets WHERE asset_id = ?"); $asset->execute([$p['asset_id']]);
    $jid = erp_post_journal($pdo, $p['entry_date'] ?: erp_today(), $dr ? (int)$dr : null, $cr ? (int)$cr : null, (float)$p['amount'], (string)$p['narration'], (string)$asset->fetchColumn());
    if ($jid) $pdo->prepare("UPDATE am_gl_postings SET journal_record_id = ? WHERE posting_id = ?")->execute([$jid, $postingId]);
    return $jid;
}
function am_gl_notice(array &$notices, int $recorded, int $posted): void {
    if ($recorded && !$posted) $notices[] = 'Ledger entry is pending - map the accounts in Administration > Company Settings, then use "Post Pending to Accounts".';
    elseif ($posted) $notices[] = 'Journal entry posted to Accounts.';
}

/* ---------------------------------------------------------
   Assets
   --------------------------------------------------------- */
function am_asset_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    if ($old && $old['status'] === 'Retired') erp_fail('A retired asset cannot be edited.');
    if (array_key_exists('asset_tag', $d) && $d['asset_tag'] === null && $old) unset($d['asset_tag']);
    if (empty($d['asset_tag']) && empty($old['asset_tag'])) {
        $type = $d['asset_type'] ?? 'Laptop';
        $n = (int)$pdo->query("SELECT COALESCE(MAX(asset_id),0)+1 FROM am_assets")->fetchColumn();
        $chk = $pdo->prepare("SELECT 1 FROM am_assets WHERE asset_tag = ?");
        do { $tag = 'AST-' . (AM_TAG_PREFIX[$type] ?? 'GEN') . '-' . str_pad((string)$n, 4, '0', STR_PAD_LEFT); $chk->execute([$tag]); $n++; } while ($chk->fetchColumn());
        $d['asset_tag'] = $tag;
    }
    if (!$old) $d['status'] = 'In Stock';
    if ($old && isset($d['asset_type']) && $d['asset_type'] !== $old['asset_type']) {
        $c = $pdo->prepare("SELECT (SELECT COUNT(*) FROM am_asset_allocations WHERE asset_id = ?) + (SELECT COUNT(*) FROM am_software_licenses WHERE asset_id = ?)");
        $c->execute([$old['asset_id'], $old['asset_id']]);
        if ((int)$c->fetchColumn() > 0) erp_fail('The type cannot be changed because this asset already has allocations or licenses.');
    }
    $date = $d['purchase_date'] ?? $old['purchase_date'] ?? null;
    $w = array_key_exists('warranty_expiry', $d) ? $d['warranty_expiry'] : ($old['warranty_expiry'] ?? null);
    if ($date && $w && $w < $date) erp_fail('Warranty expiry cannot be before the purchase date.');
}
function am_asset_after(PDO $pdo, int $id, array $d, ?array $old, array $in): array {
    $notices = [];
    $a = am_asset($pdo, $id);
    $isNew = !$old;

    // ---- depreciation configuration (virtual form fields) ----
    $method = $in['dep_method'] ?? null;
    if ($method !== null && $method !== '') {
        $cur = $pdo->prepare("SELECT * FROM am_asset_depreciation WHERE asset_id = ?"); $cur->execute([$id]);
        $dep = $cur->fetch();
        if ($method === 'None') {
            if ($dep && (float)$dep['accumulated_depreciation'] > 0) $notices[] = 'Depreciation was already booked, so it was kept. Retire the asset to stop it.';
            elseif ($dep) $pdo->prepare("DELETE FROM am_asset_depreciation WHERE asset_id = ?")->execute([$id]);
        } elseif (in_array($method, ['Straight Line', 'Declining Balance'], true)) {
            $life = max(1, (int)($in['dep_life_months'] ?? ($dep['useful_life_months'] ?? 36)));
            $salv = max(0, (float)($in['dep_salvage'] ?? ($dep['salvage_value'] ?? 0)));
            $led  = !empty($in['dep_ledger_account_id']) ? (int)$in['dep_ledger_account_id'] : ($dep['ledger_account_id'] ?? null);
            $cost = (float)$a['purchase_cost'];
            if ($salv > $cost) erp_fail('Salvage value cannot be more than the purchase cost.');
            if ($led && !erp_coa_account($pdo, $led)) erp_fail('The selected ledger account is not in the Chart of Accounts.');
            if ($dep) {
                $acc = (float)$dep['accumulated_depreciation'];
                $book = max($salv, $cost - $acc);
                $pdo->prepare("UPDATE am_asset_depreciation SET depreciation_method=?, useful_life_months=?, salvage_value=?, ledger_account_id=?, current_book_value=? WHERE asset_id=?")
                    ->execute([$method, $life, $salv, $led, $book, $id]);
            } else {
                $pdo->prepare("INSERT INTO am_asset_depreciation (asset_id, ledger_account_id, depreciation_method, useful_life_months, salvage_value, current_book_value, accumulated_depreciation) VALUES (?,?,?,?,?,?,0)")
                    ->execute([$id, $led, $method, $life, $salv, $cost]);
            }
        }
    }

    if ($isNew) {
        am_history($pdo, $id, 'Purchased', 'Added to inventory: ' . $a['brand_model'] . ' (' . $a['asset_type'] . ') cost ' . number_format((float)$a['purchase_cost'], 2));
        $pid = am_gl_record($pdo, $id, 'Purchase', '', (float)$a['purchase_cost'], $a['purchase_date'] ?: erp_today(), 'Purchase of ' . $a['asset_type'] . ' ' . $a['asset_tag'] . ' - ' . $a['brand_model']);
        if ($pid) { $j = am_gl_try_post($pdo, $pid); am_gl_notice($notices, 1, $j ? 1 : 0); }
    } else {
        am_history($pdo, $id, 'Updated', 'Asset details updated');
    }
    return $notices;
}
function am_asset_before_delete(PDO $pdo, int $id, array $old): void {
    $posted = $pdo->prepare("SELECT COUNT(*) FROM am_gl_postings WHERE asset_id = ? AND journal_record_id IS NOT NULL"); $posted->execute([$id]);
    if ((int)$posted->fetchColumn()) erp_fail('This asset already has journal entries in Accounts. Retire it instead of deleting so the books stay correct.', 409);
    $u = $pdo->prepare("SELECT (SELECT COUNT(*) FROM am_asset_allocations WHERE asset_id = ?) + (SELECT COUNT(*) FROM am_maintenance_logs WHERE asset_id = ?)");
    $u->execute([$id, $id]);
    if ((int)$u->fetchColumn()) erp_fail('This asset has allocation or maintenance history. Retire it instead of deleting.', 409);
}

/* ---------------------------------------------------------
   Depreciation run (monthly)
   --------------------------------------------------------- */
function act_am_run_depreciation(PDO $pdo): void {
    $in = erp_input();
    $asOf = !empty($in['as_of']) ? $in['as_of'] : erp_today();
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $asOf)) erp_fail('Invalid date.');
    $only = (int)($in['asset_id'] ?? 0);

    $sql = "SELECT a.*, d.* FROM am_assets a JOIN am_asset_depreciation d ON d.asset_id = a.asset_id WHERE a.status <> 'Retired'" . ($only ? " AND a.asset_id = $only" : '');
    $rows = $pdo->query($sql)->fetchAll();

    $assets = 0; $months = 0; $total = 0.0; $posted = 0; $pending = 0;
    foreach ($rows as $r) {
        $start = $r['last_calculated'] ? new DateTime($r['last_calculated']) : new DateTime(($r['purchase_date'] ?: substr((string)$r['created_at'], 0, 10)));
        $cursor = $r['last_calculated'] ? (clone $start)->modify('first day of next month') : (clone $start)->modify('first day of this month');
        $cost = (float)$r['purchase_cost']; $salv = (float)$r['salvage_value'];
        $acc = (float)$r['accumulated_depreciation']; $book = $cost - $acc;
        $life = max(1, (int)$r['useful_life_months']);
        $did = 0; $sum = 0.0; $last = $r['last_calculated'];

        while (true) {
            $monthEnd = (clone $cursor)->modify('last day of this month');
            if ($monthEnd->format('Y-m-d') > $asOf) break;
            if ($book - $salv <= 0.004) break;
            $amt = $r['depreciation_method'] === 'Straight Line' ? ($cost - $salv) / $life : $book * (2 / $life);
            $amt = round(min($amt, $book - $salv), 2);
            if ($amt <= 0) break;
            $period = $monthEnd->format('Y-m');
            $pid = am_gl_record($pdo, (int)$r['asset_id'], 'Depreciation', $period, $amt, $monthEnd->format('Y-m-d'), 'Depreciation ' . $period . ' - ' . $r['asset_tag'] . ' (' . $r['depreciation_method'] . ')');
            if ($pid) { am_gl_try_post($pdo, $pid) ? $posted++ : $pending++; }
            $acc += $amt; $book -= $amt; $sum += $amt; $did++;
            $last = $monthEnd->format('Y-m-d');
            $cursor->modify('first day of next month');
        }
        if ($did) {
            $pdo->prepare("UPDATE am_asset_depreciation SET accumulated_depreciation = ?, current_book_value = ?, last_calculated = ? WHERE asset_id = ?")
                ->execute([round($acc, 2), round($book, 2), $last, $r['asset_id']]);
            am_history($pdo, (int)$r['asset_id'], 'Depreciated', "$did month(s) depreciated, total " . number_format($sum, 2) . ". Book value now " . number_format($book, 2));
            $assets++; $months += $did; $total += $sum;
        }
    }
    $notices = [];
    if ($pending) $notices[] = "$pending depreciation entr" . ($pending == 1 ? 'y is' : 'ies are') . ' pending - map the accounts in Administration > Company Settings, then use "Post Pending to Accounts".';
    erp_ok(['assets' => $assets, 'months' => $months, 'total' => round($total, 2), 'posted' => $posted, 'pending' => $pending],
           ['message' => $assets ? "Depreciation booked for $assets asset(s): " . number_format($total, 2) . " over $months month(s)." : 'Nothing to depreciate - every asset is up to date.', 'notices' => $notices]);
}
function act_am_post_pending(PDO $pdo): void {
    $ids = $pdo->query("SELECT posting_id FROM am_gl_postings WHERE journal_record_id IS NULL ORDER BY entry_date, posting_id")->fetchAll(PDO::FETCH_COLUMN);
    $ok = 0; $left = 0;
    foreach ($ids as $id) { am_gl_try_post($pdo, (int)$id) ? $ok++ : $left++; }
    $notices = $left ? ["$left entr" . ($left == 1 ? 'y' : 'ies') . ' could not be posted because an account is not mapped in Administration > Company Settings (Accounting Mapping).'] : [];
    erp_ok(['posted' => $ok, 'pending' => $left], ['message' => $ok ? "$ok journal entr" . ($ok == 1 ? 'y' : 'ies') . ' posted to Accounts.' : ($left ? 'No entries posted.' : 'Nothing pending.'), 'notices' => $notices]);
}
function act_am_finance_summary(PDO $pdo): void {
    $r = $pdo->query("SELECT
        (SELECT COUNT(*) FROM am_assets) AS total_assets,
        (SELECT COALESCE(SUM(purchase_cost),0) FROM am_assets WHERE status <> 'Retired') AS gross_cost,
        (SELECT COALESCE(SUM(CASE WHEN d.asset_id IS NULL THEN a.purchase_cost ELSE d.current_book_value END),0) FROM am_assets a LEFT JOIN am_asset_depreciation d ON d.asset_id = a.asset_id WHERE a.status <> 'Retired') AS book_value,
        (SELECT COALESCE(SUM(accumulated_depreciation),0) FROM am_asset_depreciation) AS accumulated_dep,
        (SELECT COUNT(*) FROM am_gl_postings WHERE journal_record_id IS NULL) AS pending_postings,
        (SELECT COUNT(*) FROM am_assets WHERE status = 'In Use') AS in_use,
        (SELECT COUNT(*) FROM am_assets WHERE status = 'In Stock') AS in_stock,
        (SELECT COUNT(*) FROM am_assets WHERE status = 'In Repair') AS in_repair,
        (SELECT COUNT(*) FROM am_assets WHERE status = 'Retired') AS retired,
        (SELECT COUNT(*) FROM am_software_licenses WHERE expiry_date IS NOT NULL AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)) AS licenses_expiring,
        (SELECT COUNT(*) FROM am_asset_allocations WHERE actual_return_date IS NULL AND return_due_date < CURDATE()) AS overdue_returns")->fetch();
    $r['mapping_ready'] = (bool)(erp_fin_map($pdo)['fin_dep_expense_acct'] && erp_fin_map($pdo)['fin_accum_dep_acct'] && erp_fin_map($pdo)['fin_fixed_asset_acct']);
    erp_ok($r);
}

/* ---------------------------------------------------------
   Software licenses
   --------------------------------------------------------- */
function am_license_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    $total = (int)($d['seats_total'] ?? $old['seats_total'] ?? 1);
    if (!$old) {
        if (!isset($d['seats_available'])) $d['seats_available'] = $total;
    } elseif (isset($d['seats_total']) && !isset($in['seats_available']) && (int)$old['seats_total'] !== $total) {
        $d['seats_available'] = max(0, (int)$old['seats_available'] + ($total - (int)$old['seats_total']));
    }
    if (isset($d['seats_available']) && (int)$d['seats_available'] > $total) erp_fail('Seats available cannot be more than total seats.');

    if (!empty($d['asset_id'])) {
        $a = am_asset($pdo, (int)$d['asset_id']);
        if ($a['asset_type'] !== 'Software') erp_fail('Only assets of type Software can carry a license.');
    } elseif (!$old) {
        // auto-create the Software asset
        $name = $d['software_name'] ?? 'Software';
        $n = (int)$pdo->query("SELECT COALESCE(MAX(asset_id),0)+1 FROM am_assets")->fetchColumn();
        $chk = $pdo->prepare("SELECT 1 FROM am_assets WHERE asset_tag = ?");
        do { $tag = 'AST-SW-' . str_pad((string)$n, 4, '0', STR_PAD_LEFT); $chk->execute([$tag]); $n++; } while ($chk->fetchColumn());
        $cost = (float)($d['renewal_cost'] ?? 0);
        $pdo->prepare("INSERT INTO am_assets (asset_tag, asset_type, brand_model, purchase_date, purchase_cost, status, created_by) VALUES (?, 'Software', ?, CURDATE(), ?, 'In Stock', ?)")
            ->execute([$tag, $name, $cost, erp_user()['id']]);
        $aid = (int)$pdo->lastInsertId();
        $d['asset_id'] = $aid;
        am_history($pdo, $aid, 'Purchased', 'Software license registered: ' . $name);
        $pid = am_gl_record($pdo, $aid, 'Purchase', '', $cost, erp_today(), 'Software license purchase ' . $tag . ' - ' . $name);
        if ($pid) am_gl_try_post($pdo, $pid);
    }
}
function am_license_after(PDO $pdo, int $id, array $d, ?array $old, array $in): array { return []; }

function act_am_renew_license(PDO $pdo): void {
    $in = erp_input();
    $id = (int)($in['id'] ?? 0); $months = max(1, min(120, (int)($in['months'] ?? 12)));
    $st = $pdo->prepare("SELECT l.*, a.asset_tag FROM am_software_licenses l JOIN am_assets a ON a.asset_id = l.asset_id WHERE l.license_id = ?");
    $st->execute([$id]);
    $l = $st->fetch();
    if (!$l) erp_fail('License not found.', 404);
    $base = ($l['expiry_date'] && $l['expiry_date'] > erp_today()) ? $l['expiry_date'] : erp_today();
    $new = date('Y-m-d', strtotime("$base +$months months"));
    $pdo->prepare("UPDATE am_software_licenses SET expiry_date = ? WHERE license_id = ?")->execute([$new, $id]);
    am_history($pdo, (int)$l['asset_id'], 'Maintenance', "License renewed for $months month(s) until $new");
    $notices = [];
    if ((float)$l['renewal_cost'] > 0) {
        $pid = am_gl_record($pdo, (int)$l['asset_id'], 'Maintenance', 'renew-' . date('YmdHis'), (float)$l['renewal_cost'], erp_today(), 'Software renewal ' . $l['asset_tag'] . ' - ' . $l['software_name']);
        if ($pid) { $j = am_gl_try_post($pdo, $pid); am_gl_notice($notices, 1, $j ? 1 : 0); }
    }
    erp_ok(['expiry_date' => $new], ['message' => "License renewed until $new.", 'notices' => $notices]);
}

/* ---------------------------------------------------------
   Allocations
   --------------------------------------------------------- */
function am_alloc_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    if ($old) {
        if (isset($d['asset_id']) && (int)$d['asset_id'] !== (int)$old['asset_id']) erp_fail('To move an asset, return it first and create a new allocation.');
        if ($old['actual_return_date']) erp_fail('This allocation is closed (asset returned) and cannot be edited.');
    }
    $emp = array_key_exists('employee_id', $d) ? $d['employee_id'] : ($old['employee_id'] ?? null);
    $dep = array_key_exists('department_id', $d) ? $d['department_id'] : ($old['department_id'] ?? null);
    if (!$emp && !$dep) erp_fail('Choose an employee or a department to allocate the asset to.');
    $from = $d['allocated_date'] ?? $old['allocated_date'] ?? null;
    $due  = array_key_exists('return_due_date', $d) ? $d['return_due_date'] : ($old['return_due_date'] ?? null);
    if ($from && $due && $due < $from) erp_fail('Return due date cannot be before the allocated date.');

    if (!$old) {
        $a = am_asset($pdo, (int)$d['asset_id']);
        if ($a['status'] === 'Retired') erp_fail('This asset is retired and cannot be allocated.');
        if ($a['asset_type'] === 'Software') {
            $s = $pdo->prepare("SELECT COALESCE(SUM(seats_available),0) FROM am_software_licenses WHERE asset_id = ?"); $s->execute([$a['asset_id']]);
            if ((int)$s->fetchColumn() < 1) erp_fail('No free license seats are left for this software. Add seats or renew the license.');
        } elseif ($a['status'] !== 'In Stock') {
            erp_fail('This asset is "' . $a['status'] . '" - only assets that are In Stock can be allocated.');
        }
        $d['allocation_status'] = 'Active';
    }
    $dueNow = $due ?? null;
    $d['allocation_status'] = ($dueNow && $dueNow < erp_today()) ? 'Overdue' : 'Active';
}
function am_alloc_after(PDO $pdo, int $id, array $d, ?array $old, array $in): array {
    if ($old) return [];
    $st = $pdo->prepare("SELECT * FROM am_asset_allocations WHERE allocation_id = ?"); $st->execute([$id]);
    $al = $st->fetch();
    $a = am_asset($pdo, (int)$al['asset_id']);
    if ($a['asset_type'] === 'Software') {
        $pdo->prepare("UPDATE am_software_licenses SET seats_available = seats_available - 1 WHERE asset_id = ? AND seats_available > 0 ORDER BY seats_available DESC LIMIT 1")->execute([$a['asset_id']]);
    } else {
        $pdo->prepare("UPDATE am_assets SET status = 'In Use' WHERE asset_id = ?")->execute([$a['asset_id']]);
    }
    $who = $al['employee_id'] ? am_emp_name($pdo, (int)$al['employee_id']) : 'department';
    am_history($pdo, (int)$a['asset_id'], 'Assigned', "Allocated to $who" . ($al['return_due_date'] ? ' (return by ' . $al['return_due_date'] . ')' : ''));
    return ['Asset status is now ' . ($a['asset_type'] === 'Software' ? 'tracked by license seats' : 'In Use') . '.'];
}
function am_alloc_before_delete(PDO $pdo, int $id, array $old): void {
    if ($old['actual_return_date']) return;
    $a = am_asset($pdo, (int)$old['asset_id']);
    if ($a['asset_type'] === 'Software') {
        $pdo->prepare("UPDATE am_software_licenses SET seats_available = LEAST(seats_total, seats_available + 1) WHERE asset_id = ? ORDER BY seats_available ASC LIMIT 1")->execute([$a['asset_id']]);
    } else {
        $pdo->prepare("UPDATE am_asset_allocations SET actual_return_date = CURDATE() WHERE allocation_id = ?")->execute([$id]); // so settle sees it as closed
        am_settle_status($pdo, (int)$a['asset_id']);
    }
}
function am_alloc_sync_overdue(PDO $pdo): void {
    $pdo->exec("UPDATE am_asset_allocations SET allocation_status = 'Overdue' WHERE actual_return_date IS NULL AND return_due_date IS NOT NULL AND return_due_date < CURDATE() AND allocation_status = 'Active'");
}
function act_am_return(PDO $pdo): void {
    $in = erp_input();
    $id = (int)($in['id'] ?? 0);
    $st = $pdo->prepare("SELECT * FROM am_asset_allocations WHERE allocation_id = ?"); $st->execute([$id]);
    $al = $st->fetch();
    if (!$al) erp_fail('Allocation not found.', 404);
    if ($al['actual_return_date']) erp_fail('This asset has already been returned.');
    $date = !empty($in['date']) ? $in['date'] : erp_today();
    if ($date < $al['allocated_date']) erp_fail('Return date cannot be before the allocated date.');
    $pdo->prepare("UPDATE am_asset_allocations SET actual_return_date = ?, allocation_status = 'Returned', condition_on_return = ? WHERE allocation_id = ?")
        ->execute([$date, trim((string)($in['condition'] ?? '')) ?: null, $id]);
    $a = am_asset($pdo, (int)$al['asset_id']);
    if ($a['asset_type'] === 'Software') {
        $pdo->prepare("UPDATE am_software_licenses SET seats_available = LEAST(seats_total, seats_available + 1) WHERE asset_id = ? ORDER BY seats_available ASC LIMIT 1")->execute([$a['asset_id']]);
    } else {
        am_settle_status($pdo, (int)$a['asset_id']);
    }
    am_history($pdo, (int)$a['asset_id'], 'Returned', 'Returned by ' . ($al['employee_id'] ? am_emp_name($pdo, (int)$al['employee_id']) : 'department') . (!empty($in['condition']) ? '. Condition: ' . $in['condition'] : ''));
    erp_ok(null, ['message' => 'Asset returned and back in stock.']);
}

/* ---------------------------------------------------------
   Maintenance
   --------------------------------------------------------- */
function am_maint_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    $aid = (int)($d['asset_id'] ?? $old['asset_id'] ?? 0);
    if (!$old && am_asset($pdo, $aid)['status'] === 'Retired') erp_fail('A retired asset cannot be sent for maintenance.');
    $status = $d['status'] ?? ($old['status'] ?? 'Scheduled');
    if ($status === 'Completed') { if (empty($old['completed_on'])) $d['completed_on'] = erp_today(); }
    else $d['completed_on'] = null;
    $s = $d['service_date'] ?? $old['service_date'] ?? null;
    $n = array_key_exists('next_service_date', $d) ? $d['next_service_date'] : ($old['next_service_date'] ?? null);
    if ($s && $n && $n < $s) erp_fail('Next service date cannot be before the service date.');
}
function am_maint_after(PDO $pdo, int $id, array $d, ?array $old, array $in): array {
    $st = $pdo->prepare("SELECT m.*, a.asset_tag, a.brand_model FROM am_maintenance_logs m JOIN am_assets a ON a.asset_id = m.asset_id WHERE m.maintenance_id = ?");
    $st->execute([$id]);
    $m = $st->fetch();
    $notices = [];
    $changed = !$old || $old['status'] !== $m['status'];
    if (!$old) am_history($pdo, (int)$m['asset_id'], 'Maintenance', $m['maintenance_type'] . ' maintenance logged (' . $m['status'] . ')');
    if ($changed) {
        if ($m['status'] === 'In Progress') {
            $pdo->prepare("UPDATE am_assets SET status = 'In Repair' WHERE asset_id = ? AND status <> 'Retired'")->execute([$m['asset_id']]);
            $notices[] = 'Asset marked In Repair.';
        } else {
            am_settle_status($pdo, (int)$m['asset_id']);
        }
        if ($m['status'] === 'Completed') {
            am_history($pdo, (int)$m['asset_id'], 'Repaired', $m['maintenance_type'] . ' completed' . ((float)$m['repair_cost'] > 0 ? ', cost ' . number_format((float)$m['repair_cost'], 2) : '') . ($m['vendor_name'] ? ' by ' . $m['vendor_name'] : ''));
            if ((float)$m['repair_cost'] > 0) {
                $pid = am_gl_record($pdo, (int)$m['asset_id'], 'Maintenance', 'm' . $id, (float)$m['repair_cost'], $m['completed_on'] ?: erp_today(), 'Maintenance ' . $m['asset_tag'] . ' - ' . ($m['issue_description'] ?: $m['maintenance_type']));
                if ($pid) { $j = am_gl_try_post($pdo, $pid); am_gl_notice($notices, 1, $j ? 1 : 0); }
            }
        }
    }
    return $notices;
}

/* ---------------------------------------------------------
   Decommissioning
   --------------------------------------------------------- */
function act_am_retire(PDO $pdo): void {
    $in = erp_input();
    $id = (int)($in['id'] ?? 0);
    $a = am_asset($pdo, $id);
    if ($a['status'] === 'Retired') erp_fail('This asset is already retired.');
    $date = !empty($in['date']) ? $in['date'] : erp_today();
    $proceeds = max(0.0, (float)($in['salvage'] ?? 0));
    $reason = trim((string)($in['reason'] ?? ''));

    $pdo->beginTransaction();
    try {
        // close open allocations
        $open = $pdo->prepare("SELECT allocation_id FROM am_asset_allocations WHERE asset_id = ? AND actual_return_date IS NULL"); $open->execute([$id]);
        foreach ($open->fetchAll(PDO::FETCH_COLUMN) as $al) {
            $pdo->prepare("UPDATE am_asset_allocations SET actual_return_date = ?, allocation_status = 'Returned', condition_on_return = 'Asset retired' WHERE allocation_id = ?")->execute([$date, $al]);
        }
        $dep = $pdo->prepare("SELECT * FROM am_asset_depreciation WHERE asset_id = ?"); $dep->execute([$id]);
        $d = $dep->fetch();
        $cost = (float)$a['purchase_cost'];
        $acc = $d ? (float)$d['accumulated_depreciation'] : 0.0;
        $book = max(0.0, $cost - $acc);
        $tag = $a['asset_tag'];

        $pdo->prepare("UPDATE am_assets SET status = 'Retired', retired_on = ?, salvage_received = ? WHERE asset_id = ?")->execute([$date, $proceeds ?: null, $id]);
        if ($d) $pdo->prepare("UPDATE am_asset_depreciation SET current_book_value = 0 WHERE asset_id = ?")->execute([$id]);

        $recorded = 0; $posted = 0; $notices = [];
        $queue = [];
        if ($acc > 0) $queue[] = ['accum', $acc, "Write-off $tag: reverse accumulated depreciation"];
        $toCash = min($proceeds, $book);
        if ($toCash > 0) $queue[] = ['proceeds', $toCash, "Disposal proceeds $tag"];
        if ($book - $toCash > 0.004) $queue[] = ['loss', $book - $toCash, "Loss on disposal $tag"];
        if ($proceeds > $book) $queue[] = ['gain', $proceeds - $book, "Gain on disposal $tag"];
        foreach ($queue as [$key, $amt, $text]) {
            $pid = am_gl_record($pdo, $id, 'Disposal', $key, $amt, $date, $text);
            if ($pid) { $recorded++; if (am_gl_try_post($pdo, $pid)) $posted++; }
        }
        am_gl_notice($notices, $recorded, $posted);
        if ($recorded && $posted && $posted < $recorded) $notices[] = ($recorded - $posted) . ' disposal entr' . (($recorded - $posted) == 1 ? 'y is' : 'ies are') . ' pending an account mapping.';
        am_history($pdo, $id, 'Retired', 'Retired' . ($reason ? ": $reason" : '') . '. Book value written off: ' . number_format($book, 2) . ($proceeds ? ', salvage received ' . number_format($proceeds, 2) : ''));
        $pdo->commit();
    } catch (Throwable $e) { $pdo->rollBack(); throw $e; }
    erp_ok(null, ['message' => 'Asset retired.', 'notices' => $notices]);
}

/** Per-asset timeline for the asset detail drawer. */
function act_am_timeline(PDO $pdo): void {
    $id = (int)($_GET['id'] ?? 0);
    $a = am_asset($pdo, $id);
    $h = $pdo->prepare("SELECT h.*, u.name AS performed_by_name FROM am_asset_history h LEFT JOIN users u ON u.id = h.performed_by WHERE h.asset_id = ? ORDER BY h.history_id DESC");
    $h->execute([$id]);
    $d = $pdo->prepare("SELECT * FROM am_asset_depreciation WHERE asset_id = ?"); $d->execute([$id]);
    $g = $pdo->prepare("SELECT event_type, period_key, amount, entry_date, journal_record_id FROM am_gl_postings WHERE asset_id = ? ORDER BY entry_date, posting_id");
    $g->execute([$id]);
    erp_ok(['asset' => $a, 'history' => $h->fetchAll(), 'depreciation' => $d->fetch() ?: null, 'postings' => $g->fetchAll()]);
}
