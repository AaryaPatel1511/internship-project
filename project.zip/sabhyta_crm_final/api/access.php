<?php
/**
 * ACCESS CONTROL HELPERS
 * --------------------------------------------------------
 * One place that answers "what may the signed-in user see / do?"
 * It is used by
 *   - api/auth.php           -> tells the sidebar which menus to show
 *   - api/users.php, user_roles.php, user_permissions.php,
 *     user_masters.php, user_management_dashboard.php
 *                            -> refuse requests the user has no right to make
 *
 * Rules
 *   1. "Super Admin" and "Admin" (any capitalisation) can do everything.
 *   2. Everybody else gets what the Roles & Permissions screens give them:
 *        - the role stored on their login account (users.role)
 *        - plus any extra roles assigned to their HRMS employee record
 *        - plus per-user overrides (user_permissions), allow or deny
 *   3. The User Management screens are controlled by three permissions
 *      (module "Administration"):
 *          Manage Users        -> Users, Departments, Designations
 *          Manage Roles        -> Roles
 *          Manage Permissions  -> Permissions
 *
 * To let someone open User Management: Roles > (their role) > tick the
 * permission(s) above - or sign in as Admin / Super Admin.
 * --------------------------------------------------------
 */

if (!function_exists('acc_norm')) {

function acc_norm($s): string {
    return strtolower(trim((string)$s));
}
function acc_is_super_role($role): bool {
    return acc_norm($role) === 'super admin';
}
function acc_is_admin_role($role): bool {
    return in_array(acc_norm($role), ['super admin', 'admin'], true);
}

/** The signed-in user as ['id'=>int|null, 'role'=>string, 'name'=>string]. */
function acc_session_user(): array {
    if (session_status() === PHP_SESSION_NONE) @session_start();
    return [
        'id'   => isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null,
        'role' => (string)($_SESSION['user_role'] ?? ''),
        'name' => (string)($_SESSION['user_name'] ?? ''),
    ];
}

/**
 * Set of lower-cased permission names the user holds.
 * Never throws: if the permission tables are missing the result is simply empty.
 */
function acc_permissions(PDO $pdo, ?int $userId, string $roleName): array {
    static $cache = [];
    $key = ($userId ?? 0) . '|' . acc_norm($roleName);
    if (isset($cache[$key])) return $cache[$key];

    $perms = [];

    // 1) the role stored on the login account (users.role)
    try {
        $st = $pdo->prepare(
            "SELECT LOWER(TRIM(p.permission_name))
               FROM roles r
               JOIN role_permissions rp ON rp.role_id = r.id AND (rp.status IS NULL OR rp.status = 'Active')
               JOIN permissions p       ON p.id = rp.permission_id AND (p.status IS NULL OR p.status = 'Active')
              WHERE LOWER(TRIM(r.role_name)) = ? AND (r.status IS NULL OR r.status = 'Active')");
        $st->execute([acc_norm($roleName)]);
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $n) $perms[$n] = true;
    } catch (Throwable $e) { /* tables not created yet */ }

    // find the HRMS employee that belongs to this login (explicit link, else matching e-mail)
    $employeeId = null;
    if ($userId) {
        try {
            $st = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $st->execute([$userId]);
            $u = $st->fetch();
            if ($u && !empty($u['employee_id'])) {
                $employeeId = (int)$u['employee_id'];
            } elseif ($u && !empty($u['email'])) {
                $e = $pdo->prepare("SELECT id FROM employees WHERE official_email = ? OR personal_email = ? LIMIT 1");
                $e->execute([$u['email'], $u['email']]);
                $id = $e->fetchColumn();
                if ($id) $employeeId = (int)$id;
            }
        } catch (Throwable $e) { /* optional */ }
    }

    if ($employeeId) {
        // 2) extra roles assigned on the Users page
        try {
            $st = $pdo->prepare(
                "SELECT LOWER(TRIM(p.permission_name))
                   FROM user_roles ur
                   JOIN roles r             ON r.id = ur.role_id AND (r.status IS NULL OR r.status = 'Active')
                   JOIN role_permissions rp ON rp.role_id = r.id AND (rp.status IS NULL OR rp.status = 'Active')
                   JOIN permissions p       ON p.id = rp.permission_id AND (p.status IS NULL OR p.status = 'Active')
                  WHERE ur.employee_id = ? AND (ur.status IS NULL OR ur.status = 'Active')");
            $st->execute([$employeeId]);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $n) $perms[$n] = true;
        } catch (Throwable $e) { /* optional */ }

        // 3) per-user overrides (allow / deny, optionally date-limited)
        try {
            $st = $pdo->prepare(
                "SELECT LOWER(TRIM(p.permission_name)) AS n, up.is_allowed
                   FROM user_permissions up
                   JOIN permissions p ON p.id = up.permission_id
                  WHERE up.employee_id = ?
                    AND (up.valid_from IS NULL OR up.valid_from <= CURDATE())
                    AND (up.valid_to   IS NULL OR up.valid_to   >= CURDATE())");
            $st->execute([$employeeId]);
            foreach ($st->fetchAll() as $row) {
                if ((int)$row['is_allowed'] === 1) $perms[$row['n']] = true;
                else unset($perms[$row['n']]);
            }
        } catch (Throwable $e) { /* optional */ }
    }

    return $cache[$key] = $perms;
}

/** True when the signed-in user is Admin / Super Admin, or holds ANY of the named permissions. */
function acc_can(PDO $pdo, string ...$names): bool {
    $u = acc_session_user();
    if (!$u['id']) return false;
    if (acc_is_admin_role($u['role'])) return true;
    $have = acc_permissions($pdo, $u['id'], $u['role']);
    foreach ($names as $n) if (isset($have[acc_norm($n)])) return true;
    return false;
}

/** Stop the request with a JSON 403 unless acc_can() is true. */
function acc_require(PDO $pdo, array $names, string $what = 'do this'): void {
    if (acc_can($pdo, ...$names)) return;
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => "You don't have permission to $what. Ask an administrator to grant: " . implode(' or ', $names) . '.',
    ]);
    exit;
}

/**
 * Only administrators may touch the Super Admin / Admin roles. Without this a delegated
 * "Manage Roles" user could simply give themselves the Super Admin role.
 */
function acc_guard_privileged_role(PDO $pdo, int $roleId): void {
    $u = acc_session_user();
    if (acc_is_admin_role($u['role'])) return;
    $st = $pdo->prepare("SELECT role_name, role_level FROM roles WHERE id = ?");
    $st->execute([$roleId]);
    $r = $st->fetch();
    if ($r && (acc_is_admin_role($r['role_name']) || (int)$r['role_level'] <= 2)) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Only an Admin or Super Admin can change or assign the Admin-level roles.']);
        exit;
    }
}

/**
 * What the front-end sidebar needs to know. Sent with api/auth.php (login + check).
 * 'administration' stays Admin-only: every Administration action on the server is admin-only.
 */
function acc_menu_access(PDO $pdo, array $user): array {
    $role    = (string)($user['role'] ?? '');
    $isAdmin = acc_is_admin_role($role);
    $have    = $isAdmin ? [] : acc_permissions($pdo, isset($user['id']) ? (int)$user['id'] : null, $role);
    $has     = function (string ...$n) use ($isAdmin, $have) {
        if ($isAdmin) return true;
        foreach ($n as $x) if (isset($have[acc_norm($x)])) return true;
        return false;
    };
    $pages = [
        'Users'        => $has('Manage Users'),
        'Roles'        => $has('Manage Roles'),
        'Permissions'  => $has('Manage Permissions'),
        'Departments'  => $has('Manage Users'),
        'Designations' => $has('Manage Users'),
    ];
    return [
        'is_admin'        => $isAdmin,
        'is_super_admin'  => acc_is_super_role($role),
        'administration'  => $isAdmin,
        'user_management' => in_array(true, $pages, true),
        'pages'           => $pages,
    ];
}

} // function_exists guard
