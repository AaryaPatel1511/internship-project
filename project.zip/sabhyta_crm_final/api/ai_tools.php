<?php
/**
 * AI Tools API
 * Handles Chat Assistant, Email Generator, Proposal Generator, OCR, Voice Notes, Analytics
 */
header('Content-Type: application/json');
require_once 'db.php';
require_once 'session_guard.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$tool = $_GET['tool'] ?? '';
$userId = $_SESSION['user_id'] ?? 0;
$conn = getDBConnection();

try {
    if ($tool === 'chat_assistant') {
        handleChatAssistant($method, $action, $userId, $conn);
    } elseif ($tool === 'email_generator') {
        handleEmailGenerator($method, $action, $userId, $conn);
    } elseif ($tool === 'proposal_generator') {
        handleProposalGenerator($method, $action, $userId, $conn);
    } elseif ($tool === 'ocr_scanner') {
        handleOCRScanner($method, $action, $userId, $conn);
    } elseif ($tool === 'voice_notes') {
        handleVoiceNotes($method, $action, $userId, $conn);
    } elseif ($tool === 'analytics') {
        handleAnalytics($method, $action, $userId, $conn);
    } elseif ($tool === 'job_status') {
        handleJobStatus($method, $action, $userId, $conn);
    } else {
        throw new Exception('Invalid AI tool');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}

function handleChatAssistant($method, $action, $userId, $conn) {
    if ($method === 'POST' && $action === 'start_session') {
        $sessionId = uniqid('chat_', true);
        $stmt = $conn->prepare("INSERT INTO ai_chat_sessions (session_id, user_id) VALUES (?, ?)");
        $stmt->bind_param('si', $sessionId, $userId);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'session_id' => $sessionId]);
        } else {
            throw new Exception('Failed to start chat session');
        }
    } elseif ($method === 'POST' && $action === 'send_message') {
        $data = json_decode(file_get_contents('php://input'), true);
        $sessionId = $data['session_id'] ?? null;
        $message = $data['message'] ?? null;
        $recordAccess = json_encode($data['permitted_records'] ?? []);

        if (!$sessionId || !$message) {
            throw new Exception('Missing required fields');
        }

        // Create AI job
        $jobId = uniqid('job_', true);
        $jobType = 'chat_assistant';
        $status = 'processing';
        $stmt = $conn->prepare("INSERT INTO ai_jobs (job_id, requesting_user_id, job_type, status, user_prompt, source_references) 
                               VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('sisss', $jobId, $userId, $jobType, $status, $message, $recordAccess);
        $stmt->execute();

        // Simulate AI response (in production, call actual AI provider)
        $response = generateAIResponse($message);

        // Store in chat session
        $stmt2 = $conn->prepare("UPDATE ai_chat_sessions SET conversation_history = CONCAT(IFNULL(conversation_history, ''), ?), 
                                total_messages = total_messages + 1, last_message_date = NOW() WHERE session_id = ?");
        $msgLog = json_encode(['user' => $message, 'ai' => $response, 'timestamp' => date('Y-m-d H:i:s')]) . "\n";
        $stmt2->bind_param('ss', $msgLog, $sessionId);
        $stmt2->execute();

        // Update job status
        $stmt3 = $conn->prepare("UPDATE ai_jobs SET generated_output = ?, status = 'draft_ready', processed_date = NOW() WHERE job_id = ?");
        $stmt3->bind_param('ss', $response, $jobId);
        $stmt3->execute();

        echo json_encode([
            'success' => true,
            'job_id' => $jobId,
            'response' => $response,
            'requires_review' => false
        ]);
    }
}

function handleEmailGenerator($method, $action, $userId, $conn) {
    if ($method === 'POST' && $action === 'generate') {
        $data = json_decode(file_get_contents('php://input'), true);
        $jobId = uniqid('job_', true);
        $jobType = 'email_generator';
        $status = 'processing';

        $stmt = $conn->prepare("INSERT INTO ai_jobs (job_id, requesting_user_id, job_type, status, user_prompt) 
                               VALUES (?, ?, ?, ?, ?)");
        $prompt = json_encode($data);
        $stmt->bind_param('sisss', $jobId, $userId, $jobType, $status, $prompt);
        $stmt->execute();

        // Generate email content
        $emailSubject = generateEmailSubject($data['purpose'] ?? 'General');
        $emailBody = generateEmailBody($data);

        // Store draft
        $stmt2 = $conn->prepare("INSERT INTO ai_email_drafts 
                                (job_id, recipient_email, purpose, language, tone, email_subject, email_body) 
                                VALUES (?, ?, ?, ?, ?, ?, ?)");
        $lang = $data['language'] ?? 'en';
        $tone = $data['tone'] ?? 'professional';
        $purpose = $data['purpose'] ?? '';
        $recipientEmail = $data['recipient_email'] ?? '';
        $stmt2->bind_param('sssssss', $jobId, $recipientEmail, $purpose, $lang, $tone, $emailSubject, $emailBody);
        $stmt2->execute();

        // Update job
        $stmt3 = $conn->prepare("UPDATE ai_jobs SET generated_output = ?, status = 'draft_ready' WHERE job_id = ?");
        $output = json_encode(['subject' => $emailSubject, 'body' => $emailBody]);
        $stmt3->bind_param('ss', $output, $jobId);
        $stmt3->execute();

        echo json_encode([
            'success' => true,
            'job_id' => $jobId,
            'email_draft' => [
                'subject' => $emailSubject,
                'body' => $emailBody
            ]
        ]);
    } elseif ($method === 'POST' && $action === 'send_email') {
        $draftId = $_GET['id'] ?? null;
        $stmt = $conn->prepare("UPDATE ai_email_drafts SET is_sent = true, sent_date = NOW() WHERE id = ?");
        $stmt->bind_param('i', $draftId);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Email sent successfully']);
        } else {
            throw new Exception('Failed to send email');
        }
    }
}

function handleProposalGenerator($method, $action, $userId, $conn) {
    if ($method === 'POST' && $action === 'generate') {
        $data = json_decode(file_get_contents('php://input'), true);
        $jobId = uniqid('job_', true);
        $jobType = 'proposal_generator';
        $status = 'processing';

        // Create AI job
        $prompt = json_encode($data);
        $stmt = $conn->prepare("INSERT INTO ai_jobs (job_id, requesting_user_id, job_type, status, user_prompt) 
                               VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param('sisss', $jobId, $userId, $jobType, $status, $prompt);
        $stmt->execute();

        // Generate proposal
        $proposalContent = generateProposalContent($data);
        $proposalNumber = 'PROP-' . date('YmdHis');

        $stmt2 = $conn->prepare("INSERT INTO ai_proposals 
                                (job_id, customer_id, opportunity_id, requirement_summary, approved_scope, 
                                 deliverables, timeline_days, proposal_number) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $customerId = $data['customer_id'] ?? 0;
        $oppId = $data['opportunity_id'] ?? null;
        $reqSummary = $data['requirement_summary'] ?? '';
        $scope = $data['approved_scope'] ?? '';
        $deliverables = json_encode($data['deliverables'] ?? []);
        $timeline = $data['timeline_days'] ?? 30;
        
        $stmt2->bind_param('iissssis', $jobId, $customerId, $oppId, $reqSummary, $scope, $deliverables, $timeline, $proposalNumber);
        $stmt2->execute();

        echo json_encode([
            'success' => true,
            'job_id' => $jobId,
            'proposal_number' => $proposalNumber,
            'status' => 'awaiting_review'
        ]);
    }
}

function handleOCRScanner($method, $action, $userId, $conn) {
    if ($method === 'POST' && $action === 'scan_document') {
        if (!isset($_FILES['document'])) {
            throw new Exception('No document uploaded');
        }

        $file = $_FILES['document'];
        $jobId = uniqid('job_', true);
        
        // Validate and process file
        $uploadDir = '../uploads/ocr/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        
        $fileName = uniqid() . '_' . basename($file['name']);
        $filePath = $uploadDir . $fileName;
        
        if (!move_uploaded_file($file['tmp_name'], $filePath)) {
            throw new Exception('Failed to upload file');
        }

        // Create OCR job
        $docType = $_POST['document_type'] ?? 'invoice';
        $targetEntity = $_POST['target_entity_type'] ?? '';
        $lang = $_POST['language'] ?? 'en';

        $stmt = $conn->prepare("INSERT INTO ocr_scans 
                               (job_id, document_type, language, target_entity_type, original_file_path) 
                               VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param('sssss', $jobId, $docType, $lang, $targetEntity, $filePath);
        $stmt->execute();

        // Simulate OCR processing
        $extractedText = performOCRExtraction($filePath);
        $extractedJson = parseOCROutput($extractedText, $docType);

        $stmt2 = $conn->prepare("UPDATE ocr_scans SET extracted_text = ?, extracted_json = ? WHERE job_id = ?");
        $jsonStr = json_encode($extractedJson);
        $stmt2->bind_param('sss', $extractedText, $jsonStr, $jobId);
        $stmt2->execute();

        echo json_encode([
            'success' => true,
            'job_id' => $jobId,
            'extracted_data' => $extractedJson,
            'requires_review' => true
        ]);
    } elseif ($method === 'POST' && $action === 'confirm_extraction') {
        $scanId = $_GET['id'] ?? null;
        $data = json_decode(file_get_contents('php://input'), true);
        $corrections = json_encode($data['corrections'] ?? []);

        $stmt = $conn->prepare("UPDATE ocr_scans SET reviewer_corrections = ?, corrected_by = ?, correction_date = NOW() 
                               WHERE id = ?");
        $stmt->bind_param('sii', $corrections, $_SESSION['user_id'], $scanId);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Extraction confirmed']);
        } else {
            throw new Exception('Failed to confirm extraction');
        }
    }
}

function handleVoiceNotes($method, $action, $userId, $conn) {
    if ($method === 'POST' && $action === 'upload_recording') {
        if (!isset($_FILES['audio'])) {
            throw new Exception('No audio file uploaded');
        }

        $file = $_FILES['audio'];
        $jobId = uniqid('job_', true);
        
        $uploadDir = '../uploads/voice_notes/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        
        $fileName = uniqid() . '_' . basename($file['name']);
        $filePath = $uploadDir . $fileName;
        
        if (!move_uploaded_file($file['tmp_name'], $filePath)) {
            throw new Exception('Failed to upload audio');
        }

        // Create voice note
        $stmt = $conn->prepare("INSERT INTO voice_notes 
                               (job_id, user_id, recording_date, language, audio_file_path) 
                               VALUES (?, ?, CURDATE(), ?, ?)");
        $lang = $_POST['language'] ?? 'en';
        $stmt->bind_param('siss', $jobId, $userId, $lang, $filePath);
        $stmt->execute();

        // Simulate transcription
        $transcript = performTranscription($filePath, $lang);

        $stmt2 = $conn->prepare("UPDATE voice_notes SET transcript_text = ? WHERE job_id = ?");
        $stmt2->bind_param('ss', $transcript, $jobId);
        $stmt2->execute();

        echo json_encode([
            'success' => true,
            'job_id' => $jobId,
            'transcript' => $transcript
        ]);
    }
}

function handleAnalytics($method, $action, $userId, $conn) {
    if ($method === 'POST' && $action === 'analyze') {
        $data = json_decode(file_get_contents('php://input'), true);
        $jobId = uniqid('job_', true);
        
        $stmt = $conn->prepare("INSERT INTO ai_analytics_jobs 
                               (job_id, business_question, snapshot_date) 
                               VALUES (?, ?, CURDATE())");
        $question = $data['question'] ?? '';
        $stmt->bind_param('ss', $jobId, $question);
        $stmt->execute();

        // Generate analysis
        $analysis = performDataAnalysis($data);

        $stmt2 = $conn->prepare("UPDATE ai_analytics_jobs SET analysis_result = ?, trend_explanation = ? WHERE job_id = ?");
        $result = json_encode($analysis);
        $explanation = $analysis['explanation'] ?? '';
        $stmt2->bind_param('sss', $result, $explanation, $jobId);
        $stmt2->execute();

        echo json_encode([
            'success' => true,
            'job_id' => $jobId,
            'analysis' => $analysis
        ]);
    }
}

function handleJobStatus($method, $action, $userId, $conn) {
    if ($method === 'GET' && $action === 'status') {
        $jobId = $_GET['job_id'] ?? null;
        $stmt = $conn->prepare("SELECT id, status, generated_output, review_status FROM ai_jobs WHERE job_id = ? AND requesting_user_id = ?");
        $stmt->bind_param('si', $jobId, $userId);
        $stmt->execute();
        $job = $stmt->get_result()->fetch_assoc();
        
        if ($job) {
            echo json_encode(['success' => true, 'job' => $job]);
        } else {
            throw new Exception('Job not found');
        }
    } elseif ($method === 'POST' && $action === 'review') {
        $jobId = $_GET['job_id'] ?? null;
        $data = json_decode(file_get_contents('php://input'), true);
        $reviewStatus = $data['status'] ?? 'approved';
        $comments = $data['comments'] ?? null;

        $stmt = $conn->prepare("UPDATE ai_jobs SET review_status = ?, review_comments = ?, reviewed_by = NOW() WHERE job_id = ? AND requesting_user_id = ?");
        $stmt->bind_param('sssi', $reviewStatus, $comments, $jobId, $userId);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Review submitted']);
        } else {
            throw new Exception('Failed to submit review');
        }
    }
}

// Helper functions
function generateAIResponse($prompt) {
    return "This is a simulated AI response to: " . substr($prompt, 0, 100) . "...";
}

function generateEmailSubject($purpose) {
    $subjects = [
        'Sales Follow-up' => 'Regarding Your Inquiry',
        'Customer Support' => 'We\'re Here to Help',
        'Project Update' => 'Project Status Update',
        'General' => 'Message from Our Team'
    ];
    return $subjects[$purpose] ?? 'Important Message';
}

function generateEmailBody($data) {
    return "Dear [Recipient],\n\nThank you for your interest.\n\nBest regards,\n[Your Name]";
}

function generateProposalContent($data) {
    return json_encode($data);
}

function performOCRExtraction($filePath) {
    // Placeholder for actual OCR library integration
    return "Extracted text from document";
}

function parseOCROutput($text, $docType) {
    $data = [
        'document_type' => $docType,
        'extracted_fields' => [],
        'confidence_score' => 0.85
    ];
    return $data;
}

function performTranscription($audioPath, $lang) {
    return "This is a simulated transcription of the audio file.";
}

function performDataAnalysis($data) {
    return [
        'summary' => 'Analysis summary',
        'metrics' => [],
        'explanation' => 'Data analysis completed'
    ];
}

?>
