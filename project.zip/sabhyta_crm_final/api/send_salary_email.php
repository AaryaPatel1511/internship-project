<?php
/**
 * Send Salary Slip Email (HRMS > Salary > "Process Salary by Employee")
 * --------------------------------------------------------
 * POST /api/send_salary_email.php
 * Body (JSON): {
 *   employeeId, period (e.g. "July 2026"),
 *   basic, hra, da, conveyance, medicalAllowance, specialAllowance,
 *   pf, esic, professionalTax,
 *   gross, totalDeductions, net,
 *   grossYearly, totalDeductionsYearly, netYearly, metro
 * }
 *
 * The employee's name / email / department / designation are looked up
 * server-side from the `employees` table by employeeId — never trusted
 * from the client — so the slip always goes to the right inbox.
 *
 * NOTE: uses PHP's built-in mail(). On a typical shared-hosting cPanel
 * server this works out of the box. On local XAMPP/WAMP you must
 * configure an SMTP relay (e.g. XAMPP's sendmail.ini) or swap the
 * send section below for SMTP/PHPMailer — the slip HTML is already
 * fully built and ready to hand to either.
 * --------------------------------------------------------
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';

// ---- company / sender details — edit to match your organisation ----
const COMPANY_NAME = 'SABHYTA CRM';
const FROM_EMAIL    = 'payroll@sabhytacrm.local';
const FROM_NAME     = 'SABHYTA CRM Payroll';

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(["success" => false, "message" => "Method not allowed"], 405);
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input || empty($input['employeeId'])) {
    respond(["success" => false, "message" => "Missing employeeId"], 422);
}

$stmt = $pdo->prepare("SELECT e.*, d.department_name, de.designation_name
                        FROM employees e
                        LEFT JOIN departments d ON d.id = e.department_id
                        LEFT JOIN designations de ON de.id = e.designation_id
                        WHERE e.id = ?");
$stmt->execute([$input['employeeId']]);
$emp = $stmt->fetch();
if (!$emp) respond(["success" => false, "message" => "Employee not found"], 404);

$toEmail = $emp['official_email'] ?: $emp['personal_email'];
if (!$toEmail) respond(["success" => false, "message" => "This employee has no official or personal email on file."], 422);

$name = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''));
$period = $input['period'] ?? date('F Y');

function n($v) { return number_format((float)($v ?? 0), 2); }
function inr($v) { return '₹' . number_format((float)($v ?? 0), 2); }

$rowsHtml = '';
$earnings = [
    'Basic Salary'      => $input['basic'] ?? 0,
    'HRA'               => $input['hra'] ?? 0,
    'DA'                => $input['da'] ?? 0,
    'Conveyance'        => $input['conveyance'] ?? 0,
    'Medical Allowance' => $input['medicalAllowance'] ?? 0,
    'Special Allowance' => $input['specialAllowance'] ?? 0,
];
$deductions = [
    'Provident Fund (PF)' => $input['pf'] ?? 0,
    'ESIC'                => $input['esic'] ?? 0,
    'Professional Tax'    => $input['professionalTax'] ?? 0,
];

$earnRows = '';
foreach ($earnings as $label => $val) $earnRows .= "<tr><td style='padding:6px 10px;border:1px solid #e3e6ec;'>$label</td><td style='padding:6px 10px;border:1px solid #e3e6ec;text-align:right;'>" . inr($val) . "</td></tr>";
$dedRows = '';
foreach ($deductions as $label => $val) $dedRows .= "<tr><td style='padding:6px 10px;border:1px solid #e3e6ec;'>$label</td><td style='padding:6px 10px;border:1px solid #e3e6ec;text-align:right;'>" . inr($val) . "</td></tr>";

$html = "
<div style='font-family:Arial,Helvetica,sans-serif;max-width:640px;margin:0 auto;color:#222;'>
  <div style='background:#1c2b4a;color:#fff;padding:18px 24px;border-radius:8px 8px 0 0;'>
    <h2 style='margin:0;font-size:20px;'>" . COMPANY_NAME . "</h2>
    <p style='margin:4px 0 0;font-size:13px;opacity:.85;'>Salary Slip — $period</p>
  </div>
  <div style='border:1px solid #e3e6ec;border-top:none;padding:20px 24px;border-radius:0 0 8px 8px;'>
    <table style='width:100%;font-size:13px;margin-bottom:16px;'>
      <tr><td style='padding:3px 0;color:#666;'>Employee</td><td style='padding:3px 0;font-weight:700;'>" . htmlspecialchars($name) . " (" . htmlspecialchars($emp['employee_code'] ?? '') . ")</td></tr>
      <tr><td style='padding:3px 0;color:#666;'>Department</td><td style='padding:3px 0;'>" . htmlspecialchars($emp['department_name'] ?? '-') . "</td></tr>
      <tr><td style='padding:3px 0;color:#666;'>Designation</td><td style='padding:3px 0;'>" . htmlspecialchars($emp['designation_name'] ?? '-') . "</td></tr>
      <tr><td style='padding:3px 0;color:#666;'>CTC (Annual)</td><td style='padding:3px 0;'>" . inr($emp['ctc'] ?? 0) . "</td></tr>
    </table>

    <table style='width:100%;border-collapse:collapse;font-size:13px;margin-bottom:14px;'>
      <thead><tr style='background:#f4f6fa;'><th colspan='2' style='padding:6px 10px;border:1px solid #e3e6ec;text-align:left;'>Earnings (Monthly)</th></tr></thead>
      <tbody>$earnRows
        <tr style='font-weight:700;background:#f9fafc;'><td style='padding:6px 10px;border:1px solid #e3e6ec;'>Gross Salary</td><td style='padding:6px 10px;border:1px solid #e3e6ec;text-align:right;'>" . inr($input['gross'] ?? 0) . "</td></tr>
      </tbody>
    </table>

    <table style='width:100%;border-collapse:collapse;font-size:13px;margin-bottom:14px;'>
      <thead><tr style='background:#f4f6fa;'><th colspan='2' style='padding:6px 10px;border:1px solid #e3e6ec;text-align:left;'>Deductions (Monthly)</th></tr></thead>
      <tbody>$dedRows
        <tr style='font-weight:700;background:#f9fafc;'><td style='padding:6px 10px;border:1px solid #e3e6ec;'>Total Deductions</td><td style='padding:6px 10px;border:1px solid #e3e6ec;text-align:right;'>" . inr($input['totalDeductions'] ?? 0) . "</td></tr>
      </tbody>
    </table>

    <table style='width:100%;border-collapse:collapse;font-size:14px;margin-bottom:6px;'>
      <tr style='background:#1c2b4a;color:#fff;font-weight:700;'><td style='padding:10px;'>Net Salary (Monthly, Take Home)</td><td style='padding:10px;text-align:right;'>" . inr($input['net'] ?? 0) . "</td></tr>
    </table>
    <table style='width:100%;border-collapse:collapse;font-size:13px;color:#555;'>
      <tr><td style='padding:6px 10px;border:1px solid #e3e6ec;'>Gross Salary (Yearly)</td><td style='padding:6px 10px;border:1px solid #e3e6ec;text-align:right;'>" . inr($input['grossYearly'] ?? 0) . "</td></tr>
      <tr><td style='padding:6px 10px;border:1px solid #e3e6ec;'>Total Deductions (Yearly)</td><td style='padding:6px 10px;border:1px solid #e3e6ec;text-align:right;'>" . inr($input['totalDeductionsYearly'] ?? 0) . "</td></tr>
      <tr style='font-weight:700;'><td style='padding:6px 10px;border:1px solid #e3e6ec;'>Net Salary (Yearly, Take Home)</td><td style='padding:6px 10px;border:1px solid #e3e6ec;text-align:right;'>" . inr($input['netYearly'] ?? 0) . "</td></tr>
    </table>

    <p style='font-size:11px;color:#999;margin-top:18px;'>This is a system-generated salary slip from " . COMPANY_NAME . ". Please contact HR/Payroll for any discrepancy.</p>
  </div>
</div>";

$subject = COMPANY_NAME . " — Salary Slip for $period";
$headers  = "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
$headers .= "From: " . FROM_NAME . " <" . FROM_EMAIL . ">\r\n";
$headers .= "Reply-To: " . FROM_EMAIL . "\r\n";

$sent = @mail($toEmail, $subject, $html, $headers);

if ($sent) {
    respond(["success" => true, "message" => "Salary slip emailed to $toEmail"]);
} else {
    respond(["success" => false, "message" => "Could not send email. Configure a mail/SMTP server on this host (see comments in api/send_salary_email.php), then try again."], 500);
}
