<?php
// Compatibility alias — departments via user_masters
$_GET['type'] = 'departments';
require_once __DIR__ . '/user_masters.php';
