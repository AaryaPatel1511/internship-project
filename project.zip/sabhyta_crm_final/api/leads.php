<?php
/**
 * Lead Management REST API
 * --------------------------------------------------------
 * GET    /api/leads.php?action=list&source=&status=&priority=&branch=
 *                       &executive=&q=&date_from=&date_to=&page=&per_page=
 * GET    /api/leads.php?action=get&id=5
 * POST   /api/leads.php   action=create   (JSON body, all lead fields)
 * POST   /api/leads.php   action=update&id=5  (JSON body)
 * POST   /api/leads.php   action=delete&id=5
 * GET    /api/leads.php?action=stats            -> dashboard + pipeline counts
 * GET    /api/leads.php?action=lost_reports      -> aggregated lost-lead reports
 * GET    /api/leads.php?action=sales_reports     -> aggregated converted/booking reports
 * POST   /api/leads.php   action=import  (multipart file=leads.csv)
 * GET    /api/leads.php?action=sample_csv        -> downloadable CSV template
 * GET    /api/leads.php?action=error_csv         -> last import's failed rows
 * --------------------------------------------------------
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_REQUEST['action'] ?? ($method === 'GET' ? 'list' : '');

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

// DB column => JS/JSON field name. Kept in one place so create/update/
// import all agree on the same mapping.
const LEAD_FIELDS = [
    'lead_date'              => 'leadDate',
    'customer_name'          => 'customerName',
    'mobile'                 => 'mobile',
    'alternate_mobile'       => 'alternateMobile',
    'email'                  => 'email',
    'gender'                 => 'gender',
    'dob'                    => 'dob',
    'address_line'           => 'addressLine',
    'landmark'               => 'landmark',
    'city'                   => 'city',
    'district'               => 'district',
    'state'                  => 'state',
    'country'                => 'country',
    'pincode'                => 'pincode',
    'vehicle_brand'          => 'vehicleBrand',
    'vehicle_model'          => 'vehicleModel',
    'variant'                => 'variant',
    'fuel_type'              => 'fuelType',
    'transmission'           => 'transmission',
    'color_preference'       => 'colorPreference',
    'budget'                 => 'budget',
    'expected_purchase_date' => 'expectedPurchaseDate',
    'finance_required'       => 'financeRequired',
    'exchange_required'      => 'exchangeRequired',
    'test_drive_required'    => 'testDriveRequired',
    'corporate_customer'     => 'corporateCustomer',
    'existing_customer'      => 'existingCustomer',
    'lead_source'            => 'leadSource',
    'branch'                 => 'branch',
    'sales_executive'        => 'salesExecutive',
    'team_leader'            => 'teamLeader',
    'priority'               => 'priority',
    'requirement_notes'      => 'requirementNotes',
    'notes'                  => 'notes',
    'attachment'             => 'attachment',
    'status'                 => 'status',
];

const LOST_FIELDS = [
    'lost_date'         => 'lostDate',
    'lost_reason'       => 'lostReason',
    'competitor_name'   => 'competitorName',
    'price_difference'  => 'priceDifference',
];

const CONVERTED_FIELDS = [
    'booking_number'      => 'bookingNumber',
    'invoice_number'      => 'invoiceNumber',
    'booking_date'        => 'bookingDate',
    'delivery_date'       => 'deliveryDate',
    'finance_company'     => 'financeCompany',
    'loan_amount'         => 'loanAmount',
    'final_amount'        => 'finalAmount',
    'payment_mode'        => 'paymentMode',
    'booking_amount'      => 'bookingAmount',
    'discount_given'      => 'discountGiven',
    'exchange_value'      => 'exchangeValue',
    'accessories_sold'    => 'accessoriesSold',
    'insurance_amount'    => 'insuranceAmount',
    'extended_warranty'   => 'extendedWarranty',
    'rto_charges'         => 'rtoCharges',
    'accessories_package' => 'accessoriesPackage',
    'delivery_executive'  => 'deliveryExecutive',
];

function nextLeadCode($pdo) {
    $n = (int) $pdo->query("SELECT COALESCE(MAX(id),0) FROM leads")->fetchColumn() + 1;
    return 'LD-' . str_pad($n, 6, '0', STR_PAD_LEFT);
}

function currentUserName() {
    return $_SESSION['user_name'] ?? 'System';
}

// -----------------------------------------------------------------
// LIST
// -----------------------------------------------------------------
if ($method === 'GET' && $action === 'list') {
    $where = [];
    $params = [];

    if (!empty($_GET['source'])) { $where[] = 'lead_source = ?'; $params[] = $_GET['source']; }
    if (!empty($_GET['status'])) { $where[] = 'status = ?'; $params[] = $_GET['status']; }
    if (!empty($_GET['priority'])) { $where[] = 'priority = ?'; $params[] = $_GET['priority']; }
    if (!empty($_GET['branch'])) { $where[] = 'branch = ?'; $params[] = $_GET['branch']; }
    if (!empty($_GET['executive'])) { $where[] = 'sales_executive = ?'; $params[] = $_GET['executive']; }
    if (!empty($_GET['date_from'])) { $where[] = 'DATE(lead_date) >= ?'; $params[] = $_GET['date_from']; }
    if (!empty($_GET['date_to'])) { $where[] = 'DATE(lead_date) <= ?'; $params[] = $_GET['date_to']; }
    if (!empty($_GET['q'])) {
        $where[] = '(customer_name LIKE ? OR mobile LIKE ? OR email LIKE ? OR lead_code LIKE ?)';
        $like = '%' . $_GET['q'] . '%';
        array_push($params, $like, $like, $like, $like);
    }

    $sql = "SELECT * FROM leads";
    if ($where) $sql .= " WHERE " . implode(' AND ', $where);
    $sql .= " ORDER BY id DESC";

    $page = max(1, (int)($_GET['page'] ?? 1));
    $perPage = min(200, max(10, (int)($_GET['per_page'] ?? 50)));
    $countStmt = $pdo->prepare(str_replace('SELECT *', 'SELECT COUNT(*)', $sql));
    $countStmt->execute($params);
    $total = (int) $countStmt->fetchColumn();

    $sql .= " LIMIT $perPage OFFSET " . (($page - 1) * $perPage);
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    respond(["success" => true, "data" => $rows, "total" => $total, "page" => $page, "per_page" => $perPage]);
}

// -----------------------------------------------------------------
// GET ONE
// -----------------------------------------------------------------
if ($method === 'GET' && $action === 'get') {
    $id = (int) ($_GET['id'] ?? 0);
    $stmt = $pdo->prepare("SELECT * FROM leads WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) respond(["success" => false, "message" => "Lead not found."], 404);
    respond(["success" => true, "data" => $row]);
}

// -----------------------------------------------------------------
// CREATE
// -----------------------------------------------------------------
if ($method === 'POST' && $action === 'create') {
    $body = json_decode(file_get_contents('php://input'), true) ?? [];

    if (empty($body['customerName']) || empty($body['mobile'])) {
        respond(["success" => false, "message" => "Customer name and mobile number are required."], 422);
    }
    if (!preg_match('/^[0-9+\-\s]{7,20}$/', $body['mobile'])) {
        respond(["success" => false, "message" => "Please enter a valid mobile number."], 422);
    }

    $cols = ['lead_code'];
    $vals = [nextLeadCode($pdo)];
    $placeholders = ['?'];

    foreach (LEAD_FIELDS as $col => $key) {
        $cols[] = $col;
        $placeholders[] = '?';
        $vals[] = ($body[$key] ?? '') === '' ? null : $body[$key];
    }
    $cols[] = 'created_by'; $placeholders[] = '?'; $vals[] = currentUserName();
    if (empty($body['leadDate'])) {
        // Default to now if the form left it blank
        $idx = array_search('lead_date', $cols);
        $vals[$idx] = date('Y-m-d H:i:s');
    }
    if (empty($body['status'])) {
        $idx = array_search('status', $cols);
        $vals[$idx] = 'New Lead';
    }

    $sql = "INSERT INTO leads (" . implode(',', $cols) . ") VALUES (" . implode(',', $placeholders) . ")";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($vals);
    $id = $pdo->lastInsertId();

    $pdo->prepare("INSERT INTO lead_status_history (lead_id, old_status, new_status, updated_by) VALUES (?, NULL, ?, ?)")
        ->execute([$id, $body['status'] ?? 'New Lead', currentUserName()]);

    respond(["success" => true, "id" => $id, "message" => "Lead saved successfully."]);
}

// -----------------------------------------------------------------
// UPDATE
// -----------------------------------------------------------------
if ($method === 'POST' && $action === 'update') {
    $id = (int) ($_GET['id'] ?? $_REQUEST['id'] ?? 0);
    if (!$id) respond(["success" => false, "message" => "Missing lead id."], 422);

    $body = json_decode(file_get_contents('php://input'), true) ?? [];

    $stmt = $pdo->prepare("SELECT status FROM leads WHERE id = ?");
    $stmt->execute([$id]);
    $existing = $stmt->fetch();
    if (!$existing) respond(["success" => false, "message" => "Lead not found."], 404);

    $allFields = LEAD_FIELDS;
    if (($body['status'] ?? '') === 'Lost') $allFields = $allFields + LOST_FIELDS;
    if (($body['status'] ?? '') === 'Converted') $allFields = $allFields + CONVERTED_FIELDS;
    // Always allow lost/converted fields to be saved if present in the payload,
    // regardless of current status (e.g. correcting a booking's numbers later).
    foreach (LOST_FIELDS as $col => $key) if (array_key_exists($key, $body)) $allFields[$col] = $key;
    foreach (CONVERTED_FIELDS as $col => $key) if (array_key_exists($key, $body)) $allFields[$col] = $key;
    if (array_key_exists('nextFollowupDate', $body)) $allFields['next_followup_date'] = 'nextFollowupDate';

    $sets = [];
    $vals = [];
    foreach ($allFields as $col => $key) {
        if (!array_key_exists($key, $body)) continue;
        $sets[] = "$col = ?";
        $vals[] = ($body[$key] === '') ? null : $body[$key];
    }
    if (!$sets) respond(["success" => false, "message" => "Nothing to update."], 422);

    $vals[] = $id;
    $pdo->prepare("UPDATE leads SET " . implode(', ', $sets) . " WHERE id = ?")->execute($vals);

    if (!empty($body['status']) && $body['status'] !== $existing['status']) {
        $pdo->prepare("INSERT INTO lead_status_history (lead_id, old_status, new_status, remarks, updated_by) VALUES (?, ?, ?, ?, ?)")
            ->execute([$id, $existing['status'], $body['status'], $body['statusRemarks'] ?? null, currentUserName()]);
    }

    respond(["success" => true, "message" => "Lead updated successfully."]);
}

// -----------------------------------------------------------------
// DELETE
// -----------------------------------------------------------------
if (($method === 'POST' || $method === 'DELETE') && $action === 'delete') {
    $id = (int) ($_GET['id'] ?? $_REQUEST['id'] ?? 0);
    if (!$id) respond(["success" => false, "message" => "Missing lead id."], 422);
    $pdo->prepare("DELETE FROM leads WHERE id = ?")->execute([$id]);
    respond(["success" => true, "message" => "Lead deleted."]);
}

// -----------------------------------------------------------------
// STATS (dashboard counts used by Lead Status + overview cards)
// -----------------------------------------------------------------
if ($method === 'GET' && $action === 'stats') {
    $today = date('Y-m-d');

    $total = (int) $pdo->query("SELECT COUNT(*) FROM leads")->fetchColumn();
    $todayStmt = $pdo->prepare("SELECT COUNT(*) FROM leads WHERE DATE(lead_date) = ?");
    $todayStmt->execute([$today]);
    $todayLeads = (int) $todayStmt->fetchColumn();
    $pendingFollowups = (int) $pdo->query("SELECT COUNT(*) FROM leads WHERE next_followup_date IS NOT NULL AND next_followup_date <= CURDATE() AND status NOT IN ('Lost','Converted','Closed')")->fetchColumn();

    $byStatus = [];
    foreach ($pdo->query("SELECT status, COUNT(*) c FROM leads GROUP BY status") as $r) {
        $byStatus[$r['status']] = (int) $r['c'];
    }
    $bySource = [];
    foreach ($pdo->query("SELECT lead_source, COUNT(*) c FROM leads GROUP BY lead_source") as $r) {
        $bySource[$r['lead_source']] = (int) $r['c'];
    }

    respond(["success" => true, "data" => [
        "total_leads"       => $total,
        "today_leads"       => $todayLeads,
        "pending_followups" => $pendingFollowups,
        "test_drives"       => $byStatus['Test Drive'] ?? 0,
        "quotations_sent"   => $byStatus['Quotation Sent'] ?? 0,
        "booking_done"      => $byStatus['Booking'] ?? 0,
        "delivered"         => $byStatus['Delivered'] ?? 0,
        "lost_leads"        => $byStatus['Lost'] ?? 0,
        "by_status"         => $byStatus,
        "by_source"         => $bySource,
    ]]);
}

// -----------------------------------------------------------------
// LOST LEAD REPORTS
// -----------------------------------------------------------------
if ($method === 'GET' && $action === 'lost_reports') {
    function groupCount($pdo, $col) {
        $out = [];
        $stmt = $pdo->query("SELECT $col AS k, COUNT(*) c FROM leads WHERE status = 'Lost' GROUP BY $col ORDER BY c DESC");
        foreach ($stmt as $r) $out[] = ['label' => $r['k'] ?: 'Unspecified', 'count' => (int) $r['c']];
        return $out;
    }
    respond(["success" => true, "data" => [
        "by_executive" => groupCount($pdo, 'sales_executive'),
        "by_brand"     => groupCount($pdo, 'vehicle_brand'),
        "by_model"     => groupCount($pdo, 'vehicle_model'),
        "by_city"      => groupCount($pdo, 'city'),
        "by_reason"    => groupCount($pdo, 'lost_reason'),
        "by_month"     => (function() use ($pdo) {
            $out = [];
            $stmt = $pdo->query("SELECT DATE_FORMAT(lost_date, '%Y-%m') AS k, COUNT(*) c FROM leads WHERE status='Lost' AND lost_date IS NOT NULL GROUP BY k ORDER BY k");
            foreach ($stmt as $r) $out[] = ['label' => $r['k'], 'count' => (int) $r['c']];
            return $out;
        })(),
    ]]);
}

// -----------------------------------------------------------------
// CONVERTED / SALES REPORTS
// -----------------------------------------------------------------
if ($method === 'GET' && $action === 'sales_reports') {
    function groupSum($pdo, $col, $sumCol = 'final_amount') {
        $out = [];
        $stmt = $pdo->query("SELECT $col AS k, COUNT(*) c, COALESCE(SUM($sumCol),0) s FROM leads WHERE status = 'Converted' GROUP BY $col ORDER BY s DESC");
        foreach ($stmt as $r) $out[] = ['label' => $r['k'] ?: 'Unspecified', 'count' => (int) $r['c'], 'amount' => (float) $r['s']];
        return $out;
    }
    $totalRevenue = (float) $pdo->query("SELECT COALESCE(SUM(final_amount),0) FROM leads WHERE status='Converted'")->fetchColumn();
    $financeCount = (int) $pdo->query("SELECT COUNT(*) FROM leads WHERE status='Converted' AND finance_required='Yes'")->fetchColumn();
    $exchangeCount = (int) $pdo->query("SELECT COUNT(*) FROM leads WHERE status='Converted' AND exchange_required='Yes'")->fetchColumn();
    $convertedTotal = (int) $pdo->query("SELECT COUNT(*) FROM leads WHERE status='Converted'")->fetchColumn();

    respond(["success" => true, "data" => [
        "total_revenue"    => $totalRevenue,
        "converted_total"  => $convertedTotal,
        "finance_count"    => $financeCount,
        "exchange_count"   => $exchangeCount,
        "by_executive"     => groupSum($pdo, 'sales_executive'),
        "by_branch"        => groupSum($pdo, 'branch'),
        "by_vehicle"       => groupSum($pdo, 'vehicle_model'),
        "daily"            => (function() use ($pdo) {
            $out = [];
            $stmt = $pdo->query("SELECT booking_date AS k, COUNT(*) c, COALESCE(SUM(final_amount),0) s FROM leads WHERE status='Converted' AND booking_date IS NOT NULL GROUP BY booking_date ORDER BY booking_date DESC LIMIT 14");
            foreach ($stmt as $r) $out[] = ['label' => $r['k'], 'count' => (int) $r['c'], 'amount' => (float) $r['s']];
            return array_reverse($out);
        })(),
        "monthly"          => (function() use ($pdo) {
            $out = [];
            $stmt = $pdo->query("SELECT DATE_FORMAT(booking_date, '%Y-%m') AS k, COUNT(*) c, COALESCE(SUM(final_amount),0) s FROM leads WHERE status='Converted' AND booking_date IS NOT NULL GROUP BY k ORDER BY k");
            foreach ($stmt as $r) $out[] = ['label' => $r['k'], 'count' => (int) $r['c'], 'amount' => (float) $r['s']];
            return $out;
        })(),
    ]]);
}

// -----------------------------------------------------------------
// SAMPLE CSV TEMPLATE
// -----------------------------------------------------------------
if ($method === 'GET' && $action === 'sample_csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="lead_import_sample.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Customer Name', 'Mobile Number', 'Email', 'City', 'Vehicle Interested', 'Budget', 'Source', 'Sales Executive', 'Remarks']);
    fputcsv($out, ['Rahul Sharma', '9876543210', 'rahul@example.com', 'Mumbai', 'City SUV', '1200000', 'Website', 'Anita Rao', 'Interested in white colour']);
    fclose($out);
    exit;
}

// -----------------------------------------------------------------
// IMPORT (CSV upload)
// -----------------------------------------------------------------
if ($method === 'POST' && $action === 'import') {
    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        respond(["success" => false, "message" => "Please choose a CSV file to upload."], 422);
    }
    $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
    if ($ext !== 'csv') {
        respond(["success" => false, "message" => "Only .csv files are supported. Export your Excel sheet as CSV (UTF-8) first."], 422);
    }

    $handle = fopen($_FILES['file']['tmp_name'], 'r');
    if (!$handle) respond(["success" => false, "message" => "Could not read the uploaded file."], 500);

    $header = fgetcsv($handle);
    if (!$header) respond(["success" => false, "message" => "The file appears to be empty."], 422);
    $header = array_map(fn($h) => strtolower(trim($h)), $header);

    $colIndex = function ($names) use ($header) {
        foreach ($names as $n) {
            $i = array_search($n, $header);
            if ($i !== false) return $i;
        }
        return null;
    };
    $idx = [
        'name'      => $colIndex(['customer name', 'name']),
        'mobile'    => $colIndex(['mobile number', 'mobile']),
        'email'     => $colIndex(['email']),
        'city'      => $colIndex(['city']),
        'vehicle'   => $colIndex(['vehicle interested', 'vehicle']),
        'budget'    => $colIndex(['budget']),
        'source'    => $colIndex(['source', 'lead source']),
        'exec'      => $colIndex(['sales executive', 'executive']),
        'remarks'   => $colIndex(['remarks', 'notes']),
    ];
    if ($idx['name'] === null || $idx['mobile'] === null) {
        respond(["success" => false, "message" => "The CSV must have at least 'Customer Name' and 'Mobile Number' columns."], 422);
    }

    $total = 0; $imported = 0; $duplicates = 0; $failed = 0;
    $errorRows = [['Row', 'Customer Name', 'Mobile', 'Reason']];

    $insertStmt = $pdo->prepare("INSERT INTO leads (lead_code, lead_date, customer_name, mobile, email, city, vehicle_model, budget, lead_source, sales_executive, notes, status, created_by) VALUES (?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?, 'New Lead', ?)");
    $dupStmt = $pdo->prepare("SELECT id FROM leads WHERE mobile = ?");

    while (($row = fgetcsv($handle)) !== false) {
        if (count(array_filter($row, fn($c) => trim((string)$c) !== '')) === 0) continue; // skip blank lines
        $total++;
        $rowNum = $total + 1; // account for header row

        $name = trim($row[$idx['name']] ?? '');
        $mobile = preg_replace('/[^0-9+]/', '', trim($row[$idx['mobile']] ?? ''));

        if ($name === '') { $failed++; $errorRows[] = [$rowNum, $name, $mobile, 'Missing customer name']; continue; }
        if (!preg_match('/^[0-9+]{7,15}$/', $mobile)) { $failed++; $errorRows[] = [$rowNum, $name, $mobile, 'Invalid mobile number']; continue; }
        $email = $idx['email'] !== null ? trim($row[$idx['email']] ?? '') : '';
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) { $failed++; $errorRows[] = [$rowNum, $name, $mobile, 'Invalid email address']; continue; }

        $dupStmt->execute([$mobile]);
        if ($dupStmt->fetch()) { $duplicates++; $errorRows[] = [$rowNum, $name, $mobile, 'Duplicate — mobile already exists']; continue; }

        $lead_code = nextLeadCode($pdo);
        try {
            $insertStmt->execute([
                $lead_code, $name, $mobile, $email ?: null,
                $idx['city'] !== null ? trim($row[$idx['city']] ?? '') : null,
                $idx['vehicle'] !== null ? trim($row[$idx['vehicle']] ?? '') : null,
                $idx['budget'] !== null ? (is_numeric(trim($row[$idx['budget']] ?? '')) ? trim($row[$idx['budget']]) : null) : null,
                $idx['source'] !== null ? (trim($row[$idx['source']] ?? '') ?: 'Import') : 'Import',
                $idx['exec'] !== null ? trim($row[$idx['exec']] ?? '') : null,
                $idx['remarks'] !== null ? trim($row[$idx['remarks']] ?? '') : null,
                currentUserName(),
            ]);
            $imported++;
        } catch (Exception $e) {
            $failed++; $errorRows[] = [$rowNum, $name, $mobile, 'Database error while saving'];
        }
    }
    fclose($handle);

    // Stash the error rows in the session so the "Download Error File" link works right after.
    $_SESSION['last_import_errors'] = $errorRows;

    respond(["success" => true, "data" => [
        "total" => $total, "imported" => $imported, "duplicates" => $duplicates, "failed" => $failed,
        "has_errors" => count($errorRows) > 1,
    ]]);
}

// -----------------------------------------------------------------
// ERROR CSV (from the most recent import in this session)
// -----------------------------------------------------------------
if ($method === 'GET' && $action === 'error_csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="lead_import_errors.csv"');
    $out = fopen('php://output', 'w');
    $rows = $_SESSION['last_import_errors'] ?? [['Row', 'Customer Name', 'Mobile', 'Reason']];
    foreach ($rows as $r) fputcsv($out, $r);
    fclose($out);
    exit;
}

// -----------------------------------------------------------------
// ATTACHMENT UPLOAD (used by the Add Lead form's Attachment field)
// -----------------------------------------------------------------
if ($method === 'POST' && $action === 'upload_attachment') {
    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        respond(["success" => false, "message" => "No file received."], 422);
    }
    $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
    $allowed = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'xls', 'xlsx'];
    if (!in_array($ext, $allowed, true)) {
        respond(["success" => false, "message" => "Allowed file types: " . implode(', ', $allowed)], 422);
    }
    $dir = __DIR__ . '/../uploads/leads';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $filename = 'lead_' . uniqid() . '.' . $ext;
    if (!move_uploaded_file($_FILES['file']['tmp_name'], "$dir/$filename")) {
        respond(["success" => false, "message" => "Could not save the uploaded file."], 500);
    }
    respond(["success" => true, "path" => "uploads/leads/$filename", "name" => $_FILES['file']['name']]);
}

respond(["success" => false, "message" => "Unknown action."], 400);
