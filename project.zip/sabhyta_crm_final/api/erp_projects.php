<?php
/**
 * PROJECT MANAGEMENT - hooks & actions
 * Flow: Initiation -> Planning -> Execution -> QA -> Delivery -> Launch
 */

/* ---------------------------------------------------------
   Generic one-field update used by quick buttons (Start / Done / Mark Reached ...)
   --------------------------------------------------------- */
function act_quick(PDO $pdo): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') erp_fail('POST required.', 405);
    $in = erp_input();
    $E = erp_entity($in['entity'] ?? '');
    if (!empty($E['readOnly'])) erp_fail('This list is read-only.', 403);
    $field = $in['field'] ?? '';
    $f = erp_field($E, $field);
    if (!$f || !empty($f['ro']) || !empty($f['virtual']) || $f['t'] === 'file') erp_fail('That field cannot be changed this way.');
    $id = (int)($in['id'] ?? 0);
    if (!empty($E['handlers']['save'])) erp_fail('Use the edit form for this record.');
    $res = erp_save_entity($pdo, $E, $id, [$field => $in['value'] ?? '']);
    erp_ok($res['row'], ['notices' => $res['notices'], 'message' => 'Updated.']);
}

/* ---------------------------------------------------------
   Projects
   --------------------------------------------------------- */
function pm_project_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    if (array_key_exists('project_code', $d) && $d['project_code'] === null && $old) unset($d['project_code']);
    if (empty($d['project_code']) && empty($old['project_code'])) {
        $n = (int)$pdo->query("SELECT COALESCE(MAX(project_id),0)+1 FROM pm_projects")->fetchColumn();
        $chk = $pdo->prepare("SELECT 1 FROM pm_projects WHERE project_code = ?");
        do { $code = 'PRJ-' . str_pad((string)$n, 4, '0', STR_PAD_LEFT); $chk->execute([$code]); $n++; } while ($chk->fetchColumn());
        $d['project_code'] = $code;
    }
    $s = $d['start_date'] ?? $old['start_date'] ?? null;
    $e = array_key_exists('end_date', $d) ? $d['end_date'] : ($old['end_date'] ?? null);
    if ($s && $e && $e < $s) erp_fail('End date cannot be before the start date.');
}
function pm_project_decorate(PDO $pdo, array $rows): array {
    foreach ($rows as &$r) {
        $tot = (int)($r['task_total'] ?? 0); $done = (int)($r['task_done'] ?? 0);
        $r['progress'] = $tot ? round($done / $tot * 100) : 0;
    }
    return $rows;
}
function pm_project_before_delete(PDO $pdo, int $id, array $old): void {
    $st = $pdo->prepare("SELECT file_url_path FROM pm_files WHERE project_id = ?");
    $st->execute([$id]);
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $p) erp_delete_file($p);
}

/* ---------------------------------------------------------
   Milestones
   --------------------------------------------------------- */
function pm_milestone_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    $status = $d['status'] ?? ($old['status'] ?? 'Pending');
    if ($status === 'Reached') { if (empty($old['reached_on'])) $d['reached_on'] = erp_today(); }
    else $d['reached_on'] = null;
}

/* ---------------------------------------------------------
   Tasks
   --------------------------------------------------------- */
function pm_task_project(PDO $pdo, int $moduleId): ?int {
    $st = $pdo->prepare("SELECT project_id FROM pm_modules WHERE module_id = ?");
    $st->execute([$moduleId]);
    $p = $st->fetchColumn();
    return $p ? (int)$p : null;
}
function pm_task_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    $s = array_key_exists('start_date', $d) ? $d['start_date'] : ($old['start_date'] ?? null);
    $e = array_key_exists('due_date', $d) ? $d['due_date'] : ($old['due_date'] ?? null);
    if ($s && $e && $e < $s) erp_fail('Due date cannot be before the start date.');
    $moduleId = (int)($d['module_id'] ?? $old['module_id'] ?? 0);
    if (!empty($d['depends_on_task_id'])) {
        $dep = (int)$d['depends_on_task_id'];
        if ($old && $dep === (int)$old['task_id']) erp_fail('A task cannot depend on itself.');
        $st = $pdo->prepare("SELECT m.project_id FROM pm_tasks t JOIN pm_modules m ON m.module_id = t.module_id WHERE t.task_id = ?");
        $st->execute([$dep]);
        $depProject = (int)$st->fetchColumn();
        if ($depProject !== (int)pm_task_project($pdo, $moduleId)) erp_fail('The task you depend on must belong to the same project.');
        // no circular chains
        $cur = $dep; $guard = 0;
        while ($cur && $guard++ < 50) {
            if ($old && $cur === (int)$old['task_id']) erp_fail('That dependency would create a loop.');
            $n = $pdo->prepare("SELECT depends_on_task_id FROM pm_tasks WHERE task_id = ?"); $n->execute([$cur]);
            $cur = (int)$n->fetchColumn();
        }
    }
}
function pm_task_after(PDO $pdo, int $id, array $d, ?array $old, array $in): array {
    $notices = [];
    if (($d['status'] ?? '') === 'In Progress') {
        $pid = pm_task_project($pdo, (int)($d['module_id'] ?? $old['module_id'] ?? 0));
        if ($pid) {
            $u = $pdo->prepare("UPDATE pm_projects SET status = 'Active' WHERE project_id = ? AND status = 'Planning'");
            $u->execute([$pid]);
            if ($u->rowCount()) $notices[] = 'Project moved from Planning to Active because work has started.';
        }
    }
    return $notices;
}

/* ---------------------------------------------------------
   Assign Team (supports several employees at once)
   --------------------------------------------------------- */
function pm_assign_save(PDO $pdo, array $E, ?int $id, array $in): array {
    $taskId = (int)($in['task_id'] ?? 0);
    if (!$taskId) erp_fail('Task is required.');
    $st = $pdo->prepare("SELECT task_id FROM pm_tasks WHERE task_id = ?"); $st->execute([$taskId]);
    if (!$st->fetchColumn()) erp_fail('The selected task no longer exists.');
    $ids = array_values(array_unique(array_filter(array_map('intval', (array)($in['user_id'] ?? [])))));
    if (!$ids) erp_fail('Select at least one team member.');
    foreach ($ids as $e) if (!erp_lookup_exists($pdo, 'employees', $e)) erp_fail('A selected employee no longer exists.');
    $role = trim((string)($in['role_note'] ?? '')) ?: null;

    if ($id) {
        if (count($ids) !== 1) erp_fail('When editing, choose a single team member.');
        $dup = $pdo->prepare("SELECT 1 FROM pm_team_assignments WHERE task_id = ? AND user_id = ? AND assignment_id <> ?");
        $dup->execute([$taskId, $ids[0], $id]);
        if ($dup->fetchColumn()) erp_fail('That employee is already assigned to this task.');
        $pdo->prepare("UPDATE pm_team_assignments SET task_id = ?, user_id = ?, role_note = ? WHERE assignment_id = ?")->execute([$taskId, $ids[0], $role, $id]);
        return ['id' => $id, 'row' => erp_fetch_row($pdo, $E, $id)];
    }
    $added = 0; $skipped = [];
    $ins = $pdo->prepare("INSERT INTO pm_team_assignments (task_id, user_id, role_note) VALUES (?, ?, ?)");
    $dup = $pdo->prepare("SELECT 1 FROM pm_team_assignments WHERE task_id = ? AND user_id = ?");
    foreach ($ids as $e) {
        $dup->execute([$taskId, $e]);
        if ($dup->fetchColumn()) { $skipped[] = $e; continue; }
        $ins->execute([$taskId, $e, $role]); $added++;
        $id = (int)$pdo->lastInsertId();
    }
    if (!$added) erp_fail('Every selected employee is already assigned to this task.');
    $notices = $skipped ? [count($skipped) . ' employee(s) were already assigned and were skipped.'] : [];
    return ['id' => $id, 'row' => erp_fetch_row($pdo, $E, $id), 'notices' => $notices, 'message' => "$added team member(s) assigned."];
}

/* ---------------------------------------------------------
   Time tracking
   --------------------------------------------------------- */
function pm_hours(?string $s, ?string $e): ?float {
    if (!$s || !$e) return null;
    return round((strtotime($e) - strtotime($s)) / 3600, 2);
}
function pm_time_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    $s = $d['start_time'] ?? $old['start_time'] ?? null;
    $e = array_key_exists('end_time', $d) ? $d['end_time'] : ($old['end_time'] ?? null);
    if ($e && $s && strtotime($e) < strtotime($s)) erp_fail('End time cannot be before start time.');
    if ($s && $e && (strtotime($e) - strtotime($s)) > 86400 * 3) erp_fail('A single time log cannot be longer than 72 hours. Please split it.');
    $d['total_hours'] = pm_hours($s, $e);
    if (!$e) {
        $uid = (int)($d['user_id'] ?? $old['user_id'] ?? 0);
        $q = $pdo->prepare("SELECT time_log_id FROM pm_time_tracking WHERE user_id = ? AND end_time IS NULL AND time_log_id <> ?");
        $q->execute([$uid, (int)($old['time_log_id'] ?? 0)]);
        if ($q->fetchColumn()) erp_fail('This employee already has a running clock. Clock out first or enter an end time.');
    }
}
function act_pm_clock_in(PDO $pdo): void {
    $in = erp_input();
    $task = (int)($in['task_id'] ?? 0); $emp = (int)($in['user_id'] ?? 0);
    if (!$task || !$emp) erp_fail('Choose a task and an employee.');
    $E = erp_entity('pm_time_tracking');
    $res = erp_save_entity($pdo, $E, null, ['task_id' => $task, 'user_id' => $emp, 'start_time' => date('Y-m-d H:i:s'), 'notes' => $in['notes'] ?? '']);
    erp_ok($res['row'], ['message' => 'Clocked in.']);
}
function act_pm_clock_out(PDO $pdo): void {
    $id = (int)(erp_input()['id'] ?? 0);
    $st = $pdo->prepare("SELECT * FROM pm_time_tracking WHERE time_log_id = ?"); $st->execute([$id]);
    $r = $st->fetch();
    if (!$r) erp_fail('Time log not found.', 404);
    if ($r['end_time']) erp_fail('This clock is already stopped.');
    $now = date('Y-m-d H:i:s');
    $pdo->prepare("UPDATE pm_time_tracking SET end_time = ?, total_hours = ? WHERE time_log_id = ?")->execute([$now, pm_hours($r['start_time'], $now), $id]);
    erp_ok(null, ['message' => 'Clocked out. ' . pm_hours($r['start_time'], $now) . ' h logged.']);
}

/* ---------------------------------------------------------
   Files
   --------------------------------------------------------- */
function pm_file_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    if (!$old) $d['uploaded_by'] = erp_user()['id'];
}

/* ---------------------------------------------------------
   Bugs
   --------------------------------------------------------- */
function pm_bug_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    if (!$old) $d['reported_by'] = erp_user()['id'];
    $status = $d['status'] ?? ($old['status'] ?? 'Open');
    if ($status === 'Resolved') { if (empty($old['resolved_at'])) $d['resolved_at'] = erp_now(); }
    else $d['resolved_at'] = null;
    if (!empty($d['task_id'])) {
        $pid = (int)($d['project_id'] ?? $old['project_id'] ?? 0);
        $st = $pdo->prepare("SELECT m.project_id FROM pm_tasks t JOIN pm_modules m ON m.module_id = t.module_id WHERE t.task_id = ?");
        $st->execute([(int)$d['task_id']]);
        if ((int)$st->fetchColumn() !== $pid) erp_fail('The related task does not belong to the selected project.');
    }
}

/* ---------------------------------------------------------
   Client approvals
   --------------------------------------------------------- */
function pm_approval_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    $pid = (int)($d['project_id'] ?? $old['project_id'] ?? 0);
    if (!$old || empty($old['client_id'])) {
        $c = $pdo->prepare("SELECT client_id FROM pm_projects WHERE project_id = ?"); $c->execute([$pid]);
        $cid = $c->fetchColumn();
        if ($cid) $d['client_id'] = (int)$cid;
    }
    $status = $d['status'] ?? ($old['status'] ?? 'Pending');
    $signed = array_key_exists('signed_by', $d) ? $d['signed_by'] : ($old['signed_by'] ?? null);
    $notes  = array_key_exists('feedback_notes', $d) ? $d['feedback_notes'] : ($old['feedback_notes'] ?? null);
    if ($status !== 'Pending' && !$signed) erp_fail('Enter the name of the client signatory who ' . strtolower($status) . ' this - it is recorded as the sign-off.');
    if ($status === 'Rejected' && !$notes) erp_fail('Client feedback is required when rejecting, so the team knows what to fix.');
    if ($status === 'Pending') $d['decided_at'] = null;
    elseif (!$old || $old['status'] !== $status) $d['decided_at'] = erp_now();
    if (!empty($d['milestone_id'])) {
        $m = $pdo->prepare("SELECT project_id FROM pm_milestones WHERE milestone_id = ?"); $m->execute([(int)$d['milestone_id']]);
        if ((int)$m->fetchColumn() !== $pid) erp_fail('The linked milestone belongs to a different project.');
    }
}
function pm_approval_after(PDO $pdo, int $id, array $d, ?array $old, array $in): array {
    $notices = [];
    $row = $pdo->prepare("SELECT * FROM pm_client_approvals WHERE approval_id = ?"); $row->execute([$id]);
    $a = $row->fetch();
    $changed = !$old || $old['status'] !== $a['status'];
    if (!$changed) return $notices;

    if ($a['status'] === 'Approved') {
        if ($a['milestone_id']) {
            $u = $pdo->prepare("UPDATE pm_milestones SET status = 'Reached', reached_on = COALESCE(reached_on, CURDATE()) WHERE milestone_id = ? AND status <> 'Reached'");
            $u->execute([$a['milestone_id']]);
            if ($u->rowCount()) $notices[] = 'Linked milestone marked as Reached - it can now be billed.';
        }
        if ($a['approval_type'] === 'Final') $notices[] = 'Final approval recorded. The project is cleared for Production deployment.';
    }
    if ($a['status'] === 'Rejected') {
        // iteration task in the first module (create one if the project has none)
        $m = $pdo->prepare("SELECT module_id FROM pm_modules WHERE project_id = ? ORDER BY module_id LIMIT 1");
        $m->execute([$a['project_id']]);
        $moduleId = (int)$m->fetchColumn();
        if (!$moduleId) {
            $pdo->prepare("INSERT INTO pm_modules (project_id, module_name, description) VALUES (?, 'Client Feedback & Rework', 'Created automatically from a rejected client approval')")->execute([$a['project_id']]);
            $moduleId = (int)$pdo->lastInsertId();
        }
        $pdo->prepare("INSERT INTO pm_tasks (module_id, task_name, description, priority, status, start_date) VALUES (?, ?, ?, 'High', 'To Do', CURDATE())")
            ->execute([$moduleId, 'Rework: ' . $a['approval_type'] . ' - client feedback', $a['feedback_notes']]);
        $notices[] = 'A High-priority rework task was created from the client feedback.';
        $u = $pdo->prepare("UPDATE pm_projects SET status = 'Active' WHERE project_id = ? AND status IN ('Testing','Completed')");
        $u->execute([$a['project_id']]);
        if ($u->rowCount()) $notices[] = 'Project returned to Active so the team can iterate.';
    }
    return $notices;
}

/* ---------------------------------------------------------
   Deployments - QA / approval gate
   --------------------------------------------------------- */
function pm_deploy_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    if (!$old) $d['deployed_by'] = erp_user()['id'];
    $env = $d['environment'] ?? ($old['environment'] ?? 'Staging');
    if ($env !== 'Production') return;
    $pid = (int)($d['project_id'] ?? $old['project_id'] ?? 0);

    $a = $pdo->prepare("SELECT status FROM pm_client_approvals WHERE project_id = ? AND approval_type = 'Final' ORDER BY approval_id DESC LIMIT 1");
    $a->execute([$pid]);
    $status = $a->fetchColumn();
    if ($status !== 'Approved') {
        erp_fail('Production deployment needs an Approved "Final" client approval. ' . ($status ? "The latest Final approval is $status." : 'There is no Final approval yet.') . ' Record it under Client Approval first.');
    }
    $b = $pdo->prepare("SELECT COUNT(*) FROM pm_testing_bugs WHERE project_id = ? AND severity = 'Critical' AND status <> 'Resolved'");
    $b->execute([$pid]);
    $n = (int)$b->fetchColumn();
    if ($n) erp_fail("There are $n open Critical bug(s) on this project. Resolve them under Testing before deploying to Production.");
}
function pm_deploy_after(PDO $pdo, int $id, array $d, ?array $old, array $in): array {
    if ($old) return [];
    $dep = $pdo->prepare("SELECT project_id, environment FROM pm_deployments WHERE deployment_id = ?"); $dep->execute([$id]);
    $r = $dep->fetch();
    if ($r['environment'] === 'Production') {
        $pdo->prepare("UPDATE pm_projects SET status = 'Completed' WHERE project_id = ?")->execute([$r['project_id']]);
        return ['Deployed to Production - project marked Completed. Log post-launch issues under Maintenance.'];
    }
    $u = $pdo->prepare("UPDATE pm_projects SET status = 'Testing' WHERE project_id = ? AND status IN ('Planning','Active')");
    $u->execute([$r['project_id']]);
    return $u->rowCount() ? ['Staging deployment recorded - project moved to Testing.'] : [];
}

/* ---------------------------------------------------------
   Maintenance
   --------------------------------------------------------- */
function pm_maint_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    $st = $d['resolution_status'] ?? ($old['resolution_status'] ?? 'Logged');
    if ($st === 'Closed') { if (empty($old['closed_at'])) $d['closed_at'] = erp_now(); }
    else $d['closed_at'] = null;
}

/* ---------------------------------------------------------
   GANTT CHART DATA (computed from projects / tasks / milestones)
   --------------------------------------------------------- */
function pm_task_progress(array $t): int {
    if ($t['status'] === 'Done') return 100;
    if ((int)$t['sub_total'] > 0) return (int)round($t['sub_done'] / $t['sub_total'] * 100);
    if ((float)$t['estimated_hours'] > 0 && (float)$t['hours_logged'] > 0) return (int)min(95, round($t['hours_logged'] / $t['estimated_hours'] * 100));
    return $t['status'] === 'In Progress' ? 50 : 0;
}
function act_pm_gantt(PDO $pdo): void {
    $pid = (int)($_GET['project_id'] ?? 0);
    $p = $pdo->prepare("SELECT p.*, c.customer_name FROM pm_projects p LEFT JOIN customers c ON c.id = p.client_id WHERE p.project_id = ?");
    $p->execute([$pid]);
    $project = $p->fetch();
    if (!$project) erp_fail('Project not found.', 404);

    $mods = $pdo->prepare("SELECT module_id, module_name FROM pm_modules WHERE project_id = ? ORDER BY module_id");
    $mods->execute([$pid]);
    $modules = $mods->fetchAll();

    $tasks = $pdo->prepare(
        "SELECT t.*,
            (SELECT COUNT(*) FROM pm_sub_tasks s WHERE s.task_id = t.task_id) AS sub_total,
            (SELECT COUNT(*) FROM pm_sub_tasks s WHERE s.task_id = t.task_id AND s.is_completed = 1) AS sub_done,
            (SELECT COALESCE(SUM(tt.total_hours),0) FROM pm_time_tracking tt WHERE tt.task_id = t.task_id) AS hours_logged,
            (SELECT GROUP_CONCAT(TRIM(CONCAT(e.first_name,' ',COALESCE(e.last_name,''))) SEPARATOR ', ')
               FROM pm_team_assignments ta JOIN employees e ON e.id = ta.user_id WHERE ta.task_id = t.task_id) AS assignees
         FROM pm_tasks t JOIN pm_modules m ON m.module_id = t.module_id
         WHERE m.project_id = ? ORDER BY t.start_date IS NULL, t.start_date, t.task_id"
    );
    $tasks->execute([$pid]);
    $byModule = [];
    $today = erp_today();
    $wSum = 0; $wDone = 0; $overdue = 0; $minD = $project['start_date']; $maxD = $project['end_date'];
    foreach ($tasks->fetchAll() as $t) {
        $t['progress'] = pm_task_progress($t);
        $t['overdue'] = ($t['status'] !== 'Done' && $t['due_date'] && $t['due_date'] < $today) ? 1 : 0;
        $overdue += $t['overdue'];
        $w = (float)$t['estimated_hours'] > 0 ? (float)$t['estimated_hours'] : 1.0;
        $wSum += $w; $wDone += $w * $t['progress'] / 100;
        foreach (['start_date', 'due_date'] as $k) {
            if ($t[$k] && (!$minD || $t[$k] < $minD)) $minD = $t[$k];
            if ($t[$k] && (!$maxD || $t[$k] > $maxD)) $maxD = $t[$k];
        }
        $byModule[$t['module_id']][] = $t;
    }
    foreach ($modules as &$m) $m['tasks'] = $byModule[$m['module_id']] ?? [];
    unset($m);

    $ms = $pdo->prepare("SELECT milestone_id, milestone_title, due_date, status, deliverable_amount FROM pm_milestones WHERE project_id = ? ORDER BY due_date");
    $ms->execute([$pid]);
    $milestones = $ms->fetchAll();
    foreach ($milestones as $m) if ($m['due_date'] && (!$maxD || $m['due_date'] > $maxD)) $maxD = $m['due_date'];

    $actual = $wSum ? round($wDone / $wSum * 100) : 0;
    $planned = null; $state = 'No dates';
    if ($project['start_date'] && $project['end_date']) {
        $s = strtotime($project['start_date']); $e = strtotime($project['end_date']); $n = strtotime($today);
        $planned = $n <= $s ? 0 : ($n >= $e ? 100 : (int)round(($n - $s) / max(1, $e - $s) * 100));
        if ($project['status'] === 'Completed') $state = 'Completed';
        elseif ($n < $s) $state = 'Not started';
        elseif ($actual >= $planned + 5) $state = 'Ahead of schedule';
        elseif ($actual <= $planned - 10) $state = 'Behind schedule';
        else $state = 'On track';
    }
    erp_ok([
        'project' => $project, 'modules' => $modules, 'milestones' => $milestones, 'today' => $today,
        'range' => ['start' => $minD, 'end' => $maxD],
        'schedule' => ['planned_pct' => $planned, 'actual_pct' => $actual, 'state' => $state, 'overdue_tasks' => $overdue],
    ]);
}

/* ---------------------------------------------------------
   PROJECT REPORTS (time, cost, efficiency)
   --------------------------------------------------------- */
function act_pm_report(PDO $pdo): void {
    $pid = (int)($_GET['project_id'] ?? 0);
    $where = $pid ? 'WHERE p.project_id = ' . $pid : '';
    // Hourly rate is derived from the employee's CTC (12 months x 22 days x 8 h) - an estimate.
    $sql = "SELECT p.project_id, p.project_code, p.project_name, p.status, p.budget, p.estimated_hours, p.start_date, p.end_date,
        c.customer_name AS client_name,
        (SELECT COALESCE(SUM(tt.total_hours),0) FROM pm_time_tracking tt JOIN pm_tasks tk ON tk.task_id = tt.task_id JOIN pm_modules mo ON mo.module_id = tk.module_id WHERE mo.project_id = p.project_id) AS actual_hours,
        (SELECT COALESCE(SUM(tt.total_hours * COALESCE(e.ctc,0) / 2112),0) FROM pm_time_tracking tt JOIN employees e ON e.id = tt.user_id JOIN pm_tasks tk ON tk.task_id = tt.task_id JOIN pm_modules mo ON mo.module_id = tk.module_id WHERE mo.project_id = p.project_id) AS labour_cost,
        (SELECT COALESCE(SUM(tk.estimated_hours),0) FROM pm_tasks tk JOIN pm_modules mo ON mo.module_id = tk.module_id WHERE mo.project_id = p.project_id AND tk.status = 'Done') AS est_hours_done,
        (SELECT COALESCE(SUM(tt.total_hours),0) FROM pm_time_tracking tt JOIN pm_tasks tk ON tk.task_id = tt.task_id JOIN pm_modules mo ON mo.module_id = tk.module_id WHERE mo.project_id = p.project_id AND tk.status = 'Done') AS act_hours_done,
        (SELECT COUNT(*) FROM pm_tasks tk JOIN pm_modules mo ON mo.module_id = tk.module_id WHERE mo.project_id = p.project_id) AS tasks_total,
        (SELECT COUNT(*) FROM pm_tasks tk JOIN pm_modules mo ON mo.module_id = tk.module_id WHERE mo.project_id = p.project_id AND tk.status = 'Done') AS tasks_done,
        (SELECT COUNT(*) FROM pm_tasks tk JOIN pm_modules mo ON mo.module_id = tk.module_id WHERE mo.project_id = p.project_id AND tk.status <> 'Done' AND tk.due_date < CURDATE()) AS tasks_overdue,
        (SELECT COUNT(*) FROM pm_testing_bugs b WHERE b.project_id = p.project_id) AS bugs_total,
        (SELECT COUNT(*) FROM pm_testing_bugs b WHERE b.project_id = p.project_id AND b.status <> 'Resolved') AS bugs_open,
        (SELECT COUNT(*) FROM pm_testing_bugs b WHERE b.project_id = p.project_id AND b.status <> 'Resolved' AND b.severity = 'Critical') AS bugs_critical,
        (SELECT COALESCE(SUM(deliverable_amount),0) FROM pm_milestones m WHERE m.project_id = p.project_id AND m.status = 'Reached') AS billed,
        (SELECT COALESCE(SUM(deliverable_amount),0) FROM pm_milestones m WHERE m.project_id = p.project_id AND m.status = 'Pending') AS billing_pending,
        (SELECT COUNT(*) FROM pm_client_approvals a WHERE a.project_id = p.project_id AND a.status = 'Pending') AS approvals_pending,
        (SELECT COUNT(*) FROM pm_deployments d WHERE d.project_id = p.project_id AND d.environment = 'Production') AS prod_deployments,
        (SELECT COUNT(*) FROM pm_maintenance mt WHERE mt.project_id = p.project_id AND mt.resolution_status <> 'Closed') AS maintenance_open
        FROM pm_projects p LEFT JOIN customers c ON c.id = p.client_id $where ORDER BY p.project_id DESC";
    $rows = $pdo->query($sql)->fetchAll();
    foreach ($rows as &$r) {
        $est = (float)$r['estimated_hours']; $act = (float)$r['actual_hours'];
        // Efficiency compares like with like: estimated vs actual hours on COMPLETED tasks only.
        $r['efficiency_pct'] = ((float)$r['act_hours_done'] > 0 && (float)$r['est_hours_done'] > 0) ? round($r['est_hours_done'] / $r['act_hours_done'] * 100) : null;
        $r['hours_burn_pct'] = $est > 0 ? round($act / $est * 100) : null;
        $r['completion_pct'] = $r['tasks_total'] ? round($r['tasks_done'] / $r['tasks_total'] * 100) : 0;
        $r['labour_cost'] = round((float)$r['labour_cost'], 2);
        $r['budget_used_pct'] = ($r['budget'] > 0) ? round($r['labour_cost'] / $r['budget'] * 100) : null;
    }
    unset($r);

    $detail = null;
    if ($pid) {
        $emp = $pdo->query("SELECT TRIM(CONCAT(e.first_name,' ',COALESCE(e.last_name,''))) AS name, ROUND(SUM(tt.total_hours),2) AS hours
            FROM pm_time_tracking tt JOIN employees e ON e.id = tt.user_id JOIN pm_tasks tk ON tk.task_id = tt.task_id JOIN pm_modules mo ON mo.module_id = tk.module_id
            WHERE mo.project_id = $pid GROUP BY e.id ORDER BY hours DESC")->fetchAll();
        $mod = $pdo->query("SELECT mo.module_name AS name, ROUND(COALESCE(SUM(tt.total_hours),0),2) AS hours, COUNT(DISTINCT tk.task_id) AS tasks
            FROM pm_modules mo LEFT JOIN pm_tasks tk ON tk.module_id = mo.module_id LEFT JOIN pm_time_tracking tt ON tt.task_id = tk.task_id
            WHERE mo.project_id = $pid GROUP BY mo.module_id")->fetchAll();
        $ts = $pdo->query("SELECT tk.status, COUNT(*) AS n FROM pm_tasks tk JOIN pm_modules mo ON mo.module_id = tk.module_id WHERE mo.project_id = $pid GROUP BY tk.status")->fetchAll();
        $bs = $pdo->query("SELECT severity, status, COUNT(*) AS n FROM pm_testing_bugs WHERE project_id = $pid GROUP BY severity, status")->fetchAll();
        $detail = ['hours_by_employee' => $emp, 'hours_by_module' => $mod, 'task_status' => $ts, 'bugs' => $bs];
    }
    erp_ok(['projects' => $rows, 'detail' => $detail]);
}
