<?php
/**
 * ADMINISTRATION - hooks & actions
 * Settings (key/value, secrets encrypted) / login accounts / security rules / audit / backup
 * Users, Roles and Permissions continue to use the existing User Management APIs.
 */

/* ---------------------------------------------------------
   Settings schema
   --------------------------------------------------------- */
function adm_settings_schema(): array {
    $tz = ['Asia/Kolkata','Asia/Dubai','Asia/Singapore','Asia/Karachi','Asia/Dhaka','Europe/London','Europe/Paris','America/New_York','America/Chicago','America/Los_Angeles','Australia/Sydney','UTC'];
    $months = ['1' => 'January','2' => 'February','3' => 'March','4' => 'April','5' => 'May','6' => 'June','7' => 'July','8' => 'August','9' => 'September','10' => 'October','11' => 'November','12' => 'December'];
    $S = function (string $k, string $l, string $t = 'text', array $o = []) { return array_merge(['k' => $k, 'l' => $l, 't' => $t], $o); };
    return [
        'Company' => ['title' => 'Company Settings', 'fields' => [
            $S('company_name', 'Company Name', 'text', ['req' => true]), $S('company_legal_name', 'Legal Name'),
            $S('company_email', 'Company Email', 'email'), $S('company_phone', 'Phone', 'tel'), $S('company_website', 'Website', 'url'),
            $S('company_address', 'Address', 'textarea', ['full' => true]),
            $S('company_city', 'City'), $S('company_state', 'State'), $S('company_country', 'Country', 'text', ['def' => 'India']), $S('company_pincode', 'Pincode'),
            $S('company_gstin', 'GSTIN', 'text', ['max' => 15]), $S('company_pan', 'PAN', 'text', ['max' => 10]),
            $S('currency', 'Base Currency', 'select', ['opts' => ['INR','USD','EUR','GBP','AED','SGD','AUD'], 'def' => 'INR']),
            $S('currency_symbol', 'Currency Symbol', 'text', ['def' => '₹', 'max' => 5]),
            $S('timezone', 'Timezone', 'select', ['opts' => $tz, 'def' => 'Asia/Kolkata']),
            $S('date_format', 'Date Format', 'select', ['opts' => ['DD-MM-YYYY','MM-DD-YYYY','YYYY-MM-DD'], 'def' => 'DD-MM-YYYY']),
            $S('fy_start_month', 'Financial Year Starts In', 'select', ['optsMap' => $months, 'def' => '4']),
        ]],
        'Finance' => ['title' => 'Accounting Mapping (Asset Management -> Accounts)', 'fields' => [
            $S('fin_fixed_asset_acct', 'Fixed Assets account', 'lookup', ['src' => 'chart_accounts', 'help' => 'Debited when an asset is purchased.']),
            $S('fin_accum_dep_acct', 'Accumulated Depreciation account', 'lookup', ['src' => 'chart_accounts', 'help' => 'Credited every month by the depreciation run.']),
            $S('fin_dep_expense_acct', 'Depreciation Expense account', 'lookup', ['src' => 'chart_accounts', 'help' => 'Debited every month by the depreciation run.']),
            $S('fin_maint_expense_acct', 'IT Maintenance Expense account', 'lookup', ['src' => 'chart_accounts', 'help' => 'Repairs and software renewals post here.']),
            $S('fin_default_credit_acct', 'Default Payment / Payable account', 'lookup', ['src' => 'chart_accounts', 'help' => 'Credited for purchases and repairs (bank, cash or accounts payable).']),
            $S('fin_cash_acct', 'Cash / Bank account for disposal proceeds', 'lookup', ['src' => 'chart_accounts', 'help' => 'Optional. Defaults to the payment account.']),
            $S('fin_loss_disposal_acct', 'Loss on Disposal account', 'lookup', ['src' => 'chart_accounts']),
            $S('fin_gain_disposal_acct', 'Gain on Disposal account', 'lookup', ['src' => 'chart_accounts']),
        ]],
        'Email' => ['title' => 'Email (SMTP) Settings', 'fields' => [
            $S('smtp_host', 'SMTP Host', 'text', ['ph' => 'smtp.gmail.com']), $S('smtp_port', 'SMTP Port', 'number', ['def' => '587']),
            $S('smtp_encryption', 'Encryption', 'select', ['opts' => ['TLS','SSL','None'], 'def' => 'TLS']),
            $S('smtp_username', 'Username'), $S('smtp_password', 'Password / App Password', 'password'),
            $S('from_email', 'From Email', 'email'), $S('from_name', 'From Name'), $S('reply_to', 'Reply-To Email', 'email'),
        ]],
        'SMS' => ['title' => 'SMS Gateway', 'fields' => [
            $S('sms_provider', 'Provider', 'select', ['opts' => ['MSG91','Twilio','Textlocal','Fast2SMS','Custom HTTP'], 'def' => 'MSG91']),
            $S('sms_api_url', 'API Endpoint URL', 'url', ['full' => true]),
            $S('sms_api_key', 'API Key / Account SID', 'password'), $S('sms_auth_token', 'Auth Token / Secret', 'password'),
            $S('sms_sender_id', 'Default Sender ID', 'text', ['max' => 11]), $S('sms_dlt_entity_id', 'DLT Entity ID (India)'),
            $S('sms_default_country_code', 'Default Country Code', 'text', ['def' => '+91', 'max' => 5, 'help' => 'Used to complete 10-digit phone numbers in Marketing audiences.']),
        ]],
        'WhatsApp' => ['title' => 'WhatsApp Business API', 'fields' => [
            $S('wa_provider', 'Provider', 'select', ['opts' => ['Meta Cloud API','Twilio','Gupshup','Other'], 'def' => 'Meta Cloud API']),
            $S('wa_api_version', 'API Version', 'text', ['def' => 'v19.0']),
            $S('wa_phone_number_id', 'Phone Number ID'), $S('wa_business_account_id', 'Business Account ID'),
            $S('wa_access_token', 'Permanent Access Token', 'password', ['full' => true]), $S('wa_verify_token', 'Webhook Verify Token', 'password'),
        ]],
        'Payment' => ['title' => 'Payment Gateway', 'fields' => [
            $S('pg_provider', 'Provider', 'select', ['opts' => ['Razorpay','Stripe','PayU','Cashfree','PayPal'], 'def' => 'Razorpay']),
            $S('pg_mode', 'Mode', 'select', ['opts' => ['Test','Live'], 'def' => 'Test']),
            $S('pg_key_id', 'Public Key / Key ID'), $S('pg_key_secret', 'Secret Key', 'password'), $S('pg_webhook_secret', 'Webhook Secret', 'password'),
            $S('pg_currency', 'Currency', 'select', ['opts' => ['INR','USD','EUR','GBP'], 'def' => 'INR']),
            $S('pg_enabled', 'Gateway enabled', 'bool'),
        ]],
    ];
}
function adm_group_of(string $key): ?string {
    foreach (adm_settings_schema() as $g => $def) foreach ($def['fields'] as $f) if ($f['k'] === $key) return $g;
    return null;
}

function act_adm_settings_get(PDO $pdo): void {
    erp_require_admin();
    $schema = adm_settings_schema();
    $groups = isset($_GET['groups']) ? array_filter(explode(',', $_GET['groups'])) : array_keys($schema);
    $out = [];
    foreach ($groups as $g) {
        if (!isset($schema[$g])) continue;
        $vals = [];
        foreach ($schema[$g]['fields'] as $f) {
            $v = erp_setting_get($pdo, $f['k']);
            if ($f['t'] === 'password') { $vals[$f['k']] = ['set' => $v !== null && $v !== '', 'masked' => $v ? erp_mask((string)$v) : '']; }
            else $vals[$f['k']] = $v ?? ($f['def'] ?? '');
        }
        $out[$g] = ['title' => $schema[$g]['title'], 'fields' => $schema[$g]['fields'], 'values' => $vals];
    }
    erp_ok($out);
}
function act_adm_settings_save(PDO $pdo): void {
    erp_require_admin();
    $in = erp_input();
    $schema = adm_settings_schema();
    $group = $in['group'] ?? '';
    if (!isset($schema[$group])) erp_fail('Unknown settings group.');
    $vals = $in['values'] ?? [];
    $errors = [];
    $pdo->beginTransaction();
    try {
        foreach ($schema[$group]['fields'] as $f) {
            $k = $f['k'];
            if (!array_key_exists($k, $vals)) continue;
            $v = is_array($vals[$k]) ? '' : trim((string)$vals[$k]);
            if ($f['t'] === 'password') {
                if (!empty($in['clear'][$k])) { erp_setting_set($pdo, $group, $k, '', true); continue; }
                if ($v === '' || strpos($v, '••') !== false) continue;     // keep the saved secret
                erp_setting_set($pdo, $group, $k, $v, true); continue;
            }
            if (!empty($f['req']) && $v === '') { $errors[] = $f['l'] . ' is required.'; continue; }
            if ($v !== '') {
                if ($f['t'] === 'email' && !filter_var($v, FILTER_VALIDATE_EMAIL)) { $errors[] = $f['l'] . ' must be a valid email.'; continue; }
                if ($f['t'] === 'url' && !preg_match('~^https?://[^\s]+$~i', $v)) { $errors[] = $f['l'] . ' must start with http:// or https://'; continue; }
                if ($f['t'] === 'number' && !preg_match('/^\d+$/', $v)) { $errors[] = $f['l'] . ' must be a number.'; continue; }
                if ($f['t'] === 'select') {
                    $allowed = isset($f['optsMap']) ? array_map('strval', array_keys($f['optsMap'])) : array_map('strval', $f['opts']);
                    if (!in_array($v, $allowed, true)) { $errors[] = $f['l'] . ' has an invalid value.'; continue; }
                }
                if ($f['t'] === 'lookup' && !erp_coa_account($pdo, (int)$v)) { $errors[] = $f['l'] . ': the selected account is not in the Chart of Accounts.'; continue; }
                if ($f['t'] === 'bool') $v = in_array(strtolower($v), ['1', 'true', 'on', 'yes'], true) ? '1' : '0';
                if (!empty($f['max']) && mb_strlen($v) > $f['max']) { $errors[] = $f['l'] . ' is too long.'; continue; }
                if ($k === 'sms_default_country_code' && !preg_match('/^\+\d{1,4}$/', $v)) { $errors[] = 'Country code must look like +91.'; continue; }
                if ($k === 'company_gstin' && !preg_match('/^[0-9A-Z]{15}$/i', $v)) { $errors[] = 'GSTIN must be 15 characters.'; continue; }
                if ($k === 'company_pan' && !preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]$/i', $v)) { $errors[] = 'PAN must look like ABCDE1234F.'; continue; }
            } elseif ($f['t'] === 'bool') $v = '0';
            erp_setting_set($pdo, $group, $k, $v, false);
        }
        if ($errors) { $pdo->rollBack(); erp_fail(implode(' ', $errors), 422, ['errors' => $errors]); }
        $pdo->commit();
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
    erp_ok(null, ['message' => $schema[$group]['title'] . ' saved.']);
}
function act_adm_check_settings(PDO $pdo): void {
    erp_require_admin();
    $group = $_GET['group'] ?? '';
    $need = [
        'Email' => ['smtp_host', 'smtp_port', 'from_email'], 'SMS' => ['sms_provider', 'sms_api_key', 'sms_sender_id'],
        'WhatsApp' => ['wa_phone_number_id', 'wa_access_token'], 'Payment' => ['pg_key_id', 'pg_key_secret'],
        'Company' => ['company_name', 'currency', 'timezone'], 'Finance' => ['fin_fixed_asset_acct', 'fin_accum_dep_acct', 'fin_dep_expense_acct', 'fin_default_credit_acct'],
    ][$group] ?? null;
    if (!$need) erp_fail('Unknown group.');
    $missing = array_values(array_filter($need, fn($k) => !erp_setting_get($pdo, $k)));
    $labels = [];
    foreach (adm_settings_schema()[$group]['fields'] as $f) $labels[$f['k']] = $f['l'];
    erp_ok(['ready' => !$missing, 'missing' => array_map(fn($k) => $labels[$k] ?? $k, $missing)], ['message' => $missing ? 'Missing: ' . implode(', ', array_map(fn($k) => $labels[$k] ?? $k, $missing)) : 'All required values are present.']);
}

/* ---------------------------------------------------------
   Company logo
   --------------------------------------------------------- */
function act_adm_logo_upload(PDO $pdo): void {
    erp_require_admin();
    $f = erp_save_upload('logo', 'company', ['png', 'jpg', 'jpeg', 'gif', 'webp'], 2 * 1048576);
    if (!$f) erp_fail('Choose an image.');
    $old = erp_setting_get($pdo, 'company_logo');
    erp_setting_set($pdo, 'Company', 'company_logo', $f['path']);
    if ($old) erp_delete_file($old);
    erp_ok(['path' => $f['path']], ['message' => 'Logo updated.']);
}
function act_adm_logo(PDO $pdo): void {
    $p = erp_setting_get($pdo, 'company_logo');
    $abs = $p ? erp_abs_path($p) : null;
    if (!$abs) { http_response_code(404); exit; }
    erp_send_file($abs, 'logo.' . pathinfo($abs, PATHINFO_EXTENSION), true);
}
function act_adm_company_public(PDO $pdo): void {
    erp_ok(['company_name' => erp_setting_get($pdo, 'company_name', ''), 'currency' => erp_setting_get($pdo, 'currency', 'INR'),
            'currency_symbol' => erp_setting_get($pdo, 'currency_symbol', '₹'), 'has_logo' => (bool)erp_setting_get($pdo, 'company_logo'),
            'is_admin' => erp_is_admin(), 'role' => erp_user()['role']]);
}

/* ---------------------------------------------------------
   SMTP test (real connection)
   --------------------------------------------------------- */
function adm_smtp_send(array $c, string $to, string $subject, string $body): array {
    $log = [];
    $host = $c['host']; $port = (int)$c['port']; $enc = $c['enc'];
    $remote = ($enc === 'SSL' ? 'ssl://' : 'tcp://') . $host . ':' . $port;
    $errno = 0; $errstr = '';
    $fp = @stream_socket_client($remote, $errno, $errstr, 12, STREAM_CLIENT_CONNECT, stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]));
    if (!$fp) return [false, "Could not connect to $host:$port - $errstr ($errno)"];
    stream_set_timeout($fp, 12);
    $read = function () use ($fp, &$log) {
        $resp = '';
        while (($line = fgets($fp, 515)) !== false) { $resp .= $line; if (strlen($line) < 4 || $line[3] === ' ') break; }
        $log[] = 'S: ' . trim($resp);
        return $resp;
    };
    $send = function (string $cmd, bool $mask = false) use ($fp, &$log, $read) {
        fwrite($fp, $cmd . "\r\n"); $log[] = 'C: ' . ($mask ? '********' : $cmd); return $read();
    };
    $expect = function (string $resp, array $codes) { return in_array(substr($resp, 0, 3), $codes, true); };
    try {
        $r = $read(); if (!$expect($r, ['220'])) throw new Exception('Server did not greet: ' . trim($r));
        $name = $_SERVER['SERVER_NAME'] ?? 'localhost';
        $r = $send("EHLO $name"); if (!$expect($r, ['250'])) throw new Exception('EHLO rejected: ' . trim($r));
        if ($enc === 'TLS') {
            $r = $send('STARTTLS'); if (!$expect($r, ['220'])) throw new Exception('STARTTLS rejected: ' . trim($r));
            if (!@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new Exception('TLS negotiation failed.');
            $r = $send("EHLO $name"); if (!$expect($r, ['250'])) throw new Exception('EHLO after TLS rejected.');
        }
        if ($c['user'] !== '') {
            $r = $send('AUTH LOGIN'); if (!$expect($r, ['334'])) throw new Exception('Server does not accept AUTH LOGIN: ' . trim($r));
            $r = $send(base64_encode($c['user']), true); if (!$expect($r, ['334'])) throw new Exception('Username rejected.');
            $r = $send(base64_encode($c['pass']), true); if (!$expect($r, ['235'])) throw new Exception('Authentication failed - check username / password (Gmail needs an App Password).');
        }
        $r = $send('MAIL FROM:<' . $c['from'] . '>'); if (!$expect($r, ['250'])) throw new Exception('Sender rejected: ' . trim($r));
        $r = $send('RCPT TO:<' . $to . '>'); if (!$expect($r, ['250', '251'])) throw new Exception('Recipient rejected: ' . trim($r));
        $r = $send('DATA'); if (!$expect($r, ['354'])) throw new Exception('DATA rejected: ' . trim($r));
        $headers = 'From: ' . ($c['from_name'] ? '"' . str_replace('"', '', $c['from_name']) . '" ' : '') . '<' . $c['from'] . ">\r\nTo: <$to>\r\nSubject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\nDate: " . date('r') . "\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n";
        fwrite($fp, $headers . "\r\n" . chunk_split(base64_encode($body)) . "\r\n.\r\n");
        $r = $read(); if (!$expect($r, ['250'])) throw new Exception('Message rejected: ' . trim($r));
        $send('QUIT'); fclose($fp);
        return [true, 'Delivered to the SMTP server.'];
    } catch (Exception $e) { @fclose($fp); return [false, $e->getMessage()]; }
}
function act_adm_test_email(PDO $pdo): void {
    erp_require_admin();
    $to = trim((string)(erp_input()['to'] ?? ''));
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) erp_fail('Enter a valid email address to send the test to.');
    $host = erp_setting_get($pdo, 'smtp_host'); $from = erp_setting_get($pdo, 'from_email');
    if (!$host || !$from) erp_fail('Save the SMTP host and From email first.');
    [$ok, $msg] = adm_smtp_send([
        'host' => $host, 'port' => erp_setting_get($pdo, 'smtp_port', 587), 'enc' => erp_setting_get($pdo, 'smtp_encryption', 'TLS'),
        'user' => (string)erp_setting_get($pdo, 'smtp_username', ''), 'pass' => (string)erp_setting_get($pdo, 'smtp_password', ''),
        'from' => $from, 'from_name' => (string)erp_setting_get($pdo, 'from_name', ''),
    ], $to, 'Test email from ' . (erp_setting_get($pdo, 'company_name') ?: 'Sabhyta CRM'), "This is a test message confirming your SMTP settings work.\n\nSent " . date('d M Y H:i:s') . ' by ' . erp_user()['name'] . '.');
    if (!$ok) erp_fail('Test email failed: ' . $msg, 422);
    erp_ok(null, ['message' => "Test email accepted by the SMTP server for $to."]);
}

/* ---------------------------------------------------------
   Login accounts
   --------------------------------------------------------- */
function act_adm_accounts(PDO $pdo): void {
    erp_require_admin();
    $rows = $pdo->query("SELECT u.id, u.name, u.email, u.role, u.status, u.employee_id, u.last_login_at, u.created_at,
            TRIM(CONCAT(COALESCE(e.first_name,''),' ',COALESCE(e.last_name,''))) AS employee_name,
            (SELECT GROUP_CONCAT(r.role_name SEPARATOR ', ') FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.employee_id = u.employee_id AND (ur.status IS NULL OR ur.status='Active')) AS assigned_roles
        FROM users u LEFT JOIN employees e ON e.id = u.employee_id ORDER BY u.id")->fetchAll();
    $roles = $pdo->query("SELECT role_name FROM roles ORDER BY role_level")->fetchAll(PDO::FETCH_COLUMN);
    $emps = $pdo->query("SELECT e.id, TRIM(CONCAT(e.first_name,' ',COALESCE(e.last_name,''))) AS name, COALESCE(e.official_email, e.personal_email) AS email
        FROM employees e WHERE e.id NOT IN (SELECT employee_id FROM users WHERE employee_id IS NOT NULL) ORDER BY e.first_name")->fetchAll();
    erp_ok(['accounts' => $rows, 'roles' => $roles, 'employees' => $emps, 'me' => erp_user()['id'], 'policy' => erp_policy($pdo)]);
}
function adm_active_super_admins(PDO $pdo, int $excludeId = 0): int {
    $st = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'Super Admin' AND status = 'Active' AND id <> ?"); $st->execute([$excludeId]);
    return (int)$st->fetchColumn();
}
function act_adm_account_save(PDO $pdo): void {
    erp_require_admin();
    $in = erp_input();
    $id = (int)($in['id'] ?? 0);
    $name = trim((string)($in['name'] ?? '')); $email = strtolower(trim((string)($in['email'] ?? ''))); $role = trim((string)($in['role'] ?? ''));
    $emp = (int)($in['employee_id'] ?? 0) ?: null;
    if ($name === '') erp_fail('Name is required.');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) erp_fail('Enter a valid email address.');
    $r = $pdo->prepare("SELECT 1 FROM roles WHERE role_name = ?"); $r->execute([$role]);
    if (!$r->fetchColumn()) erp_fail('Choose a valid role.');
    if ($role === 'Super Admin' && erp_user()['role'] !== 'Super Admin') erp_fail('Only a Super Admin can grant the Super Admin role.', 403);
    if ($emp && !erp_lookup_exists($pdo, 'employees', $emp)) erp_fail('Employee not found.');
    $dup = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id <> ?"); $dup->execute([$email, $id]);
    if ($dup->fetchColumn()) erp_fail('A login account with this email already exists.');
    if ($emp) {
        $dupE = $pdo->prepare("SELECT id FROM users WHERE employee_id = ? AND id <> ?"); $dupE->execute([$emp, $id]);
        if ($dupE->fetchColumn()) erp_fail('That employee already has a login account.');
    }
    if ($id) {
        $cur = $pdo->prepare("SELECT * FROM users WHERE id = ?"); $cur->execute([$id]);
        $u = $cur->fetch();
        if (!$u) erp_fail('Account not found.', 404);
        if ($u['role'] === 'Super Admin' && $role !== 'Super Admin' && adm_active_super_admins($pdo, $id) < 1) erp_fail('This is the last active Super Admin - it cannot be demoted.');
        if ($u['role'] === 'Super Admin' && erp_user()['role'] !== 'Super Admin') erp_fail('Only a Super Admin can change a Super Admin account.', 403);
        $pdo->prepare("UPDATE users SET name = ?, email = ?, role = ?, employee_id = ? WHERE id = ?")->execute([$name, $email, $role, $emp, $id]);
        erp_ok(['id' => $id], ['message' => 'Account updated.']);
    }
    $pw = (string)($in['password'] ?? '');
    $bad = erp_check_password($pdo, $pw);
    if ($bad) erp_fail('Password must have ' . implode(', ', $bad) . '.');
    if (($in['confirm'] ?? '') !== $pw) erp_fail('Passwords do not match.');
    $pdo->prepare("INSERT INTO users (name, email, password_hash, role, employee_id, status) VALUES (?,?,?,?,?, 'Active')")
        ->execute([$name, $email, password_hash($pw, PASSWORD_BCRYPT), $role, $emp]);
    erp_ok(['id' => (int)$pdo->lastInsertId()], ['message' => "Login account created for $email."]);
}
function adm_account_target(PDO $pdo, int $id): array {
    $st = $pdo->prepare("SELECT * FROM users WHERE id = ?"); $st->execute([$id]);
    $u = $st->fetch();
    if (!$u) erp_fail('Account not found.', 404);
    if ($u['role'] === 'Super Admin' && erp_user()['role'] !== 'Super Admin') erp_fail('Only a Super Admin can change a Super Admin account.', 403);
    return $u;
}
function act_adm_account_status(PDO $pdo): void {
    erp_require_admin();
    $in = erp_input(); $id = (int)($in['id'] ?? 0); $to = $in['status'] ?? '';
    if (!in_array($to, ['Active', 'Suspended'], true)) erp_fail('Invalid status.');
    $u = adm_account_target($pdo, $id);
    if ($id === erp_user()['id'] && $to === 'Suspended') erp_fail('You cannot suspend your own account.');
    if ($to === 'Suspended' && $u['role'] === 'Super Admin' && adm_active_super_admins($pdo, $id) < 1) erp_fail('This is the last active Super Admin - it cannot be suspended.');
    $pdo->prepare("UPDATE users SET status = ? WHERE id = ?")->execute([$to, $id]);
    erp_ok(null, ['message' => $to === 'Suspended' ? 'Account suspended - the user can no longer sign in.' : 'Account re-activated.']);
}
function act_adm_account_reset(PDO $pdo): void {
    erp_require_admin();
    $in = erp_input(); $id = (int)($in['id'] ?? 0); $pw = (string)($in['password'] ?? '');
    adm_account_target($pdo, $id);
    $bad = erp_check_password($pdo, $pw);
    if ($bad) erp_fail('Password must have ' . implode(', ', $bad) . '.');
    $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?")->execute([password_hash($pw, PASSWORD_BCRYPT), $id]);
    erp_ok(null, ['message' => 'Password reset.']);
}
function act_adm_account_delete(PDO $pdo): void {
    erp_require_admin();
    $id = (int)(erp_input()['id'] ?? 0);
    $u = adm_account_target($pdo, $id);
    if ($id === erp_user()['id']) erp_fail('You cannot delete your own account.');
    if ($u['role'] === 'Super Admin' && adm_active_super_admins($pdo, $id) < 1) erp_fail('This is the last active Super Admin - it cannot be deleted.');
    $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$id]);
    erp_ok(null, ['message' => 'Account deleted.']);
}

/* ---------------------------------------------------------
   Security rules
   --------------------------------------------------------- */
function adm_valid_ip_rule(string $v): bool {
    if (filter_var($v, FILTER_VALIDATE_IP)) return true;
    if (preg_match('~^([^/]+)/(\d{1,2})$~', $v, $m)) return filter_var($m[1], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false && (int)$m[2] <= 32;
    if (!preg_match('~^[0-9*]{1,3}(\.[0-9*]{1,3}){3}$~', $v)) return false;
    foreach (explode('.', $v) as $oct) if ($oct !== '*' && (int)$oct > 255) return false;
    return true;
}
function adm_rule_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    erp_require_admin();
    $type = $d['rule_type'] ?? $old['rule_type'] ?? ''; $val = trim((string)($d['rule_value'] ?? $old['rule_value'] ?? ''));
    if (!adm_valid_ip_rule($val)) erp_fail('Enter a valid IPv4/IPv6 address, a CIDR range (203.0.113.0/24) or a wildcard (203.0.113.*).');
    $active = array_key_exists('is_active', $d) ? (int)$d['is_active'] : (int)($old['is_active'] ?? 1);
    adm_guard_lockout($pdo, (int)($old['rule_id'] ?? 0), ['type' => $type, 'value' => $val, 'active' => $active]);
}
function adm_rule_before_delete(PDO $pdo, int $id, array $old): void {
    erp_require_admin();
    adm_guard_lockout($pdo, $id, null);
}
/** Refuse a change that would block the administrator who is making it. */
function adm_guard_lockout(PDO $pdo, int $excludeId, ?array $newRule): void {
    $ip = erp_ip();
    if ($ip === '' || in_array($ip, ['127.0.0.1', '::1'], true)) return;
    $st = $pdo->prepare("SELECT rule_type, rule_value FROM adm_security_rules WHERE is_active = 1 AND rule_type IN ('IP_Whitelist','IP_Blacklist') AND rule_id <> ?");
    $st->execute([$excludeId]);
    $rules = $st->fetchAll();
    if ($newRule && $newRule['active']) $rules[] = ['rule_type' => $newRule['type'], 'rule_value' => $newRule['value']];
    $white = array_filter($rules, fn($r) => $r['rule_type'] === 'IP_Whitelist');
    foreach ($rules as $r) if ($r['rule_type'] === 'IP_Blacklist' && erp_ip_match($ip, $r['rule_value'])) erp_fail("This rule would block your own address ($ip) and lock you out.");
    if ($white) {
        $ok = false;
        foreach ($white as $r) if (erp_ip_match($ip, $r['rule_value'])) $ok = true;
        if (!$ok) erp_fail("With this change the whitelist would not include your own address ($ip) and you would be locked out. Add your address to the whitelist first.");
    }
}
function act_adm_policy_get(PDO $pdo): void {
    erp_require_admin();
    erp_ok(['policy' => erp_policy($pdo), 'your_ip' => erp_ip()]);
}
function act_adm_policy_save(PDO $pdo): void {
    erp_require_admin();
    $in = erp_input()['policy'] ?? [];
    $limits = ['min_length' => [4, 64], 'require_upper' => [0, 1], 'require_lower' => [0, 1], 'require_number' => [0, 1], 'require_special' => [0, 1],
               'expiry_days' => [0, 3650], 'max_login_attempts' => [0, 50], 'lock_minutes' => [1, 1440]];
    $pdo->beginTransaction();
    foreach ($limits as $k => [$lo, $hi]) {
        if (!array_key_exists($k, $in)) continue;
        $v = (int)$in[$k];
        if ($v < $lo || $v > $hi) { $pdo->rollBack(); erp_fail("$k must be between $lo and $hi."); }
        $pdo->prepare("DELETE FROM adm_security_rules WHERE rule_type = 'Password_Policy' AND rule_value LIKE ?")->execute([$k . '=%']);
        $default = ($k === 'min_length') ? 6 : (($k === 'lock_minutes') ? 15 : 0);
        if ($v !== $default || $k === 'min_length') $pdo->prepare("INSERT INTO adm_security_rules (rule_type, rule_value, description, is_active) VALUES ('Password_Policy', ?, 'Password / login policy', 1)")->execute(["$k=$v"]);
    }
    $pdo->commit();
    erp_ok(erp_policy($pdo), ['message' => 'Password & login policy saved.']);
}
function act_adm_security_status(PDO $pdo): void {
    erp_require_admin();
    $c = fn($sql) => (int)$pdo->query($sql)->fetchColumn();
    erp_ok([
        'your_ip' => erp_ip(), 'whitelist' => $c("SELECT COUNT(*) FROM adm_security_rules WHERE rule_type='IP_Whitelist' AND is_active=1"),
        'blacklist' => $c("SELECT COUNT(*) FROM adm_security_rules WHERE rule_type='IP_Blacklist' AND is_active=1"),
        'failed_logins_24h' => $c("SELECT COUNT(*) FROM adm_audit_logs WHERE table_affected = 'auth.php' AND outcome = 'Failed' AND created_at > NOW() - INTERVAL 1 DAY"),
        'blocked_24h' => $c("SELECT COUNT(*) FROM adm_audit_logs WHERE table_affected = 'firewall' AND created_at > NOW() - INTERVAL 1 DAY"),
        'recent_failed' => $pdo->query("SELECT created_at, action_performed, ip_address FROM adm_audit_logs WHERE table_affected IN ('auth.php','firewall') AND outcome='Failed' ORDER BY log_id DESC LIMIT 8")->fetchAll(),
        'policy' => erp_policy($pdo),
    ]);
}

/* ---------------------------------------------------------
   Audit logs
   --------------------------------------------------------- */
function adm_audit_list(PDO $pdo, array $E, array $q): array {
    erp_require_admin();
    [$sql, $params, $total] = erp_list_query($pdo, $E, $q, true);
    $st = $pdo->prepare($sql); $st->execute($params);
    return [$st->fetchAll(), $total];
}
function act_adm_audit_stats(PDO $pdo): void {
    erp_require_admin();
    $c = fn($sql) => (int)$pdo->query($sql)->fetchColumn();
    erp_ok([
        'total' => $c("SELECT COUNT(*) FROM adm_audit_logs"), 'today' => $c("SELECT COUNT(*) FROM adm_audit_logs WHERE DATE(created_at) = CURDATE()"),
        'failed' => $c("SELECT COUNT(*) FROM adm_audit_logs WHERE outcome = 'Failed' AND created_at > NOW() - INTERVAL 7 DAY"),
        'logins' => $c("SELECT COUNT(*) FROM adm_audit_logs WHERE table_affected = 'auth.php' AND action_performed LIKE 'Login%' AND outcome='Success' AND DATE(created_at) = CURDATE()"),
        'tables' => $pdo->query("SELECT DISTINCT table_affected FROM adm_audit_logs WHERE table_affected IS NOT NULL ORDER BY 1")->fetchAll(PDO::FETCH_COLUMN),
        'top_users' => $pdo->query("SELECT COALESCE(user_name,'(anonymous)') AS user_name, COUNT(*) AS n FROM adm_audit_logs WHERE created_at > NOW() - INTERVAL 30 DAY GROUP BY user_name ORDER BY n DESC LIMIT 5")->fetchAll(),
    ]);
}

/* ---------------------------------------------------------
   BACKUP / RESTORE (pure PHP - no mysqldump needed)
   --------------------------------------------------------- */
const ADM_STMT_SEP = "\n-- @@STMT@@\n";

function adm_backup_dir(): string { return erp_storage_dir('backups'); }

function adm_backup_make(PDO $pdo, string $type = 'Manual', string $label = ''): array {
    @set_time_limit(0);
    $dir = adm_backup_dir();
    $base = ($label ? preg_replace('/\W+/', '_', $label) . '_' : 'backup_') . date('Ymd_His');
    $gz = function_exists('gzopen');
    $file = $base . ($gz ? '.sql.gz' : '.sql');
    $path = $dir . '/' . $file;
    $by = $type === 'Scheduled' ? 'Scheduled job' : erp_user()['name'];
    $pdo->prepare("INSERT INTO adm_backup_history (file_name, status, backup_type, executed_by) VALUES (?, 'In Progress', ?, ?)")->execute([$file, $type, $by]);
    $hid = (int)$pdo->lastInsertId();
    try {
        $fh = $gz ? gzopen($path, 'wb6') : fopen($path, 'wb');
        if (!$fh) throw new Exception('Cannot write to the backup folder.');
        $w = function (string $s) use ($fh, $gz) { $gz ? gzwrite($fh, $s) : fwrite($fh, $s); };
        $w("-- Sabhyta CRM database backup\n-- Generated " . date('Y-m-d H:i:s') . "\n-- @@STMT@@\n");
        $w("SET NAMES utf8mb4;" . ADM_STMT_SEP . "SET FOREIGN_KEY_CHECKS=0;" . ADM_STMT_SEP . "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';" . ADM_STMT_SEP);
        $tables = $pdo->query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'")->fetchAll(PDO::FETCH_COLUMN);
        $views  = $pdo->query("SHOW FULL TABLES WHERE Table_type = 'VIEW'")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($tables as $t) {
            $create = $pdo->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM)[1];
            $w("DROP TABLE IF EXISTS `$t`;" . ADM_STMT_SEP . $create . ';' . ADM_STMT_SEP);
            $cols = $pdo->query("SHOW COLUMNS FROM `$t`")->fetchAll(PDO::FETCH_COLUMN);
            $colSql = implode(',', array_map(fn($c) => "`$c`", $cols));
            $off = 0; $chunk = 500;
            while (true) {
                $rows = $pdo->query("SELECT * FROM `$t` LIMIT $chunk OFFSET $off")->fetchAll(PDO::FETCH_NUM);
                if (!$rows) break;
                $vals = [];
                foreach ($rows as $r) $vals[] = '(' . implode(',', array_map(fn($v) => $v === null ? 'NULL' : $pdo->quote((string)$v), $r)) . ')';
                $w("INSERT INTO `$t` ($colSql) VALUES\n" . implode(",\n", $vals) . ';' . ADM_STMT_SEP);
                $off += $chunk;
                if (count($rows) < $chunk) break;
            }
        }
        foreach ($views as $v) {
            $create = $pdo->query("SHOW CREATE VIEW `$v`")->fetch(PDO::FETCH_NUM)[1];
            $create = preg_replace('/DEFINER=`[^`]*`@`[^`]*`\s*/i', '', $create);
            $w("DROP VIEW IF EXISTS `$v`;" . ADM_STMT_SEP . $create . ';' . ADM_STMT_SEP);
        }
        $w("SET FOREIGN_KEY_CHECKS=1;" . ADM_STMT_SEP);
        $gz ? gzclose($fh) : fclose($fh);
        $size = round(filesize($path) / 1048576, 2);
        $pdo->prepare("UPDATE adm_backup_history SET status='Success', file_size_mb=?, tables_count=?, message=? WHERE backup_id=?")
            ->execute([$size, count($tables), count($tables) . ' tables, ' . count($views) . ' views', $hid]);
        adm_backup_prune($pdo);
        return ['backup_id' => $hid, 'file' => $file, 'size_mb' => $size, 'tables' => count($tables)];
    } catch (Throwable $e) {
        @unlink($path);
        $pdo->prepare("UPDATE adm_backup_history SET status='Failed', message=? WHERE backup_id=?")->execute([mb_substr($e->getMessage(), 0, 480), $hid]);
        throw $e;
    }
}
function adm_backup_prune(PDO $pdo): void {
    $days = (int)erp_setting_get($pdo, 'backup_retention_days', 30);
    if ($days <= 0) return;
    $st = $pdo->prepare("SELECT backup_id, file_name FROM adm_backup_history WHERE executed_at < NOW() - INTERVAL ? DAY AND status = 'Success'");
    $st->execute([$days]);
    foreach ($st->fetchAll() as $r) {
        $p = adm_backup_dir() . '/' . basename($r['file_name']);
        if (is_file($p)) @unlink($p);
    }
}
function act_adm_backup_run(PDO $pdo): void {
    erp_require_admin();
    $r = adm_backup_make($pdo, 'Manual');
    erp_ok($r, ['message' => "Backup created: {$r['file']} ({$r['size_mb']} MB, {$r['tables']} tables)."]);
}
function act_adm_backup_list(PDO $pdo): void {
    erp_require_admin();
    $rows = $pdo->query("SELECT * FROM adm_backup_history ORDER BY backup_id DESC LIMIT 100")->fetchAll();
    foreach ($rows as &$r) $r['file_exists'] = is_file(adm_backup_dir() . '/' . basename($r['file_name']));
    unset($r);
    $free = @disk_free_space(ERP_ROOT);
    erp_ok(['history' => $rows, 'retention_days' => (int)erp_setting_get($pdo, 'backup_retention_days', 30), 'gzip' => function_exists('gzopen'),
            'free_gb' => $free ? round($free / 1073741824, 1) : null, 'php' => PHP_BINARY ?: 'php', 'cron_path' => ERP_ROOT . DIRECTORY_SEPARATOR . 'cron' . DIRECTORY_SEPARATOR . 'backup.php']);
}
function act_adm_backup_retention(PDO $pdo): void {
    erp_require_admin();
    $d = (int)(erp_input()['days'] ?? 30);
    if ($d < 0 || $d > 3650) erp_fail('Enter a number of days between 0 and 3650 (0 keeps backups forever).');
    erp_setting_set($pdo, 'Backup', 'backup_retention_days', (string)$d);
    erp_ok(null, ['message' => $d ? "Backups older than $d days are removed automatically." : 'Backups are kept forever.']);
}
function adm_backup_row(PDO $pdo, int $id): array {
    $st = $pdo->prepare("SELECT * FROM adm_backup_history WHERE backup_id = ?"); $st->execute([$id]);
    $r = $st->fetch();
    if (!$r) erp_fail('Backup not found.', 404);
    return $r;
}
function act_adm_backup_download(PDO $pdo): void {
    erp_require_admin();
    $r = adm_backup_row($pdo, (int)($_GET['id'] ?? 0));
    $p = adm_backup_dir() . '/' . basename($r['file_name']);
    if (!is_file($p)) erp_fail('The backup file no longer exists on the server.', 404);
    erp_send_file($p, $r['file_name']);
}
function act_adm_backup_delete(PDO $pdo): void {
    erp_require_admin();
    $r = adm_backup_row($pdo, (int)(erp_input()['id'] ?? 0));
    $p = adm_backup_dir() . '/' . basename($r['file_name']);
    if (is_file($p)) @unlink($p);
    $pdo->prepare("DELETE FROM adm_backup_history WHERE backup_id = ?")->execute([$r['backup_id']]);
    erp_ok(null, ['message' => 'Backup deleted.']);
}
function act_adm_backup_restore(PDO $pdo): void {
    erp_require_admin();
    if (erp_user()['role'] !== 'Super Admin') erp_fail('Only a Super Admin can restore a backup.', 403);
    $in = erp_input();
    if (($in['confirm'] ?? '') !== 'RESTORE') erp_fail('Type RESTORE to confirm.');
    $r = adm_backup_row($pdo, (int)($in['id'] ?? 0));
    $p = adm_backup_dir() . '/' . basename($r['file_name']);
    if (!is_file($p)) erp_fail('The backup file no longer exists on the server.', 404);
    $safety = adm_backup_make($pdo, 'Manual', 'pre_restore');        // safety copy of the current data
    @set_time_limit(0);
    $sql = (substr($p, -3) === '.gz') ? implode('', gzfile($p)) : file_get_contents($p);
    $n = 0;
    $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
    try {
        foreach (explode(ADM_STMT_SEP, $sql) as $stmt) {
            $stmt = trim(preg_replace('/^-- [^\n]*\n?/m', '', $stmt));
            if ($stmt === '') continue;
            $pdo->exec($stmt); $n++;
        }
    } catch (Throwable $e) {
        $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
        erp_fail('Restore stopped: ' . $e->getMessage() . ' A safety copy of the previous data was saved as ' . $safety['file'] . '.', 500);
    }
    $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
    try { $pdo->prepare("INSERT INTO adm_backup_history (file_name, file_size_mb, status, backup_type, tables_count, executed_by, message) VALUES (?,?,'Success','Manual',?,?,'Safety copy taken before a restore')")->execute([$safety['file'], $safety['size_mb'], $safety['tables'], erp_user()['name']]); } catch (Throwable $e) {}
    erp_ok(['statements' => $n], ['message' => "Backup restored ($n statements). A safety copy of the previous data was saved as {$safety['file']}."]);
}
