<?php
/**
 * User Management Dashboard Stats API (PDO)
 */
header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';
require_once 'schema_compat.php';
require_once 'access.php';
acc_require($pdo, ['Manage Users', 'Manage Roles', 'Manage Permissions'], 'view the user management dashboard');

try {
    getUnderManagementStats();
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

function getUnderManagementStats() {
    global $pdo;

    $stats = [];

    try {
        $stats['total_employees'] = (int)$pdo->query("SELECT COUNT(*) FROM employees WHERE employment_status != 'Deleted'")->fetchColumn();
    } catch (Exception $e) {
        $stats['total_employees'] = 0;
    }

    try {
        $stats['active_employees'] = (int)$pdo->query("SELECT COUNT(*) FROM employees WHERE employment_status = 'Active'")->fetchColumn();
    } catch (Exception $e) {
        $stats['active_employees'] = 0;
    }

    try {
        $stats['inactive_employees'] = (int)$pdo->query("SELECT COUNT(*) FROM employees WHERE employment_status = 'Inactive'")->fetchColumn();
    } catch (Exception $e) {
        $stats['inactive_employees'] = 0;
    }

    try {
        $stats['total_roles'] = (int)$pdo->query("SELECT COUNT(*) FROM roles WHERE status = 'Active'")->fetchColumn();
    } catch (Exception $e) {
        $stats['total_roles'] = 0;
    }

    try {
        $stats['total_departments'] = (int)$pdo->query("SELECT COUNT(*) FROM departments WHERE status = 'Active'")->fetchColumn();
    } catch (Exception $e) {
        $stats['total_departments'] = 0;
    }

    try {
        $stats['total_designations'] = (int)$pdo->query("SELECT COUNT(*) FROM designations WHERE status = 'Active'")->fetchColumn();
    } catch (Exception $e) {
        $stats['total_designations'] = 0;
    }

    try {
        $stats['users_with_roles'] = (int)$pdo->query("
            SELECT COUNT(DISTINCT employee_id) FROM user_roles WHERE status = 'Active'
        ")->fetchColumn();
    } catch (Exception $e) {
        $stats['users_with_roles'] = 0;
    }

    try {
        $stats['roles_breakdown'] = $pdo->query("
            SELECT r.role_name, r.role_level, COUNT(ur.employee_id) as user_count
            FROM roles r
            LEFT JOIN user_roles ur ON r.id = ur.role_id AND ur.status = 'Active'
            WHERE r.status = 'Active'
            GROUP BY r.id
            ORDER BY r.role_level
        ")->fetchAll();
    } catch (Exception $e) {
        $stats['roles_breakdown'] = [];
    }

    try {
        $stats['dept_breakdown'] = $pdo->query("
            SELECT " . scDeptName('d') . " as dept_name,
                   COUNT(e.id) as employee_count
            FROM departments d
            LEFT JOIN employees e ON d.id = e.department_id AND e.employment_status = 'Active'
            WHERE d.status = 'Active'
            GROUP BY d.id
            ORDER BY employee_count DESC
            LIMIT 10
        ")->fetchAll();
    } catch (Exception $e) {
        $stats['dept_breakdown'] = [];
    }

    echo json_encode(['success' => true, 'data' => $stats]);
}
