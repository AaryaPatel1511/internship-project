<?php
/**
 * Auth API
 * --------------------------------------------------------
 * GET  /api/auth.php?action=bootstrap_check         -> { hasAdmin: bool }
 * POST /api/auth.php   body: action=register_first_admin, name, email,
 *                             password, confirm  (+ optional file "avatar")
 *                       Only works while the users table is empty.
 * POST /api/auth.php   body: action=login,  email, password
 * POST /api/auth.php   body: action=logout
 * GET  /api/auth.php?action=check   -> returns current session user (or 401)
 * POST /api/auth.php   body: action=update_profile, name (+ optional file "avatar")
 * GET  /api/auth.php?action=recovery_status   -> makes sure the recovery key file exists
 * POST /api/auth.php   body: action=reset_with_key, email, recovery_key, password, confirm
 *                       Forgot-password for ANY account (incl. Super Admin). The recovery key
 *                       lives in  storage/recovery_key.php  on the server - only someone with
 *                       access to the server files can read it.
 * POST /api/auth.php   body: action=change_password, current_password, new_password, confirm
 *                       Signed-in user changes their own password.
 * --------------------------------------------------------
 */

session_start();
header('Content-Type: application/json');
require_once 'db.php';
require_once __DIR__ . '/access.php';

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

// Saves an uploaded "avatar" file (if present) under
// uploads/avatars and returns its relative web path, or null.
function saveAvatarUpload() {
    if (empty($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    $tmp  = $_FILES['avatar']['tmp_name'];
    $ext  = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    if (!in_array($ext, $allowed, true)) return null;

    $dir = __DIR__ . '/../uploads/avatars';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);

    $filename = 'avatar_' . uniqid() . '.' . $ext;
    $dest = $dir . '/' . $filename;
    if (!move_uploaded_file($tmp, $dest)) return null;

    return 'uploads/avatars/' . $filename;
}


/* ---------------------------------------------------------
   Password helpers + recovery key
   --------------------------------------------------------- */

// Same rules as Administration > Security > Password policy (falls back to 6+ characters).
function authPasswordProblems(PDO $pdo, string $pw): array {
    if (is_file(__DIR__ . '/erp_core.php')) { require_once __DIR__ . '/erp_core.php'; }
    if (function_exists('erp_check_password')) {
        try { return erp_check_password($pdo, $pw); } catch (Throwable $e) { /* use the fallback */ }
    }
    return strlen($pw) < 6 ? ['at least 6 characters'] : [];
}

function authRecoveryFile(): string {
    return dirname(__DIR__) . '/storage/recovery_key.php';
}
function authNormKey(string $k): string {
    return strtolower(preg_replace('/[^a-z0-9]/i', '', $k));
}
// Returns the key, creating the file the first time. The file is a PHP file that exits
// immediately, so even a web server that ignores .htaccess never prints the key.
function authRecoveryKey(): ?string {
    $file = authRecoveryFile();
    if (is_file($file)) {
        if (preg_match('/^RECOVERY-KEY:\s*([a-z0-9-]+)\s*$/mi', (string)@file_get_contents($file), $m)) return $m[1];
    }
    $dir = dirname($file);
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) return null;
    $key = implode('-', str_split(bin2hex(random_bytes(12)), 4));
    $body = "<?php http_response_code(404); exit; ?>\n"
          . "SABHYTA CRM - PASSWORD RECOVERY KEY\n"
          . "Keep this file private. Anyone holding this key can reset any account's password\n"
          . "from the 'Forgot password?' screen on login.html.\n"
          . "To change the key: delete this file - a new one is created the next time it is needed.\n\n"
          . "RECOVERY-KEY: $key\n";
    return @file_put_contents($file, $body, LOCK_EX) === false ? null : $key;
}

// Tiny per-IP throttle for key guesses: 5 misses per 15 minutes.
function authRecoveryThrottle(bool $recordMiss = false): bool {
    $file = dirname(__DIR__) . '/storage/recovery_attempts.json';
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $now = time(); $window = 900; $max = 5;
    $fh = @fopen($file, 'c+');
    if (!$fh) return true;                         // cannot track -> do not lock people out
    flock($fh, LOCK_EX);
    $data = json_decode((string)stream_get_contents($fh), true) ?: [];
    foreach ($data as $k => $list) {
        $data[$k] = array_values(array_filter((array)$list, fn($t) => $t > $now - $window));
        if (!$data[$k]) unset($data[$k]);
    }
    $blocked = count($data[$ip] ?? []) >= $max;
    if ($recordMiss && !$blocked) $data[$ip][] = $now;
    ftruncate($fh, 0); rewind($fh); fwrite($fh, json_encode($data)); fflush($fh);
    flock($fh, LOCK_UN); fclose($fh);
    return !$blocked;
}

$action = $_REQUEST['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'bootstrap_check') {
    $count = (int) $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    respond(["success" => true, "hasAdmin" => $count > 0]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'register_first_admin') {
    $count = (int) $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if ($count > 0) {
        respond(["success" => false, "message" => "An admin account already exists. Please sign in instead."], 409);
    }

    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    if (!$name || !$email || !$password) {
        respond(["success" => false, "message" => "Name, email and password are required."], 422);
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        respond(["success" => false, "message" => "Please enter a valid email address."], 422);
    }
    if (strlen($password) < 6) {
        respond(["success" => false, "message" => "Password must be at least 6 characters."], 422);
    }
    if ($password !== $confirm) {
        respond(["success" => false, "message" => "Passwords do not match."], 422);
    }

    $avatarPath = saveAvatarUpload();
    $hash = password_hash($password, PASSWORD_BCRYPT);

    $stmt = $pdo->prepare("INSERT INTO users (name, email, password_hash, role, avatar_path) VALUES (?, ?, ?, 'Super Admin', ?)");
    $stmt->execute([$name, $email, $hash, $avatarPath]);

    $userId = $pdo->lastInsertId();
    $_SESSION['user_id']   = $userId;
    $_SESSION['user_name'] = $name;
    $_SESSION['user_role'] = 'Super Admin';

    $me = ["id" => $userId, "name" => $name, "role" => "Super Admin", "email" => $email, "avatar" => $avatarPath];
    $me['access'] = acc_menu_access($pdo, $me);
    respond(["success" => true, "user" => $me]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'update_profile') {
    if (empty($_SESSION['user_id'])) {
        respond(["success" => false, "message" => "Not authenticated."], 401);
    }
    $name = trim($_POST['name'] ?? '');
    $avatarPath = saveAvatarUpload();

    if ($name !== '') {
        $pdo->prepare("UPDATE users SET name = ? WHERE id = ?")->execute([$name, $_SESSION['user_id']]);
        $_SESSION['user_name'] = $name;
    }
    if ($avatarPath) {
        $pdo->prepare("UPDATE users SET avatar_path = ? WHERE id = ?")->execute([$avatarPath, $_SESSION['user_id']]);
    }

    $stmt = $pdo->prepare("SELECT id, name, email, role, avatar_path FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    respond(["success" => true, "user" => $user]);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'recovery_status') {
    $ok = authRecoveryKey() !== null;
    respond([
        "success" => $ok,
        "keyFile" => "storage/recovery_key.php",
        "message" => $ok ? "Recovery key is ready." : "Could not create storage/recovery_key.php - make the storage folder writable."
    ], $ok ? 200 : 500);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'reset_with_key') {
    if (!authRecoveryThrottle(false)) {
        respond(["success" => false, "message" => "Too many wrong attempts. Please wait 15 minutes and try again."], 429);
    }
    $email    = trim($_POST['email'] ?? '');
    $key      = (string)($_POST['recovery_key'] ?? '');
    $password = (string)($_POST['password'] ?? '');
    $confirm  = (string)($_POST['confirm'] ?? '');

    if ($email === '' || $key === '' || $password === '') {
        respond(["success" => false, "message" => "Email, recovery key and the new password are required."], 422);
    }

    $real = authRecoveryKey();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $target = $stmt->fetch();

    // One message for "no such account" and "wrong key" so the form cannot be used to probe e-mails.
    if (!$real || !$target || !hash_equals(authNormKey($real), authNormKey($key))) {
        authRecoveryThrottle(true);
        respond(["success" => false, "message" => "Email or recovery key is not correct."], 401);
    }
    if ($password !== $confirm) {
        respond(["success" => false, "message" => "Passwords do not match."], 422);
    }
    $bad = authPasswordProblems($pdo, $password);
    if ($bad) {
        respond(["success" => false, "message" => "Password must have " . implode(', ', $bad) . "."], 422);
    }

    $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?")
        ->execute([password_hash($password, PASSWORD_BCRYPT), $target['id']]);
    // A Super Admin who is locked out must be able to sign in again after recovering.
    if (acc_is_super_role($target['role'] ?? '')) {
        try { $pdo->prepare("UPDATE users SET status = 'Active' WHERE id = ?")->execute([$target['id']]); } catch (Throwable $e) { /* column added by ERP module */ }
    }
    respond(["success" => true, "message" => "Password updated. You can now sign in with the new password."]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'change_password') {
    if (empty($_SESSION['user_id'])) {
        respond(["success" => false, "message" => "Not authenticated."], 401);
    }
    $current = (string)($_POST['current_password'] ?? '');
    $new     = (string)($_POST['new_password'] ?? '');
    $confirm = (string)($_POST['confirm'] ?? '');

    $stmt = $pdo->prepare("SELECT id, password_hash FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $me = $stmt->fetch();
    if (!$me || !password_verify($current, $me['password_hash'])) {
        respond(["success" => false, "message" => "Your current password is not correct."], 401);
    }
    if ($new !== $confirm) {
        respond(["success" => false, "message" => "New password and confirmation do not match."], 422);
    }
    if ($new === $current) {
        respond(["success" => false, "message" => "Choose a password different from the current one."], 422);
    }
    $bad = authPasswordProblems($pdo, $new);
    if ($bad) {
        respond(["success" => false, "message" => "Password must have " . implode(', ', $bad) . "."], 422);
    }
    $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?")
        ->execute([password_hash($new, PASSWORD_BCRYPT), $me['id']]);
    respond(["success" => true, "message" => "Password changed."]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'login') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        respond(["success" => false, "message" => "Email and password are required."], 422);
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        respond(["success" => false, "message" => "Invalid email or password."], 401);
    }

    // Accounts suspended by an administrator (Administration > Users) cannot sign in.
    if (($user['status'] ?? 'Active') === 'Suspended') {
        respond(["success" => false, "message" => "Your account has been suspended. Please contact an administrator."], 403);
    }
    try { $pdo->prepare("UPDATE users SET last_login_at = NOW() WHERE id = ?")->execute([$user['id']]); } catch (Exception $e) { /* column added by the ERP module */ }

    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_role'] = $user['role'];

    $me = ["id" => $user['id'], "name" => $user['name'], "role" => $user['role'], "email" => $user['email'], "avatar" => $user['avatar_path'] ?? null];
    $me['access'] = acc_menu_access($pdo, $me);
    respond(["success" => true, "user" => $me]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'logout') {
    $_SESSION = [];
    session_destroy();
    respond(["success" => true, "message" => "Logged out."]);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'check') {
    if (!empty($_SESSION['user_id'])) {
        $stmt = $pdo->prepare("SELECT id, name, email, role, avatar_path FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        if ($user) {
            $me = ["id" => $user['id'], "name" => $user['name'], "role" => $user['role'], "email" => $user['email'], "avatar" => $user['avatar_path']];
            // Keep the session in step with the database (role changed by an admin while signed in).
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['user_name'] = $user['name'];
            $me['access'] = acc_menu_access($pdo, $me);
            respond(["success" => true, "user" => $me]);
        }
    }
    respond(["success" => false, "message" => "Not logged in."], 401);
}

respond(["success" => false, "message" => "Invalid request."], 400);
