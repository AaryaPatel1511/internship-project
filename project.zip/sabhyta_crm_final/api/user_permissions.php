<?php
/**
 * User Permissions API (PDO)
 * GET  /api/user_permissions.php           -> list all permissions grouped by module
 * GET  /api/user_permissions.php?module_id=1
 * POST /api/user_permissions.php           -> create permission
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';
require_once 'access.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    acc_require($pdo, ['Manage Users', 'Manage Roles', 'Manage Permissions'], 'view permissions');
} else {
    acc_require($pdo, ['Manage Permissions'], 'create permissions');
}

$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'GET') {
        listPermissions();
    } elseif ($method === 'POST') {
        createPermission();
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

function listPermissions() {
    global $pdo;

    ensurePermissionTables();

    $moduleId = $_GET['module_id'] ?? null;

    $query = "
        SELECT
            p.id,
            p.permission_name,
            p.action_type,
            p.description,
            p.status,
            p.module_id,
            m.module_name,
            m.module_icon
        FROM permissions p
        JOIN modules m ON p.module_id = m.id
        WHERE p.status = 'Active'
    ";
    $params = [];
    if ($moduleId) {
        $query .= " AND p.module_id = ?";
        $params[] = $moduleId;
    }
    $query .= " ORDER BY m.module_name, p.permission_name";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $perms = $stmt->fetchAll();

    $byModule = [];
    foreach ($perms as $p) {
        $mod = $p['module_name'];
        if (!isset($byModule[$mod])) {
            $byModule[$mod] = [
                'module_id' => $p['module_id'],
                'module_name' => $p['module_name'],
                'module_icon' => $p['module_icon'],
                'permissions' => []
            ];
        }
        $byModule[$mod]['permissions'][] = $p;
    }

    echo json_encode([
        'success' => true,
        'data' => $perms,
        'by_module' => array_values($byModule),
        'count' => count($perms)
    ]);
}

function createPermission() {
    global $pdo;

    $input = json_decode(file_get_contents('php://input'), true);
    $moduleId = $input['module_id'] ?? null;
    $name = trim($input['permission_name'] ?? '');
    $action = $input['action_type'] ?? 'view';
    $description = $input['description'] ?? '';

    if (!$moduleId || $name === '') {
        echo json_encode(['success' => false, 'message' => 'Module and permission name are required']);
        return;
    }

    $stmt = $pdo->prepare("
        INSERT INTO permissions (module_id, permission_name, action_type, description, status)
        VALUES (?, ?, ?, ?, 'Active')
    ");
    $stmt->execute([$moduleId, $name, $action, $description]);
    echo json_encode([
        'success' => true,
        'message' => 'Permission created',
        'permission_id' => (int)$pdo->lastInsertId()
    ]);
}

function ensurePermissionTables() {
    global $pdo;

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS modules (
          id INT AUTO_INCREMENT PRIMARY KEY,
          module_name VARCHAR(100) UNIQUE NOT NULL,
          module_icon VARCHAR(50),
          description TEXT,
          status VARCHAR(20) DEFAULT 'Active',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS permissions (
          id INT AUTO_INCREMENT PRIMARY KEY,
          module_id INT NOT NULL,
          permission_name VARCHAR(150) NOT NULL,
          action_type VARCHAR(50) NOT NULL,
          description TEXT,
          status VARCHAR(20) DEFAULT 'Active',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_module (module_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $modCount = (int)$pdo->query("SELECT COUNT(*) FROM modules")->fetchColumn();
    if ($modCount === 0) {
        $pdo->exec("
            INSERT INTO modules (module_name, module_icon, description, status) VALUES
            ('CRM', 'fa-users', 'Customer Relationship Management', 'Active'),
            ('HRMS', 'fa-user-tie', 'Human Resource Management', 'Active'),
            ('Accounts', 'fa-wallet', 'Financial and Accounting Management', 'Active'),
            ('Projects', 'fa-project-diagram', 'Project Management', 'Active'),
            ('Inventory', 'fa-box-open', 'Stock and Inventory Management', 'Active'),
            ('Helpdesk', 'fa-headset', 'Support and Ticket Management', 'Active'),
            ('Reports', 'fa-chart-pie', 'Reporting and Analytics', 'Active'),
            ('Administration', 'fa-user-shield', 'System Administration', 'Active')
        ");
    }

    $permCount = (int)$pdo->query("SELECT COUNT(*) FROM permissions")->fetchColumn();
    if ($permCount === 0) {
        // Seed basic permissions by module name
        $mods = $pdo->query("SELECT id, module_name FROM modules")->fetchAll();
        $map = [];
        foreach ($mods as $m) $map[$m['module_name']] = $m['id'];

        $seeds = [
            ['CRM', 'View Leads', 'view'],
            ['CRM', 'Add Lead', 'add'],
            ['CRM', 'Edit Lead', 'edit'],
            ['CRM', 'Delete Lead', 'delete'],
            ['CRM', 'Assign Lead', 'assign'],
            ['CRM', 'Export Leads', 'export'],
            ['CRM', 'View Customers', 'view'],
            ['CRM', 'Add Customer', 'add'],
            ['CRM', 'Edit Customer', 'edit'],
            ['CRM', 'Approve Quotation', 'approve'],
            ['HRMS', 'View Employees', 'view'],
            ['HRMS', 'Add Employee', 'add'],
            ['HRMS', 'Edit Employee', 'edit'],
            ['HRMS', 'Delete Employee', 'delete'],
            ['HRMS', 'View Attendance', 'view'],
            ['HRMS', 'Manage Leave', 'edit'],
            ['HRMS', 'View Payroll', 'view'],
            ['HRMS', 'Process Payroll', 'edit'],
            ['Accounts', 'View Accounts', 'view'],
            ['Accounts', 'Add Invoice', 'add'],
            ['Accounts', 'Approve Payment', 'approve'],
            ['Accounts', 'View Reports', 'view'],
            ['Projects', 'View Projects', 'view'],
            ['Projects', 'Create Project', 'add'],
            ['Projects', 'Manage Tasks', 'edit'],
            ['Projects', 'Approve Project', 'approve'],
            ['Administration', 'Manage Users', 'edit'],
            ['Administration', 'Manage Roles', 'edit'],
            ['Administration', 'Manage Permissions', 'edit'],
            ['Administration', 'View Audit Logs', 'view'],
        ];

        $ins = $pdo->prepare("INSERT INTO permissions (module_id, permission_name, action_type, description, status) VALUES (?, ?, ?, ?, 'Active')");
        foreach ($seeds as $s) {
            if (!isset($map[$s[0]])) continue;
            $ins->execute([$map[$s[0]], $s[1], $s[2], $s[1]]);
        }
    }
}
