<?php
/**
 * SALARY PROCESSING API
 * Handles three types of salary processing:
 * 1. Individual Employee Monthly Salary
 * 2. Bulk Department/Branch Processing
 * 3. Financial Year Report
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/session_guard.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($action) {
        case 'process_individual':
            // Process salary for a single employee for a specific month/year
            handleIndividualSalaryProcessing();
            break;

        case 'process_bulk':
            // Process salary for entire department/branch
            handleBulkSalaryProcessing();
            break;

        case 'financial_year_report':
            // Generate salary report for a financial year
            handleFinancialYearReport();
            break;

        case 'get_employees':
            // Get list of employees for processing
            getEmployeesForProcessing();
            break;

        case 'get_salary_history':
            // Get salary processing history
            getSalaryHistory();
            break;

        case 'download_salary_slip':
            // Generate and download salary slip PDF
            downloadSalarySlip();
            break;

        default:
            http_response_code(400);
            echo json_encode(['error' => 'Invalid action']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

// ===== FUNCTION IMPLEMENTATIONS =====

function handleIndividualSalaryProcessing() {
    global $pdo;
    $data = json_decode(file_get_contents('php://input'), true);

    $employeeId = $data['employee_id'] ?? null;
    $month = $data['month'] ?? date('m');
    $year = $data['year'] ?? date('Y');
    $includeAttendance = $data['include_attendance'] ?? true;
    $includeLeaves = $data['include_leaves'] ?? false;
    $includeAllowances = $data['include_allowances'] ?? true;
    $includeDeductions = $data['include_deductions'] ?? true;

    if (!$employeeId) {
        throw new Exception('Employee ID required');
    }

    // Get employee details
    $empStmt = $pdo->prepare("SELECT * FROM employees WHERE id = ?");
    $empStmt->execute([$employeeId]);
    $employee = $empStmt->fetch();

    if (!$employee) {
        throw new Exception('Employee not found');
    }

    // Calculate salary components
    $basicSalary = $employee['basic_salary'] ?? 0;
    $hra = $employee['hra'] ?? 0;
    $da = $employee['da'] ?? 0;
    $conveyance = $employee['conveyance'] ?? 0;
    $medicalAllowance = $employee['medical_allowance'] ?? 0;
    $specialAllowance = $employee['special_allowance'] ?? 0;

    $grossSalary = $basicSalary + $hra + $da + $conveyance + $medicalAllowance + $specialAllowance;

    // Calculate deductions
    $pf = $employee['pf'] ?? 0;
    $esic = $employee['esic'] ?? 0;
    $professionalTax = $employee['professional_tax'] ?? 0;

    $totalDeductions = $pf + $esic + $professionalTax;
    $netSalary = $grossSalary - $totalDeductions;

    // Create salary record
    $slipNumber = "SLIP-" . $employeeId . "-" . $year . $month . "-" . time();
    
    $stmt = $pdo->prepare("
        INSERT INTO salary_slips 
        (employee_id, slip_number, month, year, basic_salary, hra, da, conveyance, 
         medical_allowance, special_allowance, gross_salary, pf, esic, professional_tax, 
         net_salary, status, processed_date)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Processed', NOW())
    ");

    $stmt->execute([
        $employeeId, $slipNumber, $month, $year,
        $basicSalary, $hra, $da, $conveyance, $medicalAllowance, $specialAllowance,
        $grossSalary, $pf, $esic, $professionalTax, $netSalary
    ]);

    echo json_encode([
        'status' => 'success',
        'slip_number' => $slipNumber,
        'employee' => [
            'id' => $employee['id'],
            'name' => $employee['first_name'] . ' ' . $employee['last_name'],
            'employee_code' => $employee['employee_code']
        ],
        'salary_details' => [
            'basic_salary' => $basicSalary,
            'hra' => $hra,
            'da' => $da,
            'conveyance' => $conveyance,
            'medical_allowance' => $medicalAllowance,
            'special_allowance' => $specialAllowance,
            'gross_salary' => $grossSalary,
            'pf' => $pf,
            'esic' => $esic,
            'professional_tax' => $professionalTax,
            'total_deductions' => $totalDeductions,
            'net_salary' => $netSalary
        ],
        'period' => "$month/$year"
    ]);
}

function handleBulkSalaryProcessing() {
    global $pdo;
    $data = json_decode(file_get_contents('php://input'), true);

    $department = $data['department'] ?? null;
    $branch = $data['branch'] ?? null;
    $month = $data['month'] ?? date('m');
    $year = $data['year'] ?? date('Y');

    $query = "SELECT * FROM employees WHERE status = 'Active'";
    $params = [];

    if ($department) {
        $query .= " AND department_id = ?";
        $params[] = $department;
    }
    if ($branch) {
        $query .= " AND branch = ?";
        $params[] = $branch;
    }

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $employees = $stmt->fetchAll();

    if (empty($employees)) {
        throw new Exception('No active employees found for selected criteria');
    }

    $processedSlips = [];
    $totalNetSalary = 0;

    foreach ($employees as $employee) {
        $basicSalary = $employee['basic_salary'] ?? 0;
        $hra = $employee['hra'] ?? 0;
        $da = $employee['da'] ?? 0;
        $conveyance = $employee['conveyance'] ?? 0;
        $medicalAllowance = $employee['medical_allowance'] ?? 0;
        $specialAllowance = $employee['special_allowance'] ?? 0;

        $grossSalary = $basicSalary + $hra + $da + $conveyance + $medicalAllowance + $specialAllowance;

        $pf = $employee['pf'] ?? 0;
        $esic = $employee['esic'] ?? 0;
        $professionalTax = $employee['professional_tax'] ?? 0;

        $totalDeductions = $pf + $esic + $professionalTax;
        $netSalary = $grossSalary - $totalDeductions;

        $slipNumber = "SLIP-" . $employee['id'] . "-" . $year . $month . "-" . time();

        $insertStmt = $pdo->prepare("
            INSERT INTO salary_slips 
            (employee_id, slip_number, month, year, basic_salary, hra, da, conveyance, 
             medical_allowance, special_allowance, gross_salary, pf, esic, professional_tax, 
             net_salary, status, processed_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Processed', NOW())
        ");

        $insertStmt->execute([
            $employee['id'], $slipNumber, $month, $year,
            $basicSalary, $hra, $da, $conveyance, $medicalAllowance, $specialAllowance,
            $grossSalary, $pf, $esic, $professionalTax, $netSalary
        ]);

        $totalNetSalary += $netSalary;

        $processedSlips[] = [
            'slip_number' => $slipNumber,
            'employee_name' => $employee['first_name'] . ' ' . $employee['last_name'],
            'net_salary' => $netSalary
        ];
    }

    echo json_encode([
        'status' => 'success',
        'total_processed' => count($processedSlips),
        'total_net_salary' => $totalNetSalary,
        'period' => "$month/$year",
        'slips' => $processedSlips
    ]);
}

function handleFinancialYearReport() {
    global $pdo;
    $data = json_decode(file_get_contents('php://input'), true);

    $financialYear = $data['financial_year'] ?? date('Y');
    $employeeId = $data['employee_id'] ?? null;

    $query = "SELECT * FROM salary_slips WHERE year >= ? AND year < ?";
    $params = [$financialYear, $financialYear + 1];

    if ($employeeId) {
        $query .= " AND employee_id = ?";
        $params[] = $employeeId;
    }

    $query .= " ORDER BY employee_id, year DESC, month DESC";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $slips = $stmt->fetchAll();

    // Group by employee and calculate summary
    $summary = [];
    $totalAmount = 0;

    foreach ($slips as $slip) {
        $empId = $slip['employee_id'];
        if (!isset($summary[$empId])) {
            $summary[$empId] = [
                'total_gross' => 0,
                'total_deductions' => 0,
                'total_net' => 0,
                'months_processed' => 0,
                'slips' => []
            ];
        }

        $summary[$empId]['total_gross'] += $slip['gross_salary'];
        $summary[$empId]['total_deductions'] += ($slip['pf'] + $slip['esic'] + $slip['professional_tax']);
        $summary[$empId]['total_net'] += $slip['net_salary'];
        $summary[$empId]['months_processed']++;
        $summary[$empId]['slips'][] = $slip;

        $totalAmount += $slip['net_salary'];
    }

    echo json_encode([
        'status' => 'success',
        'financial_year' => $financialYear,
        'total_amount' => $totalAmount,
        'summary' => $summary,
        'total_records' => count($slips)
    ]);
}

function getEmployeesForProcessing() {
    global $pdo;
    
    $stmt = $pdo->query("
        SELECT e.id, e.employee_code, e.first_name, e.last_name, e.designation_id, 
               e.department_id, e.branch, d.designation_name, dept.department_name
        FROM employees e
        LEFT JOIN designations d ON e.designation_id = d.id
        LEFT JOIN departments dept ON e.department_id = dept.id
        WHERE e.status = 'Active'
        ORDER BY e.first_name
    ");

    $employees = $stmt->fetchAll();

    echo json_encode([
        'status' => 'success',
        'employees' => $employees
    ]);
}

function getSalaryHistory() {
    global $pdo;
    
    $employeeId = $_GET['employee_id'] ?? null;
    
    $query = "SELECT * FROM salary_slips WHERE 1=1";
    $params = [];

    if ($employeeId) {
        $query .= " AND employee_id = ?";
        $params[] = $employeeId;
    }

    $query .= " ORDER BY year DESC, month DESC LIMIT 50";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $slips = $stmt->fetchAll();

    echo json_encode([
        'status' => 'success',
        'history' => $slips
    ]);
}

function downloadSalarySlip() {
    global $pdo;
    
    $slipId = $_GET['slip_id'] ?? null;
    
    if (!$slipId) {
        throw new Exception('Slip ID required');
    }

    $stmt = $pdo->prepare("
        SELECT ss.*, e.first_name, e.last_name, e.employee_code, 
               e.designation_id, e.bank_name, e.account_number, e.ifsc_code,
               d.designation_name
        FROM salary_slips ss
        JOIN employees e ON ss.employee_id = e.id
        LEFT JOIN designations d ON e.designation_id = d.id
        WHERE ss.id = ?
    ");

    $stmt->execute([$slipId]);
    $slip = $stmt->fetch();

    if (!$slip) {
        throw new Exception('Salary slip not found');
    }

    echo json_encode([
        'status' => 'success',
        'slip' => $slip
    ]);
}

// Create salary_slips table if it doesn't exist
try {
    $pdo->query("
        CREATE TABLE IF NOT EXISTS salary_slips (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT NOT NULL,
            slip_number VARCHAR(100) NOT NULL,
            month VARCHAR(2),
            year VARCHAR(4),
            basic_salary DECIMAL(15,2),
            hra DECIMAL(15,2),
            da DECIMAL(15,2),
            conveyance DECIMAL(15,2),
            medical_allowance DECIMAL(15,2),
            special_allowance DECIMAL(15,2),
            gross_salary DECIMAL(15,2),
            pf DECIMAL(15,2),
            esic DECIMAL(15,2),
            professional_tax DECIMAL(15,2),
            net_salary DECIMAL(15,2),
            status VARCHAR(50),
            processed_date TIMESTAMP,
            UNIQUE KEY uq_slip (employee_id, month, year),
            INDEX idx_slip_number (slip_number),
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        ) ENGINE=InnoDB
    ");
} catch (Exception $e) {
    // Table might already exist
}
?>
