<?php
/**
 * Customers REST API
 * --------------------------------------------------------
 * GET    /api/customers.php            -> list all customers (supports ?q=search)
 * GET    /api/customers.php?id=5       -> get one customer
 * POST   /api/customers.php            -> create a customer (multipart/form-data)
 * POST   /api/customers.php?id=5       -> update a customer  (multipart/form-data, sends _method=PUT)
 * DELETE /api/customers.php?id=5       -> delete a customer
 * --------------------------------------------------------
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

// Text/number/date fields stored directly in the customers table.
// Keys = DB column name, Values = form field name sent from the frontend.
$FIELDS = [
    'customer_code'          => 'customerCode',
    'customer_type'          => 'customerType',
    'customer_category'      => 'customerCategory',
    'customer_name'          => 'customerName',
    'company_name'           => 'companyName',
    'display_name'           => 'displayName',
    'gst_number'              => 'gst',
    'pan_number'              => 'pan',
    'tan_number'              => 'tan',
    'cin_number'              => 'cin',
    'msme_number'             => 'msme',
    'industry'                => 'industry',
    'business_nature'         => 'businessNature',
    'turnover'                => 'turnover',
    'employees'               => 'employees',
    'website'                 => 'website',
    'email'                   => 'email',
    'mobile'                  => 'mobile',
    'alt_mobile'              => 'altMobile',
    'landline'                => 'landline',
    'fax'                     => 'fax',
    'status'                  => 'status',
    'lead_source'             => 'leadSource',
    'customer_since'          => 'customerSince',
    'rating'                  => 'rating',
    'sales_executive'         => 'salesExecutive',
    'branch'                  => 'branch',
    'remarks'                 => 'remarks',
    'legal_company_name'      => 'legalCompanyName',
    'trade_name'              => 'tradeName',
    'registration_number'     => 'registrationNumber',
    'gst_registration_date'   => 'gstRegistrationDate',
    'address_line1'           => 'addressLine1',
    'address_line2'           => 'addressLine2',
    'area'                    => 'area',
    'city'                    => 'city',
    'district'                => 'district',
    'state'                   => 'state',
    'country'                 => 'country',
    'pincode'                 => 'pincode',
];

// File upload fields: DB column => form field name (from <input type="file">)
$FILE_FIELDS = [
    'pan_card_file'                  => 'panCardFile',
    'gst_certificate_file'           => 'gstCertificateFile',
    'incorporation_certificate_file' => 'incorporationCertificateFile',
    'business_license_file'          => 'businessLicenseFile',
    'iso_certificate_file'           => 'isoCertificateFile',
    'udyam_certificate_file'         => 'udyamCertificateFile',
    'company_logo_file'              => 'companyLogoFile',
    'company_profile_file'           => 'companyProfileFile',
];

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function handleUploads($FILE_FIELDS) {
    $uploadDir = __DIR__ . '/../uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

    $saved = [];
    foreach ($FILE_FIELDS as $col => $inputName) {
        if (!empty($_FILES[$inputName]['name'])) {
            $ext = pathinfo($_FILES[$inputName]['name'], PATHINFO_EXTENSION);
            $fileName = $col . '_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
            $target = $uploadDir . $fileName;
            if (move_uploaded_file($_FILES[$inputName]['tmp_name'], $target)) {
                $saved[$col] = 'uploads/' . $fileName;
            }
        }
    }
    return $saved;
}

// ---------------------------------------------------------
// GET — list all or fetch one
// ---------------------------------------------------------
if ($method === 'GET') {
    if (!empty($_GET['id'])) {
        $stmt = $pdo->prepare("SELECT * FROM customers WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        $row = $stmt->fetch();
        if (!$row) respond(["success" => false, "message" => "Customer not found"], 404);
        respond(["success" => true, "data" => $row]);
    } else {
        $sql = "SELECT * FROM customers";
        $params = [];
        if (!empty($_GET['q'])) {
            $sql .= " WHERE customer_name LIKE ? OR company_name LIKE ? OR mobile LIKE ? OR email LIKE ?";
            $like = '%' . $_GET['q'] . '%';
            $params = [$like, $like, $like, $like];
        }
        $sql .= " ORDER BY created_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        respond(["success" => true, "data" => $stmt->fetchAll()]);
    }
}

// ---------------------------------------------------------
// POST — create OR update (update when id + _method=PUT present)
// ---------------------------------------------------------
if ($method === 'POST') {
    $isUpdate = !empty($_POST['id']) && (($_POST['_method'] ?? '') === 'PUT');

    // Basic required-field validation
    foreach (['customerCode', 'customerType', 'customerName', 'email', 'mobile'] as $required) {
        if (empty($_POST[$required])) {
            respond(["success" => false, "message" => "Missing required field: $required"], 422);
        }
    }

    $data = [];
    foreach ($FIELDS as $col => $formName) {
        $data[$col] = $_POST[$formName] ?? null;
        if ($data[$col] === '') $data[$col] = null;
    }
    $data = array_merge($data, handleUploads($FILE_FIELDS));

    try {
        if ($isUpdate) {
            $id = $_POST['id'];
            $setSql = implode(', ', array_map(fn($c) => "$c = :$c", array_keys($data)));
            $stmt = $pdo->prepare("UPDATE customers SET $setSql WHERE id = :id");
            $data['id'] = $id;
            $stmt->execute($data);
            respond(["success" => true, "message" => "Customer updated", "id" => $id]);
        } else {
            $cols = implode(', ', array_keys($data));
            $placeholders = implode(', ', array_map(fn($c) => ":$c", array_keys($data)));
            $stmt = $pdo->prepare("INSERT INTO customers ($cols) VALUES ($placeholders)");
            $stmt->execute($data);
            respond(["success" => true, "message" => "Customer created", "id" => $pdo->lastInsertId()], 201);
        }
    } catch (PDOException $e) {
        $msg = $e->getCode() === '23000'
            ? "Customer Code already exists. Please use a unique code."
            : "Database error: " . $e->getMessage();
        respond(["success" => false, "message" => $msg], 400);
    }
}

// ---------------------------------------------------------
// DELETE — remove a customer
// ---------------------------------------------------------
if ($method === 'DELETE') {
    parse_str(file_get_contents('php://input'), $deleteVars);
    $id = $_GET['id'] ?? ($deleteVars['id'] ?? null);
    if (!$id) respond(["success" => false, "message" => "Missing id"], 422);

    $stmt = $pdo->prepare("DELETE FROM customers WHERE id = ?");
    $stmt->execute([$id]);
    respond(["success" => true, "message" => "Customer deleted"]);
}

respond(["success" => false, "message" => "Method not allowed"], 405);
