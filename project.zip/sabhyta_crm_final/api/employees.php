<?php
/**
 * Employees REST API (HRMS > Employee) — master data.
 * Every other HRMS/Sales module's "Employee" dropdown
 * (Sales Executive, Prepared By, Reporting Manager, HR
 * Assigned, Reviewer, Received By...) fetches live from here.
 * --------------------------------------------------------
 * GET    /api/employees.php             -> list all (supports ?q=search)
 * GET    /api/employees.php?id=5        -> get one
 * POST   /api/employees.php             -> create (multipart/form-data)
 * POST   /api/employees.php?id=5        -> update (multipart, _method=PUT)
 * DELETE /api/employees.php?id=5        -> delete
 * --------------------------------------------------------
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

$FIELDS = [
    'employee_code'            => 'employeeCode',
    'employee_type'            => 'employeeType',
    'employment_status'        => 'employmentStatus',
    'first_name'                => 'firstName',
    'middle_name'               => 'middleName',
    'last_name'                 => 'lastName',
    'gender'                    => 'gender',
    'date_of_birth'             => 'dateOfBirth',
    'blood_group'               => 'bloodGroup',
    'marital_status'            => 'maritalStatus',
    'nationality'               => 'nationality',
    'aadhaar_number'            => 'aadhaarNumber',
    'pan_number'                => 'panNumber',
    'passport_number'           => 'passportNumber',
    'driving_license'           => 'drivingLicense',
    'voter_id'                  => 'voterId',
    'uan_number'                => 'uanNumber',
    'esic_number'               => 'esicNumber',
    'passport_expiry'           => 'passportExpiry',
    'mobile_number'             => 'mobileNumber',
    'alternate_mobile'          => 'alternateMobile',
    'personal_email'            => 'personalEmail',
    'official_email'            => 'officialEmail',
    'emergency_contact_name'    => 'emergencyContactName',
    'emergency_contact_number'  => 'emergencyContactNumber',
    'relationship'              => 'relationship',

    'current_address'           => 'currentAddress',
    'permanent_address'         => 'permanentAddress',
    'city'                      => 'city',
    'district'                  => 'district',
    'state'                     => 'state',
    'country'                   => 'country',
    'pincode'                   => 'pincode',

    'department_id'             => 'departmentId',
    'designation_id'            => 'designationId',
    'reporting_manager_id'      => 'reportingManagerId',
    'branch'                    => 'branch',
    'office_location'           => 'officeLocation',
    'date_of_joining'           => 'dateOfJoining',
    'date_of_confirmation'      => 'dateOfConfirmation',
    'employee_grade'            => 'employeeGrade',
    'employment_category'       => 'employmentCategory',
    'work_shift'                => 'workShift',
    'weekly_off'                => 'weeklyOff',
    'probation_period'          => 'probationPeriod',
    'notice_period'             => 'noticePeriod',
    'ctc'                       => 'ctc',
    'basic_salary'              => 'basicSalary',
    // Auto-calculated on the frontend (see computeSalaryBreakup in
    // hrms_sales.js) whenever Basic Salary / CTC / City change — sent
    // along with the rest of the form so HRMS > Salary can read them
    // straight from the Employee master. All Metro/Non-Metro driven;
    // Yearly figures are derived (x12) in the UI and not stored here.
    'hra'                        => 'hra',
    'da'                         => 'da',
    'conveyance'                 => 'conveyance',
    'medical_allowance'          => 'medicalAllowance',
    'special_allowance'          => 'specialAllowance',
    'pf'                         => 'pf',
    'esic'                       => 'esic',
    'professional_tax'           => 'professionalTax',
    'gross_salary'               => 'grossSalary',
    'net_salary'                 => 'netSalary',
    'bank_name'                 => 'bankName',
    'account_number'            => 'accountNumber',
    'ifsc_code'                 => 'ifscCode',

    'education_json'            => 'educationJson',
    'experience_json'            => 'experienceJson',

    'status'                     => 'status',
];

$FILE_FIELDS = [
    'photograph_file' => 'photographFile',
];

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function handleUploads($FILE_FIELDS) {
    $uploadDir = __DIR__ . '/../uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

    $saved = [];
    foreach ($FILE_FIELDS as $col => $inputName) {
        if (!empty($_FILES[$inputName]['name'])) {
            $ext = pathinfo($_FILES[$inputName]['name'], PATHINFO_EXTENSION);
            $fileName = $col . '_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
            $target = $uploadDir . $fileName;
            if (move_uploaded_file($_FILES[$inputName]['tmp_name'], $target)) {
                $saved[$col] = 'uploads/' . $fileName;
            }
        }
    }
    return $saved;
}

if ($method === 'GET') {
    if (!empty($_GET['id'])) {
        $stmt = $pdo->prepare("SELECT e.*, d.department_name, de.designation_name,
                                       CONCAT(m.first_name, ' ', COALESCE(m.last_name,'')) AS reporting_manager_name
                                FROM employees e
                                LEFT JOIN departments d ON d.id = e.department_id
                                LEFT JOIN designations de ON de.id = e.designation_id
                                LEFT JOIN employees m ON m.id = e.reporting_manager_id
                                WHERE e.id = ?");
        $stmt->execute([$_GET['id']]);
        $row = $stmt->fetch();
        if (!$row) respond(["success" => false, "message" => "Employee not found"], 404);
        respond(["success" => true, "data" => $row]);
    } else {
        $sql = "SELECT e.*, d.department_name, de.designation_name
                FROM employees e
                LEFT JOIN departments d ON d.id = e.department_id
                LEFT JOIN designations de ON de.id = e.designation_id";
        $params = [];
        if (!empty($_GET['q'])) {
            $sql .= " WHERE e.first_name LIKE ? OR e.last_name LIKE ? OR e.employee_code LIKE ? OR e.mobile_number LIKE ? OR e.official_email LIKE ?";
            $like = '%' . $_GET['q'] . '%';
            $params = [$like, $like, $like, $like, $like];
        }
        $sql .= " ORDER BY e.created_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        respond(["success" => true, "data" => $stmt->fetchAll()]);
    }
}

if ($method === 'POST') {
    $isUpdate = !empty($_POST['id']) && (($_POST['_method'] ?? '') === 'PUT');

    foreach (['employeeCode', 'firstName', 'mobileNumber'] as $required) {
        if (empty($_POST[$required])) {
            respond(["success" => false, "message" => "Missing required field: $required"], 422);
        }
    }

    $data = [];
    foreach ($FIELDS as $col => $formName) {
        $data[$col] = $_POST[$formName] ?? null;
        if ($data[$col] === '') $data[$col] = null;
    }
    $data = array_merge($data, handleUploads($FILE_FIELDS));

    try {
        if ($isUpdate) {
            $id = $_POST['id'];
            $setSql = implode(', ', array_map(fn($c) => "$c = :$c", array_keys($data)));
            $stmt = $pdo->prepare("UPDATE employees SET $setSql WHERE id = :id");
            $data['id'] = $id;
            $stmt->execute($data);
            respond(["success" => true, "message" => "Employee updated", "id" => $id]);
        } else {
            $cols = implode(', ', array_keys($data));
            $placeholders = implode(', ', array_map(fn($c) => ":$c", array_keys($data)));
            $stmt = $pdo->prepare("INSERT INTO employees ($cols) VALUES ($placeholders)");
            $stmt->execute($data);
            respond(["success" => true, "message" => "Employee created", "id" => $pdo->lastInsertId()], 201);
        }
    } catch (PDOException $e) {
        $msg = $e->getCode() === '23000'
            ? "Employee Code already exists. Please use a unique code."
            : "Database error: " . $e->getMessage();
        respond(["success" => false, "message" => $msg], 400);
    }
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? null;
    if (!$id) respond(["success" => false, "message" => "Missing id"], 422);
    $stmt = $pdo->prepare("DELETE FROM employees WHERE id = ?");
    $stmt->execute([$id]);
    respond(["success" => true, "message" => "Employee deleted"]);
}

respond(["success" => false, "message" => "Method not allowed"], 405);
