<?php
/**
 * Extended User Profile API
 * Handles employee profiles, leave, attendance, tasks, and notifications
 */
header('Content-Type: application/json');
require_once 'db.php';
require_once 'session_guard.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$module = $_GET['module'] ?? '';

try {
    $userId = $_SESSION['user_id'] ?? 0;

    if ($module === 'profile') {
        handleProfileRequests($method, $action, $userId);
    } elseif ($module === 'password') {
        handlePasswordRequests($method, $action, $userId);
    } elseif ($module === 'attendance') {
        handleAttendanceRequests($method, $action, $userId);
    } elseif ($module === 'leave') {
        handleLeaveRequests($method, $action, $userId);
    } elseif ($module === 'tasks') {
        handleTaskRequests($method, $action, $userId);
    } elseif ($module === 'notifications') {
        handleNotificationRequests($method, $action, $userId);
    } else {
        throw new Exception('Invalid module');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}

function handleProfileRequests($method, $action, $userId) {
    $conn = getDBConnection();

    if ($method === 'GET' && $action === 'my_profile') {
        $stmt = $conn->prepare("SELECT ep.*, e.employee_code, e.department, e.designation, u.username, u.email, u.role 
                               FROM employee_profiles ep
                               LEFT JOIN employees e ON ep.employee_id = e.id
                               LEFT JOIN users u ON ep.user_id = u.id
                               WHERE ep.user_id = ?");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $profile = $stmt->get_result()->fetch_assoc();
        echo json_encode(['success' => true, 'data' => $profile]);
    } 
    elseif ($method === 'POST' && $action === 'update_editable_fields') {
        $data = json_decode(file_get_contents('php://input'), true);
        $allowedFields = ['personal_email', 'personal_phone', 'personal_address', 'city', 'state', 'postal_code', 
                         'emergency_contact_name', 'emergency_contact_phone', 'emergency_contact_relation', 'profile_photo'];
        
        $updates = [];
        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updates[$field] = $data[$field];
            }
        }

        if (!empty($updates)) {
            $updateStr = implode(', ', array_map(fn($k) => "$k = ?", array_keys($updates)));
            $stmt = $conn->prepare("UPDATE employee_profiles SET $updateStr WHERE user_id = ?");
            $types = str_repeat('s', count($updates)) . 'i';
            $values = array_values($updates);
            $values[] = $userId;
            $stmt->bind_param($types, ...$values);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Profile updated']);
            } else {
                throw new Exception('Failed to update profile');
            }
        } else {
            throw new Exception('No valid fields to update');
        }
    }
    elseif ($method === 'POST' && $action === 'request_protected_change') {
        $data = json_decode(file_get_contents('php://input'), true);
        $changeType = $data['change_type'] ?? null;
        $newValue = $data['new_value'] ?? null;
        $reason = $data['reason'] ?? null;

        if (!$changeType || !$newValue) {
            throw new Exception('Missing required fields');
        }

        $stmt = $conn->prepare("INSERT INTO profile_change_requests 
                               (employee_id, change_type, new_value, reason, requested_by, status) 
                               VALUES ((SELECT employee_id FROM employee_profiles WHERE user_id = ?), ?, ?, ?, ?, 'pending')");
        $stmt->bind_param('isssl', $userId, $changeType, $newValue, $reason, $userId);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Change request submitted for HR approval', 'id' => $conn->insert_id]);
        } else {
            throw new Exception('Failed to submit change request');
        }
    }
}

function handlePasswordRequests($method, $action, $userId) {
    $conn = getDBConnection();

    if ($method === 'POST' && $action === 'change') {
        $data = json_decode(file_get_contents('php://input'), true);
        $currentPassword = $data['current_password'] ?? null;
        $newPassword = $data['new_password'] ?? null;
        $confirmPassword = $data['confirm_password'] ?? null;

        if (!$currentPassword || !$newPassword || !$confirmPassword) {
            throw new Exception('All fields are required');
        }

        if ($newPassword !== $confirmPassword) {
            throw new Exception('Passwords do not match');
        }

        if (strlen($newPassword) < 8) {
            throw new Exception('Password must be at least 8 characters');
        }

        // Verify current password
        $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if (!$user || !password_verify($currentPassword, $user['password'])) {
            throw new Exception('Current password is incorrect');
        }

        $newPasswordHash = password_hash($newPassword, PASSWORD_BCRYPT);

        // Update password
        $stmt = $conn->prepare("UPDATE users SET password = ?, updated_date = NOW() WHERE id = ?");
        $stmt->bind_param('si', $newPasswordHash, $userId);

        if ($stmt->execute()) {
            // Log to password history
            $stmt2 = $conn->prepare("INSERT INTO password_history (user_id, password_hash, changed_by) VALUES (?, ?, ?)");
            $stmt2->bind_param('isi', $userId, $newPasswordHash, $userId);
            $stmt2->execute();

            echo json_encode(['success' => true, 'message' => 'Password changed successfully']);
        } else {
            throw new Exception('Failed to change password');
        }
    }
}

function handleAttendanceRequests($method, $action, $userId) {
    $conn = getDBConnection();

    if ($method === 'GET' && $action === 'my_attendance') {
        $month = $_GET['month'] ?? date('Y-m');
        $stmt = $conn->prepare("SELECT a.*, s.shift_name, s.start_time, s.end_time 
                               FROM attendance_records a
                               LEFT JOIN shifts s ON a.shift_id = s.id
                               WHERE a.employee_id = (SELECT employee_id FROM employee_profiles WHERE user_id = ?)
                               AND DATE_FORMAT(a.attendance_date, '%Y-%m') = ?
                               ORDER BY a.attendance_date DESC");
        $stmt->bind_param('is', $userId, $month);
        $stmt->execute();
        $records = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        echo json_encode(['success' => true, 'data' => $records]);
    }
    elseif ($method === 'POST' && $action === 'check_in') {
        $data = json_decode(file_get_contents('php://input'), true);
        $empId = $conn->prepare("SELECT employee_id FROM employee_profiles WHERE user_id = ?")->bind_param('i', $userId);
        
        $stmt = $conn->prepare("INSERT INTO attendance_records 
                               (employee_id, attendance_date, check_in_time, shift_id, status) 
                               VALUES ((SELECT employee_id FROM employee_profiles WHERE user_id = ?), CURDATE(), NOW(), ?, 'present')");
        $shiftId = $data['shift_id'] ?? 1;
        $stmt->bind_param('ii', $userId, $shiftId);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Checked in successfully']);
        } else {
            throw new Exception('Failed to check in');
        }
    }
    elseif ($method === 'POST' && $action === 'check_out') {
        $stmt = $conn->prepare("UPDATE attendance_records 
                               SET check_out_time = NOW() 
                               WHERE employee_id = (SELECT employee_id FROM employee_profiles WHERE user_id = ?)
                               AND attendance_date = CURDATE()");
        $stmt->bind_param('i', $userId);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Checked out successfully']);
        } else {
            throw new Exception('Failed to check out');
        }
    }
    elseif ($method === 'POST' && $action === 'request_regularization') {
        $data = json_decode(file_get_contents('php://input'), true);
        $attendanceId = $data['attendance_id'] ?? null;
        $reason = $data['reason'] ?? null;

        $stmt = $conn->prepare("UPDATE attendance_records SET regularization_reason = ?, status = 'incomplete' WHERE id = ?");
        $stmt->bind_param('si', $reason, $attendanceId);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Regularization request submitted']);
        } else {
            throw new Exception('Failed to submit regularization request');
        }
    }
}

function handleLeaveRequests($method, $action, $userId) {
    $conn = getDBConnection();

    if ($method === 'GET' && $action === 'my_leave_balance') {
        $empId = "(SELECT employee_id FROM employee_profiles WHERE user_id = $userId)";
        $stmt = $conn->query("SELECT lb.*, lt.leave_type_name 
                             FROM leave_balance_ledger lb
                             JOIN leave_types lt ON lb.leave_type_id = lt.id
                             WHERE lb.employee_id = $empId
                             AND lb.financial_year = YEAR(NOW())");
        $balances = $stmt->fetch_all(MYSQLI_ASSOC);
        echo json_encode(['success' => true, 'data' => $balances]);
    }
    elseif ($method === 'GET' && $action === 'my_leave_requests') {
        $empId = "(SELECT employee_id FROM employee_profiles WHERE user_id = $userId)";
        $stmt = $conn->query("SELECT lr.*, lt.leave_type_name 
                             FROM leave_requests lr
                             JOIN leave_types lt ON lr.leave_type_id = lt.id
                             WHERE lr.employee_id = $empId
                             ORDER BY lr.created_date DESC");
        $requests = $stmt->fetch_all(MYSQLI_ASSOC);
        echo json_encode(['success' => true, 'data' => $requests]);
    }
    elseif ($method === 'POST' && $action === 'request_leave') {
        $data = json_decode(file_get_contents('php://input'), true);
        $empId = "(SELECT employee_id FROM employee_profiles WHERE user_id = $userId)";
        
        $stmt = $conn->prepare("INSERT INTO leave_requests 
                               (employee_id, leave_type_id, start_date, end_date, is_full_day, half_day_type, reason, created_by) 
                               VALUES ($empId, ?, ?, ?, ?, ?, ?, ?)");
        $leaveTypeId = $data['leave_type_id'];
        $startDate = $data['start_date'];
        $endDate = $data['end_date'];
        $isFullDay = $data['is_full_day'] ?? 1;
        $halfDayType = $data['half_day_type'] ?? null;
        $reason = $data['reason'] ?? null;

        $stmt->bind_param('issisis', $leaveTypeId, $startDate, $endDate, $isFullDay, $halfDayType, $reason, $userId);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Leave request submitted', 'id' => $conn->insert_id]);
        } else {
            throw new Exception('Failed to request leave');
        }
    }
    elseif ($method === 'POST' && $action === 'withdraw_leave') {
        $leaveRequestId = $_GET['id'] ?? null;
        $stmt = $conn->prepare("UPDATE leave_requests SET approval_status = 'withdrawal_pending' WHERE id = ?");
        $stmt->bind_param('i', $leaveRequestId);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Leave withdrawal request submitted']);
        } else {
            throw new Exception('Failed to withdraw leave');
        }
    }
}

function handleTaskRequests($method, $action, $userId) {
    $conn = getDBConnection();

    if ($method === 'GET' && $action === 'my_tasks') {
        $status = $_GET['status'] ?? 'all';
        $query = "SELECT t.*, p.project_name, c.customer_name 
                  FROM employee_tasks t
                  LEFT JOIN projects p ON t.project_id = p.id
                  LEFT JOIN customers c ON t.customer_id = c.id
                  WHERE t.assigned_to = (SELECT employee_id FROM employee_profiles WHERE user_id = ?)";
        if ($status !== 'all') {
            $query .= " AND t.status = '$status'";
        }
        $query .= " ORDER BY t.due_date ASC";

        $stmt = $conn->prepare($query);
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $tasks = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        echo json_encode(['success' => true, 'data' => $tasks]);
    }
    elseif ($method === 'POST' && $action === 'update_task_status') {
        $taskId = $_GET['id'] ?? null;
        $data = json_decode(file_get_contents('php://input'), true);
        $newStatus = $data['status'] ?? null;

        $stmt = $conn->prepare("UPDATE employee_tasks SET status = ? WHERE id = ?");
        $stmt->bind_param('si', $newStatus, $taskId);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Task status updated']);
        } else {
            throw new Exception('Failed to update task');
        }
    }
    elseif ($method === 'POST' && $action === 'log_time_entry') {
        $data = json_decode(file_get_contents('php://input'), true);
        $empId = "(SELECT employee_id FROM employee_profiles WHERE user_id = $userId)";
        
        $stmt = $conn->prepare("INSERT INTO time_entries 
                               (employee_id, task_id, project_id, work_date, hours_logged, is_billable, description) 
                               VALUES ($empId, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('iiidis', $data['task_id'], $data['project_id'], $data['work_date'], 
                         $data['hours_logged'], $data['is_billable'], $data['description']);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Time entry logged']);
        } else {
            throw new Exception('Failed to log time entry');
        }
    }
}

function handleNotificationRequests($method, $action, $userId) {
    $conn = getDBConnection();

    if ($method === 'GET' && $action === 'list') {
        $limit = $_GET['limit'] ?? 20;
        $stmt = $conn->prepare("SELECT * FROM notifications 
                               WHERE recipient_user_id = ?
                               ORDER BY created_date DESC
                               LIMIT ?");
        $stmt->bind_param('ii', $userId, $limit);
        $stmt->execute();
        $notifications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        echo json_encode(['success' => true, 'data' => $notifications]);
    }
    elseif ($method === 'POST' && $action === 'mark_read') {
        $notificationId = $_GET['id'] ?? null;
        $stmt = $conn->prepare("UPDATE notifications SET is_read = true, read_date = NOW() WHERE id = ?");
        $stmt->bind_param('i', $notificationId);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Notification marked as read']);
        } else {
            throw new Exception('Failed to mark notification');
        }
    }
    elseif ($method === 'GET' && $action === 'unread_count') {
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE recipient_user_id = ? AND is_read = false");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        echo json_encode(['success' => true, 'unread_count' => $result['count']]);
    }
}

?>
