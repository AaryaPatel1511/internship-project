<?php
/**
 * ERP REGISTRY - declarative definition of every entity.
 * --------------------------------------------------------
 * Field keys:  k=column  l=label  t=type  req  opts  def  src(lookup)  dep(filter by other form fields)
 *              virtual (not a column of this table)  ro (never accepted from input)  full  help  ph
 *              showIf ['field'=>..,'in'=>[..]]  multi  unique  max  min  fileMeta
 * Types: text textarea number decimal date datetime email url tel select bool lookup combo file password
 * --------------------------------------------------------
 */

function F(string $k, string $l, string $t = 'text', array $o = []): array {
    return array_merge(['k' => $k, 'l' => $l, 't' => $t], $o);
}

/* ---------------------------------------------------------
   Lookup sources (dropdown data)
   --------------------------------------------------------- */
function erp_lookups(): array {
    global $pdo;
    $dept = function_exists('scDeptName') ? scDeptName('t') : 't.department_name';
    return [
        'customers'   => ['from' => 'customers t', 'id' => 't.id', 'label' => "CONCAT(t.customer_name, IF(COALESCE(t.company_name,'')='', '', CONCAT(' - ', t.company_name)))", 'order' => 't.customer_name'],
        'employees'   => ['from' => 'employees t', 'id' => 't.id', 'label' => "CONCAT(t.first_name, ' ', COALESCE(t.last_name,''), ' (', t.employee_code, ')')", 'order' => 't.first_name', 'attrs' => ['department_id' => 't.department_id']],
        'departments' => ['from' => 'departments t', 'id' => 't.id', 'label' => $dept, 'order' => $dept],
        'roles'       => ['from' => 'roles t', 'id' => 't.id', 'label' => 't.role_name', 'order' => 't.role_level'],
        'users'       => ['from' => 'users t', 'id' => 't.id', 'label' => "CONCAT(t.name, ' <', t.email, '>')", 'order' => 't.name'],
        'projects'    => ['from' => 'pm_projects t', 'id' => 't.project_id', 'label' => "CONCAT(t.project_code, ' - ', t.project_name)", 'order' => 't.project_name', 'attrs' => ['client_id' => 't.client_id', 'status' => 't.status']],
        'modules'     => ['from' => 'pm_modules t', 'id' => 't.module_id', 'label' => 't.module_name', 'order' => 't.module_name', 'attrs' => ['project_id' => 't.project_id']],
        'tasks'       => ['from' => 'pm_tasks t JOIN pm_modules m ON m.module_id = t.module_id', 'id' => 't.task_id', 'label' => 't.task_name', 'order' => 'm.project_id, t.task_name', 'attrs' => ['project_id' => 'm.project_id', 'module_id' => 't.module_id', 'status' => 't.status']],
        'milestones'  => ['from' => 'pm_milestones t', 'id' => 't.milestone_id', 'label' => 't.milestone_title', 'order' => 't.due_date', 'attrs' => ['project_id' => 't.project_id']],
        'assets'      => ['from' => 'am_assets t', 'id' => 't.asset_id', 'label' => "CONCAT(t.asset_tag, ' - ', t.brand_model)", 'order' => 't.asset_tag', 'attrs' => ['asset_type' => 't.asset_type', 'status' => 't.status']],
        'documents'   => ['from' => 'dms_documents t', 'id' => 't.doc_id', 'label' => "CONCAT(t.title, ' [', t.category, ']')", 'order' => 't.title', 'attrs' => ['category' => 't.category']],
        'audience_lists'  => ['from' => 'mk_audience_lists t', 'id' => 't.list_id', 'label' => "CONCAT(t.list_name, ' (', (SELECT COUNT(*) FROM mk_audience_contacts c WHERE c.list_id = t.list_id), ')')", 'order' => 't.list_name', 'attrs' => ['channel' => 't.channel']],
        'social_audiences'=> ['from' => 'mk_social_audiences t', 'id' => 't.audience_id', 'label' => "CONCAT(t.persona_name, ' - ', t.platform)", 'order' => 't.persona_name', 'attrs' => ['platform' => 't.platform']],
        // Master data created elsewhere in the app (generic_records)
        'branches'    => ['from' => 'generic_records t', 'id' => 't.id', 'label' => 't.title', 'where' => "t.module_key = 'master__branch'", 'order' => 't.title', 'labelAsValue' => true],
        'vendors'     => ['from' => 'generic_records t', 'id' => 't.id', 'label' => 't.title', 'where' => "t.module_key = 'accounts__vendor'", 'order' => 't.title', 'labelAsValue' => true],
        'chart_accounts' => ['from' => 'generic_records t', 'id' => 't.id', 'label' => 't.title', 'where' => "t.module_key = 'accounts__chart-of-accounts'", 'order' => 't.title'],
    ];
}

/* ---------------------------------------------------------
   Entities
   --------------------------------------------------------- */
function erp_entities(): array {
    static $E = null;
    if ($E !== null) return $E;

    $campStatus = ['Draft','Scheduled','Running','Completed','Paused','Cancelled'];
    $platforms  = ['Facebook','Instagram','LinkedIn','X (Twitter)','YouTube','Google Ads','Other'];

    $E = [];

    /* =====================  MARKETING  ===================== */
    $E['mk_audience_lists'] = [
        'table' => 'mk_audience_lists', 'pk' => 'list_id', 'label' => 'Audience List', 'plural' => 'Audience Lists',
        'fields' => [
            F('list_name', 'List Name', 'text', ['req' => true, 'max' => 150]),
            F('channel', 'Channel', 'select', ['req' => true, 'opts' => ['Email','SMS','WhatsApp','Social'], 'def' => 'Email']),
            F('source', 'Source', 'select', ['opts' => ['Manual','Customers','Leads','CSV Upload'], 'def' => 'Manual', 'help' => 'Use "Import / Build" on the list to fill it from the CRM or a CSV file.']),
            F('status', 'Status', 'select', ['opts' => ['Active','Inactive'], 'def' => 'Active']),
            F('description', 'Description', 'textarea', ['full' => true]),
        ],
        'sections' => [['List Details', ['list_name','channel','source','status','description']]],
        'select' => ["(SELECT COUNT(*) FROM mk_audience_contacts c WHERE c.list_id = t.list_id) AS contacts",
                     "(SELECT COUNT(*) FROM mk_audience_contacts c WHERE c.list_id = t.list_id AND c.status='Active' AND c.opt_in=1) AS active_contacts"],
        'list' => [['list_name','List'],['channel','Channel'],['source','Source'],['contacts','Contacts','num'],['active_contacts','Opted-in & Active','num'],['status','Status','chip'],['created_at','Created','date']],
        'search' => ['t.list_name'], 'filters' => ['channel','status'], 'order' => 't.list_id DESC',
        'before' => 'mk_before_generic', 'beforeDelete' => null,
    ];
    $E['mk_audience_contacts'] = [
        'table' => 'mk_audience_contacts', 'pk' => 'contact_id', 'label' => 'Contact', 'plural' => 'Contacts',
        'fields' => [
            F('list_id', 'Audience List', 'lookup', ['req' => true, 'src' => 'audience_lists']),
            F('full_name', 'Full Name', 'text', ['max' => 150]),
            F('email', 'Email', 'email'),
            F('phone', 'Phone (with country code)', 'tel', ['ph' => '+919876543210']),
            F('city', 'City'), F('state', 'State'), F('country', 'Country'),
            F('opt_in', 'Opted In', 'bool', ['def' => 1]),
            F('opt_in_at', 'Opt-in Timestamp', 'datetime', ['help' => 'Required evidence of consent for WhatsApp.']),
            F('whatsapp_verified', 'WhatsApp Verified', 'bool'),
            F('status', 'Status', 'select', ['opts' => ['Active','Unsubscribed','Bounced'], 'def' => 'Active']),
        ],
        'sections' => [['Contact', ['list_id','full_name','email','phone','city','state','country']], ['Consent', ['opt_in','opt_in_at','whatsapp_verified','status']]],
        'from' => 'mk_audience_contacts t JOIN mk_audience_lists l ON l.list_id = t.list_id',
        'select' => ['l.list_name AS list_name'],
        'list' => [['full_name','Name'],['email','Email'],['phone','Phone'],['city','City'],['opt_in','Opt-in','bool'],['whatsapp_verified','WA Verified','bool'],['status','Status','chip'],['list_name','List']],
        'search' => ['t.full_name','t.email','t.phone'], 'filters' => ['list_id','status'], 'order' => 't.contact_id DESC',
        'before' => 'mk_contact_before', 'after' => 'mk_contact_after', 'afterDelete' => 'mk_contact_after_delete',
    ];
    $E['mk_suppression'] = [
        'table' => 'mk_suppression', 'pk' => 'suppression_id', 'label' => 'Suppressed Contact', 'plural' => 'Suppression List',
        'fields' => [
            F('channel', 'Channel', 'select', ['req' => true, 'opts' => ['Email','SMS','WhatsApp'], 'def' => 'Email']),
            F('contact_value', 'Email / Phone', 'text', ['req' => true, 'max' => 190]),
            F('reason', 'Reason', 'select', ['opts' => ['Unsubscribed','Hard Bounce','Opt-out','Complaint','Manual'], 'def' => 'Unsubscribed']),
            F('notes', 'Notes', 'text', ['max' => 255, 'full' => true]),
        ],
        'sections' => [['Suppression Entry', ['channel','contact_value','reason','notes']]],
        'list' => [['contact_value','Email / Phone'],['channel','Channel'],['reason','Reason'],['notes','Notes'],['added_at','Added','date']],
        'search' => ['t.contact_value'], 'filters' => ['channel','reason'], 'order' => 't.suppression_id DESC',
        'before' => 'mk_suppression_before',
    ];

    $E['mk_email_campaigns'] = [
        'table' => 'mk_email_campaigns', 'pk' => 'campaign_id', 'label' => 'Email Campaign', 'plural' => 'Email Campaigns',
        'fields' => [
            F('campaign_name', 'Campaign Name', 'text', ['req' => true, 'max' => 190]),
            F('objective', 'Objective', 'select', ['opts' => ['Product Launch','Seasonal Sale','Newsletter','Retention','Event','Other'], 'def' => 'Newsletter']),
            F('list_id', 'Audience List (Email)', 'lookup', ['src' => 'audience_lists', 'srcFilter' => ['channel' => 'Email'], 'help' => 'Segmented subscriber list. Build one under the "Audience Lists" tab.']),
            F('sender_name', 'Sender Name', 'text', ['max' => 120]),
            F('sender_email', 'Sender Email', 'email'),
            F('sender_domain_auth', 'Sender domain authenticated (SPF / DKIM)', 'bool'),
            F('subject_line', 'Subject Line', 'text', ['max' => 255, 'full' => true]),
            F('preheader_text', 'Pre-header Text', 'text', ['max' => 255, 'full' => true]),
            F('html_template', 'HTML Email Template', 'textarea', ['full' => true, 'rows' => 8, 'help' => 'Paste your HTML template. Include an unsubscribe link.']),
            F('plain_text_body', 'Plain-text Fallback', 'textarea', ['full' => true, 'rows' => 4]),
            F('banner_image', 'Banner Image', 'file', ['accept' => 'image/*', 'ext' => ERP_MEDIA_EXT, 'sub' => 'marketing']),
            F('language', 'Language / Locale', 'text', ['ph' => 'e.g. English, Hindi', 'max' => 40]),
            F('localized_copy', 'Localized Copy', 'textarea', ['full' => true, 'rows' => 3]),
            F('landing_url', 'Landing Page URL', 'url', ['full' => true]),
            F('utm_source', 'UTM Source', 'text', ['def' => 'email']),
            F('utm_medium', 'UTM Medium', 'text', ['def' => 'email']),
            F('utm_campaign', 'UTM Campaign'),
            F('utm_content', 'UTM Content'),
            F('tracking_url', 'Tracking Link (auto-generated)', 'text', ['ro' => true, 'full' => true]),
            F('spam_score', 'Spam Score (0 = clean, 10 = spam)', 'decimal', ['min' => 0, 'max' => 10, 'help' => 'Use "Run Spam Check" to calculate.']),
            F('scheduled_at', 'Scheduled For', 'datetime'),
            F('status', 'Status', 'select', ['opts' => $campStatus, 'def' => 'Draft', 'ro' => true]),
        ],
        'sections' => [
            ['Campaign', ['campaign_name','objective','status']],
            ['Audience Data', ['list_id']],
            ['Configuration', ['sender_name','sender_email','sender_domain_auth','subject_line','preheader_text','scheduled_at']],
            ['Content Assets', ['html_template','plain_text_body','banner_image','language','localized_copy']],
            ['Tracking (UTM)', ['landing_url','utm_source','utm_medium','utm_campaign','utm_content','tracking_url','spam_score']],
        ],
        'from' => 't_ LEFT JOIN mk_audience_lists l ON l.list_id = t.list_id',
        'select' => ['l.list_name AS list_name'],
        'list' => [['campaign_name','Campaign'],['list_name','Audience'],['subject_line','Subject','trunc'],['scheduled_at','Scheduled','datetime'],['total_recipients','Recipients','num'],['spam_score','Spam','num'],['status','Status','chip']],
        'search' => ['t.campaign_name','t.subject_line'], 'filters' => ['status','objective'], 'order' => 't.campaign_id DESC',
        'before' => 'mk_email_before', 'beforeDelete' => 'mk_campaign_before_delete', 'channel' => 'Email',
    ];
    $E['mk_sms_campaigns'] = [
        'table' => 'mk_sms_campaigns', 'pk' => 'campaign_id', 'label' => 'SMS Campaign', 'plural' => 'SMS Campaigns',
        'fields' => [
            F('campaign_name', 'Campaign Name', 'text', ['req' => true, 'max' => 190]),
            F('objective', 'Objective', 'select', ['opts' => ['Product Launch','Seasonal Sale','Reminder','Retention','Event','Other'], 'def' => 'Reminder']),
            F('list_id', 'Audience List (SMS)', 'lookup', ['src' => 'audience_lists', 'srcFilter' => ['channel' => 'SMS'], 'help' => 'Cleaned phone numbers with country codes.']),
            F('sender_id', 'Approved Sender ID', 'text', ['max' => 20, 'ph' => 'e.g. SABHYT']),
            F('message_text', 'Message', 'textarea', ['full' => true, 'rows' => 4, 'help' => 'Up to 160 characters = 1 segment (70 if the text has non-English characters).']),
            F('dlt_entity_id', 'DLT Entity ID (India)', 'text', ['max' => 60]),
            F('dlt_template_id', 'DLT Template ID (India)', 'text', ['max' => 60]),
            F('opt_out_text', 'Opt-out Text', 'text', ['def' => 'Reply STOP to cancel', 'max' => 120]),
            F('short_url', 'Shortened Trackable URL', 'url', ['full' => true, 'help' => 'e.g. a Bitly link.']),
            F('scheduled_at', 'Scheduled For', 'datetime'),
            F('status', 'Status', 'select', ['opts' => $campStatus, 'def' => 'Draft', 'ro' => true]),
        ],
        'sections' => [
            ['Campaign', ['campaign_name','objective','status']],
            ['Audience Data', ['list_id']],
            ['Content Assets', ['message_text','opt_out_text','short_url']],
            ['Configuration', ['sender_id','scheduled_at']],
            ['Compliance (DLT)', ['dlt_entity_id','dlt_template_id']],
        ],
        'from' => 't_ LEFT JOIN mk_audience_lists l ON l.list_id = t.list_id',
        'select' => ['l.list_name AS list_name'],
        'list' => [['campaign_name','Campaign'],['list_name','Audience'],['sender_id','Sender ID'],['message_text','Message','trunc'],['segments','Segments','num'],['scheduled_at','Scheduled','datetime'],['total_recipients','Recipients','num'],['status','Status','chip']],
        'search' => ['t.campaign_name','t.message_text'], 'filters' => ['status','objective'], 'order' => 't.campaign_id DESC',
        'before' => 'mk_sms_before', 'beforeDelete' => 'mk_campaign_before_delete', 'channel' => 'SMS',
    ];
    $E['mk_whatsapp_campaigns'] = [
        'table' => 'mk_whatsapp_campaigns', 'pk' => 'campaign_id', 'label' => 'WhatsApp Campaign', 'plural' => 'WhatsApp Campaigns',
        'fields' => [
            F('campaign_name', 'Campaign Name', 'text', ['req' => true, 'max' => 190]),
            F('objective', 'Objective', 'select', ['opts' => ['Product Launch','Seasonal Sale','Reminder','Retention','Event','Other'], 'def' => 'Product Launch']),
            F('list_id', 'Audience List (WhatsApp)', 'lookup', ['src' => 'audience_lists', 'srcFilter' => ['channel' => 'WhatsApp'], 'help' => 'Only contacts with a verified WhatsApp account and a recorded opt-in are messaged.']),
            F('template_name', 'Template Name', 'text', ['max' => 150, 'ph' => 'lowercase_with_underscores']),
            F('template_category', 'Template Category', 'select', ['opts' => ['Marketing','Utility','Authentication'], 'def' => 'Marketing']),
            F('template_status', 'Template Approval', 'select', ['opts' => ['Draft','Submitted','Approved','Rejected'], 'def' => 'Draft', 'help' => 'Submit the template to Meta well in advance; set Approved once WhatsApp approves it.']),
            F('template_body', 'Template Body', 'textarea', ['full' => true, 'rows' => 5, 'help' => 'Use {{1}}, {{2}} for variables.']),
            F('media_type', 'Media Type', 'select', ['opts' => ['None','Image','Video','PDF'], 'def' => 'None']),
            F('media_file', 'Rich Media File', 'file', ['ext' => ERP_MEDIA_EXT, 'sub' => 'marketing', 'help' => 'Image, short MP4 or PDF brochure optimised for mobile.']),
            F('button_type', 'Button Type', 'select', ['opts' => ['None','Quick Reply','Call To Action'], 'def' => 'None']),
            F('button_config', 'Button Configuration', 'textarea', ['full' => true, 'rows' => 3, 'help' => 'One per line, e.g. "Quick Reply: Yes, I am interested" or "CTA: Visit Website | https://..."']),
            F('scheduled_at', 'Scheduled For', 'datetime'),
            F('status', 'Status', 'select', ['opts' => $campStatus, 'def' => 'Draft', 'ro' => true]),
        ],
        'sections' => [
            ['Campaign', ['campaign_name','objective','status']],
            ['Audience Data', ['list_id']],
            ['Message Template', ['template_name','template_category','template_status','template_body']],
            ['Content Assets', ['media_type','media_file']],
            ['Configuration', ['button_type','button_config','scheduled_at']],
        ],
        'from' => 't_ LEFT JOIN mk_audience_lists l ON l.list_id = t.list_id',
        'select' => ['l.list_name AS list_name'],
        'list' => [['campaign_name','Campaign'],['list_name','Audience'],['template_name','Template'],['template_status','Template','chip'],['scheduled_at','Scheduled','datetime'],['total_recipients','Recipients','num'],['status','Status','chip']],
        'search' => ['t.campaign_name','t.template_name'], 'filters' => ['status','template_status'], 'order' => 't.campaign_id DESC',
        'before' => 'mk_wa_before', 'beforeDelete' => 'mk_campaign_before_delete', 'channel' => 'WhatsApp',
    ];
    $E['mk_wa_flows'] = [
        'table' => 'mk_wa_flows', 'pk' => 'flow_id', 'label' => 'Auto-reply Flow', 'plural' => 'Auto-reply Flows',
        'fields' => [
            F('flow_name', 'Flow Name', 'text', ['req' => true, 'max' => 150]),
            F('trigger_keyword', 'Trigger Keyword', 'text', ['max' => 100, 'help' => 'Inbound message that starts this flow, e.g. PRICE. Leave empty for the default fallback.']),
            F('reply_message', 'Auto-reply Message', 'textarea', ['full' => true, 'rows' => 4]),
            F('is_fallback', 'Use as fallback (no keyword matched)', 'bool'),
            F('fallback_message', 'Fallback Message', 'textarea', ['full' => true, 'rows' => 3]),
            F('status', 'Status', 'select', ['opts' => ['Active','Inactive'], 'def' => 'Active']),
        ],
        'sections' => [['Session Data', ['flow_name','trigger_keyword','reply_message','is_fallback','fallback_message','status']]],
        'list' => [['flow_name','Flow'],['trigger_keyword','Keyword'],['reply_message','Reply','trunc'],['is_fallback','Fallback','bool'],['status','Status','chip']],
        'search' => ['t.flow_name','t.trigger_keyword'], 'filters' => ['status'], 'order' => 't.flow_id DESC',
    ];
    $E['mk_social_audiences'] = [
        'table' => 'mk_social_audiences', 'pk' => 'audience_id', 'label' => 'Audience Persona', 'plural' => 'Audience Personas',
        'fields' => [
            F('persona_name', 'Persona Name', 'text', ['req' => true, 'max' => 150]),
            F('platform', 'Platform', 'select', ['opts' => $platforms, 'def' => 'Facebook']),
            F('age_range', 'Age Range', 'text', ['ph' => '25-40']),
            F('gender', 'Gender', 'select', ['opts' => ['All','Male','Female','Other'], 'def' => 'All']),
            F('locations', 'Locations', 'text', ['full' => true]),
            F('interests', 'Interests / Behaviours', 'textarea', ['full' => true, 'rows' => 3]),
            F('lookalike_source', 'Lookalike Source Audience', 'text', ['help' => 'e.g. customer list used to build the lookalike audience.']),
            F('retargeting_pixel', 'Retargeting Pixel ID', 'text'),
            F('estimated_size', 'Estimated Audience Size', 'number', ['min' => 0]),
            F('status', 'Status', 'select', ['opts' => ['Active','Inactive'], 'def' => 'Active']),
        ],
        'sections' => [['Audience Persona', ['persona_name','platform','age_range','gender','locations','interests']], ['Lookalike & Retargeting', ['lookalike_source','retargeting_pixel','estimated_size','status']]],
        'list' => [['persona_name','Persona'],['platform','Platform'],['age_range','Age'],['gender','Gender'],['locations','Locations','trunc'],['retargeting_pixel','Pixel'],['estimated_size','Size','num'],['status','Status','chip']],
        'search' => ['t.persona_name','t.locations'], 'filters' => ['platform','status'], 'order' => 't.audience_id DESC',
    ];
    $E['mk_social_campaigns'] = [
        'table' => 'mk_social_campaigns', 'pk' => 'campaign_id', 'label' => 'Social Post / Ad', 'plural' => 'Social Media Campaigns',
        'fields' => [
            F('campaign_name', 'Campaign Name', 'text', ['req' => true, 'max' => 190]),
            F('platform', 'Platform', 'select', ['opts' => $platforms, 'def' => 'Facebook']),
            F('post_type', 'Post Type', 'select', ['opts' => ['Image','Carousel','Video / Reel','Story','Text','Ad'], 'def' => 'Image']),
            F('audience_id', 'Target Audience Persona', 'lookup', ['src' => 'social_audiences']),
            F('creative_file', 'Creative (graphic / video)', 'file', ['ext' => ERP_MEDIA_EXT, 'sub' => 'marketing']),
            F('ad_copy_a', 'Ad Copy - Variation A', 'textarea', ['full' => true, 'rows' => 3]),
            F('ad_copy_b', 'Ad Copy - Variation B', 'textarea', ['full' => true, 'rows' => 3]),
            F('publish_at', 'Publish Date & Time', 'datetime'),
            F('budget', 'Budget (INR)', 'decimal', ['min' => 0]),
            F('bidding_strategy', 'Bidding Strategy', 'select', ['opts' => ['Lowest Cost','Cost Cap','Bid Cap','Target ROAS','Manual CPC','Organic (No Bid)'], 'def' => 'Lowest Cost']),
            F('api_credential', 'Platform API Token', 'password', ['full' => true, 'help' => 'Stored encrypted. Leave blank to keep the saved token.']),
            F('landing_url', 'Landing Page URL', 'url', ['full' => true]),
            F('utm_campaign', 'UTM Campaign'),
            F('tracking_url', 'Tracking Link (auto-generated)', 'text', ['ro' => true, 'full' => true]),
            F('status', 'Status', 'select', ['opts' => $campStatus, 'def' => 'Draft', 'ro' => true]),
        ],
        'sections' => [
            ['Campaign', ['campaign_name','platform','post_type','status']],
            ['Audience Data', ['audience_id']],
            ['Content Assets', ['creative_file','ad_copy_a','ad_copy_b']],
            ['Configuration', ['publish_at','budget','bidding_strategy','api_credential']],
            ['Tracking (UTM)', ['landing_url','utm_campaign','tracking_url']],
        ],
        'from' => 't_ LEFT JOIN mk_social_audiences a ON a.audience_id = t.audience_id',
        'select' => ['a.persona_name AS persona_name', "IF(COALESCE(t.api_credential,'')='', 0, 1) AS has_token"],
        'list' => [['campaign_name','Campaign'],['platform','Platform'],['post_type','Type'],['persona_name','Audience'],['publish_at','Publish','datetime'],['budget','Budget','money'],['status','Status','chip']],
        'search' => ['t.campaign_name'], 'filters' => ['status','platform'], 'order' => 't.campaign_id DESC',
        'before' => 'mk_social_before', 'beforeDelete' => 'mk_campaign_before_delete', 'secret' => ['api_credential'], 'channel' => 'Social',
    ];
    $E['mk_utm_links'] = [
        'table' => 'mk_utm_links', 'pk' => 'utm_id', 'label' => 'UTM Link', 'plural' => 'UTM Master List',
        'fields' => [
            F('link_name', 'Link Name', 'text', ['req' => true, 'max' => 190]),
            F('channel', 'Channel', 'select', ['opts' => ['Email','SMS','WhatsApp','Social','Other'], 'def' => 'Email']),
            F('base_url', 'Base URL', 'url', ['req' => true, 'full' => true]),
            F('utm_source', 'utm_source', 'text', ['req' => true]),
            F('utm_medium', 'utm_medium', 'text', ['req' => true]),
            F('utm_campaign', 'utm_campaign', 'text', ['req' => true]),
            F('utm_term', 'utm_term'), F('utm_content', 'utm_content'),
            F('generated_url', 'Generated URL', 'text', ['ro' => true, 'full' => true]),
            F('short_url', 'Short URL (e.g. Bitly)', 'url'),
            F('conversion_goal', 'Custom Conversion Goal'),
            F('pixel_id', 'Tracking Pixel ID'),
            F('status', 'Status', 'select', ['opts' => ['Active','Inactive'], 'def' => 'Active']),
        ],
        'sections' => [['Link', ['link_name','channel','base_url','status']], ['UTM Parameters', ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','generated_url']], ['Tracking', ['short_url','conversion_goal','pixel_id']]],
        'list' => [['link_name','Link'],['channel','Channel'],['utm_source','Source'],['utm_medium','Medium'],['utm_campaign','Campaign'],['conversion_goal','Goal'],['generated_url','URL','link'],['status','Status','chip']],
        'search' => ['t.link_name','t.utm_campaign','t.base_url'], 'filters' => ['channel','status'], 'order' => 't.utm_id DESC',
        'before' => 'mk_utm_before',
    ];
    $perfRates = [
        "ROUND(t.opens / NULLIF(t.delivered,0) * 100, 2) AS open_rate",
        "ROUND(t.clicks / NULLIF(IF(t.channel='Social', t.impressions, t.delivered),0) * 100, 2) AS ctr",
        "ROUND(t.spend / NULLIF(t.clicks,0), 2) AS cpc",
        "ROUND(t.revenue / NULLIF(t.spend,0), 2) AS roas",
        "ROUND(t.conversions / NULLIF(t.clicks,0) * 100, 2) AS conv_rate",
    ];
    $E['mk_performance'] = [
        'table' => 'mk_performance', 'pk' => 'perf_id', 'label' => 'Performance Record', 'plural' => 'Performance Data',
        'fields' => [
            F('channel', 'Channel', 'select', ['req' => true, 'opts' => ['Email','SMS','WhatsApp','Social'], 'def' => 'Email']),
            F('campaign_name', 'Campaign', 'text', ['req' => true, 'max' => 190]),
            F('period_start', 'Period Start', 'date'), F('period_end', 'Period End', 'date'),
            F('sent', 'Sent', 'number', ['min' => 0, 'def' => 0]), F('delivered', 'Delivered', 'number', ['min' => 0, 'def' => 0]),
            F('opens', 'Opens / Reads', 'number', ['min' => 0, 'def' => 0]), F('clicks', 'Clicks', 'number', ['min' => 0, 'def' => 0]),
            F('conversions', 'Conversions', 'number', ['min' => 0, 'def' => 0]), F('unsubscribes', 'Unsubscribes', 'number', ['min' => 0, 'def' => 0]),
            F('bounces', 'Bounces / Failed', 'number', ['min' => 0, 'def' => 0]), F('impressions', 'Impressions (Social)', 'number', ['min' => 0, 'def' => 0]),
            F('spend', 'Spend (INR)', 'decimal', ['min' => 0, 'def' => 0]), F('revenue', 'Revenue (INR)', 'decimal', ['min' => 0, 'def' => 0]),
            F('notes', 'Notes', 'text', ['full' => true, 'max' => 255]),
        ],
        'sections' => [['Campaign', ['channel','campaign_name','period_start','period_end']], ['Delivery & Engagement', ['sent','delivered','opens','clicks','conversions','unsubscribes','bounces','impressions']], ['Cost & Return', ['spend','revenue','notes']]],
        'select' => $perfRates,
        'list' => [['campaign_name','Campaign'],['channel','Channel'],['period_end','Period End','date'],['sent','Sent','num'],['delivered','Delivered','num'],['open_rate','Open %','pct'],['ctr','CTR %','pct'],['cpc','CPC','money'],['roas','ROAS','x'],['spend','Spend','money'],['revenue','Revenue','money']],
        'search' => ['t.campaign_name'], 'filters' => ['channel'], 'order' => 't.perf_id DESC',
        'before' => 'mk_perf_before',
    ];
    $E['mk_ab_tests'] = [
        'table' => 'mk_ab_tests', 'pk' => 'test_id', 'label' => 'A/B Test', 'plural' => 'A/B Tests',
        'fields' => [
            F('test_name', 'Test Name', 'text', ['req' => true, 'max' => 190]),
            F('channel', 'Channel', 'select', ['opts' => ['Email','SMS','WhatsApp','Social'], 'def' => 'Email']),
            F('campaign_name', 'Campaign', 'text'),
            F('variable_tested', 'Variable Tested', 'select', ['opts' => ['Subject Line','Content','Send Time','CTA','Creative','Audience'], 'def' => 'Subject Line']),
            F('variant_a', 'Variant A', 'text', ['max' => 255]), F('variant_b', 'Variant B', 'text', ['max' => 255]),
            F('metric', 'Success Metric', 'select', ['opts' => ['Open Rate','Click-Through Rate','Conversion Rate'], 'def' => 'Open Rate']),
            F('a_sent', 'A - Sent', 'number', ['min' => 0, 'def' => 0]), F('a_success', 'A - Successes (opens/clicks/conversions)', 'number', ['min' => 0, 'def' => 0]),
            F('b_sent', 'B - Sent', 'number', ['min' => 0, 'def' => 0]), F('b_success', 'B - Successes', 'number', ['min' => 0, 'def' => 0]),
            F('status', 'Status', 'select', ['opts' => ['Running','Completed'], 'def' => 'Running']),
        ],
        'sections' => [['Test', ['test_name','channel','campaign_name','variable_tested','metric','status']], ['Variants', ['variant_a','variant_b']], ['Results', ['a_sent','a_success','b_sent','b_success']]],
        'list' => [['test_name','Test'],['channel','Channel'],['variable_tested','Variable'],['a_rate','A rate %','pct'],['b_rate','B rate %','pct'],['winner','Winner'],['confidence','Confidence','pct'],['status','Status','chip']],
        'search' => ['t.test_name','t.campaign_name'], 'filters' => ['channel','status'], 'order' => 't.test_id DESC',
        'before' => 'mk_ab_before', 'decorate' => 'mk_ab_decorate',
    ];

    /* =====================  PROJECT MANAGEMENT  ===================== */
    $E['pm_projects'] = [
        'table' => 'pm_projects', 'pk' => 'project_id', 'label' => 'Project', 'plural' => 'Projects',
        'fields' => [
            F('project_code', 'Project Code', 'text', ['unique' => true, 'max' => 30, 'ph' => 'Auto-generated if blank']),
            F('project_name', 'Project Name', 'text', ['req' => true, 'max' => 255, 'full' => true]),
            F('client_id', 'Client', 'lookup', ['req' => true, 'src' => 'customers']),
            F('project_manager_id', 'Project Manager', 'lookup', ['src' => 'employees']),
            F('priority', 'Priority', 'select', ['opts' => ['Low','Medium','High'], 'def' => 'Medium']),
            F('status', 'Status', 'select', ['opts' => ['Planning','Active','Testing','Completed'], 'def' => 'Planning']),
            F('start_date', 'Start Date', 'date', ['req' => true]),
            F('end_date', 'End Date', 'date'),
            F('budget', 'Budget (INR)', 'decimal', ['min' => 0]),
            F('estimated_hours', 'Estimated Hours', 'decimal', ['min' => 0]),
            F('description', 'Description / Scope', 'textarea', ['full' => true, 'rows' => 4]),
        ],
        'sections' => [['Project Details', ['project_code','project_name','client_id','project_manager_id','priority','status']], ['Timeline & Budget', ['start_date','end_date','budget','estimated_hours']], ['Scope', ['description']]],
        'from' => 't_ LEFT JOIN customers c ON c.id = t.client_id LEFT JOIN employees pm ON pm.id = t.project_manager_id',
        'select' => [
            "COALESCE(c.customer_name, '') AS client_name",
            "TRIM(CONCAT(COALESCE(pm.first_name,''),' ',COALESCE(pm.last_name,''))) AS manager_name",
            "(SELECT COUNT(*) FROM pm_tasks tk JOIN pm_modules mo ON mo.module_id = tk.module_id WHERE mo.project_id = t.project_id) AS task_total",
            "(SELECT COUNT(*) FROM pm_tasks tk JOIN pm_modules mo ON mo.module_id = tk.module_id WHERE mo.project_id = t.project_id AND tk.status = 'Done') AS task_done",
            "(SELECT COALESCE(SUM(tt.total_hours),0) FROM pm_time_tracking tt JOIN pm_tasks tk ON tk.task_id = tt.task_id JOIN pm_modules mo ON mo.module_id = tk.module_id WHERE mo.project_id = t.project_id) AS hours_logged",
        ],
        'list' => [['project_code','Code'],['project_name','Project'],['client_name','Client'],['manager_name','Manager'],['priority','Priority','chip'],['start_date','Start','date'],['end_date','End','date'],['progress','Progress','progress'],['budget','Budget','money'],['status','Status','chip']],
        'search' => ['t.project_name','t.project_code','c.customer_name'], 'filters' => ['status','priority','client_id'], 'order' => 't.project_id DESC',
        'before' => 'pm_project_before', 'beforeDelete' => 'pm_project_before_delete', 'decorate' => 'pm_project_decorate',
    ];
    $E['pm_milestones'] = [
        'table' => 'pm_milestones', 'pk' => 'milestone_id', 'label' => 'Milestone', 'plural' => 'Milestones',
        'fields' => [
            F('project_id', 'Project', 'lookup', ['req' => true, 'src' => 'projects']),
            F('milestone_title', 'Milestone Title', 'text', ['req' => true, 'max' => 255, 'full' => true]),
            F('due_date', 'Due Date', 'date'),
            F('deliverable_amount', 'Deliverable / Billing Amount (INR)', 'decimal', ['min' => 0]),
            F('status', 'Status', 'select', ['opts' => ['Pending','Reached'], 'def' => 'Pending']),
        ],
        'sections' => [['Milestone', ['project_id','milestone_title','due_date','deliverable_amount','status']]],
        'from' => 't_ JOIN pm_projects p ON p.project_id = t.project_id',
        'select' => ['p.project_name AS project_name', 'p.project_code AS project_code'],
        'list' => [['project_name','Project'],['milestone_title','Milestone'],['due_date','Due','date'],['deliverable_amount','Amount','money'],['reached_on','Reached On','date'],['status','Status','chip']],
        'search' => ['t.milestone_title','p.project_name'], 'filters' => ['project_id','status'], 'order' => 't.due_date IS NULL, t.due_date, t.milestone_id',
        'before' => 'pm_milestone_before',
    ];
    $E['pm_modules'] = [
        'table' => 'pm_modules', 'pk' => 'module_id', 'label' => 'Module', 'plural' => 'Modules',
        'fields' => [
            F('project_id', 'Project', 'lookup', ['req' => true, 'src' => 'projects']),
            F('module_name', 'Module Name', 'text', ['req' => true, 'max' => 255, 'full' => true]),
            F('description', 'Description', 'textarea', ['full' => true, 'rows' => 4]),
        ],
        'sections' => [['Module', ['project_id','module_name','description']]],
        'from' => 't_ JOIN pm_projects p ON p.project_id = t.project_id',
        'select' => ['p.project_name AS project_name', '(SELECT COUNT(*) FROM pm_tasks tk WHERE tk.module_id = t.module_id) AS task_count'],
        'list' => [['project_name','Project'],['module_name','Module'],['task_count','Tasks','num'],['description','Description','trunc']],
        'search' => ['t.module_name','p.project_name'], 'filters' => ['project_id'], 'order' => 't.module_id DESC',
    ];
    $taskFrom = 't_ JOIN pm_modules m ON m.module_id = t.module_id JOIN pm_projects p ON p.project_id = m.project_id';
    $E['pm_tasks'] = [
        'table' => 'pm_tasks', 'pk' => 'task_id', 'label' => 'Task', 'plural' => 'Tasks',
        'fields' => [
            F('project_id', 'Project', 'lookup', ['src' => 'projects', 'virtual' => true, 'col' => 'm.project_id', 'req' => true, 'help' => 'Pick the project first, then its module.']),
            F('module_id', 'Module', 'lookup', ['req' => true, 'src' => 'modules', 'dep' => ['project_id' => 'project_id']]),
            F('task_name', 'Task Name', 'text', ['req' => true, 'max' => 255, 'full' => true]),
            F('priority', 'Priority', 'select', ['opts' => ['Low','Medium','High'], 'def' => 'Medium']),
            F('status', 'Status', 'select', ['opts' => ['To Do','In Progress','Done'], 'def' => 'To Do']),
            F('start_date', 'Start Date', 'date'), F('due_date', 'Due Date', 'date'),
            F('estimated_hours', 'Estimated Hours', 'decimal', ['min' => 0]),
            F('depends_on_task_id', 'Depends On (task)', 'lookup', ['src' => 'tasks', 'dep' => ['project_id' => 'project_id'], 'excludeSelf' => true, 'help' => 'Shown as a dependency on the Gantt chart.']),
            F('description', 'Description', 'textarea', ['full' => true, 'rows' => 3]),
        ],
        'sections' => [['Task', ['project_id','module_id','task_name','priority','status']], ['Schedule', ['start_date','due_date','estimated_hours','depends_on_task_id']], ['Details', ['description']]],
        'from' => $taskFrom,
        'select' => [
            'p.project_name AS project_name', 'p.project_id AS project_id', 'm.module_name AS module_name',
            "(SELECT GROUP_CONCAT(TRIM(CONCAT(e.first_name,' ',COALESCE(e.last_name,''))) SEPARATOR ', ') FROM pm_team_assignments ta JOIN employees e ON e.id = ta.user_id WHERE ta.task_id = t.task_id) AS assignees",
            '(SELECT COUNT(*) FROM pm_sub_tasks s WHERE s.task_id = t.task_id) AS sub_total',
            '(SELECT COUNT(*) FROM pm_sub_tasks s WHERE s.task_id = t.task_id AND s.is_completed = 1) AS sub_done',
            '(SELECT COALESCE(SUM(tt.total_hours),0) FROM pm_time_tracking tt WHERE tt.task_id = t.task_id) AS hours_logged',
        ],
        'list' => [['project_name','Project'],['module_name','Module'],['task_name','Task'],['assignees','Assigned','trunc'],['priority','Priority','chip'],['start_date','Start','date'],['due_date','Due','date'],['hours_logged','Hours','num'],['status','Status','chip']],
        'search' => ['t.task_name','m.module_name','p.project_name'], 'filters' => ['project_id','status','priority'], 'order' => 't.task_id DESC',
        'before' => 'pm_task_before', 'after' => 'pm_task_after',
    ];
    $E['pm_sub_tasks'] = [
        'table' => 'pm_sub_tasks', 'pk' => 'sub_task_id', 'label' => 'Sub Task', 'plural' => 'Sub Tasks',
        'fields' => [
            F('project_id', 'Project', 'lookup', ['src' => 'projects', 'virtual' => true, 'col' => 'm.project_id']),
            F('task_id', 'Task', 'lookup', ['req' => true, 'src' => 'tasks', 'dep' => ['project_id' => 'project_id']]),
            F('sub_task_title', 'Sub Task Title', 'text', ['req' => true, 'max' => 255, 'full' => true]),
            F('is_completed', 'Completed', 'bool'),
        ],
        'sections' => [['Sub Task', ['project_id','task_id','sub_task_title','is_completed']]],
        'from' => 't_ JOIN pm_tasks tk ON tk.task_id = t.task_id JOIN pm_modules m ON m.module_id = tk.module_id JOIN pm_projects p ON p.project_id = m.project_id',
        'select' => ['p.project_name AS project_name', 'p.project_id AS project_id', 'tk.task_name AS task_name'],
        'list' => [['project_name','Project'],['task_name','Task'],['sub_task_title','Sub Task'],['is_completed','Done','bool']],
        'search' => ['t.sub_task_title','tk.task_name','p.project_name'], 'filters' => ['project_id','task_id','is_completed'], 'order' => 't.sub_task_id DESC',
    ];
    $E['pm_team_assignments'] = [
        'table' => 'pm_team_assignments', 'pk' => 'assignment_id', 'label' => 'Team Assignment', 'plural' => 'Team Assignments',
        'fields' => [
            F('project_id', 'Project', 'lookup', ['src' => 'projects', 'virtual' => true, 'col' => 'm.project_id']),
            F('module_id', 'Module', 'lookup', ['src' => 'modules', 'virtual' => true, 'col' => 'tk.module_id', 'dep' => ['project_id' => 'project_id']]),
            F('task_id', 'Task', 'lookup', ['req' => true, 'src' => 'tasks', 'dep' => ['project_id' => 'project_id', 'module_id' => 'module_id']]),
            F('user_id', 'Team Member(s)', 'lookup', ['req' => true, 'src' => 'employees', 'multi' => true, 'help' => 'Hold Ctrl / Cmd to select several employees at once.']),
            F('role_note', 'Role on this task', 'text', ['max' => 100, 'ph' => 'e.g. Developer, Reviewer']),
        ],
        'sections' => [['Assign Team', ['project_id','module_id','task_id','user_id','role_note']]],
        'from' => 't_ JOIN pm_tasks tk ON tk.task_id = t.task_id JOIN pm_modules m ON m.module_id = tk.module_id JOIN pm_projects p ON p.project_id = m.project_id JOIN employees e ON e.id = t.user_id',
        'select' => ['p.project_name AS project_name', 'p.project_id AS project_id', 'tk.module_id AS module_id', 'm.module_name AS module_name', 'tk.task_name AS task_name', "TRIM(CONCAT(e.first_name,' ',COALESCE(e.last_name,''))) AS employee_name", 'tk.due_date AS task_due'],
        'list' => [['project_name','Project'],['module_name','Module'],['task_name','Task'],['employee_name','Team Member'],['role_note','Role'],['task_due','Task Due','date'],['assigned_date','Assigned','date']],
        'search' => ['tk.task_name','e.first_name','e.last_name','p.project_name'], 'filters' => ['project_id','user_id'], 'order' => 't.assignment_id DESC',
        'saveOverride' => 'pm_assign_save',
    ];
    $E['pm_time_tracking'] = [
        'table' => 'pm_time_tracking', 'pk' => 'time_log_id', 'label' => 'Time Log', 'plural' => 'Time Tracking',
        'fields' => [
            F('project_id', 'Project', 'lookup', ['src' => 'projects', 'virtual' => true, 'col' => 'm.project_id']),
            F('task_id', 'Task', 'lookup', ['req' => true, 'src' => 'tasks', 'dep' => ['project_id' => 'project_id']]),
            F('user_id', 'Employee', 'lookup', ['req' => true, 'src' => 'employees']),
            F('start_time', 'Start Time', 'datetime', ['req' => true]),
            F('end_time', 'End Time', 'datetime', ['help' => 'Leave empty if the clock is still running.']),
            F('total_hours', 'Total Hours (auto)', 'decimal', ['ro' => true]),
            F('notes', 'Notes', 'text', ['max' => 255, 'full' => true]),
        ],
        'sections' => [['Time Log', ['project_id','task_id','user_id','start_time','end_time','total_hours','notes']]],
        'from' => 't_ JOIN pm_tasks tk ON tk.task_id = t.task_id JOIN pm_modules m ON m.module_id = tk.module_id JOIN pm_projects p ON p.project_id = m.project_id JOIN employees e ON e.id = t.user_id',
        'select' => ['p.project_name AS project_name', 'p.project_id AS project_id', 'tk.task_name AS task_name', "TRIM(CONCAT(e.first_name,' ',COALESCE(e.last_name,''))) AS employee_name", "IF(t.end_time IS NULL, 1, 0) AS is_running"],
        'list' => [['project_name','Project'],['task_name','Task'],['employee_name','Employee'],['start_time','Start','datetime'],['end_time','End','datetime'],['total_hours','Hours','hours'],['notes','Notes','trunc']],
        'search' => ['tk.task_name','e.first_name','p.project_name'], 'filters' => ['project_id','user_id'], 'order' => 't.start_time DESC',
        'before' => 'pm_time_before',
    ];
    $E['pm_files'] = [
        'table' => 'pm_files', 'pk' => 'file_id', 'label' => 'Project File', 'plural' => 'Project Files',
        'fields' => [
            F('project_id', 'Project', 'lookup', ['req' => true, 'src' => 'projects']),
            F('file_category', 'Category', 'select', ['opts' => ['Brief','Contract','Requirement','Design','Deliverable','Other'], 'def' => 'Brief']),
            F('file_url_path', 'File', 'file', ['req' => true, 'ext' => ERP_DOC_EXT, 'sub' => 'project_files', 'fileMeta' => ['name' => 'file_name', 'size' => 'file_size'], 'full' => true, 'help' => 'Briefs, contracts, requirement documents, designs, deliverables.']),
            F('file_name', 'File Name', 'text', ['ro' => true]),
        ],
        'sections' => [['Upload File', ['project_id','file_category','file_url_path']]],
        'from' => 't_ JOIN pm_projects p ON p.project_id = t.project_id LEFT JOIN users u ON u.id = t.uploaded_by',
        'select' => ['p.project_name AS project_name', 'u.name AS uploaded_by_name'],
        'list' => [['project_name','Project'],['file_name','File'],['file_category','Category'],['file_size','Size','bytes'],['uploaded_by_name','Uploaded By'],['uploaded_at','Uploaded','datetime']],
        'search' => ['t.file_name','p.project_name'], 'filters' => ['project_id','file_category'], 'order' => 't.file_id DESC',
        'before' => 'pm_file_before', 'beforeDelete' => 'pm_file_before_delete', 'download' => 'file_url_path', 'downloadName' => 'file_name',
    ];
    $E['pm_testing_bugs'] = [
        'table' => 'pm_testing_bugs', 'pk' => 'bug_id', 'label' => 'Bug / Test Issue', 'plural' => 'Testing & Bugs',
        'fields' => [
            F('project_id', 'Project', 'lookup', ['req' => true, 'src' => 'projects']),
            F('task_id', 'Related Task', 'lookup', ['src' => 'tasks', 'dep' => ['project_id' => 'project_id']]),
            F('bug_title', 'Bug Title', 'text', ['req' => true, 'max' => 255, 'full' => true]),
            F('issue_description', 'Issue Description / Steps to Reproduce', 'textarea', ['full' => true, 'rows' => 5]),
            F('severity', 'Severity', 'select', ['opts' => ['Minor','Major','Critical'], 'def' => 'Minor']),
            F('status', 'Status', 'select', ['opts' => ['Open','Fixing','Resolved'], 'def' => 'Open']),
            F('assigned_to', 'Assigned Developer', 'lookup', ['src' => 'employees']),
        ],
        'sections' => [['Bug Report', ['project_id','task_id','bug_title','issue_description']], ['Triage', ['severity','status','assigned_to']]],
        'from' => 't_ JOIN pm_projects p ON p.project_id = t.project_id LEFT JOIN pm_tasks tk ON tk.task_id = t.task_id LEFT JOIN employees e ON e.id = t.assigned_to LEFT JOIN users u ON u.id = t.reported_by',
        'select' => ['p.project_name AS project_name', 'tk.task_name AS task_name', "TRIM(CONCAT(COALESCE(e.first_name,''),' ',COALESCE(e.last_name,''))) AS assignee_name", 'u.name AS reporter_name'],
        'list' => [['project_name','Project'],['bug_title','Bug'],['task_name','Task'],['severity','Severity','chip'],['assignee_name','Assigned To'],['reporter_name','Reported By'],['created_at','Reported','date'],['status','Status','chip']],
        'search' => ['t.bug_title','t.issue_description','p.project_name'], 'filters' => ['project_id','severity','status'], 'order' => 't.bug_id DESC',
        'before' => 'pm_bug_before',
    ];
    $E['pm_client_approvals'] = [
        'table' => 'pm_client_approvals', 'pk' => 'approval_id', 'label' => 'Client Approval', 'plural' => 'Client Approvals',
        'fields' => [
            F('project_id', 'Project', 'lookup', ['req' => true, 'src' => 'projects']),
            F('milestone_id', 'Linked Milestone', 'lookup', ['src' => 'milestones', 'dep' => ['project_id' => 'project_id'], 'help' => 'Approving marks this milestone as Reached.']),
            F('approval_type', 'Approval Type', 'select', ['req' => true, 'opts' => ['Requirements','Design','Prototype','Milestone','UAT','Final'], 'def' => 'Design']),
            F('status', 'Status', 'select', ['opts' => ['Pending','Approved','Rejected'], 'def' => 'Pending']),
            F('signed_by', 'Approved / Rejected By (client signatory)', 'text', ['max' => 150, 'help' => 'Required when approving or rejecting - recorded as the digital sign-off.']),
            F('feedback_notes', 'Client Feedback', 'textarea', ['full' => true, 'rows' => 4, 'help' => 'Required when rejecting. A rework task is created automatically.']),
        ],
        'sections' => [['Approval Request', ['project_id','milestone_id','approval_type','status']], ['Sign-off', ['signed_by','feedback_notes']]],
        'from' => 't_ JOIN pm_projects p ON p.project_id = t.project_id LEFT JOIN customers c ON c.id = t.client_id LEFT JOIN pm_milestones ms ON ms.milestone_id = t.milestone_id',
        'select' => ['p.project_name AS project_name', 'c.customer_name AS client_name', 'ms.milestone_title AS milestone_title'],
        'list' => [['project_name','Project'],['client_name','Client'],['approval_type','Type'],['milestone_title','Milestone'],['requested_at','Requested','date'],['decided_at','Decided','date'],['signed_by','Signed By'],['status','Status','chip']],
        'search' => ['p.project_name','t.feedback_notes','t.signed_by'], 'filters' => ['project_id','status','approval_type'], 'order' => 't.approval_id DESC',
        'before' => 'pm_approval_before', 'after' => 'pm_approval_after',
    ];
    $E['pm_deployments'] = [
        'table' => 'pm_deployments', 'pk' => 'deployment_id', 'label' => 'Deployment', 'plural' => 'Deployments',
        'fields' => [
            F('project_id', 'Project', 'lookup', ['req' => true, 'src' => 'projects']),
            F('version_tag', 'Version Tag', 'text', ['req' => true, 'max' => 50, 'ph' => 'v1.0.0']),
            F('environment', 'Environment', 'select', ['req' => true, 'opts' => ['Staging','Production'], 'def' => 'Staging', 'help' => 'Production needs an approved "Final" client approval and no open Critical bugs.']),
            F('deployment_date', 'Deployment Date & Time', 'datetime', ['req' => true]),
            F('release_notes', 'Release Notes', 'textarea', ['full' => true, 'rows' => 4]),
        ],
        'sections' => [['Deployment', ['project_id','version_tag','environment','deployment_date','release_notes']]],
        'from' => 't_ JOIN pm_projects p ON p.project_id = t.project_id LEFT JOIN users u ON u.id = t.deployed_by',
        'select' => ['p.project_name AS project_name', 'u.name AS deployed_by_name'],
        'list' => [['project_name','Project'],['version_tag','Version'],['environment','Environment','chip'],['deployment_date','Deployed','datetime'],['deployed_by_name','Deployed By'],['release_notes','Notes','trunc']],
        'search' => ['t.version_tag','p.project_name'], 'filters' => ['project_id','environment'], 'order' => 't.deployment_date DESC',
        'before' => 'pm_deploy_before', 'after' => 'pm_deploy_after',
    ];
    $E['pm_maintenance'] = [
        'table' => 'pm_maintenance', 'pk' => 'maintenance_id', 'label' => 'Maintenance Request', 'plural' => 'Maintenance Requests',
        'fields' => [
            F('project_id', 'Project', 'lookup', ['req' => true, 'src' => 'projects']),
            F('request_date', 'Request Date & Time', 'datetime', ['req' => true]),
            F('issue_details', 'Issue Details', 'textarea', ['req' => true, 'full' => true, 'rows' => 4]),
            F('priority', 'Priority', 'select', ['opts' => ['Low','Medium','High'], 'def' => 'Medium']),
            F('assigned_to', 'Assigned To', 'lookup', ['src' => 'employees']),
            F('resolution_status', 'Resolution Status', 'select', ['opts' => ['Logged','In Progress','Closed'], 'def' => 'Logged']),
            F('resolution_notes', 'Resolution Notes', 'textarea', ['full' => true, 'rows' => 3]),
        ],
        'sections' => [['Support Request', ['project_id','request_date','issue_details','priority']], ['Resolution', ['assigned_to','resolution_status','resolution_notes']]],
        'from' => 't_ JOIN pm_projects p ON p.project_id = t.project_id LEFT JOIN employees e ON e.id = t.assigned_to',
        'select' => ['p.project_name AS project_name', "TRIM(CONCAT(COALESCE(e.first_name,''),' ',COALESCE(e.last_name,''))) AS assignee_name"],
        'list' => [['project_name','Project'],['request_date','Requested','datetime'],['issue_details','Issue','trunc'],['priority','Priority','chip'],['assignee_name','Assigned To'],['closed_at','Closed','date'],['resolution_status','Status','chip']],
        'search' => ['t.issue_details','p.project_name'], 'filters' => ['project_id','resolution_status','priority'], 'order' => 't.maintenance_id DESC',
        'before' => 'pm_maint_before',
    ];

    /* =====================  ASSET MANAGEMENT  ===================== */
    $E['am_assets'] = [
        'table' => 'am_assets', 'pk' => 'asset_id', 'label' => 'Asset', 'plural' => 'Company Assets',
        'fields' => [
            F('asset_tag', 'Asset Tag', 'text', ['unique' => true, 'max' => 100, 'ph' => 'Auto-generated if blank']),
            F('asset_type', 'Asset Type', 'select', ['req' => true, 'opts' => ['Laptop','Desktop','Printer','Server','Software'], 'def' => 'Laptop']),
            F('brand_model', 'Brand / Model', 'text', ['req' => true, 'max' => 255]),
            F('serial_number', 'Serial Number', 'text', ['max' => 255]),
            F('purchase_date', 'Purchase Date', 'date'),
            F('purchase_cost', 'Purchase Cost (INR)', 'decimal', ['min' => 0, 'req' => true, 'def' => 0]),
            F('vendor_name', 'Vendor', 'combo', ['src' => 'vendors', 'max' => 255, 'help' => 'Pick a vendor from Accounts or type a name.']),
            F('invoice_number', 'Invoice Number', 'text', ['max' => 100]),
            F('warranty_expiry', 'Warranty Expiry', 'date'),
            F('branch', 'Branch', 'combo', ['src' => 'branches', 'max' => 150]),
            F('location', 'Location / Desk', 'text', ['max' => 150]),
            F('status', 'Status', 'select', ['opts' => ['In Stock','In Use','In Repair','Retired'], 'def' => 'In Stock', 'ro' => true]),
            F('specifications', 'Specifications', 'textarea', ['full' => true, 'rows' => 3]),
            F('dep_method', 'Depreciation Method', 'select', ['virtual' => true, 'opts' => ['None','Straight Line','Declining Balance'], 'def' => 'Straight Line', 'help' => 'Drives the monthly depreciation journal in Accounts.']),
            F('dep_life_months', 'Useful Life (months)', 'number', ['virtual' => true, 'min' => 1, 'def' => 36]),
            F('dep_salvage', 'Salvage Value (INR)', 'decimal', ['virtual' => true, 'min' => 0, 'def' => 0]),
            F('dep_ledger_account_id', 'Fixed-Asset Ledger Account', 'lookup', ['virtual' => true, 'src' => 'chart_accounts', 'help' => 'Optional. Overrides the default account set in Administration > Company Settings.']),
        ],
        'sections' => [
            ['Asset Details', ['asset_tag','asset_type','brand_model','serial_number','specifications']],
            ['Purchase & Warranty', ['purchase_date','purchase_cost','vendor_name','invoice_number','warranty_expiry']],
            ['Location', ['branch','location']],
            ['Finance & Depreciation', ['dep_method','dep_life_months','dep_salvage','dep_ledger_account_id']],
        ],
        'from' => 't_ LEFT JOIN am_asset_depreciation d ON d.asset_id = t.asset_id',
        'select' => [
            'd.current_book_value AS book_value', 'd.accumulated_depreciation AS accumulated_dep', 'd.depreciation_method AS dep_method',
            'd.useful_life_months AS dep_life_months', 'd.salvage_value AS dep_salvage', 'd.ledger_account_id AS dep_ledger_account_id', 'd.last_calculated AS dep_last',
            "(SELECT TRIM(CONCAT(e.first_name,' ',COALESCE(e.last_name,''))) FROM am_asset_allocations a JOIN employees e ON e.id = a.employee_id WHERE a.asset_id = t.asset_id AND a.actual_return_date IS NULL ORDER BY a.allocation_id DESC LIMIT 1) AS assigned_to",
            "IF(t.warranty_expiry IS NOT NULL AND t.warranty_expiry < CURDATE(), 1, 0) AS warranty_expired",
        ],
        'list' => [['asset_tag','Tag'],['asset_type','Type'],['brand_model','Brand / Model'],['serial_number','Serial'],['purchase_date','Purchased','date'],['purchase_cost','Cost','money'],['book_value','Book Value','money'],['assigned_to','Assigned To'],['warranty_expiry','Warranty','date'],['status','Status','chip']],
        'search' => ['t.asset_tag','t.brand_model','t.serial_number','t.vendor_name'], 'filters' => ['asset_type','status'], 'order' => 't.asset_id DESC',
        'before' => 'am_asset_before', 'after' => 'am_asset_after', 'beforeDelete' => 'am_asset_before_delete',
    ];
    $E['am_software_licenses'] = [
        'table' => 'am_software_licenses', 'pk' => 'license_id', 'label' => 'Software License', 'plural' => 'Software Licenses',
        'fields' => [
            F('software_name', 'Software Name', 'text', ['req' => true, 'max' => 255]),
            F('license_type', 'License Type', 'select', ['opts' => ['Perpetual','Subscription','Volume','Open Source'], 'def' => 'Subscription']),
            F('asset_id', 'Linked Software Asset', 'lookup', ['src' => 'assets', 'srcFilter' => ['asset_type' => 'Software'], 'help' => 'Leave empty to create the software asset automatically.']),
            F('license_key', 'License Key', 'text', ['max' => 500, 'full' => true]),
            F('seats_total', 'Total Seats', 'number', ['req' => true, 'min' => 1, 'def' => 1]),
            F('seats_available', 'Seats Available', 'number', ['min' => 0, 'help' => 'Defaults to total seats. Allocations reduce this automatically.']),
            F('expiry_date', 'Expiry / Renewal Date', 'date'),
            F('renewal_cost', 'Renewal / Purchase Cost (INR)', 'decimal', ['min' => 0]),
        ],
        'sections' => [['License', ['software_name','license_type','asset_id','license_key']], ['Seats & Renewal', ['seats_total','seats_available','expiry_date','renewal_cost']]],
        'from' => 't_ JOIN am_assets a ON a.asset_id = t.asset_id',
        'select' => ['a.asset_tag AS asset_tag', 'DATEDIFF(t.expiry_date, CURDATE()) AS days_left'],
        'list' => [['software_name','Software'],['asset_tag','Asset Tag'],['license_type','Type'],['license_key','Key','masked'],['seats_total','Seats','num'],['seats_available','Free','num'],['expiry_date','Expiry','date'],['days_left','Expires In','days'],['renewal_cost','Cost','money']],
        'search' => ['t.software_name','a.asset_tag'], 'filters' => ['license_type'], 'order' => 't.license_id DESC',
        'before' => 'am_license_before', 'after' => 'am_license_after',
    ];
    $E['am_asset_allocations'] = [
        'table' => 'am_asset_allocations', 'pk' => 'allocation_id', 'label' => 'Allocation', 'plural' => 'Asset Allocations',
        'fields' => [
            F('asset_id', 'Asset', 'lookup', ['req' => true, 'src' => 'assets', 'avail' => true, 'help' => 'Only assets that are In Stock (or software with free seats) can be allocated.']),
            F('employee_id', 'Employee', 'lookup', ['src' => 'employees']),
            F('department_id', 'Department', 'lookup', ['src' => 'departments']),
            F('allocated_date', 'Allocated Date', 'date', ['req' => true]),
            F('return_due_date', 'Return Due Date', 'date', ['help' => 'Leave empty for permanent issue.']),
            F('condition_on_issue', 'Condition on Issue', 'text', ['max' => 150, 'def' => 'Good']),
            F('actual_return_date', 'Actual Return Date', 'date', ['ro' => true]),
            F('allocation_status', 'Status', 'select', ['opts' => ['Active','Returned','Overdue'], 'def' => 'Active', 'ro' => true]),
            F('remarks', 'Remarks', 'textarea', ['full' => true, 'rows' => 3]),
        ],
        'sections' => [['Allocation', ['asset_id','employee_id','department_id','allocated_date','return_due_date']], ['Condition & Notes', ['condition_on_issue','remarks']]],
        'from' => 't_ JOIN am_assets a ON a.asset_id = t.asset_id LEFT JOIN employees e ON e.id = t.employee_id LEFT JOIN departments dp ON dp.id = t.department_id',
        'select' => ['a.asset_tag AS asset_tag', 'a.brand_model AS brand_model', 'a.asset_type AS asset_type', "TRIM(CONCAT(COALESCE(e.first_name,''),' ',COALESCE(e.last_name,''))) AS employee_name", ((function_exists('scDeptName') ? scDeptName('dp') : 'dp.department_name') . ' AS department_name')],
        'list' => [['asset_tag','Tag'],['brand_model','Asset'],['employee_name','Employee'],['department_name','Department'],['allocated_date','Allocated','date'],['return_due_date','Due Back','date'],['actual_return_date','Returned','date'],['allocation_status','Status','chip']],
        'search' => ['a.asset_tag','a.brand_model','e.first_name','e.last_name'], 'filters' => ['allocation_status','employee_id'], 'order' => 't.allocation_id DESC',
        'before' => 'am_alloc_before', 'after' => 'am_alloc_after', 'beforeDelete' => 'am_alloc_before_delete', 'prepareList' => 'am_alloc_sync_overdue',
    ];
    $E['am_maintenance_logs'] = [
        'table' => 'am_maintenance_logs', 'pk' => 'maintenance_id', 'label' => 'Maintenance Log', 'plural' => 'Asset Maintenance',
        'fields' => [
            F('asset_id', 'Asset', 'lookup', ['req' => true, 'src' => 'assets', 'notRetired' => true]),
            F('maintenance_type', 'Type', 'select', ['opts' => ['Routine','Break/Fix','Upgrade'], 'def' => 'Routine']),
            F('service_date', 'Service Date', 'date', ['req' => true]),
            F('issue_description', 'Issue / Work Description', 'textarea', ['full' => true, 'rows' => 3]),
            F('vendor_name', 'Vendor / Service Provider', 'combo', ['src' => 'vendors', 'max' => 255]),
            F('repair_cost', 'Repair Cost (INR)', 'decimal', ['min' => 0, 'def' => 0, 'help' => 'Posted to the IT maintenance expense account when the job is Completed.']),
            F('next_service_date', 'Next Service Due', 'date'),
            F('status', 'Status', 'select', ['opts' => ['Scheduled','In Progress','Completed'], 'def' => 'Scheduled']),
        ],
        'sections' => [['Maintenance', ['asset_id','maintenance_type','service_date','status','issue_description']], ['Vendor & Cost', ['vendor_name','repair_cost','next_service_date']]],
        'from' => 't_ JOIN am_assets a ON a.asset_id = t.asset_id',
        'select' => ['a.asset_tag AS asset_tag', 'a.brand_model AS brand_model'],
        'list' => [['asset_tag','Tag'],['brand_model','Asset'],['maintenance_type','Type'],['service_date','Service Date','date'],['issue_description','Work','trunc'],['vendor_name','Vendor'],['repair_cost','Cost','money'],['next_service_date','Next Due','date'],['status','Status','chip']],
        'search' => ['a.asset_tag','a.brand_model','t.issue_description','t.vendor_name'], 'filters' => ['status','maintenance_type','asset_id'], 'order' => 't.maintenance_id DESC',
        'before' => 'am_maint_before', 'after' => 'am_maint_after',
    ];
    $E['am_asset_history'] = [
        'table' => 'am_asset_history', 'pk' => 'history_id', 'label' => 'History Entry', 'plural' => 'Asset History', 'readOnly' => true,
        'fields' => [
            F('asset_id', 'Asset', 'lookup', ['src' => 'assets']),
            F('action_type', 'Action', 'select', ['opts' => ['Purchased','Assigned','Returned','Repaired','Retired','Maintenance','Updated','Depreciated']]),
        ],
        'sections' => [],
        'from' => 't_ JOIN am_assets a ON a.asset_id = t.asset_id LEFT JOIN users u ON u.id = t.performed_by',
        'select' => ['a.asset_tag AS asset_tag', 'a.brand_model AS brand_model', 'a.asset_type AS asset_type', 'u.name AS performed_by_name'],
        'list' => [['action_date','Date','datetime'],['asset_tag','Tag'],['brand_model','Asset'],['action_type','Action','chip'],['performed_by_name','By'],['remarks','Remarks','trunc']],
        'search' => ['a.asset_tag','a.brand_model','t.remarks'], 'filters' => ['asset_id','action_type'], 'order' => 't.history_id DESC',
    ];

    /* =====================  DOCUMENT MANAGEMENT  ===================== */
    $E['dms_documents'] = [
        'table' => 'dms_documents', 'pk' => 'doc_id', 'label' => 'Document', 'plural' => 'Documents',
        'fields' => [
            F('title', 'Document Title', 'text', ['req' => true, 'max' => 255, 'full' => true]),
            F('category', 'Category', 'select', ['req' => true, 'opts' => ['Contract','NDA','Agreement','Proposal','Company','Employee','Client'], 'def' => 'Contract']),
            F('status', 'Status', 'select', ['opts' => ['Draft','Pending Review','Active','Archived'], 'def' => 'Draft']),
            F('owner_id', 'Document Owner', 'lookup', ['src' => 'employees']),
            F('client_id', 'Client', 'lookup', ['src' => 'customers', 'showIf' => ['field' => 'category', 'in' => ['Contract','NDA','Agreement','Proposal','Client']]]),
            F('employee_id', 'Employee', 'lookup', ['src' => 'employees', 'showIf' => ['field' => 'category', 'in' => ['Employee']]]),
            F('effective_date', 'Effective Date', 'date'),
            F('expiry_date', 'Expiry / Renewal Date', 'date', ['help' => 'Renewal alerts are raised for expiring contracts and NDAs.']),
            F('renewal_alert_days', 'Alert Before Expiry (days)', 'number', ['min' => 0, 'def' => 30]),
            F('description', 'Description', 'textarea', ['full' => true, 'rows' => 3]),
            F('file', 'Upload File (creates version v1.0)', 'file', ['virtual' => true, 'ext' => ERP_DOC_EXT, 'sub' => 'documents', 'full' => true]),
            F('change_log', 'Version Note', 'text', ['virtual' => true, 'full' => true, 'max' => 255, 'ph' => 'e.g. Initial draft']),
        ],
        'sections' => [
            ['Document', ['title','category','status','owner_id','client_id','employee_id']],
            ['Validity', ['effective_date','expiry_date','renewal_alert_days','description']],
            ['File', ['file','change_log']],
        ],
        'from' => 't_ LEFT JOIN dms_document_versions v ON v.version_id = t.current_version_id LEFT JOIN employees o ON o.id = t.owner_id LEFT JOIN customers c ON c.id = t.client_id LEFT JOIN employees em ON em.id = t.employee_id',
        'select' => [
            'v.version_number AS version', 'v.file_name AS file_name', 'v.file_size AS file_size',
            "TRIM(CONCAT(COALESCE(o.first_name,''),' ',COALESCE(o.last_name,''))) AS owner_name",
            'c.customer_name AS client_name', "TRIM(CONCAT(COALESCE(em.first_name,''),' ',COALESCE(em.last_name,''))) AS employee_name",
            'DATEDIFF(t.expiry_date, CURDATE()) AS days_left',
            '(SELECT COUNT(*) FROM dms_document_versions x WHERE x.doc_id = t.doc_id) AS version_count',
            '(SELECT COUNT(*) FROM dms_document_signatures s WHERE s.doc_id = t.doc_id) AS signature_count',
        ],
        'list' => [['title','Title'],['category','Category'],['owner_name','Owner'],['party','Client / Employee'],['version','Version'],['expiry_date','Expiry','date'],['days_left','Expires In','days'],['signature_count','Signed','num'],['updated_at','Updated','date'],['status','Status','chip']],
        'search' => ['t.title','t.description','c.customer_name','v.file_name'], 'filters' => ['status','category'], 'order' => 't.doc_id DESC',
        'handlers' => ['list' => 'dms_list', 'get' => 'dms_get', 'save' => 'dms_save', 'delete' => 'dms_delete'],
    ];
    $E['dms_audit_logs'] = [
        'table' => 'dms_audit_logs', 'pk' => 'log_id', 'label' => 'Audit Entry', 'plural' => 'Document Audit Trail', 'readOnly' => true,
        'fields' => [F('action', 'Action', 'select', ['opts' => ['Created','Viewed','Downloaded','Updated','Deleted','Version Added','Signed','Permission Changed','Restored']])],
        'sections' => [],
        'list' => [['timestamp','When','datetime'],['doc_title','Document'],['action','Action','chip'],['user_name','User'],['details','Details','trunc'],['ip_address','IP']],
        'search' => ['t.doc_title','t.user_name','t.details'], 'filters' => ['action','doc_id'], 'order' => 't.log_id DESC',
        'handlers' => ['list' => 'dms_audit_list'],
    ];

    /* =====================  ADMINISTRATION  ===================== */
    $E['adm_audit_logs'] = [
        'table' => 'adm_audit_logs', 'pk' => 'log_id', 'label' => 'Audit Log', 'plural' => 'Audit Logs', 'readOnly' => true,
        'fields' => [
            F('outcome', 'Outcome', 'select', ['opts' => ['Success','Failed']]),
            F('request_method', 'Method', 'select', ['opts' => ['POST','PUT','DELETE','PATCH']]),
            F('table_affected', 'Module / Table', 'text'),
        ],
        'sections' => [],
        'list' => [['created_at','When','datetime'],['user_name','User'],['action_performed','Action','trunc'],['table_affected','Module / Table'],['request_method','Method'],['ip_address','IP'],['outcome','Outcome','chip']],
        'search' => ['t.user_name','t.action_performed','t.table_affected','t.ip_address'], 'filters' => ['outcome','request_method','table_affected'], 'order' => 't.log_id DESC',
        'dateField' => 't.created_at', 'adminOnly' => true,
        'handlers' => ['list' => 'adm_audit_list'],
    ];
    $E['adm_security_rules'] = [
        'table' => 'adm_security_rules', 'pk' => 'rule_id', 'label' => 'Security Rule', 'plural' => 'Security Rules',
        'fields' => [
            F('rule_type', 'Rule Type', 'select', ['req' => true, 'opts' => ['IP_Whitelist','IP_Blacklist'], 'def' => 'IP_Blacklist', 'help' => 'Whitelist: ONLY these addresses may use the application. Blacklist: these addresses are blocked.']),
            F('rule_value', 'IP Address / Range', 'text', ['req' => true, 'max' => 255, 'ph' => '203.0.113.7  or  203.0.113.0/24  or  203.0.113.*']),
            F('description', 'Description', 'text', ['max' => 255, 'full' => true]),
            F('is_active', 'Active', 'bool', ['def' => 1]),
        ],
        'sections' => [['IP Access Rule', ['rule_type','rule_value','description','is_active']]],
        'where' => "t.rule_type IN ('IP_Whitelist','IP_Blacklist')",
        'list' => [['rule_type','Type','chip'],['rule_value','IP / Range'],['description','Description'],['is_active','Active','bool'],['created_at','Added','date']],
        'search' => ['t.rule_value','t.description'], 'filters' => ['rule_type'], 'order' => 't.rule_id DESC',
        'before' => 'adm_rule_before', 'beforeDelete' => 'adm_rule_before_delete', 'adminOnly' => true,
    ];

    // Normalise: expand "t_" placeholder in from, default from
    foreach ($E as $key => &$e) {
        if (empty($e['from'])) $e['from'] = $e['table'] . ' t';
        else $e['from'] = str_replace('t_ ', $e['table'] . ' t ', $e['from']);
        $e['key'] = $key;
    }
    unset($e);
    return $E;
}

/** Everything the browser needs - hooks, SQL and secrets are stripped. */
function erp_meta(): array {
    $out = ['entities' => [], 'lookups' => []];
    foreach (erp_entities() as $k => $e) {
        $out['entities'][$k] = [
            'key' => $k, 'label' => $e['label'], 'plural' => $e['plural'], 'pk' => $e['pk'],
            'fields' => $e['fields'], 'sections' => $e['sections'], 'list' => $e['list'],
            'filters' => $e['filters'] ?? [], 'readOnly' => !empty($e['readOnly']),
            'download' => $e['download'] ?? null, 'channel' => $e['channel'] ?? null,
            'dateField' => !empty($e['dateField']),
        ];
    }
    foreach (erp_lookups() as $k => $l) $out['lookups'][$k] = ['labelAsValue' => !empty($l['labelAsValue'])];
    return $out;
}
