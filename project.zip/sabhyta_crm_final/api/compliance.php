<?php
/**
 * Compliance Records API
 * Handles GST, TDS, PF, ESIC, Professional Tax, ROC, Licenses, ISO Documents, Reminders
 */
header('Content-Type: application/json');
require_once 'db.php';
require_once 'session_guard.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$type = $_GET['type'] ?? '';

try {
    // GST Records
    if ($type === 'gst') {
        handleGSTRequests($method, $action);
    }
    // TDS Records
    elseif ($type === 'tds') {
        handleTDSRequests($method, $action);
    }
    // PF Records
    elseif ($type === 'pf') {
        handlePFRequests($method, $action);
    }
    // ESIC Records
    elseif ($type === 'esic') {
        handleESICRequests($method, $action);
    }
    // Professional Tax
    elseif ($type === 'prof_tax') {
        handleProfessionalTaxRequests($method, $action);
    }
    // ROC Filings
    elseif ($type === 'roc') {
        handleROCRequests($method, $action);
    }
    // Licenses
    elseif ($type === 'license') {
        handleLicenseRequests($method, $action);
    }
    // ISO Documents
    elseif ($type === 'iso') {
        handleISORequests($method, $action);
    }
    // Reminders
    elseif ($type === 'reminder') {
        handleReminderRequests($method, $action);
    }
    // Compliance Dashboard
    elseif ($type === 'dashboard') {
        handleComplianceDashboard();
    }
    else {
        throw new Exception('Invalid compliance type');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}

function handleGSTRequests($method, $action) {
    $conn = getDBConnection();
    $userId = getUserId();

    if ($method === 'GET' && $action === 'list') {
        $company_id = $_GET['company_id'] ?? null;
        $financial_year = $_GET['financial_year'] ?? null;
        $status = $_GET['status'] ?? null;

        $query = "SELECT * FROM gst_records WHERE 1=1";
        $params = [];

        if ($company_id) {
            $query .= " AND company_id = ?";
            $params[] = $company_id;
        }
        if ($financial_year) {
            $query .= " AND financial_year = ?";
            $params[] = $financial_year;
        }
        if ($status) {
            $query .= " AND filing_status = ?";
            $params[] = $status;
        }

        $stmt = $conn->prepare($query);
        if ($params) $stmt->bind_param(str_repeat('s', count($params)), ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        $records = $result->fetch_all(MYSQLI_ASSOC);

        echo json_encode(['success' => true, 'data' => $records]);
    } elseif ($method === 'POST' && $action === 'create') {
        $data = json_decode(file_get_contents('php://input'), true);
        $data['created_by'] = $userId;
        $data['owner_id'] = $userId;

        $columns = implode(',', array_keys($data));
        $placeholders = implode(',', array_fill(0, count($data), '?'));
        $query = "INSERT INTO gst_records ($columns) VALUES ($placeholders)";

        $stmt = $conn->prepare($query);
        $types = str_repeat('s', count($data));
        $stmt->bind_param($types, ...array_values($data));
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'id' => $conn->insert_id]);
        } else {
            throw new Exception('Failed to create GST record');
        }
    } elseif ($method === 'POST' && $action === 'update') {
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $_GET['id'] ?? null;
        $data['updated_by'] = $userId;

        $updates = [];
        foreach ($data as $key => $value) {
            $updates[] = "$key = ?";
        }

        $query = "UPDATE gst_records SET " . implode(', ', $updates) . " WHERE id = ?";
        $values = array_values($data);
        $values[] = $id;

        $stmt = $conn->prepare($query);
        $types = str_repeat('s', count($values));
        $stmt->bind_param($types, ...$values);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'GST record updated']);
        } else {
            throw new Exception('Failed to update GST record');
        }
    } elseif ($method === 'GET' && $action === 'detail') {
        $id = $_GET['id'] ?? null;
        $stmt = $conn->prepare("SELECT * FROM gst_records WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();
        echo json_encode(['success' => true, 'data' => $result->fetch_assoc()]);
    }
}

function handleTDSRequests($method, $action) {
    $conn = getDBConnection();
    $userId = getUserId();

    if ($method === 'GET' && $action === 'list') {
        $company_id = $_GET['company_id'] ?? null;
        $stmt = $conn->prepare("SELECT * FROM tds_records WHERE company_id = ? ORDER BY created_date DESC");
        $stmt->bind_param('i', $company_id);
        $stmt->execute();
        $result = $stmt->get_result();
        echo json_encode(['success' => true, 'data' => $result->fetch_all(MYSQLI_ASSOC)]);
    } elseif ($method === 'POST' && $action === 'create') {
        $data = json_decode(file_get_contents('php://input'), true);
        $data['created_by'] = $userId;
        $data['owner_id'] = $userId;

        $columns = implode(',', array_keys($data));
        $placeholders = implode(',', array_fill(0, count($data), '?'));
        $query = "INSERT INTO tds_records ($columns) VALUES ($placeholders)";

        $stmt = $conn->prepare($query);
        $types = str_repeat('s', count($data));
        $stmt->bind_param($types, ...array_values($data));
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'id' => $conn->insert_id]);
        } else {
            throw new Exception('Failed to create TDS record');
        }
    }
}

function handlePFRequests($method, $action) {
    $conn = getDBConnection();
    $userId = getUserId();

    if ($method === 'GET' && $action === 'list') {
        $company_id = $_GET['company_id'] ?? null;
        $wage_month = $_GET['wage_month'] ?? null;
        
        $query = "SELECT * FROM pf_records WHERE company_id = ?";
        $params = [$company_id];

        if ($wage_month) {
            $query .= " AND wage_month = ?";
            $params[] = $wage_month;
        }

        $stmt = $conn->prepare($query);
        $types = 'i' . (count($params) > 1 ? 's' : '');
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        echo json_encode(['success' => true, 'data' => $result->fetch_all(MYSQLI_ASSOC)]);
    } elseif ($method === 'POST' && $action === 'create') {
        $data = json_decode(file_get_contents('php://input'), true);
        $data['created_by'] = $userId;

        $columns = implode(',', array_keys($data));
        $placeholders = implode(',', array_fill(0, count($data), '?'));
        $query = "INSERT INTO pf_records ($columns) VALUES ($placeholders)";

        $stmt = $conn->prepare($query);
        $types = str_repeat('s', count($data));
        $stmt->bind_param($types, ...array_values($data));
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'id' => $conn->insert_id]);
        } else {
            throw new Exception('Failed to create PF record');
        }
    }
}

function handleESICRequests($method, $action) {
    $conn = getDBConnection();
    $userId = getUserId();

    if ($method === 'GET' && $action === 'list') {
        $company_id = $_GET['company_id'] ?? null;
        $stmt = $conn->prepare("SELECT * FROM esic_records WHERE company_id = ? ORDER BY wage_period DESC");
        $stmt->bind_param('i', $company_id);
        $stmt->execute();
        $result = $stmt->get_result();
        echo json_encode(['success' => true, 'data' => $result->fetch_all(MYSQLI_ASSOC)]);
    } elseif ($method === 'POST' && $action === 'create') {
        $data = json_decode(file_get_contents('php://input'), true);
        $data['created_by'] = $userId;

        $columns = implode(',', array_keys($data));
        $placeholders = implode(',', array_fill(0, count($data), '?'));
        $query = "INSERT INTO esic_records ($columns) VALUES ($placeholders)";

        $stmt = $conn->prepare($query);
        $types = str_repeat('s', count($data));
        $stmt->bind_param($types, ...array_values($data));
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'id' => $conn->insert_id]);
        } else {
            throw new Exception('Failed to create ESIC record');
        }
    }
}

function handleProfessionalTaxRequests($method, $action) {
    $conn = getDBConnection();
    $userId = getUserId();

    if ($method === 'GET' && $action === 'list') {
        $company_id = $_GET['company_id'] ?? null;
        $deduction_month = $_GET['deduction_month'] ?? null;

        $query = "SELECT * FROM prof_tax_records WHERE company_id = ?";
        $params = [$company_id];

        if ($deduction_month) {
            $query .= " AND deduction_month = ?";
            $params[] = $deduction_month;
        }

        $stmt = $conn->prepare($query);
        $types = 'i' . (count($params) > 1 ? 's' : '');
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        echo json_encode(['success' => true, 'data' => $result->fetch_all(MYSQLI_ASSOC)]);
    } elseif ($method === 'POST' && $action === 'create') {
        $data = json_decode(file_get_contents('php://input'), true);
        $data['created_by'] = $userId;

        $columns = implode(',', array_keys($data));
        $placeholders = implode(',', array_fill(0, count($data), '?'));
        $query = "INSERT INTO prof_tax_records ($columns) VALUES ($placeholders)";

        $stmt = $conn->prepare($query);
        $types = str_repeat('s', count($data));
        $stmt->bind_param($types, ...array_values($data));
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'id' => $conn->insert_id]);
        } else {
            throw new Exception('Failed to create Professional Tax record');
        }
    }
}

function handleROCRequests($method, $action) {
    $conn = getDBConnection();
    $userId = getUserId();

    if ($method === 'GET' && $action === 'list') {
        $company_id = $_GET['company_id'] ?? null;
        $stmt = $conn->prepare("SELECT * FROM roc_filings WHERE company_id = ? ORDER BY due_date ASC");
        $stmt->bind_param('i', $company_id);
        $stmt->execute();
        $result = $stmt->get_result();
        echo json_encode(['success' => true, 'data' => $result->fetch_all(MYSQLI_ASSOC)]);
    } elseif ($method === 'POST' && $action === 'create') {
        $data = json_decode(file_get_contents('php://input'), true);
        $data['created_by'] = $userId;

        $columns = implode(',', array_keys($data));
        $placeholders = implode(',', array_fill(0, count($data), '?'));
        $query = "INSERT INTO roc_filings ($columns) VALUES ($placeholders)";

        $stmt = $conn->prepare($query);
        $types = str_repeat('s', count($data));
        $stmt->bind_param($types, ...array_values($data));
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'id' => $conn->insert_id]);
        } else {
            throw new Exception('Failed to create ROC filing');
        }
    }
}

function handleLicenseRequests($method, $action) {
    $conn = getDBConnection();
    $userId = getUserId();

    if ($method === 'GET' && $action === 'list') {
        $company_id = $_GET['company_id'] ?? null;
        $status = $_GET['status'] ?? null;

        $query = "SELECT * FROM company_licenses WHERE company_id = ?";
        $params = [$company_id];

        if ($status) {
            $query .= " AND status = ?";
            $params[] = $status;
        }

        $stmt = $conn->prepare($query);
        $types = 'i' . (count($params) > 1 ? 's' : '');
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        echo json_encode(['success' => true, 'data' => $result->fetch_all(MYSQLI_ASSOC)]);
    } elseif ($method === 'POST' && $action === 'create') {
        $data = json_decode(file_get_contents('php://input'), true);
        $data['created_by'] = $userId;

        $columns = implode(',', array_keys($data));
        $placeholders = implode(',', array_fill(0, count($data), '?'));
        $query = "INSERT INTO company_licenses ($columns) VALUES ($placeholders)";

        $stmt = $conn->prepare($query);
        $types = str_repeat('s', count($data));
        $stmt->bind_param($types, ...array_values($data));
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'id' => $conn->insert_id]);
        } else {
            throw new Exception('Failed to create license record');
        }
    }
}

function handleISORequests($method, $action) {
    $conn = getDBConnection();
    $userId = getUserId();

    if ($method === 'GET' && $action === 'list') {
        $company_id = $_GET['company_id'] ?? null;
        $stmt = $conn->prepare("SELECT * FROM iso_documents WHERE company_id = ? ORDER BY created_date DESC");
        $stmt->bind_param('i', $company_id);
        $stmt->execute();
        $result = $stmt->get_result();
        echo json_encode(['success' => true, 'data' => $result->fetch_all(MYSQLI_ASSOC)]);
    } elseif ($method === 'POST' && $action === 'create') {
        $data = json_decode(file_get_contents('php://input'), true);
        $data['created_by'] = $userId;

        $columns = implode(',', array_keys($data));
        $placeholders = implode(',', array_fill(0, count($data), '?'));
        $query = "INSERT INTO iso_documents ($columns) VALUES ($placeholders)";

        $stmt = $conn->prepare($query);
        $types = str_repeat('s', count($data));
        $stmt->bind_param($types, ...array_values($data));
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'id' => $conn->insert_id]);
        } else {
            throw new Exception('Failed to create ISO document');
        }
    }
}

function handleReminderRequests($method, $action) {
    $conn = getDBConnection();
    $userId = getUserId();

    if ($method === 'GET' && $action === 'list') {
        $company_id = $_GET['company_id'] ?? null;
        $status = $_GET['status'] ?? 'pending';

        $stmt = $conn->prepare("SELECT * FROM compliance_reminders WHERE company_id = ? AND delivery_status = ? ORDER BY due_date ASC");
        $stmt->bind_param('is', $company_id, $status);
        $stmt->execute();
        $result = $stmt->get_result();
        echo json_encode(['success' => true, 'data' => $result->fetch_all(MYSQLI_ASSOC)]);
    } elseif ($method === 'POST' && $action === 'acknowledge') {
        $id = $_GET['id'] ?? null;
        $stmt = $conn->prepare("UPDATE compliance_reminders SET delivery_status = 'acknowledged', acknowledgement_date = NOW() WHERE id = ?");
        $stmt->bind_param('i', $id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Reminder acknowledged']);
        } else {
            throw new Exception('Failed to acknowledge reminder');
        }
    }
}

function handleComplianceDashboard() {
    $conn = getDBConnection();
    $company_id = $_GET['company_id'] ?? null;

    // Get overview statistics
    $overdue = $conn->query("SELECT COUNT(*) as count FROM gst_records WHERE company_id = $company_id AND filing_status = 'pending' AND DATE(created_date) < DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetch_assoc();
    $pending = $conn->query("SELECT COUNT(*) as count FROM gst_records WHERE company_id = $company_id AND filing_status = 'pending'")->fetch_assoc();
    $upcomingReminders = $conn->query("SELECT COUNT(*) as count FROM compliance_reminders WHERE company_id = $company_id AND delivery_status = 'pending' AND due_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)")->fetch_assoc();

    echo json_encode([
        'success' => true,
        'statistics' => [
            'overdue_obligations' => $overdue['count'] ?? 0,
            'pending_obligations' => $pending['count'] ?? 0,
            'upcoming_reminders_7days' => $upcomingReminders['count'] ?? 0,
        ]
    ]);
}

function getUserId() {
    return $_SESSION['user_id'] ?? 0;
}
?>
