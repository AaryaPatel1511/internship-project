<?php
/**
 * QUOTATION TO SALES ORDER AUTO-POPULATION
 * Automatically populates all quotation details into sales order
 * when user selects "Use for Orders"
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/session_guard.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? 'get';
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($action) {
        case 'get':
            // Get quotation details for auto-population
            getQuotationDetails();
            break;

        case 'auto_populate':
            // Get fully populated sales order data from quotation
            autoPopulateSalesOrder();
            break;

        case 'convert_and_create':
            // Convert quotation to sales order
            convertQuotationToOrder();
            break;

        default:
            http_response_code(400);
            echo json_encode(['error' => 'Invalid action']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

// ===== FUNCTION IMPLEMENTATIONS =====

function getQuotationDetails() {
    global $pdo;
    
    $quotationNumber = $_GET['quotation_number'] ?? null;
    
    if (!$quotationNumber) {
        throw new Exception('Quotation number required');
    }

    $stmt = $pdo->prepare("
        SELECT * FROM generic_records 
        WHERE module_key = 'crm__create-quote' AND title = ?
    ");
    
    $stmt->execute([$quotationNumber]);
    $quotation = $stmt->fetch();

    if (!$quotation) {
        throw new Exception('Quotation not found');
    }

    $extraData = $quotation['extra_data'] ? json_decode($quotation['extra_data'], true) : [];

    echo json_encode([
        'status' => 'success',
        'quotation' => [
            'id' => $quotation['id'],
            'quotation_number' => $quotation['title'],
            'party_name' => $quotation['party_name'],
            'assigned_to' => $quotation['assigned_to'],
            'amount' => $quotation['amount'],
            'extra_data' => $extraData
        ]
    ]);
}

function autoPopulateSalesOrder() {
    global $pdo;
    
    $data = json_decode(file_get_contents('php://input'), true);
    $quotationNumber = $data['quotation_number'] ?? null;

    if (!$quotationNumber) {
        throw new Exception('Quotation number required');
    }

    // Get quotation
    $stmt = $pdo->prepare("
        SELECT * FROM generic_records 
        WHERE module_key = 'crm__create-quote' AND title = ?
    ");
    
    $stmt->execute([$quotationNumber]);
    $quotation = $stmt->fetch();

    if (!$quotation) {
        throw new Exception('Quotation not found');
    }

    $extraData = $quotation['extra_data'] ? json_decode($quotation['extra_data'], true) : [];

    // Get customer information
    $customer = null;
    $customerId = $extraData['customerId'] ?? null;
    
    if ($customerId) {
        $custStmt = $pdo->prepare("SELECT * FROM customers WHERE id = ?");
        $custStmt->execute([$customerId]);
        $customer = $custStmt->fetch();
    }

    // Get quotation items with products/services
    $items = $extraData['items'] ?? [];

    // Get employee details for sales executive
    $salesExecutive = null;
    if ($quotation['assigned_to']) {
        $empStmt = $pdo->prepare("SELECT * FROM employees WHERE CONCAT(first_name, ' ', last_name) = ? OR email = ? LIMIT 1");
        $empStmt->execute([$quotation['assigned_to'], $quotation['assigned_to']]);
        $salesExecutive = $empStmt->fetch();
    }

    // Prepare auto-populated sales order data
    $populatedData = [
        'customer' => $customer ? [
            'id' => $customer['id'],
            'name' => $customer['customer_name'],
            'code' => $customer['customer_code'],
            'email' => $customer['email'],
            'mobile' => $customer['mobile'],
            'address' => $customer['address_line1'] . (isset($customer['address_line2']) ? ', ' . $customer['address_line2'] : ''),
            'city' => $customer['city'],
            'state' => $customer['state'],
            'gst' => $customer['gst_number'] ?? null
        ] : null,

        'quotation' => [
            'number' => $quotation['title'],
            'date' => $quotation['record_date'],
            'amount' => $quotation['amount'],
            'reference' => $quotationNumber
        ],

        'salesExecutive' => $salesExecutive ? [
            'id' => $salesExecutive['id'],
            'name' => $salesExecutive['first_name'] . ' ' . $salesExecutive['last_name'],
            'email' => $salesExecutive['official_email'] ?? $salesExecutive['personal_email'],
            'mobile' => $salesExecutive['mobile_number']
        ] : null,

        'items' => array_map(function($item) {
            return [
                'productService' => $item['productService'] ?? $item['product'] ?? 'N/A',
                'description' => $item['description'] ?? '',
                'quantity' => $item['quantity'] ?? 0,
                'unit' => $item['unit'] ?? 'Nos',
                'rate' => $item['rate'] ?? 0,
                'discount' => $item['discount'] ?? 0,
                'amount' => $item['amount'] ?? ($item['quantity'] * $item['rate']),
                'tax' => $item['tax'] ?? 0,
                'totalAmount' => $item['totalAmount'] ?? ($item['quantity'] * $item['rate'])
            ];
        }, $items),

        'commercialTerms' => $extraData['commercialTerms'] ?? [
            'paymentTerms' => $extraData['paymentTerms'] ?? 'Net 30 Days',
            'deliveryTerms' => $extraData['deliveryTerms'] ?? 'FOB',
            'warranty' => $extraData['warranty'] ?? '12 Months',
            'notes' => $extraData['notes'] ?? ''
        ],

        'totals' => [
            'subtotal' => $extraData['subtotal'] ?? $quotation['amount'],
            'discount' => $extraData['discount'] ?? 0,
            'tax' => $extraData['tax'] ?? 0,
            'total' => $extraData['total'] ?? $quotation['amount'],
            'currency' => $extraData['currency'] ?? 'INR'
        ]
    ];

    echo json_encode([
        'status' => 'success',
        'populatedData' => $populatedData,
        'message' => 'Quotation data auto-populated successfully'
    ]);
}

function convertQuotationToOrder() {
    global $pdo;
    
    $data = json_decode(file_get_contents('php://input'), true);

    // Validate required fields
    $required = ['quotation_number', 'customer_id', 'sales_order_data'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            throw new Exception("$field is required");
        }
    }

    $quotationNumber = $data['quotation_number'];
    $customerId = $data['customer_id'];
    $orderData = $data['sales_order_data'];

    // Generate sales order number
    $timestamp = date('Ymd');
    $random = rand(1000, 9999);
    $salesOrderNumber = "SO-" . $timestamp . "-" . $random;

    // Get customer details
    $custStmt = $pdo->prepare("SELECT * FROM customers WHERE id = ?");
    $custStmt->execute([$customerId]);
    $customer = $custStmt->fetch();

    if (!$customer) {
        throw new Exception('Customer not found');
    }

    // Prepare order data
    $title = $salesOrderNumber;
    $partyName = $customer['customer_name'];
    $amount = $orderData['totals']['total'] ?? 0;
    $recordDate = date('Y-m-d');

    // Store order data with all details
    $extraData = [
        'quotationReference' => $quotationNumber,
        'customerId' => $customerId,
        'customerDetails' => [
            'name' => $customer['customer_name'],
            'code' => $customer['customer_code'],
            'email' => $customer['email'],
            'mobile' => $customer['mobile'],
            'gst' => $customer['gst_number'] ?? null,
            'address' => $customer['address_line1'],
            'city' => $customer['city'],
            'state' => $customer['state']
        ],
        'items' => $orderData['items'] ?? [],
        'commercialTerms' => $orderData['commercialTerms'] ?? [],
        'totals' => $orderData['totals'] ?? [],
        'orderStatus' => 'Draft',
        'createdFrom' => 'Quotation',
        'conversionDate' => date('Y-m-d H:i:s')
    ];

    // Insert into sales_orders table if it exists, otherwise generic_records
    try {
        $stmt = $pdo->prepare("
            INSERT INTO sales_orders 
            (sales_order_number, order_date, quotation_number, customer_id, contact_person, status)
            VALUES (?, ?, ?, ?, ?, 'Draft')
        ");
        
        $contactPerson = $orderData['contactPerson'] ?? $customer['email'];
        $stmt->execute([$salesOrderNumber, $recordDate, $quotationNumber, $customerId, $contactPerson]);
        $orderId = $pdo->lastInsertId();

    } catch (Exception $e) {
        // Fallback to generic_records if sales_orders table doesn't exist
        $stmt = $pdo->prepare("
            INSERT INTO generic_records 
            (module_key, module_label, title, party_name, amount, record_date, status, extra_data)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            'Sales||Sales Order',
            'Sales Order',
            $salesOrderNumber,
            $partyName,
            $amount,
            $recordDate,
            'Draft',
            json_encode($extraData)
        ]);
        $orderId = $pdo->lastInsertId();
    }

    // Create activity log
    createActivityLog(
        'sales_order_created',
        'Sales Order ' . $salesOrderNumber . ' created from Quotation ' . $quotationNumber,
        $customerId,
        'sales_order',
        $orderId
    );

    echo json_encode([
        'status' => 'success',
        'sales_order_number' => $salesOrderNumber,
        'order_id' => $orderId,
        'customer_id' => $customerId,
        'amount' => $amount,
        'message' => 'Sales Order created successfully from Quotation',
        'next_action' => 'Confirm Order'
    ]);
}

function createActivityLog($action, $description, $partyId, $partyType, $recordId) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO activity_logs (action, description, party_id, party_type, record_id, user_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $userId = $_SESSION['user_id'] ?? 1;
        $stmt->execute([$action, $description, $partyId, $partyType, $recordId, $userId]);
    } catch (Exception $e) {
        // Activity logging table might not exist, continue without logging
    }
}
?>
