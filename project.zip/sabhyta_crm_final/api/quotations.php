<?php
/** Compatibility endpoint for current MySQL-backed quotations. */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/session_guard.php';
require_once __DIR__ . '/db.php';

function quotations_respond(array $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    quotations_respond(['success' => false, 'message' => 'Method not allowed.'], 405);
}

$sql = "SELECT id, title AS quotation_number, party_name AS customer, created_at, status, amount, extra_data
        FROM generic_records WHERE module_key = 'crm__create-quote'";
$params = [];
if (!empty($_GET['id'])) {
    $sql .= ' AND id = ?';
    $params[] = (int)$_GET['id'];
} elseif (!empty($_GET['search'])) {
    $sql .= ' AND title LIKE ?';
    $params[] = '%' . trim((string)$_GET['search']) . '%';
}
$sql .= ' ORDER BY created_at DESC LIMIT ' . (!empty($_GET['id']) ? '1' : (!empty($_GET['search']) ? '20' : '100'));

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $data = array_map(static function (array $row): array {
        $extra = json_decode((string)($row['extra_data'] ?? ''), true);
        if (!is_array($extra)) $extra = [];
        return [
            'id' => (int)$row['id'],
            'quotation_number' => $row['quotation_number'],
            'customer' => $row['customer'],
            'created_at' => $row['created_at'],
            'status' => $row['status'] ?? 'Active',
            'amount' => $row['amount'] ?? 0,
            'items' => $extra['items'] ?? [],
            'quotation_data' => $extra['quotationData'] ?? $extra,
        ];
    }, $stmt->fetchAll());
    quotations_respond(['success' => true, 'data' => !empty($_GET['id']) ? ($data[0] ?? null) : $data]);
} catch (Throwable $e) {
    error_log('SABHYTA CRM quotations API failed: ' . $e->getMessage());
    quotations_respond(['success' => false, 'message' => 'Could not load quotations.'], 500);
}