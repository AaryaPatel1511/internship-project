<?php
/**
 * Lead Source Integration Settings API
 * --------------------------------------------------------
 * GET  /api/lead_settings.php?action=get&source=facebook
 *      -> { webhookUrl, webhookToken, config: {...}, lastTest }
 * POST /api/lead_settings.php   action=save&source=facebook   (JSON body: config object)
 * POST /api/lead_settings.php   action=regenerate_token&source=facebook
 * POST /api/lead_settings.php   action=test&source=facebook
 * --------------------------------------------------------
 * source is one of: website | facebook | google_ads | whatsapp
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_REQUEST['action'] ?? '';
$source = $_REQUEST['source'] ?? '';
$validSources = ['website', 'facebook', 'google_ads', 'whatsapp'];

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

if (!in_array($source, $validSources, true)) {
    respond(["success" => false, "message" => "Unknown source."], 422);
}

function webhookBaseUrl() {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $path = dirname($_SERVER['SCRIPT_NAME']); // .../api
    $root = rtrim(dirname($path), '/');       // project root
    return "$scheme://$host$root/api/lead_webhooks.php";
}

function ensureRow($pdo, $source) {
    $stmt = $pdo->prepare("SELECT * FROM lead_source_settings WHERE source_key = ?");
    $stmt->execute([$source]);
    $row = $stmt->fetch();
    if (!$row) {
        $token = bin2hex(random_bytes(16));
        $pdo->prepare("INSERT INTO lead_source_settings (source_key, webhook_token, config_json) VALUES (?, ?, '{}')")
            ->execute([$source, $token]);
        $stmt->execute([$source]);
        $row = $stmt->fetch();
    }
    return $row;
}

if ($method === 'GET' && $action === 'get') {
    $row = ensureRow($pdo, $source);
    respond(["success" => true, "data" => [
        "webhookUrl"   => webhookBaseUrl() . "?source=$source&token=" . $row['webhook_token'],
        "webhookToken" => $row['webhook_token'],
        "config"       => json_decode($row['config_json'] ?: '{}', true),
        "lastTestAt"   => $row['last_test_at'],
        "lastTestResult" => $row['last_test_result'],
    ]]);
}

if ($method === 'POST' && $action === 'save') {
    ensureRow($pdo, $source);
    $body = json_decode(file_get_contents('php://input'), true) ?? [];
    $pdo->prepare("UPDATE lead_source_settings SET config_json = ? WHERE source_key = ?")
        ->execute([json_encode($body), $source]);
    respond(["success" => true, "message" => "Integration settings saved."]);
}

if ($method === 'POST' && $action === 'regenerate_token') {
    ensureRow($pdo, $source);
    $token = bin2hex(random_bytes(16));
    $pdo->prepare("UPDATE lead_source_settings SET webhook_token = ? WHERE source_key = ?")->execute([$token, $source]);
    respond(["success" => true, "data" => ["webhookUrl" => webhookBaseUrl() . "?source=$source&token=$token", "webhookToken" => $token]]);
}

if ($method === 'POST' && $action === 'test') {
    $row = ensureRow($pdo, $source);
    $config = json_decode($row['config_json'] ?: '{}', true);
    $result = '';
    $ok = false;

    try {
        if ($source === 'facebook') {
            if (empty($config['accessToken'])) throw new Exception('Enter a Page Access Token first.');
            $url = 'https://graph.facebook.com/v19.0/me?access_token=' . urlencode($config['accessToken']);
            $resp = @file_get_contents($url);
            $data = json_decode($resp ?: '', true);
            if (!empty($data['id'])) { $ok = true; $result = 'Connected as Facebook Page: ' . ($data['name'] ?? $data['id']); }
            else { $result = 'Facebook rejected this token: ' . ($data['error']['message'] ?? 'unknown error'); }
        } elseif ($source === 'whatsapp') {
            if (empty($config['accessToken']) || empty($config['phoneNumberId'])) throw new Exception('Enter both the Access Token and Phone Number ID.');
            $url = 'https://graph.facebook.com/v19.0/' . urlencode($config['phoneNumberId']);
            $ctx = stream_context_create(['http' => ['header' => "Authorization: Bearer {$config['accessToken']}\r\n", 'ignore_errors' => true]]);
            $resp = @file_get_contents($url, false, $ctx);
            $data = json_decode($resp ?: '', true);
            if (!empty($data['id'])) { $ok = true; $result = 'Connected to WhatsApp number: ' . ($data['display_phone_number'] ?? $data['id']); }
            else { $result = 'WhatsApp Business API rejected this: ' . ($data['error']['message'] ?? 'unknown error'); }
        } elseif ($source === 'google_ads') {
            // Google Ads requires a full OAuth2 flow (client id/secret + refresh
            // token exchange) which can't be completed from a single server-side
            // call — this just validates that the pieces needed for that flow
            // have been filled in, so the CRM side is confirmed ready.
            if (empty($config['developerToken']) || empty($config['customerId'])) {
                throw new Exception('Enter your Developer Token and Customer ID.');
            }
            $ok = true;
            $result = 'Developer Token and Customer ID look complete. Full OAuth verification happens when Google Ads sends its first lead form webhook.';
        } elseif ($source === 'website') {
            $ok = true;
            $result = 'Website webhook is active and ready to receive leads — no external credentials required.';
        }
    } catch (Exception $e) {
        $result = $e->getMessage();
    }

    $pdo->prepare("UPDATE lead_source_settings SET last_test_at = NOW(), last_test_result = ? WHERE source_key = ?")
        ->execute([$result, $source]);

    respond(["success" => $ok, "message" => $result]);
}

respond(["success" => false, "message" => "Unknown action."], 400);
