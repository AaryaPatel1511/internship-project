<?php
// Compatibility alias — designations via user_masters
$_GET['type'] = 'designations';
require_once __DIR__ . '/user_masters.php';
