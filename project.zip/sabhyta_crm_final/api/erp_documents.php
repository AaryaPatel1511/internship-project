<?php
/**
 * DOCUMENT MANAGEMENT - hooks & actions
 * Upload -> Version control -> Collaboration -> Signature -> Ongoing management
 *
 * Rules
 *  - Files are stored under /storage/documents (not web-served) and only streamed through
 *    this API after a permission check; every view/download is written to the audit trail.
 *  - A file is never overwritten: each upload is a new version (v1.0, v1.1 ... v2.0).
 *  - Access = highest of: Administrator role / document owner / uploader (Admin),
 *    explicit permission rows for the user (employee) or any of the user's roles.
 *    Company documents without explicit rows are viewable by everyone (baseline).
 */

const DMS_RANK = ['View' => 1, 'Comment' => 2, 'Edit' => 3, 'Admin' => 4];

function dms_audit(PDO $pdo, ?int $docId, ?string $title, ?int $versionId, string $action, string $details = ''): void {
    $u = erp_user();
    $pdo->prepare("INSERT INTO dms_audit_logs (doc_id, doc_title, version_id, user_id, user_name, action, details, ip_address) VALUES (?,?,?,?,?,?,?,?)")
        ->execute([$docId, $title, $versionId, $u['id'], $u['name'], $action, $details !== '' ? mb_substr($details, 0, 255) : null, erp_ip()]);
}
function dms_current_role_ids(PDO $pdo): array {
    static $ids = null;
    if ($ids !== null) return $ids;
    $ids = [];
    $emp = erp_current_employee_id($pdo);
    if ($emp) {
        $st = $pdo->prepare("SELECT role_id FROM user_roles WHERE employee_id = ? AND (status IS NULL OR status = 'Active')");
        $st->execute([$emp]);
        $ids = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    }
    return $ids;
}
/** Access rank for the current user on a document row (0 = none). */
function dms_access(PDO $pdo, array $doc): int {
    if (erp_is_admin()) return 4;
    $uid = erp_user()['id']; $emp = erp_current_employee_id($pdo);
    if ($uid && (int)$doc['created_by'] === $uid) return 4;
    if ($emp && (int)$doc['owner_id'] === $emp) return 4;

    $st = $pdo->prepare("SELECT user_id, role_id, access_level FROM dms_document_permissions WHERE doc_id = ?");
    $st->execute([$doc['doc_id']]);
    $rows = $st->fetchAll();
    $best = 0; $roles = dms_current_role_ids($pdo);
    foreach ($rows as $r) {
        if (($r['user_id'] && $emp && (int)$r['user_id'] === $emp) || ($r['role_id'] && in_array((int)$r['role_id'], $roles, true))) {
            $best = max($best, DMS_RANK[$r['access_level']] ?? 0);
        }
    }
    if ($best === 0 && !$rows && $doc['category'] === 'Company') return 1;
    return $best;
}
function dms_doc(PDO $pdo, int $id): array {
    $st = $pdo->prepare("SELECT * FROM dms_documents WHERE doc_id = ?"); $st->execute([$id]);
    $d = $st->fetch();
    if (!$d) erp_fail('Document not found.', 404);
    return $d;
}
function dms_require(PDO $pdo, array $doc, int $rank, string $what): void {
    if (dms_access($pdo, $doc) < $rank) erp_fail("You do not have permission to $what this document.", 403);
}
function dms_next_version(PDO $pdo, int $docId, bool $major): string {
    $st = $pdo->prepare("SELECT version_number FROM dms_document_versions WHERE doc_id = ? ORDER BY version_id DESC LIMIT 1");
    $st->execute([$docId]);
    $cur = $st->fetchColumn();
    if (!$cur || !preg_match('/^v(\d+)\.(\d+)$/', $cur, $m)) return 'v1.0';
    return $major ? 'v' . ((int)$m[1] + 1) . '.0' : 'v' . $m[1] . '.' . ((int)$m[2] + 1);
}
function dms_add_version_row(PDO $pdo, int $docId, array $info, string $note, string $version): int {
    $pdo->prepare("INSERT INTO dms_document_versions (doc_id, version_number, file_name, file_url_path, file_size, file_type, uploaded_by, change_log) VALUES (?,?,?,?,?,?,?,?)")
        ->execute([$docId, $version, $info['name'], $info['path'], $info['size'], $info['ext'], erp_user()['id'], $note !== '' ? $note : null]);
    $vid = (int)$pdo->lastInsertId();
    $pdo->prepare("UPDATE dms_documents SET current_version_id = ? WHERE doc_id = ?")->execute([$vid, $docId]);
    return $vid;
}

/* ---------------------------------------------------------
   LIST (only documents the user may see)
   --------------------------------------------------------- */
function dms_list(PDO $pdo, array $E, array $q): array {
    [$sql, $params] = erp_list_query($pdo, $E, $q, false);
    $st = $pdo->prepare($sql . ' LIMIT 5000'); $st->execute($params);
    $out = [];
    foreach ($st->fetchAll() as $r) {
        $rank = dms_access($pdo, $r);
        if ($rank < 1) continue;
        $r['access'] = $rank;
        $r['party'] = $r['category'] === 'Employee' ? $r['employee_name'] : ($r['client_name'] ?: '');
        $r['alert'] = null;
        if ($r['expiry_date'] && $r['status'] !== 'Archived') {
            $dl = (int)$r['days_left'];
            if ($dl < 0) $r['alert'] = 'Expired';
            elseif ($dl <= (int)$r['renewal_alert_days']) $r['alert'] = 'Renewal due';
        }
        $out[] = $r;
    }
    $total = count($out);
    $per = max(1, min(200, (int)($q['per'] ?? 25))); $page = max(1, (int)($q['page'] ?? 1));
    return [array_slice($out, ($page - 1) * $per, $per), $total];
}
function dms_get(PDO $pdo, array $E, int $id): ?array {
    $row = erp_fetch_row($pdo, $E, $id);
    if (!$row) return null;
    dms_require($pdo, $row, 1, 'open');
    $row['access'] = dms_access($pdo, $row);
    return $row;
}

/* ---------------------------------------------------------
   SAVE (metadata + first file / new version)
   --------------------------------------------------------- */
function dms_save(PDO $pdo, array $E, ?int $id, array $in): array {
    $isNew = !$id;
    $file = erp_save_upload('file', 'documents', ERP_DOC_EXT, 25 * 1048576);
    if ($isNew && !$file) erp_fail('Please choose the file to upload - it becomes version v1.0.');
    $cat = $in['category'] ?? null;
    try {
        if ($id) {
            $doc = dms_doc($pdo, $id);
            dms_require($pdo, $doc, 3, 'edit');
            $cat = $cat ?: $doc['category'];
        }
        if ($cat === 'Client' && empty($in['client_id']) && ($isNew || !$doc['client_id'])) erp_fail('Choose the client this document belongs to.');
        if ($cat === 'Employee' && empty($in['employee_id']) && ($isNew || !$doc['employee_id'])) erp_fail('Choose the employee this document belongs to.');
        $eff = $in['effective_date'] ?? ($doc['effective_date'] ?? null); $exp = array_key_exists('expiry_date', $in) ? $in['expiry_date'] : ($doc['expiry_date'] ?? null);
        if ($eff && $exp && $exp < $eff) erp_fail('Expiry date cannot be before the effective date.');
        if ($isNew && empty($in['owner_id'])) { $e = erp_current_employee_id($pdo); if ($e) $in['owner_id'] = $e; }
        // clear the party that does not apply to the category
        if (in_array($cat, ['Company'], true)) { $in['client_id'] = ''; $in['employee_id'] = ''; }
        elseif ($cat === 'Employee') $in['client_id'] = '';
        elseif (isset($in['category'])) $in['employee_id'] = '';

        $res = erp_save_entity($pdo, $E, $id, $in);
    } catch (Throwable $e) {
        if ($file) erp_delete_file($file['path']);
        throw $e;
    }
    $docId = (int)$res['id'];
    $doc = dms_doc($pdo, $docId);
    $notices = $res['notices'];

    if ($file) {
        $ver = $isNew ? 'v1.0' : dms_next_version($pdo, $docId, false);
        $note = trim((string)($in['change_log'] ?? '')) ?: ($isNew ? 'Initial upload' : 'Updated file');
        $vid = dms_add_version_row($pdo, $docId, $file, $note, $ver);
        dms_audit($pdo, $docId, $doc['title'], $vid, $isNew ? 'Created' : 'Version Added', "$ver - {$file['name']}");
        if (!$isNew) $notices[] = "New file saved as version $ver. Earlier versions are preserved.";
    } else {
        dms_audit($pdo, $docId, $doc['title'], null, $isNew ? 'Created' : 'Updated', $isNew ? 'Document created' : 'Details updated');
    }
    $res['row'] = erp_fetch_row($pdo, $E, $docId);
    $res['notices'] = $notices;
    return $res;
}
function dms_delete(PDO $pdo, array $E, int $id): void {
    $doc = dms_doc($pdo, $id);
    dms_require($pdo, $doc, 4, 'delete');
    $vs = $pdo->prepare("SELECT file_url_path FROM dms_document_versions WHERE doc_id = ?"); $vs->execute([$id]);
    $paths = $vs->fetchAll(PDO::FETCH_COLUMN);
    dms_audit($pdo, $id, $doc['title'], null, 'Deleted', 'Document and ' . count($paths) . ' version(s) deleted');
    $pdo->prepare("UPDATE dms_documents SET current_version_id = NULL WHERE doc_id = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM dms_documents WHERE doc_id = ?")->execute([$id]);
    foreach ($paths as $p) erp_delete_file($p);
}

/* ---------------------------------------------------------
   Audit-trail list (global = admin only, per document = Admin on that doc)
   --------------------------------------------------------- */
function dms_audit_list(PDO $pdo, array $E, array $q): array {
    if (!erp_is_admin()) {
        $docId = (int)($q['f_doc_id'] ?? 0);
        if (!$docId) erp_fail('Only an Administrator can view the global audit trail.', 403);
        dms_require($pdo, dms_doc($pdo, $docId), 4, 'view the audit trail of');
    }
    [$sql, $params, $total] = erp_list_query($pdo, $E, $q, true);
    $st = $pdo->prepare($sql); $st->execute($params);
    return [$st->fetchAll(), $total];
}

/* ---------------------------------------------------------
   DETAIL (versions, permissions, signatures, audit)
   --------------------------------------------------------- */
function act_dms_detail(PDO $pdo): void {
    $id = (int)($_GET['id'] ?? 0);
    $E = erp_entity('dms_documents');
    $doc = erp_fetch_row($pdo, $E, $id);
    if (!$doc) erp_fail('Document not found.', 404);
    $rank = dms_access($pdo, $doc);
    if ($rank < 1) erp_fail('You do not have permission to open this document.', 403);
    dms_audit($pdo, $id, $doc['title'], (int)$doc['current_version_id'], 'Viewed', 'Opened document details');

    $v = $pdo->prepare("SELECT v.*, u.name AS uploaded_by_name FROM dms_document_versions v LEFT JOIN users u ON u.id = v.uploaded_by WHERE v.doc_id = ? ORDER BY v.version_id DESC");
    $v->execute([$id]);
    $versions = $v->fetchAll();
    foreach ($versions as &$x) { unset($x['file_url_path']); $x['is_current'] = (int)$x['version_id'] === (int)$doc['current_version_id']; }
    unset($x);

    $sg = $pdo->prepare("SELECT s.*, v.version_number FROM dms_document_signatures s JOIN dms_document_versions v ON v.version_id = s.version_id WHERE s.doc_id = ? ORDER BY s.signature_id DESC");
    $sg->execute([$id]);
    $sigs = $sg->fetchAll();
    $uid = erp_user()['id'];
    $signed = false;
    foreach ($sigs as $s) if ((int)$s['signer_user_id'] === $uid && (int)$s['version_id'] === (int)$doc['current_version_id']) $signed = true;

    $perms = []; $audit = [];
    if ($rank >= 4) {
        $p = $pdo->prepare("SELECT p.*, TRIM(CONCAT(COALESCE(e.first_name,''),' ',COALESCE(e.last_name,''))) AS employee_name, r.role_name FROM dms_document_permissions p LEFT JOIN employees e ON e.id = p.user_id LEFT JOIN roles r ON r.id = p.role_id WHERE p.doc_id = ? ORDER BY p.permission_id");
        $p->execute([$id]); $perms = $p->fetchAll();
        $a = $pdo->prepare("SELECT * FROM dms_audit_logs WHERE doc_id = ? ORDER BY log_id DESC LIMIT 100");
        $a->execute([$id]); $audit = $a->fetchAll();
    }
    erp_ok(['doc' => $doc, 'access' => $rank, 'versions' => $versions, 'signatures' => $sigs, 'signed_current' => $signed, 'permissions' => $perms, 'audit' => $audit,
            'baseline' => ($doc['category'] === 'Company' && !$perms && $rank < 4)]);
}

/* ---------------------------------------------------------
   DOWNLOAD (permission-checked + audited)
   --------------------------------------------------------- */
function act_dms_download(PDO $pdo): void {
    $id = (int)($_GET['id'] ?? 0);
    $doc = dms_doc($pdo, $id);
    dms_require($pdo, $doc, 1, 'download');
    $vid = (int)($_GET['version_id'] ?? $doc['current_version_id']);
    $st = $pdo->prepare("SELECT * FROM dms_document_versions WHERE version_id = ? AND doc_id = ?"); $st->execute([$vid, $id]);
    $v = $st->fetch();
    if (!$v) erp_fail('That version does not exist.', 404);
    $abs = erp_abs_path($v['file_url_path']);
    if (!$abs) erp_fail('The stored file is missing on the server.', 404);
    $inline = !empty($_GET['inline']);
    dms_audit($pdo, $id, $doc['title'], $vid, $inline ? 'Viewed' : 'Downloaded', $v['version_number'] . ' - ' . $v['file_name']);
    erp_send_file($abs, $v['file_name'], $inline);
}

/* ---------------------------------------------------------
   VERSIONS
   --------------------------------------------------------- */
function act_dms_add_version(PDO $pdo): void {
    $in = erp_input();
    $doc = dms_doc($pdo, (int)($in['doc_id'] ?? 0));
    dms_require($pdo, $doc, 3, 'add a version to');
    $file = erp_save_upload('file', 'documents', ERP_DOC_EXT, 25 * 1048576);
    if (!$file) erp_fail('Choose the new file to upload.');
    $note = trim((string)($in['change_log'] ?? ''));
    if ($note === '') { erp_delete_file($file['path']); erp_fail('Describe what changed - it is kept in the version history.'); }
    $ver = dms_next_version($pdo, (int)$doc['doc_id'], !empty($in['major']));
    $vid = dms_add_version_row($pdo, (int)$doc['doc_id'], $file, $note, $ver);
    dms_audit($pdo, (int)$doc['doc_id'], $doc['title'], $vid, 'Version Added', "$ver - $note");
    $notices = [];
    $hadSig = $pdo->prepare("SELECT COUNT(*) FROM dms_document_signatures WHERE doc_id = ?"); $hadSig->execute([$doc['doc_id']]);
    if ($doc['status'] === 'Active' && (int)$hadSig->fetchColumn() > 0) {
        $pdo->prepare("UPDATE dms_documents SET status = 'Pending Review' WHERE doc_id = ?")->execute([$doc['doc_id']]);
        $notices[] = 'The document was Active and signed. Because the content changed it is back to Pending Review and needs a fresh signature.';
    }
    erp_ok(['version' => $ver], ['message' => "Version $ver saved.", 'notices' => $notices]);
}
function act_dms_restore_version(PDO $pdo): void {
    $in = erp_input();
    $st = $pdo->prepare("SELECT * FROM dms_document_versions WHERE version_id = ?"); $st->execute([(int)($in['version_id'] ?? 0)]);
    $v = $st->fetch();
    if (!$v) erp_fail('Version not found.', 404);
    $doc = dms_doc($pdo, (int)$v['doc_id']);
    dms_require($pdo, $doc, 3, 'restore a version of');
    $src = erp_abs_path($v['file_url_path']);
    if (!$src) erp_fail('The stored file for that version is missing.', 404);
    $ext = strtolower(pathinfo($src, PATHINFO_EXTENSION));
    $dir = erp_storage_dir('documents');
    $stored = bin2hex(random_bytes(12)) . '.' . $ext;
    if (!copy($src, $dir . '/' . $stored)) erp_fail('Could not copy the file.', 500);
    $ver = dms_next_version($pdo, (int)$doc['doc_id'], false);
    $vid = dms_add_version_row($pdo, (int)$doc['doc_id'], ['path' => 'storage/documents/' . $stored, 'name' => $v['file_name'], 'size' => $v['file_size'], 'ext' => $v['file_type']], 'Restored from ' . $v['version_number'], $ver);
    dms_audit($pdo, (int)$doc['doc_id'], $doc['title'], $vid, 'Restored', "{$v['version_number']} restored as $ver");
    erp_ok(['version' => $ver], ['message' => "{$v['version_number']} restored as the new current version $ver."]);
}

/* ---------------------------------------------------------
   PERMISSIONS
   --------------------------------------------------------- */
function act_dms_set_permission(PDO $pdo): void {
    $in = erp_input();
    $doc = dms_doc($pdo, (int)($in['doc_id'] ?? 0));
    dms_require($pdo, $doc, 4, 'manage access to');
    $emp = (int)($in['user_id'] ?? 0) ?: null; $role = (int)($in['role_id'] ?? 0) ?: null;
    $lvl = $in['access_level'] ?? '';
    if (!isset(DMS_RANK[$lvl])) erp_fail('Choose an access level.');
    if (($emp ? 1 : 0) + ($role ? 1 : 0) !== 1) erp_fail('Choose either one employee or one role.');
    if ($emp && !erp_lookup_exists($pdo, 'employees', $emp)) erp_fail('Employee not found.');
    if ($role && !erp_lookup_exists($pdo, 'roles', $role)) erp_fail('Role not found.');
    $ex = $pdo->prepare("SELECT permission_id FROM dms_document_permissions WHERE doc_id = ? AND user_id <=> ? AND role_id <=> ?");
    $ex->execute([$doc['doc_id'], $emp, $role]);
    if ($pid = $ex->fetchColumn()) $pdo->prepare("UPDATE dms_document_permissions SET access_level = ? WHERE permission_id = ?")->execute([$lvl, $pid]);
    else $pdo->prepare("INSERT INTO dms_document_permissions (doc_id, user_id, role_id, access_level) VALUES (?,?,?,?)")->execute([$doc['doc_id'], $emp, $role, $lvl]);
    dms_audit($pdo, (int)$doc['doc_id'], $doc['title'], null, 'Permission Changed', ($emp ? "employee #$emp" : "role #$role") . " -> $lvl");
    erp_ok(null, ['message' => 'Access saved.']);
}
function act_dms_remove_permission(PDO $pdo): void {
    $pid = (int)(erp_input()['permission_id'] ?? 0);
    $st = $pdo->prepare("SELECT * FROM dms_document_permissions WHERE permission_id = ?"); $st->execute([$pid]);
    $p = $st->fetch();
    if (!$p) erp_fail('Permission not found.', 404);
    $doc = dms_doc($pdo, (int)$p['doc_id']);
    dms_require($pdo, $doc, 4, 'manage access to');
    $pdo->prepare("DELETE FROM dms_document_permissions WHERE permission_id = ?")->execute([$pid]);
    dms_audit($pdo, (int)$doc['doc_id'], $doc['title'], null, 'Permission Changed', 'Access removed');
    erp_ok(null, ['message' => 'Access removed.']);
}

/* ---------------------------------------------------------
   SIGNATURE
   --------------------------------------------------------- */
function act_dms_sign(PDO $pdo): void {
    $in = erp_input();
    $doc = dms_doc($pdo, (int)($in['doc_id'] ?? 0));
    dms_require($pdo, $doc, 1, 'sign');
    if (!$doc['current_version_id']) erp_fail('There is no file to sign.');
    if ($doc['status'] === 'Archived') erp_fail('An archived document cannot be signed.');
    if (empty($in['confirm'])) erp_fail('Please confirm that you have read the document and agree to sign it.');
    $u = erp_user();
    $dup = $pdo->prepare("SELECT 1 FROM dms_document_signatures WHERE doc_id = ? AND version_id = ? AND signer_user_id = ?");
    $dup->execute([$doc['doc_id'], $doc['current_version_id'], $u['id']]);
    if ($dup->fetchColumn()) erp_fail('You have already signed this version.');
    $pdo->prepare("INSERT INTO dms_document_signatures (doc_id, version_id, signer_user_id, signer_name, signed_at, ip_address, remarks) VALUES (?,?,?,?,NOW(),?,?)")
        ->execute([$doc['doc_id'], $doc['current_version_id'], $u['id'], $u['name'], erp_ip(), trim((string)($in['remarks'] ?? '')) ?: null]);
    $notices = [];
    if (in_array($doc['status'], ['Draft', 'Pending Review'], true)) {
        $pdo->prepare("UPDATE dms_documents SET status = 'Active' WHERE doc_id = ?")->execute([$doc['doc_id']]);
        $notices[] = 'Signature recorded - the document is now Active.';
    }
    dms_audit($pdo, (int)$doc['doc_id'], $doc['title'], (int)$doc['current_version_id'], 'Signed', 'Signed by ' . $u['name']);
    erp_ok(null, ['message' => 'Document signed.', 'notices' => $notices]);
}

/* ---------------------------------------------------------
   RENEWAL ALERTS
   --------------------------------------------------------- */
function act_dms_alerts(PDO $pdo): void {
    $E = erp_entity('dms_documents');
    [$rows] = dms_list($pdo, $E, ['per' => 200, 'page' => 1]);
    $out = array_values(array_filter($rows, fn($r) => $r['alert'] !== null));
    usort($out, fn($a, $b) => (int)$a['days_left'] <=> (int)$b['days_left']);
    erp_ok(array_map(fn($r) => ['doc_id' => $r['doc_id'], 'title' => $r['title'], 'category' => $r['category'], 'expiry_date' => $r['expiry_date'], 'days_left' => (int)$r['days_left'], 'alert' => $r['alert']], $out));
}
