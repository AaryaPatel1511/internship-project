/**
 * User Management Router
 * Add this code to script.js in the dispatchLeaf function, after routeReportsLeaf check
 */

// In the dispatchLeaf function, add this check:
/*
} else if (typeof routeUserMgmt === 'function' && routeUserMgmt(itemLabel, sectionLabel, backAction, backLabel)) {
    // handled by modules/user_management.js (Users, Roles, Permissions, Departments, Designations)
*/

// Then add this function to script.js (after other route functions):

function routeUserMgmt(itemLabel, sectionLabel, backAction, backLabel) {
    if (sectionLabel !== 'User Management') return false;
    
    switch (itemLabel) {
        case 'Users':
            renderUsersPage();
            break;
        case 'Roles':
            renderRolesPage();
            break;
        case 'Permissions':
            renderRolesPage(); // Permissions are shown in the Roles page
            break;
        case 'Departments':
            renderDepartmentsPage();
            break;
        case 'Designations':
            renderDepartmentsPage(); // Designations are shown in the Departments page
            break;
        default:
            return false;
    }
    
    return true;
}
