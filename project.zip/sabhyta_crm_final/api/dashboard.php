<?php
/**
 * Dashboard Stats API
 * GET /api/dashboard.php -> aggregated real numbers for the home dashboard
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

// ---- Headline counts -------------------------------------------------
$totalCustomers = (int) $pdo->query("SELECT COUNT(*) FROM customers")->fetchColumn();
$totalRecords   = (int) $pdo->query("SELECT COUNT(*) FROM generic_records")->fetchColumn();

$totalRevenue = (float) $pdo->query(
    "SELECT COALESCE(SUM(amount),0) FROM generic_records"
)->fetchColumn();

$newLeads = (int) $pdo->query(
    "SELECT COUNT(*) FROM generic_records WHERE module_key LIKE '%lead%'"
)->fetchColumn();

// Reads from the dedicated Helpdesk tables (see database/schema_helpdesk.sql)
// instead of generic_records now that Tickets has its own module.
$openTicketsTableExists = (int) $pdo->query(
    "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'helpdesk_tickets'"
)->fetchColumn();

$openTickets = $openTicketsTableExists
    ? (int) $pdo->query("SELECT COUNT(*) FROM helpdesk_tickets WHERE ticket_status NOT IN ('Resolved','Closed')")->fetchColumn()
    : (int) $pdo->query("SELECT COUNT(*) FROM generic_records WHERE module_key LIKE '%ticket%' AND status IN ('Active','Pending')")->fetchColumn();

$activeProjects = (int) $pdo->query(
    "SELECT COUNT(*) FROM generic_records WHERE module_key LIKE '%project%' AND status = 'Active'"
)->fetchColumn();
try { $activeProjects += (int) $pdo->query("SELECT COUNT(*) FROM pm_projects WHERE status = 'Active'")->fetchColumn(); } catch (Throwable $e) { /* project tables not created yet */ }

// ---- Revenue by month (last 6 months, zero-filled) --------------------
$monthly = [];
for ($i = 5; $i >= 0; $i--) {
    $ym = date('Y-m', strtotime("-$i months"));
    $monthly[$ym] = ['label' => date('M', strtotime("-$i months")), 'total' => 0];
}
$rows = $pdo->query(
    "SELECT DATE_FORMAT(created_at, '%Y-%m') ym, SUM(amount) total
     FROM generic_records
     WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
     GROUP BY ym"
)->fetchAll();
foreach ($rows as $r) {
    if (isset($monthly[$r['ym']])) $monthly[$r['ym']]['total'] = (float) $r['total'];
}
$monthlyRevenue = array_values($monthly);

// ---- Customers by type (real breakdown, replaces "Leads by Source") ---
$typeRows = $pdo->query(
    "SELECT COALESCE(NULLIF(customer_type,''),'Unspecified') AS label, COUNT(*) AS count
     FROM customers GROUP BY label ORDER BY count DESC"
)->fetchAll();

// ---- Recent activity: latest customers + records combined -------------
$recentCustomers = $pdo->query(
    "SELECT 'customer' AS kind, customer_name AS title, company_name AS sub, created_at
     FROM customers ORDER BY created_at DESC LIMIT 5"
)->fetchAll();
$recentRecords = $pdo->query(
    "SELECT 'record' AS kind, title, module_label AS sub, created_at
     FROM generic_records ORDER BY created_at DESC LIMIT 5"
)->fetchAll();
$recentActivity = array_merge($recentCustomers, $recentRecords);
usort($recentActivity, fn($a, $b) => strtotime($b['created_at']) <=> strtotime($a['created_at']));
$recentActivity = array_slice($recentActivity, 0, 5);

// ---- Tasks for you: pending records ------------------------------------
$tasks = $pdo->query(
    "SELECT title, module_label, record_date, status
     FROM generic_records WHERE status = 'Pending'
     ORDER BY record_date IS NULL, record_date ASC LIMIT 5"
)->fetchAll();

respond([
    "success" => true,
    "data" => [
        "total_customers"  => $totalCustomers,
        "total_records"    => $totalRecords,
        "total_revenue"    => $totalRevenue,
        "new_leads"        => $newLeads,
        "open_tickets"     => $openTickets,
        "active_projects"  => $activeProjects,
        "monthly_revenue"  => $monthlyRevenue,
        "customer_types"   => $typeRows,
        "recent_activity"  => $recentActivity,
        "tasks"            => $tasks,
    ]
]);
