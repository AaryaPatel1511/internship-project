<?php
/**
 * ERP HOOKS - loaded at the end of db.php, so it runs for every API script.
 * ---------------------------------------------------------------
 *  1. FIREWALL     IP whitelist / blacklist from Administration > Security
 *  2. LOGIN GUARD  optional brute-force lockout (off until enabled in Security)
 *  3. AUDIT TRAIL  every POST / PUT / DELETE / PATCH is written to adm_audit_logs
 *                  (who, what, which module, from which IP, success or failure).
 *                  Request bodies are never stored - so passwords never reach the log.
 * Everything here is wrapped so that a problem in the hooks can never break an API.
 */

if (!function_exists('erp_ip_match')) {
    function erp_ip_match(string $ip, string $rule): bool {
        $rule = trim($rule);
        if ($rule === '' || $ip === '') return false;
        if ($ip === $rule) return true;
        if (strpos($rule, '*') !== false) {
            $re = '/^' . str_replace('\*', '\d{1,3}', preg_quote($rule, '/')) . '$/';
            return (bool)preg_match($re, $ip);
        }
        if (strpos($rule, '/') !== false && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            [$net, $bits] = explode('/', $rule, 2);
            if (!filter_var($net, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) return false;
            $bits = (int)$bits;
            $mask = $bits === 0 ? 0 : (~((1 << (32 - $bits)) - 1)) & 0xFFFFFFFF;
            return ((ip2long($ip) & $mask) === (ip2long($net) & $mask));
        }
        return false;
    }
}

function erp_hook_json_block(int $code, string $msg): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => $msg]);
    exit;
}
function erp_hook_log(PDO $pdo, ?int $uid, ?string $uname, string $action, string $table, string $method, string $outcome): void {
    $pdo->prepare("INSERT INTO adm_audit_logs (user_id, user_name, action_performed, table_affected, request_method, ip_address, outcome) VALUES (?,?,?,?,?,?,?)")
        ->execute([$uid, $uname, mb_substr($action, 0, 1000), mb_substr($table, 0, 100), $method, $_SERVER['REMOTE_ADDR'] ?? null, $outcome]);
}

function erp_hook_firewall(PDO $pdo): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    if ($ip === '' || $ip === '127.0.0.1' || $ip === '::1') return;   // the server itself is never blocked
    $script = basename($_SERVER['SCRIPT_NAME'] ?? '');
    $rules = $pdo->query("SELECT rule_type, rule_value FROM adm_security_rules WHERE is_active = 1 AND rule_type IN ('IP_Whitelist','IP_Blacklist')")->fetchAll();
    if ($rules) {
        $white = [];
        foreach ($rules as $r) {
            if ($r['rule_type'] === 'IP_Blacklist' && erp_ip_match($ip, $r['rule_value'])) {
                erp_hook_log($pdo, null, null, "Blocked by blacklist rule {$r['rule_value']} on $script", 'firewall', $_SERVER['REQUEST_METHOD'] ?? 'GET', 'Failed');
                erp_hook_json_block(403, "Access from your IP address ($ip) is blocked by the security policy.");
            }
            if ($r['rule_type'] === 'IP_Whitelist') $white[] = $r['rule_value'];
        }
        // Webhooks from external services (Facebook, Google ...) cannot be whitelisted by address.
        if ($white && $script !== 'lead_webhooks.php' && !in_array($ip, ['127.0.0.1', '::1'], true)) {
            $ok = false;
            foreach ($white as $w) if (erp_ip_match($ip, $w)) { $ok = true; break; }
            if (!$ok) {
                erp_hook_log($pdo, null, null, "Blocked - IP not in whitelist ($script)", 'firewall', $_SERVER['REQUEST_METHOD'] ?? 'GET', 'Failed');
                erp_hook_json_block(403, "Access from your IP address ($ip) is not permitted by the security policy.");
            }
        }
    }
    // brute-force guard (only when the administrator has set a limit)
    if ($script === 'auth.php' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && (($_GET['action'] ?? $_POST['action'] ?? '') === 'login')) {
        $max = 0; $lock = 15;
        foreach ($pdo->query("SELECT rule_value FROM adm_security_rules WHERE rule_type='Password_Policy' AND is_active=1 AND (rule_value LIKE 'max_login_attempts=%' OR rule_value LIKE 'lock_minutes=%')") as $r) {
            [$k, $v] = explode('=', $r['rule_value'], 2);
            if ($k === 'max_login_attempts') $max = (int)$v; else $lock = max(1, (int)$v);
        }
        if ($max > 0) {
            $st = $pdo->prepare("SELECT COUNT(*) FROM adm_audit_logs WHERE table_affected = 'auth.php' AND outcome = 'Failed' AND ip_address = ?
                AND created_at > NOW() - INTERVAL $lock MINUTE
                AND log_id > COALESCE((SELECT MAX(l2.log_id) FROM adm_audit_logs l2 WHERE l2.table_affected = 'auth.php' AND l2.outcome = 'Success' AND l2.ip_address = ?), 0)");
            $st->execute([$ip, $ip]);
            if ((int)$st->fetchColumn() >= $max) erp_hook_json_block(429, "Too many failed sign-in attempts. Please try again in $lock minutes.");
        }
    }
}

function erp_hook_audit_setup(PDO $pdo): void {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if (in_array($method, ['GET', 'HEAD', 'OPTIONS'], true)) return;

    // who is calling? (session may not be started yet in some scripts)
    $who = ['id' => null, 'name' => null];
    if (session_status() === PHP_SESSION_NONE && !headers_sent() && !empty($_COOKIE[session_name()])) {
        @session_start(['read_and_close' => true]);
    }
    if (!empty($_SESSION['user_id'])) $who = ['id' => (int)$_SESSION['user_id'], 'name' => $_SESSION['user_name'] ?? null];

    $GLOBALS['__erp_audit_out'] = '';
    ob_start(function ($buf) { if ($GLOBALS['__erp_audit_out'] === '') $GLOBALS['__erp_audit_out'] = substr($buf, 0, 600); return $buf; });

    register_shutdown_function(function () use ($pdo, $method, $who) {
        try {
            if (session_status() === PHP_SESSION_ACTIVE && !empty($_SESSION['user_id'])) $who = ['id' => (int)$_SESSION['user_id'], 'name' => $_SESSION['user_name'] ?? null];
            $script = basename($_SERVER['SCRIPT_NAME'] ?? '');
            $action = $_GET['action'] ?? $_POST['action'] ?? '';
            $out = $GLOBALS['__erp_audit_out'] ?? '';
            $code = http_response_code();
            $failed = ($code && $code >= 400) || (bool)preg_match('/"success"\s*:\s*false/', $out);
            $table = $script; $desc = "$method $script" . ($action !== '' ? " action=$action" : '');

            if ($script === 'auth.php') {
                if ($action === 'login') {
                    $ok = !$failed && !empty($_SESSION['user_id']);
                    $failed = !$ok;
                    $desc = ($ok ? 'Login success' : 'Login failed') . ' (' . substr(trim((string)($_POST['email'] ?? '')), 0, 120) . ')';
                    if ($ok) { $who = ['id' => (int)$_SESSION['user_id'], 'name' => $_SESSION['user_name'] ?? null]; }
                } elseif ($action === 'logout') $desc = 'Logout';
                elseif ($action === 'register_first_admin') $desc = 'First administrator registered';
            } else {
                if ($script === 'erp.php') {
                    $ent = $_GET['entity'] ?? $_POST['entity'] ?? '';
                    if ($ent !== '') $table = $ent;
                    $desc = "$method erp.php $action" . ($ent ? " $ent" : '');
                }
                $body = null;
                $ct = $_SERVER['CONTENT_TYPE'] ?? '';
                if (stripos($ct, 'json') !== false) {
                    $raw = @file_get_contents('php://input');
                    if ($raw !== '' && strlen($raw) < 200000) $body = json_decode($raw, true);
                }
                $pick = [];
                foreach (['module_key', 'module_label', 'type'] as $k) {
                    $v = $_GET[$k] ?? $_POST[$k] ?? (is_array($body) ? ($body[$k] ?? null) : null);
                    if (is_scalar($v) && $v !== '') $pick[] = "$k=" . substr((string)$v, 0, 60);
                }
                $id = $_GET['id'] ?? $_POST['id'] ?? (is_array($body) ? ($body['id'] ?? null) : null);
                if (is_scalar($id) && $id !== '') $pick[] = "id=" . substr((string)$id, 0, 20);
                if ($pick) $desc .= ' ' . implode(' ', $pick);
            }
            erp_hook_log($pdo, $who['id'], $who['name'], $desc, $table, $method, $failed ? 'Failed' : 'Success');
        } catch (Throwable $e) { /* never break the request */ }
    });
}

if (PHP_SAPI !== 'cli' && isset($pdo) && $pdo instanceof PDO) {
    try { erp_hook_firewall($pdo); } catch (PDOException $e) { /* security tables not created yet */ }
    try { erp_hook_audit_setup($pdo); } catch (Throwable $e) {}
}
