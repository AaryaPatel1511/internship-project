<?php
/**
 * AUTO-INITIALIZATION SYSTEM
 * Runs on first application load to set up the database schema and
 * demo reference data. It deliberately does NOT create a default
 * admin account with a fixed password anymore — that is handled by
 * login.html the first time it's opened (a "Create Admin Account"
 * screen appears automatically while the users table is empty), so
 * every install gets its own administrator credentials instead of a
 * shared default account.
 */

require_once __DIR__ . '/db.php';

header('Content-Type: application/json');

try {
    // Use a dedicated marker. The base schema itself creates generic_records,
    // so that table cannot distinguish an imported-but-incomplete install.
    $initialized = $pdo->query("SHOW TABLES LIKE 'app_init_status'")->fetch();
    $usersCount = $initialized ? (int) $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn() : 0;

    if ($initialized) {
        echo json_encode([
            'status' => 'already_initialized',
            'message' => 'Database already initialized',
            'has_admin' => $usersCount > 0,
        ]);
        exit;
    }

    // Step 1: Run main schema
    $schema = file_get_contents(__DIR__ . '/../database/schema.sql');
    $statements = array_filter(array_map('trim', preg_split('/;/', $schema)));
    foreach ($statements as $stmt) {
        if (!empty($stmt)) {
            $pdo->exec($stmt);
        }
    }

    // Step 2: Run HRMS/Sales schema
    $hrmsSchema = file_get_contents(__DIR__ . '/../database/schema_hrms_sales.sql');
    $statements = array_filter(array_map('trim', preg_split('/;/', $hrmsSchema)));
    foreach ($statements as $stmt) {
        if (!empty($stmt)) {
            $pdo->exec($stmt);
        }
    }

    // Step 3: Run masters schema
    $mastersSchema = file_get_contents(__DIR__ . '/../database/schema_masters.sql');
    $statements = array_filter(array_map('trim', preg_split('/;/', $mastersSchema)));
    foreach ($statements as $stmt) {
        if (!empty($stmt)) {
            $pdo->exec($stmt);
        }
    }

    // Step 4: Run Lead Management schema
    $leadsSchema = file_get_contents(__DIR__ . '/../database/schema_leads.sql');
    $statements = array_filter(array_map('trim', preg_split('/;/', $leadsSchema)));
    foreach ($statements as $stmt) {
        if (!empty($stmt)) {
            @$pdo->exec($stmt); // @ because the RAND()-based INSERT IGNORE seed can be re-run safely
        }
    }

    // Initialize the additional modules that are otherwise missing on a clean install.
    foreach ([
        'schema_erp_modules.sql',
        'schema_helpdesk.sql',
        'schema_user_management.sql',
        'schema_user_profile_extended.sql',
        'schema_ai_tools.sql',
        'schema_compliance.sql',
    ] as $schemaFile) {
        $moduleSchema = file_get_contents(__DIR__ . '/../database/' . $schemaFile);
        if ($moduleSchema === false) throw new RuntimeException('Could not read ' . $schemaFile);
        $statements = array_filter(array_map('trim', preg_split('/;/', $moduleSchema)));
        foreach ($statements as $stmt) {
            if ($stmt !== '') $pdo->exec($stmt);
        }
    }

    // Step 5: Seed initial data
    $seedModuleMap = file_get_contents(__DIR__ . '/../database/seed_module_map.php');
    if ($seedModuleMap === false) throw new RuntimeException('Could not read the module seed map.');
    ob_start();
    eval('?>' . $seedModuleMap);
    ob_end_clean();

    // Step 6: Seed demo data
    $seedDemo = file_get_contents(__DIR__ . '/../database/seed_demo_data.php');
    if ($seedDemo === false) throw new RuntimeException('Could not read the demo data seed.');
    ob_start();
    eval('?>' . $seedDemo);
    ob_end_clean();

    // Step 7: Seed account groups
    $accountGroupsSql = file_get_contents(__DIR__ . '/../database/account_groups_seed.sql');
    $statements = array_filter(array_map('trim', preg_split('/;/', $accountGroupsSql)));
    foreach ($statements as $stmt) {
        if (!empty($stmt)) {
            @$pdo->exec($stmt); // Use @ to suppress errors if tables don't exist
        }
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS app_init_status (
        id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
        initialized_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("INSERT IGNORE INTO app_init_status (id) VALUES (1)");

    echo json_encode([
        'status' => 'success',
        'message' => 'Database initialized successfully. Open login.html to create your admin account.',
        'has_admin' => false,
    ]);

} catch (Exception $e) {
    http_response_code(500);
    error_log('SABHYTA CRM initialization failed: ' . $e->getMessage());
    echo json_encode([
        'status' => 'error',
        'message' => 'Initialization failed. Check the PHP and database error logs, then verify the database user can create and update the sabhytacrm database.'
    ]);
}
?>

