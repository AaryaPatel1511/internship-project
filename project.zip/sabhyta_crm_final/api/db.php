<?php
/**
 * Database connection (PDO + MySQLi)
 * Provides both $pdo (preferred) and $conn (mysqli) for full project compatibility.
 * Edit these 4 values to match your XAMPP / MySQL setup.
 * Default XAMPP install: host=localhost, user=root, pass="" (empty)
 */

$DB_HOST = getenv('SABHYTA_DB_HOST') ?: 'localhost';
$DB_PORT = (int)(getenv('SABHYTA_DB_PORT') ?: 3306);
$DB_NAME = getenv('SABHYTA_DB_NAME') ?: 'sabhytacrm';
$DB_USER = getenv('SABHYTA_DB_USER') ?: 'root';
$DB_PASS = getenv('SABHYTA_DB_PASS') ?: '';

// ---------- PDO (used by most APIs) ----------
try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};port={$DB_PORT};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json');
    error_log('SABHYTA CRM database connection failed: ' . $e->getMessage());
    echo json_encode(["success" => false, "message" => "Database connection failed. Check the database settings and try again."]);
    exit;
}

// ---------- MySQLi (used by User Management APIs) ----------
$conn = @new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, $DB_PORT);
if ($conn->connect_error) {
    // Do not exit — PDO may still work; user-mgmt endpoints will report clearly
    $conn = null;
} else {
    $conn->set_charset('utf8mb4');
}

// ---------- ERP hooks: IP firewall, login guard, audit trail (see erp_hooks.php) ----------
if (is_file(__DIR__ . '/erp_hooks.php')) { require_once __DIR__ . '/erp_hooks.php'; }

// Shared MySQLi connector for the legacy HRMS, AI and compliance handlers.
function getDBConnection(): mysqli {
    global $conn;
    if (!$conn instanceof mysqli || $conn->connect_errno) {
        throw new RuntimeException('Database connection failed. Check the database settings and try again.');
    }
    return $conn;
}
