<?php
/**
 * Sales Orders REST API (Sales > Sales Order)
 * --------------------------------------------------------
 * GET    /api/sales_orders.php             -> list all
 * GET    /api/sales_orders.php?id=5        -> get one
 * POST   /api/sales_orders.php             -> create
 * POST   /api/sales_orders.php (id + _method=PUT) -> update
 * DELETE /api/sales_orders.php?id=5        -> delete
 * --------------------------------------------------------
 * Line items + attachment checklist travel as JSON strings
 * (items_json / attachments_json) in the POST body, exactly
 * like generic_records.extra_data does for Create Quote.
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

$FIELDS = [
    'sales_order_number'     => 'salesOrderNumber',
    'order_date'             => 'orderDate',
    'quotation_number'       => 'quotationNumber',
    'customer_id'            => 'customerId',
    'contact_person'         => 'contactPerson',
    'customer_po_number'     => 'customerPoNumber',
    'customer_po_date'       => 'customerPoDate',
    'project_name'           => 'projectName',
    'project_code'           => 'projectCode',
    'site_location'          => 'siteLocation',
    'sales_executive_id'     => 'salesExecutiveId',
    'department_id'          => 'departmentId',
    'branch'                 => 'branch',
    'currency'               => 'currency',
    'payment_terms'          => 'paymentTerms',
    'delivery_terms'         => 'deliveryTerms',
    'delivery_address'       => 'deliveryAddress',
    'billing_address'        => 'billingAddress',
    'shipping_address'       => 'shippingAddress',
    'freight_terms'          => 'freightTerms',
    'insurance'              => 'insurance',
    'warranty'               => 'warranty',
    'installation_required'  => 'installationRequired',
    'amc_required'           => 'amcRequired',
    'expected_delivery_date' => 'expectedDeliveryDate',
    'priority'               => 'priority',
    'order_status'           => 'orderStatus',
    'internal_notes'         => 'internalNotes',
    'customer_notes'         => 'customerNotes',
    'items_json'             => 'itemsJson',
    'attachments_json'       => 'attachmentsJson',
    'sub_total'              => 'subTotal',
    'discount_total'         => 'discountTotal',
    'tax_amount'             => 'taxAmount',
    'freight_charges'        => 'freightCharges',
    'installation_charges'   => 'installationCharges',
    'packing_charges'        => 'packingCharges',
    'insurance_charges'      => 'insuranceCharges',
    'other_charges'          => 'otherCharges',
    'round_off'              => 'roundOff',
    'grand_total'            => 'grandTotal',
];

if ($method === 'GET') {
    if (!empty($_GET['id'])) {
        $stmt = $pdo->prepare("SELECT so.*, c.customer_name, c.company_name,
                                       CONCAT(e.first_name, ' ', COALESCE(e.last_name,'')) AS sales_executive_name
                                FROM sales_orders so
                                LEFT JOIN customers c ON c.id = so.customer_id
                                LEFT JOIN employees e ON e.id = so.sales_executive_id
                                WHERE so.id = ?");
        $stmt->execute([$_GET['id']]);
        $row = $stmt->fetch();
        if (!$row) respond(["success" => false, "message" => "Sales Order not found"], 404);
        respond(["success" => true, "data" => $row]);
    }
    $sql = "SELECT so.*, c.customer_name, c.company_name,
                   CONCAT(e.first_name, ' ', COALESCE(e.last_name,'')) AS sales_executive_name
            FROM sales_orders so
            LEFT JOIN customers c ON c.id = so.customer_id
            LEFT JOIN employees e ON e.id = so.sales_executive_id";
    $params = [];
    if (!empty($_GET['q'])) {
        $sql .= " WHERE so.sales_order_number LIKE ? OR c.customer_name LIKE ? OR c.company_name LIKE ?";
        $like = '%' . $_GET['q'] . '%';
        $params = [$like, $like, $like];
    }
    $sql .= " ORDER BY so.created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    respond(["success" => true, "data" => $stmt->fetchAll()]);
}

if ($method === 'POST') {
    $isUpdate = !empty($_POST['id']) && (($_POST['_method'] ?? '') === 'PUT');

    foreach (['salesOrderNumber', 'customerId'] as $required) {
        if (empty($_POST[$required])) {
            respond(["success" => false, "message" => "Missing required field: $required"], 422);
        }
    }

    $data = [];
    foreach ($FIELDS as $col => $formName) {
        $data[$col] = $_POST[$formName] ?? null;
        if ($data[$col] === '') $data[$col] = null;
    }

    try {
        if ($isUpdate) {
            $id = $_POST['id'];
            $setSql = implode(', ', array_map(fn($c) => "$c = :$c", array_keys($data)));
            $stmt = $pdo->prepare("UPDATE sales_orders SET $setSql WHERE id = :id");
            $data['id'] = $id;
            $stmt->execute($data);
            respond(["success" => true, "message" => "Sales Order updated", "id" => $id]);
        } else {
            $cols = implode(', ', array_keys($data));
            $placeholders = implode(', ', array_map(fn($c) => ":$c", array_keys($data)));
            $stmt = $pdo->prepare("INSERT INTO sales_orders ($cols) VALUES ($placeholders)");
            $stmt->execute($data);
            respond(["success" => true, "message" => "Sales Order created", "id" => $pdo->lastInsertId()], 201);
        }
    } catch (PDOException $e) {
        $msg = $e->getCode() === '23000'
            ? "Sales Order Number already exists. Please use a unique number."
            : "Database error: " . $e->getMessage();
        respond(["success" => false, "message" => $msg], 400);
    }
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? null;
    if (!$id) respond(["success" => false, "message" => "Missing id"], 422);
    $stmt = $pdo->prepare("DELETE FROM sales_orders WHERE id = ?");
    $stmt->execute([$id]);
    respond(["success" => true, "message" => "Sales Order deleted"]);
}

respond(["success" => false, "message" => "Method not allowed"], 405);
