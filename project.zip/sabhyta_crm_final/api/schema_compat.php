<?php
/**
 * Schema compatibility helpers for Department / Designation columns.
 * --------------------------------------------------------
 * The HRMS schema names the columns   department_name / department_code /
 * designation_name  while an older User-Management schema used
 * dept_name / dept_code / desig_name / desig_code.
 *
 * MySQL & MariaDB abort a whole query with "Unknown column" if it
 * merely MENTIONS a column that does not exist, so the old
 *   COALESCE(d.department_name, d.dept_name)
 * pattern broke Users, Departments and Designations whenever only one
 * of the two naming styles was present in the real table.
 *
 * These helpers look at the REAL columns once (cached) and only ever
 * emit SQL for columns that exist.
 */

function sc_columns(PDO $pdo, string $table): array {
    static $cache = [];
    if (!isset($cache[$table])) {
        try {
            $cache[$table] = $pdo->query("SHOW COLUMNS FROM `" . str_replace('`', '', $table) . "`")->fetchAll(PDO::FETCH_COLUMN);
        } catch (Exception $e) {
            $cache[$table] = [];
        }
    }
    return $cache[$table];
}

/** COALESCE() over whichever of $candidates really exist in $table. */
function sc_expr(PDO $pdo, string $table, string $alias, array $candidates, string $fallback = "''"): string {
    $cols = sc_columns($pdo, $table);
    $parts = [];
    foreach ($candidates as $c) {
        if (in_array($c, $cols, true)) $parts[] = $alias . '.`' . $c . '`';
    }
    if (!$parts) return $fallback;
    if (count($parts) === 1 && $fallback === "''") return $parts[0];
    $parts[] = $fallback;
    return 'COALESCE(' . implode(', ', $parts) . ')';
}

function scDeptName(string $alias = 'd', string $fallback = "''"): string {
    global $pdo;
    return sc_expr($pdo, 'departments', $alias, ['department_name', 'dept_name'], $fallback);
}
function scDeptCode(string $alias = 'd', string $fallback = "''"): string {
    global $pdo;
    return sc_expr($pdo, 'departments', $alias, ['department_code', 'dept_code'], $fallback);
}
function scDesigName(string $alias = 'dg', string $fallback = "''"): string {
    global $pdo;
    return sc_expr($pdo, 'designations', $alias, ['designation_name', 'desig_name'], $fallback);
}
function scDesigCode(string $alias = 'dg', string $fallback = null): string {
    global $pdo;
    if ($fallback === null) $fallback = "CAST({$alias}.id AS CHAR)";
    return sc_expr($pdo, 'designations', $alias, ['designation_code', 'desig_code'], $fallback);
}
