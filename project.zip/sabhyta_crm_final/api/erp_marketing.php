<?php
/**
 * MARKETING - hooks & actions
 * Strategy -> Audience & assets -> Channels -> Delivery -> Analytics -> Optimisation
 *
 * This module manages the DATA each channel needs (audiences, content, configuration,
 * compliance) and the campaign lifecycle. Actual message delivery happens in your
 * email service provider / SMS gateway / WhatsApp Business API / ad platform - the
 * "Export recipients" action hands them the cleaned, consent-checked, suppression-free list.
 */

function mk_default_cc(PDO $pdo): string {
    $c = (string)erp_setting_get($pdo, 'sms_default_country_code', '+91');
    return preg_match('/^\+\d{1,4}$/', $c) ? $c : '+91';
}
function mk_norm_phone(PDO $pdo, ?string $p): ?string {
    if ($p === null) return null;
    $p = preg_replace('/[^\d+]/', '', trim($p));
    if ($p === '') return null;
    if (strpos($p, '00') === 0) $p = '+' . substr($p, 2);
    if ($p[0] !== '+') {
        $digits = $p;
        if (strlen($digits) === 11 && $digits[0] === '0') $digits = substr($digits, 1);
        if (strlen($digits) === 10) return mk_default_cc($pdo) . $digits;
        $p = '+' . $digits;
    }
    return preg_match('/^\+\d{8,15}$/', $p) ? $p : null;
}
function mk_build_url(string $base, array $params): string {
    $params = array_filter($params, fn($v) => $v !== null && $v !== '');
    if (!$params) return $base;
    $frag = '';
    if (($i = strpos($base, '#')) !== false) { $frag = substr($base, $i); $base = substr($base, 0, $i); }
    $sep = strpos($base, '?') === false ? '?' : '&';
    return $base . $sep . http_build_query($params, '', '&', PHP_QUERY_RFC3986) . $frag;
}
function mk_slug(?string $s): string { return trim(strtolower(preg_replace('/[^a-z0-9]+/i', '_', (string)$s)), '_'); }

/* ---------------------------------------------------------
   Generic / list / contact / suppression hooks
   --------------------------------------------------------- */
function mk_before_generic(PDO $pdo, array &$d, ?array $old, array $in): void {}

function mk_contact_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    $email = array_key_exists('email', $d) ? $d['email'] : ($old['email'] ?? null);
    $phone = array_key_exists('phone', $d) ? $d['phone'] : ($old['phone'] ?? null);
    if (array_key_exists('email', $d) && $d['email']) $d['email'] = strtolower($d['email']);
    if (array_key_exists('phone', $d) && $d['phone']) {
        $n = mk_norm_phone($pdo, $d['phone']);
        if (!$n) erp_fail('Phone number is not valid. Use the international format, e.g. +919876543210.');
        $d['phone'] = $n; $phone = $n;
    }
    if (!$email && !$phone) erp_fail('A contact needs an email address or a phone number.');
    $list = (int)($d['list_id'] ?? $old['list_id'] ?? 0);
    $self = (int)($old['contact_id'] ?? 0);
    if ($email) {
        $q = $pdo->prepare("SELECT 1 FROM mk_audience_contacts WHERE list_id = ? AND email = ? AND contact_id <> ?"); $q->execute([$list, strtolower($email), $self]);
        if ($q->fetchColumn()) erp_fail('This email is already in the list.');
    }
    if ($phone) {
        $q = $pdo->prepare("SELECT 1 FROM mk_audience_contacts WHERE list_id = ? AND phone = ? AND contact_id <> ?"); $q->execute([$list, $phone, $self]);
        if ($q->fetchColumn()) erp_fail('This phone number is already in the list.');
    }
    $status = $d['status'] ?? $old['status'] ?? 'Active';
    if ($status !== 'Active') $d['opt_in'] = 0;
    $optIn = array_key_exists('opt_in', $d) ? $d['opt_in'] : ($old['opt_in'] ?? 1);
    if ($optIn && empty($d['opt_in_at']) && empty($old['opt_in_at'])) $d['opt_in_at'] = erp_now();
}
function mk_contact_after(PDO $pdo, int $id, array $d, ?array $old, array $in): array {
    $c = $pdo->prepare("SELECT * FROM mk_audience_contacts WHERE contact_id = ?"); $c->execute([$id]);
    $r = $c->fetch();
    if (!$r || $r['status'] === 'Active') return [];
    $reason = $r['status'] === 'Bounced' ? 'Hard Bounce' : 'Unsubscribed';
    $ins = $pdo->prepare("INSERT IGNORE INTO mk_suppression (channel, contact_value, reason, notes) VALUES (?, ?, ?, 'Added automatically from audience contact')");
    if ($r['email']) $ins->execute(['Email', strtolower($r['email']), $reason]);
    if ($r['phone']) { $ins->execute(['SMS', $r['phone'], $reason === 'Unsubscribed' ? 'Opt-out' : $reason]); $ins->execute(['WhatsApp', $r['phone'], $reason === 'Unsubscribed' ? 'Opt-out' : $reason]); }
    return ['Contact added to the suppression list so no campaign will message them.'];
}
function mk_contact_after_delete(PDO $pdo, int $id, array $old): void {}

function mk_suppression_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    $ch = $d['channel'] ?? $old['channel'] ?? 'Email';
    $v = $d['contact_value'] ?? $old['contact_value'] ?? '';
    if ($ch === 'Email') {
        if (!filter_var($v, FILTER_VALIDATE_EMAIL)) erp_fail('Enter a valid email address for an Email suppression.');
        $d['contact_value'] = strtolower($v);
    } else {
        $n = mk_norm_phone($pdo, $v);
        if (!$n) erp_fail('Enter a valid phone number (international format) for an SMS / WhatsApp suppression.');
        $d['contact_value'] = $n;
    }
}

/* ---------------------------------------------------------
   Campaign hooks
   --------------------------------------------------------- */
function mk_check_schedule(array $d, ?array $old): void {
    $s = $d['scheduled_at'] ?? ($d['publish_at'] ?? null);
    if ($s && !$old && strtotime($s) < time() - 60) erp_fail('The scheduled time is in the past.');
}
function mk_email_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    mk_check_schedule($d, $old);
    $land = array_key_exists('landing_url', $d) ? $d['landing_url'] : ($old['landing_url'] ?? null);
    $camp = $d['utm_campaign'] ?? ($old['utm_campaign'] ?? null) ?: mk_slug($d['campaign_name'] ?? $old['campaign_name'] ?? '');
    if (array_key_exists('utm_campaign', $d) || !$old) $d['utm_campaign'] = $camp ?: null;
    $d['tracking_url'] = $land ? mk_build_url($land, [
        'utm_source' => $d['utm_source'] ?? $old['utm_source'] ?? 'email', 'utm_medium' => $d['utm_medium'] ?? $old['utm_medium'] ?? 'email',
        'utm_campaign' => $camp, 'utm_content' => $d['utm_content'] ?? $old['utm_content'] ?? null]) : null;
    if (!empty($d['list_id'])) mk_check_list_channel($pdo, (int)$d['list_id'], 'Email');
}
function mk_check_list_channel(PDO $pdo, int $listId, string $channel): void {
    $q = $pdo->prepare("SELECT channel FROM mk_audience_lists WHERE list_id = ?"); $q->execute([$listId]);
    $c = $q->fetchColumn();
    if ($c && $c !== $channel) erp_fail("The selected audience list is a $c list. Choose a $channel list (or create one).");
}
function mk_sms_segments(string $text): int {
    $len = mb_strlen($text);
    if ($len === 0) return 1;
    $unicode = (bool)preg_match('/[^\x00-\x7F]/u', $text);
    $single = $unicode ? 70 : 160; $multi = $unicode ? 67 : 153;
    return $len <= $single ? 1 : (int)ceil($len / $multi);
}
function mk_sms_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    mk_check_schedule($d, $old);
    if (array_key_exists('message_text', $d)) $d['segments'] = mk_sms_segments((string)$d['message_text']);
    if (!empty($d['sender_id']) && !preg_match('/^[A-Za-z0-9]{3,11}$/', $d['sender_id'])) erp_fail('Sender ID must be 3-11 letters or digits with no spaces.');
    if (!empty($d['list_id'])) mk_check_list_channel($pdo, (int)$d['list_id'], 'SMS');
}
function mk_wa_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    mk_check_schedule($d, $old);
    if (!empty($d['template_name']) && !preg_match('/^[a-z0-9_]{1,150}$/', $d['template_name'])) erp_fail('Template name may only use lowercase letters, digits and underscores (WhatsApp rule).');
    if (!empty($d['list_id'])) mk_check_list_channel($pdo, (int)$d['list_id'], 'WhatsApp');
    $mt = $d['media_type'] ?? $old['media_type'] ?? 'None';
    if ($mt === 'None' && !empty($d['media_file'])) $d['media_type'] = 'Image';
}
function mk_social_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    mk_check_schedule($d, $old);
    $land = array_key_exists('landing_url', $d) ? $d['landing_url'] : ($old['landing_url'] ?? null);
    $plat = $d['platform'] ?? $old['platform'] ?? 'Facebook';
    $camp = ($d['utm_campaign'] ?? $old['utm_campaign'] ?? null) ?: mk_slug($d['campaign_name'] ?? $old['campaign_name'] ?? '');
    if (array_key_exists('utm_campaign', $d) || !$old) $d['utm_campaign'] = $camp ?: null;
    $d['tracking_url'] = $land ? mk_build_url($land, ['utm_source' => mk_slug($plat), 'utm_medium' => 'social', 'utm_campaign' => $camp]) : null;
}
function mk_campaign_before_delete(PDO $pdo, int $id, array $old): void {
    if (in_array($old['status'], ['Running'], true)) erp_fail('A running campaign cannot be deleted. Pause or cancel it first.', 409);
}
function mk_utm_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    $g = fn($k) => array_key_exists($k, $d) ? $d[$k] : ($old[$k] ?? null);
    $d['generated_url'] = mk_build_url((string)$g('base_url'), [
        'utm_source' => $g('utm_source'), 'utm_medium' => $g('utm_medium'), 'utm_campaign' => $g('utm_campaign'),
        'utm_term' => $g('utm_term'), 'utm_content' => $g('utm_content')]);
}
function mk_perf_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    $g = fn($k) => (int)(array_key_exists($k, $d) ? $d[$k] : ($old[$k] ?? 0));
    if ($g('sent') > 0 && $g('delivered') > $g('sent')) erp_fail('Delivered cannot be more than Sent.');
    $s = $d['period_start'] ?? $old['period_start'] ?? null; $e = array_key_exists('period_end', $d) ? $d['period_end'] : ($old['period_end'] ?? null);
    if ($s && $e && $e < $s) erp_fail('Period end cannot be before period start.');
}
function mk_ab_before(PDO $pdo, array &$d, ?array $old, array $in): void {
    $g = fn($k) => (int)(array_key_exists($k, $d) ? $d[$k] : ($old[$k] ?? 0));
    if ($g('a_success') > $g('a_sent')) erp_fail('Variant A successes cannot exceed the number sent.');
    if ($g('b_success') > $g('b_sent')) erp_fail('Variant B successes cannot exceed the number sent.');
}
function mk_norm_cdf(float $z): float {
    $t = 1 / (1 + 0.2316419 * abs($z));
    $d = 0.3989423 * exp(-$z * $z / 2);
    $p = $d * $t * (0.3193815 + $t * (-0.3565638 + $t * (1.781478 + $t * (-1.821256 + $t * 1.330274))));
    return $z > 0 ? 1 - $p : $p;
}
function mk_ab_decorate(PDO $pdo, array $rows): array {
    foreach ($rows as &$r) {
        $as = (int)$r['a_sent']; $bs = (int)$r['b_sent'];
        $pa = $as ? $r['a_success'] / $as : 0; $pb = $bs ? $r['b_success'] / $bs : 0;
        $r['a_rate'] = round($pa * 100, 2); $r['b_rate'] = round($pb * 100, 2);
        $r['winner'] = 'Not enough data'; $r['confidence'] = null;
        if ($as >= 30 && $bs >= 30) {
            $pp = ($r['a_success'] + $r['b_success']) / ($as + $bs);
            $se = sqrt($pp * (1 - $pp) * (1 / $as + 1 / $bs));
            if ($se > 0) {
                $z = abs($pa - $pb) / $se;
                $conf = (2 * mk_norm_cdf($z) - 1) * 100;
                $r['confidence'] = round($conf, 1);
                $r['winner'] = $conf >= 95 ? ($pa > $pb ? 'Variant A' : 'Variant B') : 'Inconclusive (<95%)';
            } else $r['winner'] = 'Tie';
        }
    }
    return $rows;
}

/* ---------------------------------------------------------
   Spam check (local heuristic - no external service)
   --------------------------------------------------------- */
function act_mk_spam_check(PDO $pdo): void {
    $in = erp_input();
    $subject = trim((string)($in['subject_line'] ?? '')); $html = (string)($in['html_template'] ?? ''); $plain = trim((string)($in['plain_text_body'] ?? ''));
    $auth = !empty($in['sender_domain_auth']) && $in['sender_domain_auth'] !== '0';
    $score = 0.0; $issues = []; $passed = [];
    $add = function (float $pts, string $msg) use (&$score, &$issues) { $score += $pts; $issues[] = ['points' => $pts, 'text' => $msg]; };

    if ($subject === '') $add(2, 'The subject line is empty.');
    else {
        $letters = preg_replace('/[^A-Za-z]/', '', $subject);
        if (strlen($letters) > 8 && strlen(preg_replace('/[^A-Z]/', '', $letters)) / strlen($letters) > 0.6) $add(1.5, 'Subject is mostly CAPITAL letters.'); else $passed[] = 'Subject capitalisation looks normal.';
        if (substr_count($subject, '!') > 1) $add(1, 'Subject has several exclamation marks.');
        if (mb_strlen($subject) > 70) $add(0.5, 'Subject is longer than 70 characters and may be cut off.');
    }
    $words = ['free','winner','guarantee','guaranteed','cash','urgent','act now','limited time','click here','buy now','100%','risk-free','no obligation','congratulations','earn money','double your','lowest price'];
    $hay = strtolower($subject . ' ' . strip_tags($html) . ' ' . $plain);
    $hits = [];
    foreach ($words as $w) if (strpos($hay, $w) !== false) $hits[] = $w;
    if ($hits) $add(min(3, count($hits) * 0.5), 'Spam-trigger words found: ' . implode(', ', array_slice($hits, 0, 8)) . '.'); else $passed[] = 'No common spam-trigger words.';
    if (stripos($html . $plain, 'unsubscribe') === false) $add(2, 'No unsubscribe link or text found - required by law and by mailbox providers.'); else $passed[] = 'Unsubscribe option present.';
    if ($plain === '') $add(1, 'No plain-text fallback. Add one for better deliverability.'); else $passed[] = 'Plain-text fallback present.';
    if (!$auth) $add(1.5, 'Sender domain is not marked as authenticated (SPF / DKIM / DMARC).'); else $passed[] = 'Sender domain authenticated.';
    $imgs = preg_match_all('/<img\b/i', $html);
    if ($imgs > 5 && mb_strlen(trim(strip_tags($html))) < 200) $add(1, 'The email is mostly images with very little text.');
    if (preg_match('~https?://(bit\.ly|tinyurl\.com|goo\.gl|t\.co)/~i', $html)) $add(0.5, 'URL shorteners in an email body can trigger filters - use your own domain.');
    $score = round(min(10, $score), 1);
    $verdict = $score < 3 ? 'Clean' : ($score <= 5 ? 'Needs review' : 'High spam risk');
    erp_ok(['score' => $score, 'verdict' => $verdict, 'issues' => $issues, 'passed' => $passed]);
}

/* ---------------------------------------------------------
   Recipient resolution
   --------------------------------------------------------- */
function mk_suppression_set(PDO $pdo, string $channel): array {
    $st = $pdo->prepare("SELECT contact_value FROM mk_suppression WHERE channel = ?"); $st->execute([$channel]);
    return array_flip(array_map('strtolower', $st->fetchAll(PDO::FETCH_COLUMN)));
}
/** @return array{rows:array,total:int,suppressed:int,skipped:array} */
function mk_recipients(PDO $pdo, string $channel, int $listId): array {
    $st = $pdo->prepare("SELECT * FROM mk_audience_contacts WHERE list_id = ? ORDER BY contact_id"); $st->execute([$listId]);
    $all = $st->fetchAll();
    $sup = mk_suppression_set($pdo, $channel);
    $rows = []; $suppressed = 0; $skip = ['not_opted_in' => 0, 'inactive' => 0, 'missing_contact' => 0, 'not_wa_verified' => 0, 'no_wa_consent_time' => 0];
    foreach ($all as $c) {
        if ($c['status'] !== 'Active') { $skip['inactive']++; continue; }
        if (!$c['opt_in']) { $skip['not_opted_in']++; continue; }
        $key = $channel === 'Email' ? strtolower((string)$c['email']) : (string)$c['phone'];
        if ($key === '') { $skip['missing_contact']++; continue; }
        if ($channel === 'WhatsApp') {
            if (!$c['whatsapp_verified']) { $skip['not_wa_verified']++; continue; }
            if (!$c['opt_in_at']) { $skip['no_wa_consent_time']++; continue; }
        }
        if (isset($sup[strtolower($key)])) { $suppressed++; continue; }
        $rows[] = $c;
    }
    return ['rows' => $rows, 'total' => count($all), 'suppressed' => $suppressed, 'skipped' => array_filter($skip)];
}
function mk_campaign_table(string $entity): array {
    $E = erp_entity($entity);
    if (empty($E['channel'])) erp_fail('Not a campaign.');
    return $E;
}

/* ---------------------------------------------------------
   Launch / lifecycle
   --------------------------------------------------------- */
function act_mk_launch(PDO $pdo): void {
    $in = erp_input();
    $E = mk_campaign_table($in['entity'] ?? '');
    $id = (int)($in['id'] ?? 0);
    $c = erp_fetch_row($pdo, $E, $id);
    if (!$c) erp_fail('Campaign not found.', 404);
    if (!in_array($c['status'], ['Draft', 'Paused', 'Scheduled'], true)) erp_fail('Only Draft, Scheduled or Paused campaigns can be launched (current status: ' . $c['status'] . ').');
    $ch = $E['channel']; $problems = [];

    if ($ch !== 'Social' && empty($c['list_id'])) $problems[] = 'Choose an audience list.';
    if ($ch === 'Email') {
        if (empty($c['subject_line'])) $problems[] = 'Subject line is required.';
        if (empty($c['sender_name']) || empty($c['sender_email'])) $problems[] = 'Sender name and sender email are required.';
        if (empty($c['html_template']) && empty($c['plain_text_body'])) $problems[] = 'Add an HTML template or a plain-text body.';
        if (!$c['sender_domain_auth']) $problems[] = 'Confirm the sender domain is authenticated (SPF / DKIM).';
        if ($c['spam_score'] !== null && (float)$c['spam_score'] > 5) $problems[] = 'Spam score is ' . $c['spam_score'] . ' - fix the issues from "Run Spam Check" first.';
    } elseif ($ch === 'SMS') {
        if (empty($c['sender_id'])) $problems[] = 'An approved Sender ID is required.';
        if (empty($c['message_text'])) $problems[] = 'Message text is required.';
        if (empty($c['dlt_template_id']) || empty($c['dlt_entity_id'])) $problems[] = 'DLT Entity ID and Template ID are required for SMS in India.';
        if (empty($c['opt_out_text'])) $problems[] = 'Add opt-out text such as "Reply STOP to cancel".';
    } elseif ($ch === 'WhatsApp') {
        if (empty($c['template_name']) || empty($c['template_body'])) $problems[] = 'Template name and body are required.';
        if ($c['template_status'] !== 'Approved') $problems[] = 'The WhatsApp template must be Approved by Meta before launch (currently ' . $c['template_status'] . ').';
        if ($c['media_type'] !== 'None' && empty($c['media_file'])) $problems[] = 'Upload the ' . $c['media_type'] . ' file you selected.';
    } elseif ($ch === 'Social') {
        if (empty($c['ad_copy_a']) && empty($c['creative_file'])) $problems[] = 'Add ad copy or a creative file.';
        if ($c['post_type'] === 'Ad' && (empty($c['budget']) || (float)$c['budget'] <= 0)) $problems[] = 'A paid ad needs a budget.';
    }
    if ($problems) erp_fail('Fix these before launching: ' . implode(' ', $problems), 422, ['errors' => $problems]);

    $sched = $ch === 'Social' ? $c['publish_at'] : $c['scheduled_at'];
    $future = $sched && strtotime($sched) > time();
    $newStatus = $future ? 'Scheduled' : 'Running';
    $sum = ['recipients' => 0, 'suppressed' => 0, 'skipped' => []];
    if ($ch !== 'Social') {
        $r = mk_recipients($pdo, $ch, (int)$c['list_id']);
        if (!count($r['rows'])) erp_fail('No eligible recipients: every contact in the list is opted-out, suppressed, inactive' . ($ch === 'WhatsApp' ? ' or not WhatsApp-verified' : '') . '.');
        $sum = ['recipients' => count($r['rows']), 'suppressed' => $r['suppressed'], 'skipped' => $r['skipped']];
        $pdo->prepare("UPDATE {$E['table']} SET status = ?, total_recipients = ?, suppressed_count = ?, launched_at = NOW() WHERE campaign_id = ?")
            ->execute([$newStatus, $sum['recipients'], $sum['suppressed'], $id]);
    } else {
        $pdo->prepare("UPDATE {$E['table']} SET status = ?, launched_at = NOW() WHERE campaign_id = ?")->execute([$newStatus, $id]);
    }
    $msg = $future ? "Campaign scheduled for $sched." : 'Campaign is now Running.';
    if ($ch !== 'Social') $msg .= " {$sum['recipients']} eligible recipient(s), {$sum['suppressed']} suppressed. Use \"Export Recipients\" to upload the list to your platform.";
    erp_ok($sum + ['status' => $newStatus], ['message' => $msg]);
}
function act_mk_set_status(PDO $pdo): void {
    $in = erp_input();
    $E = mk_campaign_table($in['entity'] ?? '');
    $id = (int)($in['id'] ?? 0); $to = $in['status'] ?? '';
    $c = erp_fetch_row($pdo, $E, $id);
    if (!$c) erp_fail('Campaign not found.', 404);
    $allowed = [
        'Running'   => ['Paused', 'Completed', 'Cancelled'],
        'Paused'    => ['Running', 'Cancelled', 'Draft'],
        'Scheduled' => ['Draft', 'Cancelled'],
        'Draft'     => ['Cancelled'],
        'Completed' => [], 'Cancelled' => ['Draft'],
    ];
    if (!in_array($to, $allowed[$c['status']] ?? [], true)) erp_fail("A {$c['status']} campaign cannot be changed to $to.");
    $pdo->prepare("UPDATE {$E['table']} SET status = ? WHERE campaign_id = ?")->execute([$to, $id]);
    erp_ok(null, ['message' => "Campaign is now $to."]);
}
function act_mk_export_recipients(PDO $pdo): void {
    $E = mk_campaign_table($_GET['entity'] ?? '');
    $c = erp_fetch_row($pdo, $E, (int)($_GET['id'] ?? 0));
    if (!$c || empty($c['list_id'])) erp_fail('Campaign or audience list not found.', 404);
    $r = mk_recipients($pdo, $E['channel'], (int)$c['list_id']);
    $out = [];
    foreach ($r['rows'] as $x) $out[] = [$x['full_name'], $x['email'], $x['phone'], $x['city'], $x['state'], $x['country'], $x['opt_in_at']];
    erp_csv_out('recipients_' . mk_slug($c['campaign_name']) . '_' . date('Ymd') . '.csv', ['Name', 'Email', 'Phone', 'City', 'State', 'Country', 'Opt-in Time'], $out);
}

/* ---------------------------------------------------------
   Audience import / build
   --------------------------------------------------------- */
function mk_read_csv_upload(string $field): array {
    if (empty($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) erp_fail('Choose a CSV file to upload.');
    $f = $_FILES[$field];
    if ($f['error'] !== UPLOAD_ERR_OK) erp_fail(erp_upload_error_text((int)$f['error']));
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['csv', 'txt'], true)) erp_fail('Please upload a .csv file (in Excel use Save As > CSV).');
    if ($f['size'] > 20 * 1048576) erp_fail('File is too large (max 20 MB).');
    $h = fopen($f['tmp_name'], 'r');
    $first = fgets($h);
    if ($first === false) erp_fail('The file is empty.');
    $first = preg_replace('/^\xEF\xBB\xBF/', '', $first);
    $delim = (substr_count($first, ';') > substr_count($first, ',')) ? ';' : ((substr_count($first, "\t") > substr_count($first, ',')) ? "\t" : ',');
    $header = array_map(fn($x) => strtolower(trim(preg_replace('/[^a-z0-9]+/i', '_', $x), '_')), str_getcsv($first, $delim));
    $rows = [];
    while (($line = fgetcsv($h, 0, $delim)) !== false) {
        if (count($line) === 1 && trim((string)$line[0]) === '') continue;
        $row = [];
        foreach ($header as $i => $k) $row[$k] = isset($line[$i]) ? trim($line[$i]) : '';
        $rows[] = $row;
        if (count($rows) > 50000) erp_fail('A single import is limited to 50,000 rows. Split the file.');
    }
    fclose($h);
    return [$header, $rows];
}
function mk_pick(array $row, array $keys): string {
    foreach ($keys as $k) if (isset($row[$k]) && $row[$k] !== '') return $row[$k];
    return '';
}
function mk_truthy($v, bool $default): int {
    if ($v === '' || $v === null) return $default ? 1 : 0;
    return in_array(strtolower(trim((string)$v)), ['1', 'yes', 'y', 'true', 'on'], true) ? 1 : 0;
}
function mk_list_or_fail(PDO $pdo, int $id): array {
    $st = $pdo->prepare("SELECT * FROM mk_audience_lists WHERE list_id = ?"); $st->execute([$id]);
    $l = $st->fetch();
    if (!$l) erp_fail('Audience list not found.', 404);
    return $l;
}
function act_mk_import_contacts(PDO $pdo): void {
    $in = erp_input();
    $list = mk_list_or_fail($pdo, (int)($in['list_id'] ?? 0));
    if (empty($in['consent'])) erp_fail('Please confirm that these contacts have given consent to be contacted.');
    [$header, $rows] = mk_read_csv_upload('file');
    if (!array_intersect($header, ['email', 'e_mail', 'email_address', 'phone', 'mobile', 'phone_number', 'mobile_number', 'contact'])) erp_fail('The CSV needs a header row with at least an "email" or "phone" column. Found: ' . implode(', ', $header));

    $existing = $pdo->prepare("SELECT email, phone FROM mk_audience_contacts WHERE list_id = ?"); $existing->execute([$list['list_id']]);
    $haveE = []; $haveP = [];
    foreach ($existing->fetchAll() as $x) { if ($x['email']) $haveE[$x['email']] = 1; if ($x['phone']) $haveP[$x['phone']] = 1; }
    $ins = $pdo->prepare("INSERT INTO mk_audience_contacts (list_id, full_name, email, phone, city, state, country, opt_in, opt_in_at, whatsapp_verified, status, source_ref) VALUES (?,?,?,?,?,?,?,?,?,?, 'Active', 'csv')");
    $n = 0; $dup = 0; $bad = 0; $badSamples = [];
    $pdo->beginTransaction();
    foreach ($rows as $i => $r) {
        $email = strtolower(mk_pick($r, ['email', 'e_mail', 'email_address']));
        $phoneRaw = mk_pick($r, ['phone', 'mobile', 'phone_number', 'mobile_number', 'contact']);
        $phone = $phoneRaw !== '' ? mk_norm_phone($pdo, $phoneRaw) : null;
        if (($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) || ($phoneRaw !== '' && !$phone) || ($email === '' && !$phone)) {
            $bad++; if (count($badSamples) < 5) $badSamples[] = 'Row ' . ($i + 2) . ': ' . ($email ?: $phoneRaw ?: 'no contact value'); continue;
        }
        if (($email !== '' && isset($haveE[$email])) || ($phone && isset($haveP[$phone]))) { $dup++; continue; }
        $name = mk_pick($r, ['name', 'full_name', 'customer_name', 'first_name']);
        if ($name !== '' && !empty($r['last_name'])) $name .= ' ' . $r['last_name'];
        $opt = mk_truthy($r['opt_in'] ?? '', true);
        $ins->execute([$list['list_id'], $name ?: null, $email ?: null, $phone, mk_pick($r, ['city']) ?: null, mk_pick($r, ['state']) ?: null, mk_pick($r, ['country']) ?: null,
                       $opt, $opt ? erp_now() : null, mk_truthy($r['whatsapp_verified'] ?? ($r['whatsapp'] ?? ''), false)]);
        if ($email !== '') $haveE[$email] = 1; if ($phone) $haveP[$phone] = 1;
        $n++;
    }
    if ($list['source'] === 'Manual') $pdo->prepare("UPDATE mk_audience_lists SET source = 'CSV Upload' WHERE list_id = ?")->execute([$list['list_id']]);
    $pdo->commit();
    erp_ok(['imported' => $n, 'duplicates' => $dup, 'invalid' => $bad, 'invalid_samples' => $badSamples],
           ['message' => "$n contact(s) imported, $dup duplicate(s) skipped, $bad invalid row(s) skipped."]);
}
function act_mk_build_list(PDO $pdo): void {
    $in = erp_input();
    $list = mk_list_or_fail($pdo, (int)($in['list_id'] ?? 0));
    $src = $in['source'] ?? '';
    if (!in_array($src, ['Customers', 'Leads'], true)) erp_fail('Choose Customers or Leads.');
    if (empty($in['consent'])) erp_fail('Please confirm you have permission to market to these contacts.');
    $wa = !empty($in['wa_verified']) ? 1 : 0;

    if ($src === 'Customers') {
        $sql = "SELECT id, customer_name AS name, email, mobile AS phone, city, state, country FROM customers WHERE 1=1";
        $p = [];
        if (!empty($in['status'])) { $sql .= " AND status = ?"; $p[] = $in['status']; }
        if (!empty($in['city']))   { $sql .= " AND city LIKE ?";  $p[] = '%' . $in['city'] . '%'; }
        $ref = 'customer:';
    } else {
        $sql = "SELECT id, customer_name AS name, email, mobile AS phone, city, state, country FROM leads WHERE 1=1";
        $p = [];
        if (!empty($in['status'])) { $sql .= " AND status = ?"; $p[] = $in['status']; }
        if (!empty($in['city']))   { $sql .= " AND city LIKE ?";  $p[] = '%' . $in['city'] . '%'; }
        $ref = 'lead:';
    }
    $st = $pdo->prepare($sql); $st->execute($p);
    $rows = $st->fetchAll();

    $existing = $pdo->prepare("SELECT email, phone FROM mk_audience_contacts WHERE list_id = ?"); $existing->execute([$list['list_id']]);
    $haveE = []; $haveP = [];
    foreach ($existing->fetchAll() as $x) { if ($x['email']) $haveE[$x['email']] = 1; if ($x['phone']) $haveP[$x['phone']] = 1; }
    $ins = $pdo->prepare("INSERT INTO mk_audience_contacts (list_id, full_name, email, phone, city, state, country, opt_in, opt_in_at, whatsapp_verified, status, source_ref) VALUES (?,?,?,?,?,?,?,1,NOW(),?, 'Active', ?)");
    $n = 0; $dup = 0; $bad = 0;
    $pdo->beginTransaction();
    foreach ($rows as $r) {
        $email = strtolower(trim((string)$r['email'])); if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $email = '';
        $phone = $r['phone'] ? mk_norm_phone($pdo, $r['phone']) : null;
        if ($list['channel'] === 'Email' && $email === '') { $bad++; continue; }
        if (in_array($list['channel'], ['SMS', 'WhatsApp'], true) && !$phone) { $bad++; continue; }
        if ($email === '' && !$phone) { $bad++; continue; }
        if (($email !== '' && isset($haveE[$email])) || ($phone && isset($haveP[$phone]))) { $dup++; continue; }
        $ins->execute([$list['list_id'], $r['name'], $email ?: null, $phone, $r['city'], $r['state'], $r['country'], $wa, $ref . $r['id']]);
        if ($email !== '') $haveE[$email] = 1; if ($phone) $haveP[$phone] = 1;
        $n++;
    }
    if ($list['source'] === 'Manual') $pdo->prepare("UPDATE mk_audience_lists SET source = ? WHERE list_id = ?")->execute([$src, $list['list_id']]);
    $pdo->commit();
    erp_ok(['added' => $n, 'duplicates' => $dup, 'skipped' => $bad], ['message' => "$n contact(s) added from $src ($dup duplicate, $bad without a usable " . strtolower($list['channel']) . ' contact skipped).']);
}
function act_mk_import_performance(PDO $pdo): void {
    [$header, $rows] = mk_read_csv_upload('file');
    foreach (['channel', 'campaign_name'] as $need) if (!in_array($need, $header, true)) erp_fail("The CSV needs a \"$need\" column. Found: " . implode(', ', $header));
    $ins = $pdo->prepare("INSERT INTO mk_performance (channel, campaign_name, period_start, period_end, sent, delivered, opens, clicks, conversions, unsubscribes, bounces, impressions, spend, revenue, data_source) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'CSV Import')");
    $n = 0; $bad = []; $chs = ['email' => 'Email', 'sms' => 'SMS', 'whatsapp' => 'WhatsApp', 'social' => 'Social'];
    $d = fn($v) => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$v) ? $v : null;
    $num = fn($v) => is_numeric(str_replace(',', '', (string)$v)) ? (float)str_replace(',', '', (string)$v) : 0;
    $pdo->beginTransaction();
    foreach ($rows as $i => $r) {
        $ch = $chs[strtolower($r['channel'] ?? '')] ?? null;
        if (!$ch || ($r['campaign_name'] ?? '') === '') { $bad[] = 'Row ' . ($i + 2); continue; }
        $ins->execute([$ch, $r['campaign_name'], $d($r['period_start'] ?? ''), $d($r['period_end'] ?? ''), (int)$num($r['sent'] ?? 0), (int)$num($r['delivered'] ?? 0),
            (int)$num($r['opens'] ?? ($r['reads'] ?? 0)), (int)$num($r['clicks'] ?? 0), (int)$num($r['conversions'] ?? 0), (int)$num($r['unsubscribes'] ?? 0),
            (int)$num($r['bounces'] ?? 0), (int)$num($r['impressions'] ?? 0), $num($r['spend'] ?? 0), $num($r['revenue'] ?? 0)]);
        $n++;
    }
    $pdo->commit();
    erp_ok(['imported' => $n, 'invalid' => count($bad)], ['message' => "$n performance row(s) imported" . ($bad ? ', ' . count($bad) . ' skipped (' . implode(', ', array_slice($bad, 0, 5)) . ')' : '') . '.']);
}

/* ---------------------------------------------------------
   Analytics dashboard
   --------------------------------------------------------- */
function act_mk_analytics(PDO $pdo): void {
    $ch = $_GET['channel'] ?? '';
    $w = in_array($ch, ['Email', 'SMS', 'WhatsApp', 'Social'], true) ? "WHERE channel = " . $pdo->quote($ch) : '';
    $agg = fn($row) => $row + [
        'open_rate' => $row['delivered'] > 0 ? round($row['opens'] / $row['delivered'] * 100, 2) : null,
        'ctr' => ($row['channel'] ?? '') === 'Social' ? ($row['impressions'] > 0 ? round($row['clicks'] / $row['impressions'] * 100, 2) : null) : ($row['delivered'] > 0 ? round($row['clicks'] / $row['delivered'] * 100, 2) : null),
        'cpc' => $row['clicks'] > 0 ? round($row['spend'] / $row['clicks'], 2) : null,
        'roas' => $row['spend'] > 0 ? round($row['revenue'] / $row['spend'], 2) : null,
        'conv_rate' => $row['clicks'] > 0 ? round($row['conversions'] / $row['clicks'] * 100, 2) : null,
    ];
    $by = $pdo->query("SELECT channel, COUNT(*) AS records, SUM(sent) sent, SUM(delivered) delivered, SUM(opens) opens, SUM(clicks) clicks, SUM(conversions) conversions,
        SUM(unsubscribes) unsubscribes, SUM(bounces) bounces, SUM(impressions) impressions, SUM(spend) spend, SUM(revenue) revenue FROM mk_performance $w GROUP BY channel ORDER BY channel")->fetchAll();
    foreach ($by as &$b) { foreach (['sent','delivered','opens','clicks','conversions','unsubscribes','bounces','impressions'] as $k) $b[$k] = (int)$b[$k]; $b['spend'] = (float)$b['spend']; $b['revenue'] = (float)$b['revenue']; $b = $agg($b); }
    unset($b);
    $tot = ['channel' => 'All', 'records' => 0, 'sent' => 0, 'delivered' => 0, 'opens' => 0, 'clicks' => 0, 'conversions' => 0, 'unsubscribes' => 0, 'bounces' => 0, 'impressions' => 0, 'spend' => 0.0, 'revenue' => 0.0];
    foreach ($by as $b) foreach ($tot as $k => $v) if ($k !== 'channel') $tot[$k] += $b[$k];
    $tot = $agg($tot);

    $trend = $pdo->query("SELECT DATE_FORMAT(COALESCE(period_end, DATE(created_at)), '%Y-%m') AS ym, SUM(sent) sent, SUM(clicks) clicks, SUM(conversions) conversions, SUM(spend) spend, SUM(revenue) revenue
        FROM mk_performance $w GROUP BY ym ORDER BY ym DESC LIMIT 12")->fetchAll();
    $top = $pdo->query("SELECT channel, campaign_name, spend, revenue, ROUND(revenue/NULLIF(spend,0),2) AS roas, ROUND(opens/NULLIF(delivered,0)*100,2) AS open_rate, clicks, conversions
        FROM mk_performance $w ORDER BY (revenue/NULLIF(spend,0)) IS NULL, (revenue/NULLIF(spend,0)) DESC, revenue DESC LIMIT 5")->fetchAll();

    $cnt = fn($t) => $pdo->query("SELECT status, COUNT(*) n FROM $t GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);
    $campaigns = ['Email' => $cnt('mk_email_campaigns'), 'SMS' => $cnt('mk_sms_campaigns'), 'WhatsApp' => $cnt('mk_whatsapp_campaigns'), 'Social' => $cnt('mk_social_campaigns')];
    $ab = $pdo->query("SELECT COUNT(*) total, SUM(status='Completed') done FROM mk_ab_tests")->fetch();
    $audience = $pdo->query("SELECT (SELECT COUNT(*) FROM mk_audience_contacts WHERE status='Active' AND opt_in=1) AS reachable, (SELECT COUNT(*) FROM mk_suppression) AS suppressed, (SELECT COUNT(*) FROM mk_utm_links) AS utm_links")->fetch();
    erp_ok(['by_channel' => $by, 'totals' => $tot, 'trend' => array_reverse($trend), 'top' => $top, 'campaigns' => $campaigns, 'ab' => $ab, 'audience' => $audience]);
}
