<?php
/**
 * Lead Follow-up API
 * --------------------------------------------------------
 * GET  /api/lead_followups.php?action=list&lead_id=5      -> history for one lead
 * GET  /api/lead_followups.php?action=due                 -> all follow-ups due today/overdue, across leads
 * POST /api/lead_followups.php   action=create (JSON body: leadId, followupDate, followupTime,
 *                                 nextFollowupDate, executive, discussion, customerFeedback,
 *                                 status, reminderChannels: ["SMS","WhatsApp",...])
 * POST /api/lead_followups.php   action=delete&id=5
 * --------------------------------------------------------
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_REQUEST['action'] ?? ($method === 'GET' ? 'list' : '');

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

if ($method === 'GET' && $action === 'list') {
    $leadId = (int) ($_GET['lead_id'] ?? 0);
    if (!$leadId) respond(["success" => false, "message" => "Missing lead_id."], 422);
    $stmt = $pdo->prepare("SELECT * FROM lead_followups WHERE lead_id = ? ORDER BY id DESC");
    $stmt->execute([$leadId]);
    respond(["success" => true, "data" => $stmt->fetchAll()]);
}

if ($method === 'GET' && $action === 'due') {
    $sql = "SELECT l.id, l.lead_code, l.customer_name, l.mobile, l.sales_executive, l.priority, l.next_followup_date, l.status
            FROM leads l
            WHERE l.next_followup_date IS NOT NULL AND l.next_followup_date <= CURDATE()
              AND l.status NOT IN ('Lost','Converted','Closed')
            ORDER BY l.next_followup_date ASC";
    respond(["success" => true, "data" => $pdo->query($sql)->fetchAll()]);
}

if ($method === 'POST' && $action === 'create') {
    $body = json_decode(file_get_contents('php://input'), true) ?? [];
    $leadId = (int) ($body['leadId'] ?? 0);
    if (!$leadId) respond(["success" => false, "message" => "Missing lead."], 422);
    if (empty($body['followupDate'])) respond(["success" => false, "message" => "Follow-up date is required."], 422);

    $channels = isset($body['reminderChannels']) && is_array($body['reminderChannels'])
        ? implode(',', $body['reminderChannels']) : null;

    $stmt = $pdo->prepare("INSERT INTO lead_followups
        (lead_id, followup_date, followup_time, next_followup_date, executive, discussion, customer_feedback, status, reminder_channels)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $leadId,
        $body['followupDate'],
        $body['followupTime'] ?: null,
        $body['nextFollowupDate'] ?: null,
        $body['executive'] ?? ($_SESSION['user_name'] ?? null),
        $body['discussion'] ?? null,
        $body['customerFeedback'] ?? null,
        $body['status'] ?? 'Call Later',
        $channels,
    ]);

    // Keep the lead record itself in sync: bump its next follow-up date,
    // and if the follow-up outcome implies a pipeline stage, move it there.
    $statusMap = [
        'Interested'        => 'Interested',
        'Test Drive'        => 'Test Drive',
        'Finance Required'  => 'Finance',
        'Booking Expected'  => 'Quotation Sent',
        'Not Interested'    => 'Lost',
        'Lost'              => 'Lost',
    ];
    $updates = ['next_followup_date = ?'];
    $vals = [$body['nextFollowupDate'] ?: null];
    if (isset($statusMap[$body['status'] ?? ''])) {
        $updates[] = 'status = ?';
        $vals[] = $statusMap[$body['status']];
    }
    $vals[] = $leadId;
    $pdo->prepare("UPDATE leads SET " . implode(', ', $updates) . " WHERE id = ?")->execute($vals);

    respond(["success" => true, "message" => "Follow-up saved."]);
}

if ($method === 'POST' && $action === 'delete') {
    $id = (int) ($_GET['id'] ?? $_REQUEST['id'] ?? 0);
    if (!$id) respond(["success" => false, "message" => "Missing id."], 422);
    $pdo->prepare("DELETE FROM lead_followups WHERE id = ?")->execute([$id]);
    respond(["success" => true, "message" => "Follow-up removed."]);
}

respond(["success" => false, "message" => "Unknown action."], 400);
