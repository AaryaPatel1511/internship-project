<?php
/**
 * Include this at the very top of any API file that should only
 * be reachable by a logged-in user (e.g. customers.php).
 */
session_start();

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    header('Content-Type: application/json');
    echo json_encode(["success" => false, "message" => "Not authenticated. Please log in again."]);
    exit;
}
