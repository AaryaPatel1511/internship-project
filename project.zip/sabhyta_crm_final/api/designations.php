<?php
/**
 * Designations REST API (HRMS > Designation)
 * --------------------------------------------------------
 * GET    /api/designations.php             -> list all
 * GET    /api/designations.php?id=5        -> get one
 * POST   /api/designations.php             -> create
 * POST   /api/designations.php (id + _method=PUT) -> update
 * DELETE /api/designations.php?id=5        -> delete
 * --------------------------------------------------------
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

$FIELDS = [
    'designation_name'     => 'designationName',
    'department_id'        => 'departmentId',
    'reporting_manager_id' => 'reportingManagerId',
    'salary_grade'          => 'salaryGrade',
    'job_description'       => 'jobDescription',
    'responsibilities'      => 'responsibilities',
    'status'                => 'status',
];

if ($method === 'GET') {
    if (!empty($_GET['id'])) {
        $stmt = $pdo->prepare("SELECT * FROM designations WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        $row = $stmt->fetch();
        if (!$row) respond(["success" => false, "message" => "Designation not found"], 404);
        respond(["success" => true, "data" => $row]);
    }
    $stmt = $pdo->query("SELECT de.*, d.department_name,
                                 CONCAT(e.first_name, ' ', COALESCE(e.last_name,'')) AS reporting_manager_name
                          FROM designations de
                          LEFT JOIN departments d ON d.id = de.department_id
                          LEFT JOIN employees e ON e.id = de.reporting_manager_id
                          ORDER BY de.created_at DESC");
    respond(["success" => true, "data" => $stmt->fetchAll()]);
}

if ($method === 'POST') {
    $isUpdate = !empty($_POST['id']) && (($_POST['_method'] ?? '') === 'PUT');

    if (empty($_POST['designationName'])) {
        respond(["success" => false, "message" => "Missing required field: designationName"], 422);
    }

    $data = [];
    foreach ($FIELDS as $col => $formName) {
        $data[$col] = $_POST[$formName] ?? null;
        if ($data[$col] === '') $data[$col] = null;
    }

    try {
        if ($isUpdate) {
            $id = $_POST['id'];
            $setSql = implode(', ', array_map(fn($c) => "$c = :$c", array_keys($data)));
            $stmt = $pdo->prepare("UPDATE designations SET $setSql WHERE id = :id");
            $data['id'] = $id;
            $stmt->execute($data);
            respond(["success" => true, "message" => "Designation updated", "id" => $id]);
        } else {
            $cols = implode(', ', array_keys($data));
            $placeholders = implode(', ', array_map(fn($c) => ":$c", array_keys($data)));
            $stmt = $pdo->prepare("INSERT INTO designations ($cols) VALUES ($placeholders)");
            $stmt->execute($data);
            respond(["success" => true, "message" => "Designation created", "id" => $pdo->lastInsertId()], 201);
        }
    } catch (PDOException $e) {
        respond(["success" => false, "message" => "Database error: " . $e->getMessage()], 400);
    }
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? null;
    if (!$id) respond(["success" => false, "message" => "Missing id"], 422);
    $stmt = $pdo->prepare("DELETE FROM designations WHERE id = ?");
    $stmt->execute([$id]);
    respond(["success" => true, "message" => "Designation deleted"]);
}

respond(["success" => false, "message" => "Method not allowed"], 405);
