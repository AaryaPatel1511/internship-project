<?php
/**
 * Helpdesk Module REST API
 * --------------------------------------------------------
 * One file, one URL, every Helpdesk sidebar leaf — same shape
 * as api/leads.php so it's easy to recognise/maintain.
 *
 * GET  /api/helpdesk.php?action=<entity>_list&...filters
 * GET  /api/helpdesk.php?action=<entity>_get&id=5
 * POST /api/helpdesk.php   action=<entity>_create   (JSON body)
 * POST /api/helpdesk.php   action=<entity>_update&id=5  (JSON body)
 * POST /api/helpdesk.php   action=<entity>_delete&id=5
 * GET  /api/helpdesk.php?action=dashboard   -> KPI cards for the
 *      Tickets landing page (open/in-progress/resolved/breached)
 *
 * <entity> is one of:
 *   tickets | complaints | support | amc | remote | priorities | sla | resolutions
 * --------------------------------------------------------
 */

header('Content-Type: application/json');
require_once 'session_guard.php';
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_REQUEST['action'] ?? '';

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function bodyJson() {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

/** Zero-padded running number like TKT-2026-00001 */
function nextCode(PDO $pdo, string $table, string $codeCol, string $prefix): string {
    $year = date('Y');
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$table} WHERE {$codeCol} LIKE ?");
    $stmt->execute(["{$prefix}-{$year}-%"]);
    $n = (int) $stmt->fetchColumn() + 1;
    return sprintf('%s-%s-%05d', $prefix, $year, $n);
}

// =========================================================
// Entity registry — table name, code column/prefix, and the
// full editable column list per entity. Adding a column here
// is the only step needed to expose it through the API.
// =========================================================
const ENTITIES = [
    'tickets' => [
        'table'  => 'helpdesk_tickets',
        'code'   => ['col' => 'ticket_no', 'prefix' => 'TKT'],
        'fields' => ['customer_id','customer_name','contact_person','contact_number','email',
            'product_service','category','subject','description','attachment_path','source',
            'priority_id','assigned_department','assigned_employee','amc_id','sla_id',
            'ticket_status','due_at','resolved_at','closed_at','resolution','customer_feedback'],
    ],
    'complaints' => [
        'table'  => 'helpdesk_complaints',
        'code'   => ['col' => 'complaint_no', 'prefix' => 'CMP'],
        'fields' => ['customer_id','customer_name','contact_person','complaint_date','complaint_type',
            'subject','description','related_ticket_id','product_service','complaint_source',
            'priority_id','assigned_employee','department','expected_resolution_date',
            'complaint_status','escalation_level','resolution','customer_remarks',
            'attachment_path','created_by','closed_at'],
    ],
    'support' => [
        'table'  => 'helpdesk_support_activities',
        'code'   => ['col' => 'support_no', 'prefix' => 'SUP'],
        'fields' => ['ticket_id','customer_name','assigned_employee','support_type','start_time',
            'end_time','work_description','time_spent_minutes','action_taken','parts_used',
            'internal_remarks','customer_remarks','attachment_path','next_followup_date','support_status'],
    ],
    'amc' => [
        'table'  => 'helpdesk_amc_contracts',
        'code'   => ['col' => 'amc_code', 'prefix' => 'AMC'],
        'fields' => ['customer_id','customer_name','contract_no','start_date','end_date','amc_value',
            'billing_frequency','service_type','covered_products','support_hours','visit_included',
            'remote_support','onsite_support','number_of_visits','sla_id','assigned_team',
            'contract_status','renewal_date'],
    ],
    'remote' => [
        'table'  => 'helpdesk_remote_sessions',
        'code'   => ['col' => 'session_no', 'prefix' => 'RS'],
        'fields' => ['ticket_id','customer_name','contact_person','support_engineer','remote_tool',
            'start_time','end_time','duration_minutes','customer_permission','problem_description',
            'action_taken','files_transferred','attachment_path','resolution',
            'customer_confirmation','session_status'],
    ],
    'priorities' => [
        'table'  => 'helpdesk_priorities',
        'code'   => null,
        'fields' => ['name','response_minutes','resolution_minutes','color','sort_order','status'],
    ],
    'sla' => [
        'table'  => 'helpdesk_sla',
        'code'   => ['col' => 'sla_code', 'prefix' => 'SLA'],
        'fields' => ['sla_name','customer_type','priority_id','response_minutes','resolution_minutes',
            'working_hours','working_days','escalation_level1','escalation_level2',
            'escalation_level3','status'],
    ],
    'resolutions' => [
        'table'  => 'helpdesk_resolutions',
        'code'   => ['col' => 'resolution_no', 'prefix' => 'RES'],
        'fields' => ['ticket_id','customer_name','problem_summary','root_cause','troubleshooting',
            'action_taken','final_solution','technician','start_time','end_time',
            'total_time_minutes','parts_used','attachment_path','kb_article',
            'customer_confirmation','customer_rating','resolution_date','closed_by'],
    ],
];

if (!$action) respond(['success' => false, 'message' => 'Missing action'], 400);

if ($action === 'dashboard') dashboardStats($pdo); // exits via respond()

// action = "<entity>_<op>"
if (!preg_match('/^([a-z]+)_(list|get|create|update|delete)$/', $action, $m)) {
    respond(['success' => false, 'message' => 'Unknown action'], 400);
}
[, $entity, $op] = $m;
if (!isset(ENTITIES[$entity])) respond(['success' => false, 'message' => "Unknown entity: $entity"], 400);
$cfg = ENTITIES[$entity];

switch ($op) {
    case 'list':   listEntity($pdo, $entity, $cfg); break;
    case 'get':    getEntity($pdo, $cfg); break;
    case 'create': createEntity($pdo, $entity, $cfg); break;
    case 'update': updateEntity($pdo, $cfg); break;
    case 'delete': deleteEntity($pdo, $cfg); break;
}

// =========================================================
// Handlers
// =========================================================

function listEntity(PDO $pdo, string $entity, array $cfg) {
    $table = $cfg['table'];
    $where = [];
    $params = [];

    if (!empty($_GET['status'])) {
        $col = $entity === 'tickets' ? 'ticket_status' : ($entity === 'complaints' ? 'complaint_status' : 'status');
        if (in_array($col, array_merge($cfg['fields'], ['status'])) || $col === 'ticket_status' || $col === 'complaint_status') {
            $where[] = "$col = ?";
            $params[] = $_GET['status'];
        }
    }
    if (!empty($_GET['q'])) {
        $where[] = "(customer_name LIKE ? OR subject LIKE ?)";
        $params[] = '%' . $_GET['q'] . '%';
        $params[] = '%' . $_GET['q'] . '%';
    }
    if (!empty($_GET['ticket_id']) && in_array('ticket_id', $cfg['fields'])) {
        $where[] = "ticket_id = ?";
        $params[] = $_GET['ticket_id'];
    }

    $sql = "SELECT * FROM " . ($entity === 'tickets' ? 'v_helpdesk_tickets' : $table);
    if ($where) $sql .= " WHERE " . implode(' AND ', $where);
    $sql .= " ORDER BY id DESC LIMIT 500";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    // AMC: attach a computed alert level (90/60/30/expired) dynamically.
    if ($entity === 'amc') {
        foreach ($rows as &$r) {
            $days = (strtotime($r['end_date']) - strtotime(date('Y-m-d'))) / 86400;
            $r['days_to_expiry'] = (int) $days;
            $r['alert'] = $days < 0 ? 'Expired' : ($days <= 30 ? 'Expiring in 30 days'
                : ($days <= 60 ? 'Expiring in 60 days' : ($days <= 90 ? 'Expiring in 90 days' : 'OK')));
        }
        unset($r);
    }

    respond(['success' => true, 'data' => $rows]);
}

function getEntity(PDO $pdo, array $cfg) {
    $id = (int) ($_GET['id'] ?? 0);
    $stmt = $pdo->prepare("SELECT * FROM {$cfg['table']} WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) respond(['success' => false, 'message' => 'Not found'], 404);
    respond(['success' => true, 'data' => $row]);
}

function createEntity(PDO $pdo, string $entity, array $cfg) {
    $body = bodyJson();
    $cols = [];
    $vals = [];
    $ph   = [];

    if ($cfg['code']) {
        $cols[] = $cfg['code']['col'];
        $vals[] = nextCode($pdo, $cfg['table'], $cfg['code']['col'], $cfg['code']['prefix']);
        $ph[] = '?';
    }
    foreach ($cfg['fields'] as $f) {
        if (array_key_exists($f, $body)) {
            $cols[] = $f;
            $vals[] = $body[$f] === '' ? null : $body[$f];
            $ph[] = '?';
        }
    }

    // ---- Ticket-specific: auto SLA due date + AMC coverage check ----
    if ($entity === 'tickets') {
        $priorityId = $body['priority_id'] ?? null;
        $slaId = $body['sla_id'] ?? null;
        $resolutionMinutes = 1440;
        if ($slaId) {
            $s = $pdo->prepare("SELECT resolution_minutes FROM helpdesk_sla WHERE id = ?");
            $s->execute([$slaId]);
            if ($v = $s->fetchColumn()) $resolutionMinutes = (int) $v;
        } elseif ($priorityId) {
            $s = $pdo->prepare("SELECT resolution_minutes FROM helpdesk_priorities WHERE id = ?");
            $s->execute([$priorityId]);
            if ($v = $s->fetchColumn()) $resolutionMinutes = (int) $v;
        }
        if (!in_array('due_at', $cols)) {
            $cols[] = 'due_at';
            $vals[] = date('Y-m-d H:i:s', strtotime("+{$resolutionMinutes} minutes"));
            $ph[] = '?';
        }
        // If AMC linked, auto-check it's still active; otherwise leave amc_id null (paid support).
        if (!empty($body['amc_id'])) {
            $a = $pdo->prepare("SELECT contract_status, end_date FROM helpdesk_amc_contracts WHERE id = ?");
            $a->execute([$body['amc_id']]);
            $amc = $a->fetch();
            if (!$amc || $amc['contract_status'] !== 'Active' || strtotime($amc['end_date']) < time()) {
                // AMC not active/expired -> don't attach it, ticket becomes paid support
                $idx = array_search('amc_id', $cols);
                if ($idx !== false) { unset($cols[$idx], $vals[$idx], $ph[$idx]); $cols = array_values($cols); $vals = array_values($vals); $ph = array_values($ph); }
            }
        }
    }

    if (!$cols) respond(['success' => false, 'message' => 'No fields to save'], 400);

    $sql = "INSERT INTO {$cfg['table']} (" . implode(',', $cols) . ") VALUES (" . implode(',', $ph) . ")";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($vals);
    $newId = (int) $pdo->lastInsertId();

    // ---- Resolution-specific: mark linked ticket Resolved ----
    if ($entity === 'resolutions' && !empty($body['ticket_id'])) {
        $pdo->prepare("UPDATE helpdesk_tickets SET ticket_status='Resolved', resolved_at=NOW(), resolution=? WHERE id=?")
            ->execute([$body['final_solution'] ?? null, $body['ticket_id']]);
    }
    // ---- Complaint-specific: if no related ticket given, nothing further ----

    $get = $pdo->prepare("SELECT * FROM {$cfg['table']} WHERE id = ?");
    $get->execute([$newId]);
    respond(['success' => true, 'data' => $get->fetch()]);
}

function updateEntity(PDO $pdo, array $cfg) {
    $id = (int) ($_GET['id'] ?? 0);
    if (!$id) respond(['success' => false, 'message' => 'Missing id'], 400);
    $body = bodyJson();

    $sets = [];
    $vals = [];
    foreach ($cfg['fields'] as $f) {
        if (array_key_exists($f, $body)) {
            $sets[] = "$f = ?";
            $vals[] = $body[$f] === '' ? null : $body[$f];
        }
    }
    if (!$sets) respond(['success' => false, 'message' => 'No fields to update'], 400);
    $vals[] = $id;

    $sql = "UPDATE {$cfg['table']} SET " . implode(',', $sets) . " WHERE id = ?";
    $pdo->prepare($sql)->execute($vals);

    // Auto-stamp closed_at when a ticket/complaint status flips to Closed.
    if (isset($body['ticket_status']) && $body['ticket_status'] === 'Closed') {
        $pdo->prepare("UPDATE helpdesk_tickets SET closed_at = NOW() WHERE id = ? AND closed_at IS NULL")->execute([$id]);
    }
    if (isset($body['complaint_status']) && $body['complaint_status'] === 'Closed') {
        $pdo->prepare("UPDATE helpdesk_complaints SET closed_at = NOW() WHERE id = ? AND closed_at IS NULL")->execute([$id]);
    }

    $get = $pdo->prepare("SELECT * FROM {$cfg['table']} WHERE id = ?");
    $get->execute([$id]);
    respond(['success' => true, 'data' => $get->fetch()]);
}

function deleteEntity(PDO $pdo, array $cfg) {
    $id = (int) ($_GET['id'] ?? $_REQUEST['id'] ?? 0);
    if (!$id) respond(['success' => false, 'message' => 'Missing id'], 400);
    $pdo->prepare("DELETE FROM {$cfg['table']} WHERE id = ?")->execute([$id]);
    respond(['success' => true]);
}

function dashboardStats(PDO $pdo) {
    $open        = (int) $pdo->query("SELECT COUNT(*) FROM helpdesk_tickets WHERE ticket_status NOT IN ('Resolved','Closed')")->fetchColumn();
    $inProgress  = (int) $pdo->query("SELECT COUNT(*) FROM helpdesk_tickets WHERE ticket_status = 'In Progress'")->fetchColumn();
    $resolved    = (int) $pdo->query("SELECT COUNT(*) FROM helpdesk_tickets WHERE ticket_status IN ('Resolved','Closed')")->fetchColumn();
    $breached    = (int) $pdo->query("SELECT COUNT(*) FROM helpdesk_tickets WHERE ticket_status NOT IN ('Resolved','Closed') AND due_at IS NOT NULL AND due_at < NOW()")->fetchColumn();
    $amcExpiring = (int) $pdo->query("SELECT COUNT(*) FROM helpdesk_amc_contracts WHERE contract_status='Active' AND DATEDIFF(end_date, CURDATE()) BETWEEN 0 AND 90")->fetchColumn();
    $total       = (int) $pdo->query("SELECT COUNT(*) FROM helpdesk_tickets")->fetchColumn();

    respond(['success' => true, 'data' => [
        'total_tickets'   => $total,
        'open_tickets'    => $open,
        'in_progress'     => $inProgress,
        'resolved'        => $resolved,
        'sla_breached'    => $breached,
        'amc_expiring'    => $amcExpiring,
    ]]);
}
